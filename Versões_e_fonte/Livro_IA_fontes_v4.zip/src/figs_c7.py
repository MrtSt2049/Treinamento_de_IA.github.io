"""Figuras do Capítulo 7 (SVG), com valores calculados ou lidos das saídas reais dos programas."""
import re
import numpy as np
from figs_c6 import painel, curva, legenda, salvar, fmt  # noqa: F401  (reaproveita os auxiliares; executa figs_c6 uma vez)

SEL = 'style="fill:none;stroke:var(--violeta);stroke-width:3"'


def grade(x0, y0, M, cel, fonte=13, destaque=None, heat=None, marcar=None):
    """Desenha uma matriz como grade de células. heat=(vmax) colore por sinal; destaque=(i,j,h,w) contorna."""
    out = []
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M[i, j]
            x, y = x0 + j * cel, y0 + i * cel
            if heat:
                cor = "var(--violeta)" if v > 0 else "var(--rubi)"
                op = min(1, abs(v) / heat) * 0.85
                out.append(f'<rect x="{x}" y="{y}" width="{cel}" height="{cel}" style="fill:{cor};fill-opacity:{op:.2f};stroke:var(--linha)"/>')
            else:
                out.append(f'<rect x="{x}" y="{y}" width="{cel}" height="{cel}" style="fill:var(--papel-2);stroke:var(--linha)"/>')
            txt = f"{int(v)}" if float(v).is_integer() else f"{v:.1f}"
            out.append(f'<text x="{x+cel/2}" y="{y+cel/2+4.5}" font-size="{fonte}" text-anchor="middle">{txt}</text>')
    if destaque:
        i, j, h, w = destaque
        out.append(f'<rect x="{x0+j*cel}" y="{y0+i*cel}" width="{w*cel}" height="{h*cel}" rx="3" {SEL}/>')
    return out


def corr(x, k):
    kh, kw = k.shape
    return np.array([[(x[i:i + kh, j:j + kw] * k).sum() for j in range(x.shape[1] - kw + 1)] for i in range(x.shape[0] - kh + 1)])


# ---------- Figura 7.1: a janela deslizante ----------
X = np.array([[1, 2, 0, 1, 3], [0, 1, 3, 1, 0], [2, 1, 0, 2, 1], [1, 0, 1, 3, 2], [0, 2, 1, 0, 1]], dtype=float)
K = np.array([[1, 0, -1], [0, 1, 0], [-1, 0, 1]], dtype=float)
Y = corr(X, K)
c = ['<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker></defs>']
c.append('<text x="95" y="24" font-size="14" text-anchor="middle" font-weight="700">entrada x (5×5)</text>')
c += grade(20, 36, X, 38, destaque=(1, 1, 3, 3))
c.append('<text x="345" y="24" font-size="14" text-anchor="middle" font-weight="700">filtro k (3×3)</text>')
c += grade(285, 36, K, 38, heat=1.0)
c.append('<text x="565" y="24" font-size="14" text-anchor="middle" font-weight="700">mapa y (3×3)</text>')
c += grade(505, 36, Y, 38, destaque=(1, 1, 1, 1))
c.append('<line class="seta" x1="215" y1="112" x2="278" y2="112"/><line class="seta" x1="405" y1="112" x2="498" y2="112"/>')
c.append('<text x="247" y="104" font-size="12" text-anchor="middle" class="t2">⊙</text><text x="452" y="104" font-size="12" text-anchor="middle" class="t2">soma</text>')
c.append('<text x="320" y="262" font-size="13" text-anchor="middle">y[1,1] = soma dos produtos elemento a elemento entre a janela destacada e o filtro = ' + f"{int(Y[1,1])}" + '</text>')
salvar("fig_c7_janela.svg", 640, 280, "Uma convolução: a janela 3 por 3 da entrada é multiplicada elemento a elemento pelo filtro e somada, produzindo um valor do mapa de características", c)

# ---------- Figura 7.2: Sobel em um quadrado (mesmo cálculo do programa c7_convolucao.py) ----------
img = np.zeros((8, 8)); img[2:6, 2:6] = 1.0
sobel = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=float)
mapa = corr(np.pad(img, 1), sobel)
c = []
c.append('<text x="100" y="22" font-size="14" text-anchor="middle" font-weight="700">imagem</text>')
c += grade(20, 32, img, 20, fonte=10)
c.append('<text x="305" y="22" font-size="14" text-anchor="middle" font-weight="700">filtro (Sobel vertical)</text>')
c += grade(260, 32, sobel, 30, fonte=12, heat=2)
c.append('<text x="530" y="22" font-size="14" text-anchor="middle" font-weight="700">mapa de características</text>')
c += grade(450, 32, mapa, 20, fonte=10, heat=4)
c.append('<text x="320" y="222" font-size="12" text-anchor="middle" class="t2">violeta: resposta positiva · vermelho: negativa</text>')
salvar("fig_c7_mapa.svg", 640, 240, "Imagem de um quadrado, filtro de Sobel vertical e o mapa de características resultante, positivo na borda esquerda e negativo na direita", c)

# ---------- Figura 7.3: bloco residual ----------
c = ['<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker></defs>']
c.append('<text x="40" y="160" font-size="14" text-anchor="middle">x</text>')
c.append('<line class="seta" x1="55" y1="156" x2="105" y2="156"/>')
for xx, tt in ((110, "Conv 3×3"), (230, "BatchNorm\n+ ReLU"), (350, "Conv 3×3")):
    lin = tt.split("\n")
    c.append(f'<rect class="cx" x="{xx}" y="132" width="100" height="48" rx="8"/>')
    if len(lin) == 1:
        c.append(f'<text x="{xx+50}" y="161" font-size="13" text-anchor="middle">{lin[0]}</text>')
    else:
        c.append(f'<text x="{xx+50}" y="154" font-size="13" text-anchor="middle">{lin[0]}</text><text x="{xx+50}" y="171" font-size="13" text-anchor="middle">{lin[1]}</text>')
c.append('<line class="seta" x1="210" y1="156" x2="228" y2="156"/><line class="seta" x1="330" y1="156" x2="348" y2="156"/><line class="seta" x1="450" y1="156" x2="498" y2="156"/>')
c.append('<text x="475" y="146" font-size="12" class="t2" text-anchor="middle">F(x)</text>')
c.append('<circle cx="515" cy="156" r="16" class="cxa"/><text x="515" y="162" font-size="18" text-anchor="middle">+</text>')
c.append('<line class="seta" x1="531" y1="156" x2="580" y2="156"/><rect class="cx" x="582" y="140" width="52" height="32" rx="6"/><text x="608" y="161" font-size="13" text-anchor="middle">ReLU</text>')
c.append('<path class="seta" d="M78,156 L78,70 L515,70 L515,138"/>')
c.append('<text x="300" y="60" font-size="13" text-anchor="middle" style="fill:var(--azul)">conexão de atalho (identidade): x</text>')
c.append('<text x="320" y="215" font-size="13" text-anchor="middle">saída: ReLU(x + F(x))   ·   gradiente: ∂/∂x [x + F(x)] = I + ∂F/∂x</text>')
salvar("fig_c7_residual.svg", 650, 235, "Bloco residual: a entrada x segue por um atalho de identidade e é somada à saída de duas convoluções", c)

# ---------- Figura 7.4: arquitetura da CNN do Projeto 5 ----------
c = ['<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker></defs>']
blocos = [("imagem", "1×8×8", 18), ("Conv 3×3, 8 + ReLU", "8×8×8", 128), ("MaxPool 2", "8×4×4", 238), ("Conv 3×3, 16 + ReLU", "16×4×4", 348), ("MaxPool 2", "16×2×2", 458), ("Linear 64→10", "10", 568)]
for i, (t, f, xx) in enumerate(blocos):
    cls = "cxa" if i == len(blocos) - 1 else "cx"
    w = 92
    c.append(f'<rect class="{cls}" x="{xx}" y="40" width="{w}" height="58" rx="8"/>')
    if " + " in t:
        a, b = t.split(" + ")
        c.append(f'<text x="{xx+w/2}" y="62" font-size="12" text-anchor="middle">{a}</text><text x="{xx+w/2}" y="78" font-size="12" text-anchor="middle">+ {b}</text>')
    else:
        c.append(f'<text x="{xx+w/2}" y="72" font-size="12" text-anchor="middle">{t}</text>')
    c.append(f'<text x="{xx+w/2}" y="136" font-size="12" text-anchor="middle" class="t2">{f}</text>')
    if i:
        c.append(f'<line class="seta" x1="{xx-16}" y1="69" x2="{xx-1}" y2="69"/>')
c.append('<rect x="120" y="22" width="436" height="92" rx="10" style="fill:none;stroke:var(--violeta);stroke-dasharray:5 3"/><text x="338" y="16" font-size="12" text-anchor="middle" style="fill:var(--violeta)">extrator de características (1 248 parâmetros)</text>')
c.append('<text x="614" y="16" font-size="12" text-anchor="middle" style="fill:var(--azul)">cabeça (650)</text>')
salvar("fig_c7_arquitetura.svg", 690, 150, "Arquitetura da CNN do Projeto 5: duas convoluções com pooling, e uma camada linear", c)

# ---------- Figura 7.5: transferência (lê as médias de projeto5.out) ----------
txt = open("codigo/projeto5.out").read()
tabela = {}
for bloco in re.split(r"\n(?=\d+ exemplos rotulados no alvo)", txt.split("Parte B")[1]):
    m = re.match(r"(\d+) exemplos rotulados", bloco)
    if not m:
        continue
    n = int(m.group(1))
    for nome, med, dp in re.findall(r"^\s+(.+?)\s+([0-9.]+) ± ([0-9.]+)$", bloco, re.M):
        tabela.setdefault(nome, {})[n] = (float(med), float(dp))
ordem = [("do zero", "lv", None), ("extração (aleatório)", "lr", "6 3"), ("extração (pré-treinado)", "lm", None), ("ajuste fino η=1e-03", "lg", "6 3"), ("ajuste fino η=3e-03", "la", None)]
c = []
s, X, Y = painel(70, 20, 520, 240, 10, 115, 0.7, 1.0, [25, 50, 100], [0.7, 0.8, 0.9, 1.0], "exemplos rotulados no alvo", "acurácia no teste")
c += s
for nome, cls, dash in ordem:
    ns = sorted(tabela[nome])
    c.append(curva(X, Y, ns, [tabela[nome][n][0] for n in ns], cls, dash))
    for n in ns:
        mu, dp = tabela[nome][n]
        c.append(f'<line class="{cls}" x1="{fmt(X(n))}" y1="{fmt(Y(mu-dp))}" x2="{fmt(X(n))}" y2="{fmt(Y(mu+dp))}" style="stroke-width:1.2"/>')
c += legenda([(cls, nome, d) for nome, cls, d in ordem[:3]], 40, 318, 210)
c += legenda([(cls, nome, d) for nome, cls, d in ordem[3:]], 40, 340, 210)
salvar("fig_c7_transfer.svg", 640, 360, "Acurácia no teste, no problema alvo, em função do número de exemplos rotulados, para cinco estratégias", c)
print("ok", {k: v for k, v in tabela.items()}.keys())
