<div class="objetivos">

Objetivos do capítulo

- Formular o aprendizado como um problema estatístico: estimar uma função desconhecida a partir de dados ruidosos.
- Separar o erro de previsão em parte redutível e parte irredutível, e explicar por que a segunda é um limite.
- Distinguir regressão de classificação e caracterizar o melhor preditor possível em cada caso.
- Descrever o aprendizado não supervisionado e derivar seus dois métodos básicos: componentes principais e k-médias.
- Enunciar o problema do aprendizado por reforço: recompensas, retorno e decisões sequenciais.

**Pré-requisitos:** Capítulo 1 (seções 1.6, 1.12 a 1.14) e Capítulo 2 (seções 2.5 a 2.7).

</div>

## 3.1 Do agente ao aprendizado

O Capítulo 2 terminou com uma constatação: escrever à mão o programa de um agente só é viável em ambientes muito simples. Ninguém sabe escrever as regras que reconhecem um tumor em uma imagem ou que estimam o risco de um cliente cancelar um serviço. O que existe, nesses casos, são **exemplos**: imagens já diagnosticadas, clientes cujo desfecho se conhece.

O Aprendizado de Máquina (*Machine Learning*, ML) substitui a escrita do programa pela sua estimação a partir de exemplos. Este capítulo formula o problema com precisão. A formulação é necessária porque determina o que é possível esperar: mostra que existe um limite de acerto que nenhum método ultrapassa, diz qual seria o preditor ideal se a distribuição dos dados fosse conhecida e fornece o critério pelo qual todos os métodos dos próximos capítulos serão julgados.

Três paradigmas organizam a área, conforme o tipo de informação disponível.

| Paradigma | O que os dados contêm | Pergunta típica |
|---|---|---|
| Supervisionado | Entradas e respostas corretas | Qual é a resposta para uma nova entrada? |
| Não supervisionado | Apenas entradas | Que estrutura existe nestes dados? |
| Por reforço | Recompensas obtidas por ações | Como agir para acumular mais recompensa? |

## 3.2 Formulação estatística do aprendizado supervisionado

### Variáveis preditoras e resposta

Dispõe-se de $n$ observações. Em cada uma, medem-se $d$ **variáveis preditoras**, reunidas no vetor $X = (X_1,\dots,X_d)$, e uma **resposta** $Y$. As preditoras também são chamadas de entradas, características (*features*) ou variáveis independentes; a resposta, de saída, alvo (*target*) ou variável dependente.

::: definicao 3.1 · Modelo estatístico do aprendizado supervisionado
Supõe-se que a resposta se relaciona com as preditoras por

$$
Y = f(X)+\varepsilon ,
$$

em que $f$ é uma função fixa e **desconhecida** e $\varepsilon$ é um termo de erro aleatório, com $\mathbb{E}[\varepsilon] = 0$ e independente de $X$.
:::

A função $f$ representa a informação **sistemática** que $X$ fornece sobre $Y$. O termo $\varepsilon$ reúne tudo o que afeta $Y$ e não está em $X$: variáveis não medidas, erros de medição, variação intrínseca do fenômeno. A hipótese $\mathbb{E}[\varepsilon]=0$ não é restritiva: qualquer média não nula pode ser absorvida em $f$. Já a independência entre $\varepsilon$ e $X$ é uma **hipótese estatística** simplificadora, que será relaxada quando necessário.

Aprender, nesse quadro, é construir uma estimativa $\hat f$ de $f$ a partir do **conjunto de treinamento** $\{(x_1,y_1),\dots,(x_n,y_n)\}$.

### Dois propósitos: previsão e inferência

Estima-se $f$ por duas razões diferentes, e a razão orienta a escolha do método.

**Previsão.** Quer-se $\hat Y = \hat f(X)$ próximo de $Y$ para entradas novas. A forma de $\hat f$ é secundária: ela pode ser tratada como uma caixa opaca, desde que preveja bem.

**Inferência.** Quer-se entender a relação: quais preditoras se associam à resposta, em que direção e com que intensidade. Aqui a forma de $\hat f$ é o próprio resultado, e modelos simples e interpretáveis têm vantagem.

Um banco que decide conceder crédito quer previsão. Um epidemiologista que estuda fatores de risco quer inferência. Este livro concentra-se na previsão, que é o que os sistemas dos módulos seguintes fazem, mas o Capítulo 4 trata da leitura inferencial dos coeficientes, porque ela é indispensável para interpretar modelos.

## 3.3 Erro redutível e erro irredutível

### O resultado

Suponha, por um momento, $\hat f$ e $X$ fixos. Quanto erra a previsão $\hat Y = \hat f(X)$?

::: proposicao 3.1 · Decomposição do erro de previsão
Sob o modelo da Definição 3.1, para $\hat f$ fixa e um ponto $x$ fixo,

$$
\mathbb{E}\bigl[(Y-\hat Y)^2\mid X=x\bigr] = \underbrace{\bigl(f(x)-\hat f(x)\bigr)^2}_{\text{erro redutível}}+\underbrace{\operatorname{Var}(\varepsilon)}_{\text{erro irredutível}} .
$$
:::

::: demonstracao
Substituindo $Y = f(x)+\varepsilon$ e chamando $a = f(x)-\hat f(x)$, que é uma constante: $\mathbb{E}[(a+\varepsilon)^2] = a^2+2a\,\mathbb{E}[\varepsilon]+\mathbb{E}[\varepsilon^2]$. O termo cruzado é nulo porque $\mathbb{E}[\varepsilon]=0$, e $\mathbb{E}[\varepsilon^2] = \operatorname{Var}(\varepsilon)$ pela Proposição 1.10.
:::

### Interpretação

O **erro redutível** vem de $\hat f$ não coincidir com $f$. Pode ser diminuído com um método melhor ou com mais dados. Todo o esforço do aprendizado de máquina dirige-se a esse termo.

O **erro irredutível** é a variância do ruído. Mesmo que se conhecesse $f$ exatamente, a previsão $f(x)$ erraria, em média quadrática, $\operatorname{Var}(\varepsilon)$. Nenhum algoritmo, com nenhuma quantidade de dados, passa desse limite **para as preditoras dadas**. A única forma de reduzi-lo é mudar o problema: medir variáveis novas que expliquem parte do que hoje é ruído.

::: erro Interpretar erro irredutível como falha do modelo
Um modelo cujo erro quadrático médio se aproxima de $\operatorname{Var}(\varepsilon)$ atingiu o que é possível. Insistir em reduzi-lo no conjunto de treinamento só produz ajuste ao ruído (Capítulo 5). Na prática, $\operatorname{Var}(\varepsilon)$ é desconhecida, e parte da habilidade do analista consiste em reconhecer quando os ganhos adicionais deixaram de ser reais.
:::

### Verificação numérica

<<< codigo/c3_erro.py

>>> codigo/c3_erro.out

A segunda linha da saída é o ponto central: usar a função verdadeira produz erro igual à variância do ruído. Nas demais, a soma das duas parcelas reproduz o erro total, como afirma a proposição. Polinômios mais flexíveis reduzem a parcela redutível de $0{,}21$ para $0{,}003$; o piso de $0{,}09$ permanece.

## 3.4 Perda, risco e o melhor preditor

### Função de perda e risco

Para comparar preditores, é preciso um critério numérico.

::: definicao 3.2 · Função de perda, risco e risco empírico
Uma **função de perda** $\ell(y,\hat y)\ge0$ mede o custo de prever $\hat y$ quando a resposta é $y$.

O **risco** (ou erro esperado) de um preditor $g$ é a perda média sobre a distribuição conjunta de $(X,Y)$:

$$
R(g) = \mathbb{E}\bigl[\ell\bigl(Y,g(X)\bigr)\bigr].
$$

O **risco empírico** é a perda média nos $n$ exemplos de treinamento:

$$
\hat R_n(g) = \frac1n\sum_{i=1}^n\ell\bigl(y_i,g(x_i)\bigr).
$$
:::

O risco é o que interessa: o desempenho em dados novos. Mas ele depende da distribuição dos dados, que é desconhecida. O risco empírico é o que se pode calcular. A estratégia de escolher, em uma família de funções, aquela de menor risco empírico chama-se **Minimização do Risco Empírico** (*Empirical Risk Minimization*, ERM). O treinamento de quase todos os modelos deste livro, da regressão linear aos Transformers, é uma forma de ERM, e a descida do gradiente do Capítulo 1 é a ferramenta que a executa.

A distância entre risco empírico e risco é o problema da **generalização**, objeto do Capítulo 5. Por ora, convém fixar que minimizar o primeiro é um meio, e não o fim.

### O preditor ideal em regressão

Se a distribuição de $(X,Y)$ fosse conhecida, qual seria o melhor preditor sob perda quadrática?

::: teorema 3.2 · Função de regressão
Entre todas as funções $g$, o risco quadrático $\mathbb{E}[(Y-g(X))^2]$ é minimizado por

$$
f^\star(x) = \mathbb{E}[Y\mid X=x],
$$

a esperança condicional de $Y$ dado $X = x$.
:::

::: demonstracao
Fixe $x$ e seja $m = \mathbb{E}[Y\mid X=x]$. Para qualquer valor $c$, somando e subtraindo $m$: $\mathbb{E}[(Y-c)^2\mid X=x] = \mathbb{E}[(Y-m)^2\mid X=x]+2(m-c)\,\mathbb{E}[Y-m\mid X=x]+(m-c)^2$. O termo do meio é nulo pela definição de $m$. O primeiro não depende de $c$. O último é minimizado, com valor zero, em $c = m$. Como isso vale em cada $x$, vale em média sobre $X$.
:::

No modelo $Y = f(X)+\varepsilon$, tem-se $\mathbb{E}[Y\mid X=x] = f(x)$: a função desconhecida da Definição 3.1 é exatamente o preditor ideal. O teorema dá à regressão um alvo bem definido: **estimar a média condicional**. A escolha da perda importa: sob perda absoluta $\lvert y-\hat y\rvert$, o preditor ideal é a mediana condicional, menos sensível a valores extremos.

## 3.5 Regressão e classificação

::: definicao 3.3 · Regressão e classificação
Um problema supervisionado é de **regressão** quando a resposta é **quantitativa**: assume valores numéricos em que diferenças têm significado (preço, temperatura, tempo). É de **classificação** quando a resposta é **qualitativa**: assume valores em um conjunto finito de classes, sem estrutura métrica (spam ou legítimo; espécie de uma planta; dígito escrito).
:::

A distinção refere-se à resposta, e não às preditoras, que podem ser de qualquer tipo em ambos os casos. Ela determina a perda natural. Em regressão, usa-se a perda quadrática. Em classificação, a perda mais simples é a **perda 0-1**, que vale 1 quando a classe prevista difere da verdadeira e 0 quando coincide. Seu risco é a probabilidade de erro, $P\bigl(Y\neq g(X)\bigr)$.

### O classificador ideal

::: teorema 3.3 · Classificador de Bayes
A probabilidade de erro é minimizada pelo classificador que atribui a cada $x$ a classe mais provável dado $x$:

$$
g^\star(x) = \arg\max_{j}\;P(Y=j\mid X=x).
$$

Seu risco, a **taxa de erro de Bayes**, é $1-\mathbb{E}\bigl[\max_j P(Y=j\mid X)\bigr]$.
:::

::: demonstracao
Fixe $x$. Um classificador que escolhe a classe $k$ acerta com probabilidade $P(Y=k\mid X=x)$ e erra com probabilidade $1-P(Y=k\mid X=x)$. Esse erro é mínimo quando $k$ é a classe de maior probabilidade condicional. Minimizando em cada $x$, minimiza-se a média sobre $X$, que vale $\mathbb{E}[1-\max_jP(Y=j\mid X)]$.
:::

O classificador de Bayes é o análogo da função de regressão, e a taxa de erro de Bayes é o análogo do erro irredutível. Quando as classes se sobrepõem, isto é, quando o mesmo $x$ ocorre com classes diferentes, nem o classificador ideal acerta sempre.

O teorema também organiza os métodos do Capítulo 4. Como as probabilidades $P(Y=j\mid X=x)$ são desconhecidas, cada método é uma forma de estimá-las: a regressão logística supõe uma forma funcional para elas; o KNN estima-as pela proporção de classes entre os vizinhos; a árvore, pela proporção em cada folha.

::: atencao A perda 0-1 trata todos os erros como iguais
Deixar de detectar uma doença grave e emitir um alarme falso contam o mesmo na taxa de erro. Quando os custos diferem, o classificador que minimiza o custo esperado não é o da classe mais provável: ele desloca o limiar de decisão. O Capítulo 5 retoma esse ponto com precisão, recall e curva ROC.
:::

### Métodos paramétricos e não paramétricos

Há duas grandes estratégias para estimar $f$.

Os **métodos paramétricos** supõem uma forma para $f$ com número fixo de parâmetros, por exemplo $f(x) = \beta_0+\beta_1x_1+\dots+\beta_dx_d$, e reduzem o problema à estimação de $d+1$ números. São simples, exigem poucos dados e são interpretáveis. Se a forma suposta estiver longe da verdadeira, o erro redutível não desaparece, por mais dados que se tenha.

Os **métodos não paramétricos** não fixam a forma de $f$; deixam que os dados a determinem. O KNN e as árvores do Capítulo 4 são exemplos. Podem aproximar formas muito variadas e, em troca, precisam de mais dados e correm mais risco de ajustar o ruído.

Entre os dois extremos, há um contínuo de **flexibilidade**. O resultado mais importante do Capítulo 5 é que mais flexibilidade não significa menos erro: existe um nível intermediário, dependente do problema e da quantidade de dados, em que o erro em dados novos é mínimo.

## 3.6 Aprendizado não supervisionado

### O problema

No aprendizado não supervisionado, observam-se apenas as preditoras $x_1,\dots,x_n$, sem resposta. Não há o que prever, e portanto não há erro de previsão para medir. O objetivo é **descobrir estrutura**: grupos de observações semelhantes, direções em que os dados variam, observações atípicas.

Essa ausência de gabarito tem uma consequência metodológica importante. Não existe, em geral, um critério objetivo e universal para dizer se um agrupamento está certo. O resultado é avaliado pela utilidade para um fim: os grupos de clientes fazem sentido para o negócio? As direções encontradas simplificam uma análise posterior? Por isso o aprendizado não supervisionado é frequentemente parte da **análise exploratória**, a etapa em que se procura entender os dados antes de modelá-los.

Esta seção apresenta os dois métodos básicos. Ambos são aplicações diretas do Capítulo 1.

### Análise de Componentes Principais

**Motivação.** Dados com muitas variáveis são difíceis de visualizar e costumam ser redundantes: variáveis correlacionadas carregam a mesma informação. A Análise de Componentes Principais (*Principal Component Analysis*, PCA) procura poucas direções ao longo das quais os dados variam mais, e descreve cada observação por suas coordenadas nessas direções.

**Formulação.** Seja $\mathbf{X}\in\mathbb{R}^{n\times d}$ a matriz de dados com colunas centradas (média zero) e $\mathbf{S} = \tfrac{1}{n-1}\mathbf{X}^\top\mathbf{X}$ sua matriz de covariância amostral. Projetar os dados em uma direção unitária $\mathbf{v}$ produz os escores $\mathbf{X}\mathbf{v}$, cuja variância amostral é $\mathbf{v}^\top\mathbf{S}\mathbf{v}$ (Proposição 1.11). A primeira componente principal é a direção que maximiza essa variância:

$$
\mathbf{v}_1 = \arg\max_{\lVert\mathbf{v}\rVert_2=1}\;\mathbf{v}^\top\mathbf{S}\mathbf{v}.
$$

::: proposicao 3.4 · Componentes principais são autovetores da covariância
A solução $\mathbf{v}_1$ é o autovetor de $\mathbf{S}$ associado ao maior autovalor $\lambda_1$, e a variância máxima é $\lambda_1$. A $k$-ésima componente, restrita a ser ortogonal às anteriores, é o autovetor do $k$-ésimo maior autovalor.
:::

::: demonstracao
Pelo teorema espectral (Teorema 1.3), $\mathbf{S} = \mathbf{Q}\boldsymbol\Lambda\mathbf{Q}^\top$, com $\lambda_1\ge\dots\ge\lambda_d\ge0$. Escrevendo $\mathbf{z} = \mathbf{Q}^\top\mathbf{v}$, tem-se $\lVert\mathbf{z}\rVert_2 = 1$ e $\mathbf{v}^\top\mathbf{S}\mathbf{v} = \sum_i\lambda_iz_i^2\le\lambda_1\sum_iz_i^2 = \lambda_1$. A igualdade é atingida com $\mathbf{z} = \mathbf{e}_1$, isto é, $\mathbf{v} = \mathbf{q}_1$. Para a segunda componente, a restrição de ortogonalidade impõe $z_1 = 0$, e o mesmo argumento dá $\lambda_2$ e $\mathbf{q}_2$; e assim por diante.
:::

A fração $\lambda_k/\sum_i\lambda_i$ é a **proporção da variância explicada** pela componente $k$. Manter as $m$ primeiras componentes reduz cada observação de $d$ para $m$ números.

<<< codigo/c3_pca.py

>>> codigo/c3_pca.out

No conjunto Iris (150 flores, 4 medidas), duas componentes retêm cerca de 97,8% da variância. A implementação com autovetores e a do scikit-learn coincidem, exceto pelo sinal de cada componente, que é arbitrário (seção 1.6). O scikit-learn usa internamente a SVD da matriz centrada, numericamente mais estável do que formar $\mathbf{X}^\top\mathbf{X}$.

::: atencao Limitações da PCA
- **Depende da escala.** Uma variável medida em milímetros domina outra medida em metros. Quando as unidades diferem, padronizam-se as colunas antes.
- **Captura apenas estrutura linear.** Dados dispostos sobre uma curva não são bem resumidos por direções retas.
- **Variância não é relevância.** A direção de maior variância pode ser irrelevante para prever uma resposta. A PCA não vê a resposta.
:::

### Agrupamento por k-médias

**Motivação.** Agrupar (*clustering*) é dividir as observações em grupos, de modo que observações do mesmo grupo sejam parecidas e as de grupos diferentes, distintas. Usa-se para segmentar clientes, organizar documentos, resumir grandes conjuntos por representantes.

**Formulação.** Fixado o número $K$ de grupos, o método das k-médias (*k-means*) procura uma partição $C_1,\dots,C_K$ e centros $\boldsymbol\mu_1,\dots,\boldsymbol\mu_K$ que minimizem a soma das distâncias ao quadrado de cada ponto ao centro do seu grupo:

$$
J = \sum_{k=1}^K\sum_{i\in C_k}\lVert\mathbf{x}_i-\boldsymbol\mu_k\rVert_2^2 .
$$

Encontrar o mínimo global de $J$ é um problema computacionalmente intratável no caso geral. O algoritmo de Lloyd (1982) é uma heurística que alterna dois passos:

1. **Atribuição:** com os centros fixos, cada ponto vai para o grupo do centro mais próximo.
2. **Atualização:** com os grupos fixos, cada centro vai para a média dos pontos do seu grupo.

::: proposicao 3.5 · Convergência do algoritmo de Lloyd
Nenhum dos dois passos aumenta $J$, e o algoritmo termina em um número finito de iterações.
:::

::: demonstracao
No passo de atribuição, cada ponto troca seu termo em $J$ pela menor distância disponível, o que não aumenta a soma. No passo de atualização, para cada grupo, o ponto $\boldsymbol\mu$ que minimiza $\sum_{i\in C_k}\lVert\mathbf{x}_i-\boldsymbol\mu\rVert^2$ é a média do grupo: o gradiente em $\boldsymbol\mu$ é $-2\sum_{i\in C_k}(\mathbf{x}_i-\boldsymbol\mu)$, que se anula na média, e a função é convexa. Como $J\ge0$ não aumenta e existe um número finito de partições de $n$ pontos em $K$ grupos, o algoritmo não pode prosseguir indefinidamente sem repetir uma partição, e para quando as atribuições deixam de mudar.
:::

A proposição garante convergência, mas **não** garante o mínimo global. O ponto de chegada depende dos centros iniciais.

<<< codigo/c3_kmeans.py

>>> codigo/c3_kmeans.out

A execução mostra as duas faces da proposição. O objetivo decresce a cada iteração, como demonstrado. E a implementação didática, com uma única inicialização aleatória, estaciona em $J\approx2109$, quase o dobro do valor encontrado pelo scikit-learn ($1093{,}5$). É o comportamento típico de quando dois centros iniciais caem no mesmo grupo real: o algoritmo não consegue desfazer a escolha. O scikit-learn executa várias inicializações (`n_init`) com a estratégia k-means++ (Arthur e Vassilvitskii, 2007), que espalha os centros iniciais, e fica com o melhor resultado. É a diferença entre código didático e código de produção.

A última linha mostra $J$ para $K$ de 1 a 6. O valor sempre diminui com $K$ (com $K=n$ seria zero), de modo que $J$ não serve, sozinho, para escolher $K$. Procura-se o ponto em que a queda deixa de ser acentuada, aqui em $K=3$, critério conhecido como método do cotovelo. Trata-se de uma heurística visual.

::: erro Tratar grupos encontrados como categorias reais
O k-médias sempre devolve $K$ grupos, haja ou não estrutura de grupos nos dados. Ele pressupõe grupos aproximadamente esféricos e de tamanhos semelhantes, é sensível à escala das variáveis e a valores atípicos. Um agrupamento é uma hipótese sobre os dados, a ser examinada, e não uma descoberta garantida.
:::

## 3.7 Introdução ao aprendizado por reforço

### O problema

Nos dois paradigmas anteriores, os dados são coletados de antemão e não dependem do que o sistema faz. No Aprendizado por Reforço (*Reinforcement Learning*, RL), um agente interage com um ambiente, e os dados que observa são consequência das próprias ações. O paradigma corresponde ao ambiente **sequencial** da seção 2.6 e difere do supervisionado em três aspectos.

- **Não há resposta correta fornecida.** O agente recebe apenas uma **recompensa** numérica, que avalia o que ele fez, sem dizer o que deveria ter feito.
- **As consequências são tardias.** Uma ação pode afetar recompensas muito posteriores. Atribuir o resultado final às decisões que o causaram é o problema da atribuição de crédito.
- **O agente escolhe o que observa.** Só se aprende o valor das ações experimentadas.

### Formalização

A cada instante $t$, o agente observa um estado $S_t$, escolhe uma ação $A_t$, recebe uma recompensa $R_{t+1}$ e passa ao estado $S_{t+1}$.

::: definicao 3.4 · Processo de decisão de Markov, política e retorno
Um **Processo de Decisão de Markov** (*Markov Decision Process*, MDP) é definido por um conjunto de estados $\mathcal{S}$, um conjunto de ações $\mathcal{A}$, uma dinâmica $p(s',r\mid s,a)$, que dá a probabilidade de passar ao estado $s'$ com recompensa $r$ ao executar $a$ em $s$, e um fator de desconto $\gamma\in[0,1]$. A dinâmica depende apenas do estado e da ação atuais (propriedade de Markov).

Uma **política** $\pi(a\mid s)$ é a probabilidade de escolher a ação $a$ no estado $s$.

O **retorno** a partir do instante $t$ é a soma descontada das recompensas futuras:

$$
G_t = R_{t+1}+\gamma R_{t+2}+\gamma^2R_{t+3}+\dots = \sum_{k=0}^{\infty}\gamma^kR_{t+k+1}.
$$
:::

A política é a função do agente da seção 2.4, agora probabilística. O objetivo é encontrar a política que maximiza o retorno **esperado**: é a máxima utilidade esperada da Definição 2.4, com a utilidade dada pela soma das recompensas. O desconto $\gamma<1$ faz recompensas próximas valerem mais que distantes e mantém a soma finita.

A **função de valor** de uma política, $v_\pi(s) = \mathbb{E}_\pi[G_t\mid S_t=s]$, mede quão bom é estar em $s$ seguindo $\pi$. Como $G_t = R_{t+1}+\gamma G_{t+1}$, ela satisfaz uma relação recursiva, a **equação de Bellman**:

$$
v_\pi(s) = \sum_a\pi(a\mid s)\sum_{s',r}p(s',r\mid s,a)\,\bigl[r+\gamma\,v_\pi(s')\bigr].
$$

A equação diz que o valor de um estado é a recompensa imediata esperada mais o valor descontado do estado seguinte. Quase todos os algoritmos de aprendizado por reforço são formas de resolver essa equação, exatamente ou por aproximação, sem conhecer $p$.

### Exploração e aproveitamento

O caso mais simples, com um único estado, já exibe o dilema central do paradigma. No problema dos **caça-níqueis de vários braços** (*multi-armed bandit*), cada ação tem uma recompensa média desconhecida. Escolher sempre a ação que parece melhor (**aproveitamento**) pode fixar o agente em uma ação inferior, cuja estimativa inicial foi favorável por acaso. Experimentar outras ações (**exploração**) custa recompensa agora e pode revelar algo melhor. A estratégia $\varepsilon$-gulosa resolve o conflito de forma rudimentar: com probabilidade $\varepsilon$, escolhe ao acaso; caso contrário, escolhe a melhor estimativa.

<<< codigo/c3_bandit.py

>>> codigo/c3_bandit.out

Sem exploração ($\varepsilon=0$), o agente obtém em média $0{,}48$, muito abaixo do ótimo de $0{,}8$: frequentemente trava em uma ação ruim. Com exploração excessiva ($\varepsilon=0{,}5$), desperdiça metade das escolhas. Um valor intermediário é melhor que os dois extremos. A linha `Q[a] += (r - Q[a]) / N[a]` é o padrão de atualização de todo o paradigma: nova estimativa igual à antiga mais um passo na direção do erro observado.

::: aplicacao Onde o aprendizado por reforço aparece neste livro
O paradigma não é desenvolvido além desta introdução; a referência para aprofundamento é Sutton e Barto (2018). Suas ideias, porém, reaparecem. A exploração é a justificativa da amostragem com temperatura em LLMs (Capítulo 11). A noção de um agente que age, observa o resultado e ajusta o comportamento estrutura os padrões ReAct e Reflexion (Capítulo 13), embora ali a adaptação ocorra no contexto, e não nos parâmetros do modelo. E a avaliação de agentes (Capítulo 15) enfrenta o mesmo problema de atribuição de crédito: qual passo de uma longa trajetória causou a falha?
:::

## 3.8 Síntese dos paradigmas

| | Supervisionado | Não supervisionado | Por reforço |
|---|---|---|---|
| Dados | Pares $(x_i,y_i)$ | Apenas $x_i$ | Trajetórias de estados, ações e recompensas |
| Objetivo | Minimizar o risco de previsão | Descobrir estrutura | Maximizar o retorno esperado |
| Sinal de aprendizado | Resposta correta | Nenhum | Recompensa avaliativa |
| Avaliação | Erro em dados novos | Utilidade para um fim | Retorno obtido |
| Ambiente (seção 2.6) | Episódico | Episódico | Sequencial |
| Exemplos neste livro | Capítulos 4 a 10 | PCA, k-médias, *embeddings* | Conceitos nos Capítulos 11, 13 e 15 |

As fronteiras são menos rígidas do que a tabela sugere. O pré-treinamento de modelos de linguagem (Capítulo 9) usa texto sem rótulos, mas transforma-o em um problema supervisionado ao prever cada palavra a partir das anteriores. Essa estratégia, chamada **aprendizado autossupervisionado**, é a base dos LLMs.

## 3.9 Resumo do capítulo

::: resumo Ideias centrais
- O aprendizado supervisionado supõe $Y = f(X)+\varepsilon$ e procura uma estimativa $\hat f$ a partir de exemplos.
- O erro de previsão decompõe-se em **redutível**, $(f-\hat f)^2$, e **irredutível**, $\operatorname{Var}(\varepsilon)$. O segundo é um limite para as preditoras dadas.
- O que se quer minimizar é o **risco**; o que se consegue calcular é o **risco empírico**. A diferença entre eles é o problema da generalização.
- Sob perda quadrática, o preditor ideal é a **média condicional**. Sob perda 0-1, é o **classificador de Bayes**, que escolhe a classe mais provável.
- **Regressão** tem resposta quantitativa; **classificação**, qualitativa.
- No aprendizado **não supervisionado** não há resposta. A PCA encontra as direções de maior variância (autovetores da covariância); o k-médias minimiza distâncias aos centros e converge para mínimos locais.
- No aprendizado **por reforço**, um agente aprende com recompensas a maximizar o retorno esperado, equilibrando exploração e aproveitamento.
:::

## 3.10 Exercícios

### Nível I: consolidação

**3.1** Classifique cada problema como regressão, classificação ou não supervisionado, e indique $n$, $d$ e a resposta quando houver: (a) prever o salário de 800 profissionais a partir de formação, experiência e setor; (b) decidir, a partir de 12 medidas, se cada uma de 5 000 transações é fraudulenta; (c) organizar 20 000 notícias em temas, sem temas definidos de antemão; (d) estimar o número de passageiros de uma linha de ônibus em cada hora do dia.

**3.2** Para cada situação, diga se o interesse principal é previsão ou inferência: (a) uma seguradora quer saber quais características do motorista mais se associam a sinistros; (b) um aplicativo quer estimar o tempo de entrega de um pedido.

**3.3** Em um problema com $\operatorname{Var}(\varepsilon) = 4$, um colega relata erro quadrático médio de teste igual a $2{,}5$. O que você conclui?

**3.4** Em um ponto $x$, as probabilidades condicionais de três classes são $0{,}5$, $0{,}3$ e $0{,}2$. Qual é a previsão do classificador de Bayes e qual é sua probabilidade de erro nesse ponto?

**3.5** Calcule o retorno $G_0$ para a sequência de recompensas $1, 0, 2, 3$ (e zero depois), com $\gamma = 0{,}5$ e com $\gamma = 1$.

### Nível II: desenvolvimento

**3.6** Mostre que, sob perda absoluta, o valor $c$ que minimiza $\mathbb{E}\lvert Y-c\rvert$ é uma mediana de $Y$. (Sugestão: para $Y$ contínua, derive em relação a $c$.)

**3.7** Duas classes equiprováveis têm $X\mid Y=0\sim\mathcal{N}(0,1)$ e $X\mid Y=1\sim\mathcal{N}(2,1)$. (a) Determine o classificador de Bayes. (b) Calcule a taxa de erro de Bayes. (c) Confira por simulação.

**3.8** Prove que a média de um conjunto de pontos minimiza a soma das distâncias ao quadrado a esses pontos, e que $\sum_i\lVert\mathbf{x}_i-\mathbf{c}\rVert^2 = \sum_i\lVert\mathbf{x}_i-\bar{\mathbf{x}}\rVert^2+n\lVert\bar{\mathbf{x}}-\mathbf{c}\rVert^2$.

**3.9** (Computacional) Aplique PCA ao conjunto Iris com e sem padronização das colunas. Compare as proporções de variância explicada e explique a diferença.

**3.10** Um MDP tem um único estado não terminal, em que a única ação dá recompensa 1 e retorna ao mesmo estado com probabilidade $0{,}9$, ou encerra o episódio com probabilidade $0{,}1$. Com $\gamma = 1$, escreva a equação de Bellman e calcule o valor do estado.

### Nível III: avançado

**3.11** (Experimento) No programa da seção 3.3, varie o tamanho do treino $n\in\{20, 50, 200, 1000\}$ para os graus 1, 3 e 9. Descreva como o erro redutível de cada grau se comporta com $n$ e explique por que o do grau 1 não tende a zero.

**3.12** (Análise crítica) Uma equipe aplica k-médias com $K=4$ a dados de clientes e passa a tratar os quatro grupos como "os quatro perfis de cliente da empresa". Liste as verificações que você exigiria antes de aceitar essa conclusão.

**3.13** (Pesquisa) Implemente a estratégia de limite superior de confiança (UCB) para o problema dos caça-níqueis, como descrita em Sutton e Barto (2018, cap. 2), e compare com a $\varepsilon$-gulosa. Por que explorar de forma dirigida pela incerteza é melhor do que explorar ao acaso?

## 3.11 Soluções comentadas

::: solucao 3.1
(a) Regressão; $n=800$, $d=3$; resposta: salário. (b) Classificação binária; $n=5\,000$, $d=12$; resposta: fraude ou não. (c) Não supervisionado (agrupamento); $n=20\,000$; sem resposta. (d) Regressão; a resposta é uma contagem, quantitativa.
:::

::: solucao 3.2
(a) Inferência: interessa a relação entre características e sinistros. (b) Previsão: interessa o valor estimado, e não a forma do modelo.
:::

::: solucao 3.3
O erro esperado em dados novos não pode ser inferior a 4. Um valor de $2{,}5$ indica problema: conjunto de teste muito pequeno (flutuação amostral), dados de teste usados no ajuste ou vazamento de informação da resposta para as preditoras. A outra possibilidade é que a variância do ruído tenha sido superestimada.
:::

::: solucao 3.4
Prevê a primeira classe, com probabilidade de erro $1-0{,}5 = 0{,}5$. Mesmo o classificador ideal erra metade das vezes nesse ponto.
:::

::: solucao 3.5
Com $\gamma=0{,}5$: $1+0{,}5\cdot0+0{,}25\cdot2+0{,}125\cdot3 = 1{,}875$. Com $\gamma=1$: $6$.
:::

::: solucao 3.6
Para $Y$ com densidade $p$, $\mathbb{E}\lvert Y-c\rvert = \int_{-\infty}^c(c-y)\,p(y)\,dy+\int_c^\infty(y-c)\,p(y)\,dy$. Derivando em $c$: $P(Y\le c)-P(Y>c)$. A derivada anula-se quando $P(Y\le c) = 1/2$, isto é, em uma mediana, e é crescente em $c$, o que confirma o mínimo.
:::

::: solucao 3.7
(a) Com prioris iguais, escolhe-se a classe de maior densidade. As duas densidades Gaussianas, de mesma variância, cruzam-se no ponto médio: prevê-se a classe 1 quando $x>1$.

(b) O erro é $\tfrac12P(X>1\mid Y=0)+\tfrac12P(X<1\mid Y=1) = P(Z>1)\approx0{,}1587$, em que $Z\sim\mathcal{N}(0,1)$.

(c) Gerando um milhão de pares e aplicando a regra $x>1$, a frequência de erros fica em torno de $0{,}159$. Nenhum classificador, por mais sofisticado, faz melhor nesse problema.
:::

::: solucao 3.8
Somando e subtraindo $\bar{\mathbf{x}}$: $\lVert\mathbf{x}_i-\mathbf{c}\rVert^2 = \lVert\mathbf{x}_i-\bar{\mathbf{x}}\rVert^2+2(\mathbf{x}_i-\bar{\mathbf{x}})^\top(\bar{\mathbf{x}}-\mathbf{c})+\lVert\bar{\mathbf{x}}-\mathbf{c}\rVert^2$. Somando em $i$, o termo cruzado desaparece, porque $\sum_i(\mathbf{x}_i-\bar{\mathbf{x}}) = \mathbf{0}$. Resta a identidade pedida, cujo lado direito é mínimo em $\mathbf{c} = \bar{\mathbf{x}}$. É o mesmo argumento do Teorema 3.2: a média é o melhor resumo sob perda quadrática.
:::

::: solucao 3.9 (orientação)
Use `StandardScaler` antes de `PCA`. Sem padronização, a primeira componente explica cerca de 92% da variância, porque o comprimento da pétala tem variância muito maior que as demais medidas e domina a covariância. Com padronização, cada variável contribui com variância 1, e a primeira componente explica cerca de 73%. Nenhuma das duas análises é "a correta": padroniza-se quando as escalas são arbitrárias ou as unidades diferem.
:::

::: solucao 3.10
$v = 1+0{,}9\,v+0{,}1\cdot0$, logo $v = 1/0{,}1 = 10$. O resultado coincide com o número esperado de passos até o término de um processo geométrico com probabilidade de parada $0{,}1$.
:::

::: solucao 3.11 (orientação)
O erro redutível tem duas origens: a família de funções não contém $f$ (viés) e os parâmetros são estimados com erro (variância). A reta não consegue representar uma senoide: seu erro redutível estabiliza em torno de $0{,}2$, qualquer que seja $n$. O grau 9 tem erro alto para $n=20$, por variância, e muito baixo para $n=1000$. O grau 3 fica entre os dois. O Capítulo 5 formaliza essa decomposição.
:::

::: solucao 3.12 (orientação)
Verificações esperadas: estabilidade dos grupos sob reamostragem e sob outras inicializações; sensibilidade à escala e à escolha das variáveis; comparação com outros valores de $K$ e com outro método de agrupamento; inspeção de se os grupos diferem em variáveis não usadas no agrupamento; exame visual em duas componentes principais; e, sobretudo, se tratar os grupos de forma diferente produz resultado mensurável. Sem isso, os perfis são um artefato possível do algoritmo.
:::

::: solucao 3.13 (orientação)
A regra UCB escolhe a ação que maximiza $Q(a)+c\sqrt{\ln t/N(a)}$. O segundo termo é grande para ações pouco experimentadas e diminui à medida que são testadas. A exploração concentra-se onde a incerteza ainda pode mudar a decisão, e não se desperdiçam escolhas em ações já sabidamente ruins, como faz a $\varepsilon$-gulosa. Espera-se recompensa média superior à da $\varepsilon$-gulosa com $\varepsilon=0{,}1$ no problema da seção 3.7.
:::

## 3.12 Referências e leituras

**O que estudar primeiro.** James et al. (2023), capítulo 2, que este capítulo acompanha de perto na formulação supervisionada; depois o capítulo 12, sobre métodos não supervisionados.

### Livros didáticos fundamentais

- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Capítulos 2 e 12. Disponível em: www.statlearning.com.
- SUTTON, R. S.; BARTO, A. G. *Reinforcement Learning: An Introduction*. 2. ed. Cambridge, MA: MIT Press, 2018. Capítulos 1 a 3.

### Referências complementares

- HASTIE, T.; TIBSHIRANI, R.; FRIEDMAN, J. *The Elements of Statistical Learning*. 2. ed. New York: Springer, 2009. Capítulo 2.
- RUSSELL, S.; NORVIG, P. *Artificial Intelligence: A Modern Approach*. 4. ed. Hoboken: Pearson, 2021. Capítulo 19.

### Artigos originais

- ARTHUR, D.; VASSILVITSKII, S. k-means++: the advantages of careful seeding. In: *Proceedings of the 18th Annual ACM-SIAM Symposium on Discrete Algorithms*, 2007. p. 1027–1035.
- LLOYD, S. P. Least squares quantization in PCM. *IEEE Transactions on Information Theory*, v. 28, n. 2, p. 129–137, 1982.
- PEDREGOSA, F. et al. Scikit-learn: machine learning in Python. *Journal of Machine Learning Research*, v. 12, p. 2825–2830, 2011.

### Documentação técnica

- scikit-learn, guia do usuário: seções de decomposição (PCA) e de agrupamento (K-means). scikit-learn.org/stable/user_guide.html. Programas executados com a versão 1.9.
