"""Gera o arquivo único (offline) a partir de site/: CSS, fontes do KaTeX, JS e capítulos embutidos."""
import base64, re, sys, pathlib
site = pathlib.Path("/home/claude/livro/site")
saida = pathlib.Path(sys.argv[1])
html = (site / "index.html").read_text()

def fonte(m):
    arq = site / "css" / "fonts" / m.group(1)
    return "url(data:font/woff2;base64," + base64.b64encode(arq.read_bytes()).decode() + ")"

kcss = re.sub(r"url\(fonts/([^)]+\.woff2)\)", fonte, (site / "css" / "katex.min.css").read_text())
lcss = (site / "css" / "livro.css").read_text()
html = html.replace('<link rel="stylesheet" href="css/katex.min.css">', f"<style>{kcss}</style>")
html = html.replace('<link rel="stylesheet" href="css/livro.css">', f"<style>{lcss}</style>")
seguro = lambda t: t.replace("</script", "<\\/script")
caps = "".join(f"<script>{seguro(p.read_text())}</script>\n" for p in sorted((site / "capitulos").glob("*.js")))
html = html.replace('<script src="js/livro.js"></script>', f"<script>{seguro((site / 'js' / 'livro.js').read_text())}</script>\n{caps}")
saida.write_text(html)
print(saida, round(len(html) / 1024 / 1024, 2), "MB")
