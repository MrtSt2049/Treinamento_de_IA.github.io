## 8.4 Portas e memória: LSTM e GRU

### A ideia: um caminho aditivo

A recorrência da rede simples **reescreve** o estado a cada passo: $\mathbf{h}_t=\tanh(\mathbf{W}\mathbf{h}_{t-1}+\dots)$ multiplica o passado por uma matriz e o comprime por uma não linearidade. É essa composição que gera o produto de jacobianos do Teorema 8.3. A ideia de Hochreiter e Schmidhuber (1997) foi manter, ao lado do estado, uma **memória** $\mathbf{c}_t$ atualizada de modo **aditivo**,
$$\mathbf{c}_t=\mathbf{c}_{t-1}+(\text{novidade}),$$
de modo que, se nada for escrito, a informação atravessa o tempo **intacta**. Uma memória que apenas soma, porém, nunca esquece e se satura. A solução está nas **portas** (*gates*): vetores com valores em $(0,1)$, produzidos por sigmoides, que multiplicam outros vetores componente a componente e decidem **quanto** passa. A porta de esquecimento foi acrescentada por Gers, Schmidhuber e Cummins (2000).

::: definicao 8.4 · Célula LSTM
A **LSTM** (*long short-term memory*) mantém dois vetores, o estado oculto $\mathbf{h}_t$ e a **célula de memória** $\mathbf{c}_t$. Com $[\mathbf{x}_t,\mathbf{h}_{t-1}]$ a entrada atual e o estado anterior,
$$\begin{aligned}
\mathbf{f}_t&=\sigma(\mathbf{W}_f\mathbf{x}_t+\mathbf{U}_f\mathbf{h}_{t-1}+\mathbf{b}_f)&&\text{porta de esquecimento}\\
\mathbf{i}_t&=\sigma(\mathbf{W}_i\mathbf{x}_t+\mathbf{U}_i\mathbf{h}_{t-1}+\mathbf{b}_i)&&\text{porta de escrita (entrada)}\\
\mathbf{o}_t&=\sigma(\mathbf{W}_o\mathbf{x}_t+\mathbf{U}_o\mathbf{h}_{t-1}+\mathbf{b}_o)&&\text{porta de leitura (saída)}\\
\mathbf{g}_t&=\tanh(\mathbf{W}_g\mathbf{x}_t+\mathbf{U}_g\mathbf{h}_{t-1}+\mathbf{b}_g)&&\text{candidato a escrever}\\
\mathbf{c}_t&=\mathbf{f}_t\odot\mathbf{c}_{t-1}+\mathbf{i}_t\odot\mathbf{g}_t&&\text{atualização aditiva da memória}\\
\mathbf{h}_t&=\mathbf{o}_t\odot\tanh(\mathbf{c}_t)&&\text{leitura}
\end{aligned}$$
:::

<figure>
+++ fig_c8_lstm.svg
<figcaption><b>Figura 8.3.</b> Célula LSTM. A linha horizontal superior é a memória $\mathbf{c}$: ela passa por uma multiplicação (a porta $\mathbf{f}$ decide o que esquecer) e por uma soma (a porta $\mathbf{i}$ decide quanto do candidato $\mathbf{g}$ escrever). A porta $\mathbf{o}$ decide quanto da memória, comprimida por $\tanh$, vira estado de saída $\mathbf{h}_t$. As quatro transformações usam $[\mathbf{h}_{t-1},\mathbf{x}_t]$.</figcaption>
</figure>

Cada porta aprende uma pergunta distinta: **o que manter** (esquecer), **o que acrescentar** (escrever) e **o que revelar** (ler). A ordem do bloco de pesos no PyTorch é $(\mathbf{i},\mathbf{f},\mathbf{g},\mathbf{o})$, o que importa na hora de inicializar uma porta específica.

### Por que o gradiente sobrevive

::: teorema 8.4 · O jacobiano da memória da LSTM
Na LSTM da Definição 8.4, a derivada da memória em relação à memória anterior, **incluindo** os caminhos que passam por $\mathbf{h}_{t-1}$, é
$$\begin{aligned}\frac{\partial\mathbf{c}_t}{\partial\mathbf{c}_{t-1}}&=\operatorname{diag}(\mathbf{f}_t)\\&\quad+\Bigl[\operatorname{diag}\bigl(\mathbf{c}_{t-1}\odot\mathbf{f}_t\odot(1-\mathbf{f}_t)\bigr)\mathbf{U}_f+\operatorname{diag}\bigl(\mathbf{g}_t\odot\mathbf{i}_t\odot(1-\mathbf{i}_t)\bigr)\mathbf{U}_i\\&\qquad\ +\operatorname{diag}\bigl(\mathbf{i}_t\odot(1-\mathbf{g}_t^{\odot2})\bigr)\mathbf{U}_g\Bigr]\operatorname{diag}\bigl(\mathbf{o}_{t-1}\odot(1-\tanh^2\mathbf{c}_{t-1})\bigr).\end{aligned}$$
O primeiro termo, $\operatorname{diag}(\mathbf{f}_t)$, é o caminho **direto** pela atualização aditiva. Assim, ao longo desse caminho, o efeito de $\mathbf{c}_{t-k}$ sobre $\mathbf{c}_t$ é a matriz diagonal $\operatorname{diag}\bigl(\prod_{u=t-k+1}^{t}\mathbf{f}_u\bigr)$, cujas entradas valem $\prod_u f_{u,j}$.
:::

::: demonstracao
$\mathbf{c}_t$ depende de $\mathbf{c}_{t-1}$ diretamente, pelo fator $\mathbf{f}_t$, e indiretamente por $\mathbf{h}_{t-1}=\mathbf{o}_{t-1}\odot\tanh(\mathbf{c}_{t-1})$, de que dependem as três grandezas $\mathbf{f}_t,\mathbf{i}_t,\mathbf{g}_t$ (por $\mathbf{U}_f,\mathbf{U}_i,\mathbf{U}_g$). A porta $\mathbf{o}_{t-1}$ é função de $\mathbf{x}_{t-1}$ e $\mathbf{h}_{t-2}$, não de $\mathbf{c}_{t-1}$. Derivando $\mathbf{c}_t=\mathbf{f}_t\odot\mathbf{c}_{t-1}+\mathbf{i}_t\odot\mathbf{g}_t$ e usando $\sigma'=\sigma(1-\sigma)$ e $\tanh'=1-\tanh^2$:
$\partial\mathbf{c}_t/\partial\mathbf{c}_{t-1}=\operatorname{diag}(\mathbf{f}_t)+\bigl[\operatorname{diag}(\mathbf{c}_{t-1})\,\partial\mathbf{f}_t/\partial\mathbf{h}_{t-1}+\operatorname{diag}(\mathbf{g}_t)\,\partial\mathbf{i}_t/\partial\mathbf{h}_{t-1}+\operatorname{diag}(\mathbf{i}_t)\,\partial\mathbf{g}_t/\partial\mathbf{h}_{t-1}\bigr]\,\partial\mathbf{h}_{t-1}/\partial\mathbf{c}_{t-1}$, com $\partial\mathbf{f}_t/\partial\mathbf{h}_{t-1}=\operatorname{diag}(\mathbf{f}_t\odot(1-\mathbf{f}_t))\mathbf{U}_f$ e analogamente para $\mathbf{i}$ e $\mathbf{g}$, e $\partial\mathbf{h}_{t-1}/\partial\mathbf{c}_{t-1}=\operatorname{diag}(\mathbf{o}_{t-1}\odot(1-\tanh^2\mathbf{c}_{t-1}))$.
:::

Compare com o Teorema 8.3: lá, o jacobiano é $\mathbf{D}_u\mathbf{W}_{hh}$, uma **matriz cheia** multiplicada várias vezes, cuja norma o teorema limita por $(\gamma\sigma)^k$. Aqui há um caminho cujo jacobiano é **diagonal**, controlado componente a componente pelas portas $f_{u,j}\in(0,1)$. Se as portas ficam próximas de $1$, o produto não decai rapidamente; se uma porta vale $0$, a memória daquele componente é apagada. A rede **decide**, a partir dos dados, quanto tempo cada componente deve lembrar.

::: atencao O teorema não garante, sozinho, que o gradiente total se conserva
O Teorema 8.4 é uma **identidade** para a derivada, e não um limite. Os termos entre colchetes dependem de $\mathbf{U}_f,\mathbf{U}_i,\mathbf{U}_g$ e podem somar ou subtrair do caminho direto; eles ficam pequenos quando as portas saturam, porque $\sigma(1-\sigma)\approx0$. O que o teorema mostra é que **existe** um caminho sem a compressão e a matriz cheia da RNN simples. Se o treino o aproveita, é uma questão empírica, medida a seguir.
:::

### A inicialização do viés da porta de esquecimento

::: proposicao 8.5 · Horizonte de memória de uma porta constante
Se a porta de esquecimento vale $f=\sigma(\beta)$, constante no tempo, o fator do caminho direto após $k$ passos é $f^k$, e a **meia-vida** da memória (o $k$ para o qual $f^k=\tfrac12$) é $k_{1/2}=\ln2/(-\ln f)=\ln2/\ln(1+e^{-\beta})$. Em particular, $\beta=0$ dá $f=\tfrac12$ e $k_{1/2}=1$; $\beta=1$ dá $f\approx0{,}73$ e $k_{1/2}\approx2{,}2$; $\beta=5$ dá $f\approx0{,}9933$ e $k_{1/2}\approx103$ passos.
:::

::: demonstracao
Basta $f^k=e^{k\ln f}=\tfrac12$ e $\ln f=\ln\sigma(\beta)=-\ln(1+e^{-\beta})$. Para $\beta=5$: $\ln(1+e^{-5})\approx0{,}006715$ e $0{,}6931/0{,}006715\approx103$.
:::

Na inicialização padrão do PyTorch, todos os pesos e vieses são sorteados em $\mathcal{U}(-1/\sqrt{H},1/\sqrt{H})$, e com isso as portas começam com valores em torno de $\sigma(0)=\tfrac12$: a memória **começa** com meia-vida de cerca de um passo. A recomendação prática, que remonta a Gers e colegas (2000) e é discutida por Jozefowicz, Zaremba e Sutskever (2015), é **inicializar o viés da porta de esquecimento com um valor positivo**, para que a rede comece lembrando, e deixar o treino aprender a esquecer.

### A GRU

A **GRU** (*gated recurrent unit*, Cho e colegas, 2014) simplifica a LSTM: não há célula separada, e duas portas fazem o trabalho de três.

::: definicao 8.5 · Célula GRU (convenção do PyTorch)
$$\begin{aligned}
\mathbf{r}_t&=\sigma(\mathbf{W}_r\mathbf{x}_t+\mathbf{U}_r\mathbf{h}_{t-1}+\mathbf{b}_r)&&\text{porta de reinício}\\
\mathbf{z}_t&=\sigma(\mathbf{W}_z\mathbf{x}_t+\mathbf{U}_z\mathbf{h}_{t-1}+\mathbf{b}_z)&&\text{porta de atualização}\\
\mathbf{n}_t&=\tanh\bigl(\mathbf{W}_n\mathbf{x}_t+\mathbf{b}_{n}+\mathbf{r}_t\odot(\mathbf{U}_n\mathbf{h}_{t-1}+\mathbf{b}_{hn})\bigr)&&\text{candidato}\\
\mathbf{h}_t&=(1-\mathbf{z}_t)\odot\mathbf{n}_t+\mathbf{z}_t\odot\mathbf{h}_{t-1}&&\text{interpolação}
\end{aligned}$$
:::

A última linha é uma **interpolação convexa**: com $\mathbf{z}_t\approx\mathbf{1}$, o estado é **copiado** do passo anterior, e com $\mathbf{z}_t\approx\mathbf{0}$, é substituído pelo candidato. O caminho direto tem jacobiano $\operatorname{diag}(\mathbf{z}_t)$, o mesmo papel de $\operatorname{diag}(\mathbf{f}_t)$ na LSTM, e a mesma recomendação vale: viés positivo na porta $\mathbf{z}$ (no PyTorch, o segundo bloco de pesos, na ordem $(\mathbf{r},\mathbf{z},\mathbf{n})$). A porta $\mathbf{r}_t$ controla o quanto do estado passado entra no candidato. Com três blocos em vez de quatro, a GRU tem $25\%$ menos parâmetros que a LSTM de mesmo $H$ (Proposição 8.1). Outras autoras e autores escrevem a interpolação com $\mathbf{z}_t$ e $1-\mathbf{z}_t$ trocados; ao ler um artigo, confira qual convenção ele usa.

### Medindo o gradiente nas três células

O programa a seguir mede, para $T=100$ e $H=32$, a norma de $\partial\mathrm{perda}/\partial\mathbf{x}_{T-k}$ (o gradiente em relação à entrada $k$ passos antes de uma perda definida sobre o **último** estado, a soma dos seus quadrados), em média sobre $10$ sorteios de pesos e $16$ sequências aleatórias, para RNN, GRU e LSTM com a inicialização padrão e com o viés da porta de esquecimento (LSTM) ou de atualização (GRU) **fixado em $5$**.

<<< codigo/c8_gradiente_modelos.py

>>> codigo/c8_gradiente_modelos.out

<figure>
+++ fig_c8_gradiente_modelos.svg
<figcaption><b>Figura 8.4.</b> Norma do gradiente em relação à entrada a $k$ passos do fim (valores de <code>c8_gradiente_modelos.out</code>; escala logarítmica). A RNN em $k=99$ vale $0$ em ponto flutuante e não aparece no gráfico.</figcaption>
</figure>

Há quatro lições, todas do experimento, e nenhuma delas é "a LSTM resolve o problema":

1. **Com a inicialização padrão, as três células perdem o gradiente.** Em $k=50$, a RNN tem $2\times10^{-13}$, a GRU $4\times10^{-11}$ e a LSTM $7\times10^{-12}$. A GRU e a LSTM são melhores que a RNN por poucas ordens de grandeza, mas a queda é exponencial nas três. As portas existem; é preciso que **estejam abertas**.
2. **Com o viés alto, a diferença é qualitativa.** A GRU com o viés de $z$ em $5$ mantém a norma em torno de $10^{-3}$ de $k=1$ a $k=99$ (de $1{,}3\times10^{-3}$ a $7{,}0\times10^{-4}$). A LSTM com o viés de $f$ em $5$ mantém em torno de $4\times10^{-2}$ a $6\times10^{-1}$: **sem decaimento**.
3. **O gradiente não é de graça.** Na GRU com $z\approx1$, a norma em $k=1$ é pequena ($1{,}3\times10^{-3}$, contra $2{,}5\times10^{-1}$ na GRU padrão): como a célula quase só copia o estado, a entrada mais recente quase não o altera. O custo da memória longa é uma adaptação lenta ao curto prazo.
4. **Um resultado inesperado.** Na LSTM com $f$ alto, a norma em $k=99$ ($6{,}4\times10^{-1}$) é *maior* do que em $k=1$ ($7{,}1\times10^{-2}$). Não isolei a causa. Uma leitura plausível, que não verifiquei, é que a memória quase não esquece e acumula contribuições de todas as entradas, enquanto os termos entre colchetes do Teorema 8.4 somam muitos caminhos indiretos. O ponto que importa aqui é que o gradiente **não** decai.

## 8.5 Prática com sequências

### Comprimentos diferentes: preenchimento, empacotamento e máscaras

Em um lote, as sequências têm comprimentos distintos. O recurso usual é **preencher** (*pad*) as mais curtas com zeros até o comprimento máximo. Se, porém, a rede lê esses zeros como entrada real, o estado final fica contaminado. Há duas soluções, e o programa abaixo as compara com a referência (cada sequência processada sozinha).

<<< codigo/c8_empacotamento.py

>>> codigo/c8_empacotamento.out

Lido ingenuamente depois dos zeros, o estado final erra em $0{,}22$ nas duas sequências mais curtas (a mais longa, sem preenchimento, está correta). Com `pack_padded_sequence`, que informa à rede o comprimento verdadeiro de cada sequência, o erro é de arredondamento; o mesmo vale para a **máscara**, que lê a saída no último passo válido de cada sequência. Na **perda**, o mesmo cuidado vale: posições de preenchimento não devem contribuir (em `CrossEntropyLoss`, o argumento `ignore_index` serve a isso).

### Camadas bidirecionais e empilhadas

- **Bidirecional** (`bidirectional=True`): duas células, uma que lê a sequência do início ao fim e outra do fim ao início; suas saídas são concatenadas, e a saída tem dimensão $2H$ (o programa da seção 8.2 confirma o formato $(3,5,12)$). Serve quando a sequência **inteira** está disponível (classificação de texto, marcação de palavras) e é **inadequada** quando o futuro não existe no momento da previsão (geração, previsão de séries).
- **Empilhadas** (`num_layers>1`): a saída da camada $l$ é a entrada da camada $l+1$. O argumento `dropout` aplica o *dropout* **entre** camadas, e não dentro da recorrência.

### Outras práticas de treino

- **Recorte de gradiente** (Definição 8.3), quase sempre. O Projeto 6 usa $c=1$.
- **BPTT truncada:** para sequências muito longas, divide-se em trechos de $K$ passos, propaga-se o estado de um trecho ao seguinte, mas **interrompe-se** o gradiente na fronteira (`h = h.detach()`). A memória cai de $O(T)$ para $O(K)$, ao custo de o gradiente não atravessar os trechos.
- **Forçamento do professor** (*teacher forcing*): ao treinar um modelo que gera sequências, alimenta-se o passo $t+1$ com o valor **real** do passo $t$, e não com o previsto. Isso estabiliza o treino, mas cria uma discrepância na geração, em que o modelo vê as próprias previsões (*exposure bias*).
- **Inicialização:** viés positivo na porta de esquecimento ou de atualização (seção 8.4); uma $\mathbf{W}_{hh}$ ortogonal, que mantém os valores singulares em $1$ no início, é uma alternativa para a RNN simples, embora a $\tanh$ ainda comprima o gradiente (Figura 8.2).

### Do estado fixo à atenção

Para **sequência-para-sequência** (tradução, por exemplo), a abordagem recorrente clássica usa um **codificador**, uma RNN que lê a entrada e a resume em seu estado final, e um **decodificador**, outra RNN que gera a saída a partir desse resumo (Sutskever, Vinyals e Le, 2014; Cho e colegas, 2014). Todo o conteúdo da entrada precisa caber em um vetor de tamanho fixo $\mathbf{h}_T$: um **gargalo** que se agrava com $T$. Bahdanau, Cho e Bengio (2015) propuseram deixar o decodificador **consultar** todos os estados do codificador, $\mathbf{h}_1,\dots,\mathbf{h}_T$, ponderando-os a cada passo. Esse foi o primeiro **mecanismo de atenção** em tradução neural, e é o ponto de partida do Capítulo 9. Há ainda uma razão computacional: a recorrência obriga a calcular $\mathbf{h}_t$ somente depois de $\mathbf{h}_{t-1}$, o que impede paralelizar ao longo do tempo, e a informação entre as posições $s$ e $t$ percorre $t-s$ passos, enquanto a atenção as conecta diretamente.
