"""Figuras do Capítulo 10 (SVG). Lê as saídas reais dos programas em codigo/."""
import re
from figs_c6 import painel, curva, legenda, salvar, fmt  # noqa: F401

# ---------- Figura 10.1: tokens por mil bytes vs número de fusões ----------
K, T = [], []
for lin in open("codigo/c10_bpe_manual.out"):
    m = re.match(r"^\s*(\d+)\s+([0-9.]+)\s+([0-9.]+)\s*$", lin)
    if m:
        K.append(int(m.group(1))); T.append(float(m.group(2)))
c = []
s, X, Y = painel(70, 20, 520, 250, 0, 800, 300, 1000, [0, 100, 200, 400, 600, 800], [300, 400, 500, 600, 700, 800, 900, 1000], "número de fusões K (vocabulário = 256 + K)", "tokens por mil bytes (validação)")
c += s
c.append(curva(X, Y, K, T, "lv"))
for k, t in zip(K, T):
    c.append(f'<circle cx="{fmt(X(k))}" cy="{fmt(Y(t))}" r="4" style="fill:var(--papel);stroke-width:2" class="lv"/>')
    c.append(f'<text class="t2" x="{fmt(X(k)+8)}" y="{fmt(Y(t)-8)}" font-size="11">{str(t).replace(".", ",")}</text>')
salvar("fig_c10_bpe.svg", 640, 310, "Número de tokens por mil bytes na validação em função do número de fusões do BPE: cai de 1000 para 349 com retornos decrescentes", c)
print("fig_c10_bpe ok")

# ---------- Figura 10.2: o compromisso entre aprender o domínio novo e esquecer o antigo ----------
import json
import math

R = [json.loads(l) for l in open("codigo/p7_resultados.jsonl")]
base_o, base_a = 57.07, 83.8                                      # modelo pré-treinado sem ajuste (validação; p7_pretreino.out)
comp = sorted([(r["lr"], r["orig_va"], r["alvo_va"]) for r in R if r["etapa"] in ("varredura", "varredura2") and r["metodo"] == "completo"])
lora4 = sorted([(r["lr"], r["orig_va"], r["alvo_va"]) for r in R if r["etapa"] in ("varredura", "varredura2") and r["metodo"] == "lora" and r["lr"] <= 3e-2])
fin = {}
for r in R:
    if r["etapa"] == "final" and r["metodo"] == "lora":
        fin.setdefault(r["r"], []).append((r["orig_va"], r["alvo_va"]))
fin = {k: (sum(a for a, _ in v) / len(v), sum(b for _, b in v) / len(v)) for k, v in fin.items()}
c = []
s, X, Y = painel(70, 20, 520, 270, 50, 130, 45, 90, [50, 60, 70, 80, 90, 100, 110, 120, 130], [45, 55, 65, 75, 85], "perplexidade no domínio de origem (validação): menor = esqueceu menos", "perplexidade no domínio-alvo (validação)")
c += s
pts = [(o, a) for _, o, a in comp if o <= 130]
c.append(curva(X, Y, [p[0] for p in pts], [p[1] for p in pts], "lv"))
for lr, o, a in comp:
    if o <= 130:
        c.append(f'<circle cx="{fmt(X(o))}" cy="{fmt(Y(a))}" r="4.5" class="lv" style="fill:var(--papel);stroke-width:2"/>')
        dx, anc = (-8, "end") if lr < 5e-5 else (7, "start")
        c.append(f'<text class="t2" x="{fmt(X(o)+dx)}" y="{fmt(Y(a)+(4 if lr < 5e-5 else -7))}" font-size="10" text-anchor="{anc}">{lr:.0e}</text>')
pts = [(o, a) for _, o, a in lora4]
c.append(curva(X, Y, [p[0] for p in pts], [p[1] for p in pts], "la", "6 3"))
for lr, o, a in lora4:
    c.append(f'<rect x="{fmt(X(o)-4)}" y="{fmt(Y(a)-4)}" width="8" height="8" class="la" style="fill:var(--papel);stroke-width:2"/>')
for rr, (o, a) in sorted(fin.items()):
    c.append(f'<polygon points="{fmt(X(o))},{fmt(Y(a)-6)} {fmt(X(o)+6)},{fmt(Y(a)+5)} {fmt(X(o)-6)},{fmt(Y(a)+5)}" class="lg" style="stroke-width:2"/>')
    c.append(f'<text x="{fmt(X(o)+9)}" y="{fmt(Y(a)+16)}" font-size="11">r={rr}</text>')
c.append(f'<circle cx="{fmt(X(base_o))}" cy="{fmt(Y(base_a))}" r="6" class="lr" style="stroke-width:2.5"/><text x="{fmt(X(base_o)+10)}" y="{fmt(Y(base_a)+4)}" font-size="12">sem ajuste</text>')
c += legenda([("lv", "ajuste completo (taxa de aprendizado)", None), ("la", "LoRA r=4 (taxa de aprendizado)", "6 3")], 40, 338, 280)
c.append(f'<polygon points="62,358 68,369 56,369" class="lg" style="stroke-width:2"/><text x="76" y="368" font-size="13">LoRA r=1 e r=16 (taxa 1e-2; média de 3 sementes)</text>')
salvar("fig_c10_compromisso.svg", 640, 384, "Perplexidade no domínio-alvo contra perplexidade no domínio de origem para o ajuste completo e a LoRA em várias taxas de aprendizado", c)

# ---------- Figura 10.3: quantização pós-treino ----------
Q = {}
for lin in open("codigo/p7_quant.out"):
    m = re.match(r"^\s*(\d)\s+(tensor|canal|bloco)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+", lin)
    if m:
        Q.setdefault(m.group(2), []).append((float(m.group(3)), float(m.group(5))))
lg = lambda v: math.log10(v)
c = []
tk = [lg(v) for v in (60, 100, 200, 400, 800)]
s, X, Y = painel(70, 20, 520, 250, 1.5, 9, lg(50), lg(900), [2, 3, 4, 5, 6, 7, 8], tk, "bits por peso (incluindo as escalas)", "perplexidade (origem, validação)", lambda v: f"{10 ** v:.0f}")
c += s
c.append(f'<line class="fraco" x1="70" y1="{fmt(Y(lg(57.07)))}" x2="590" y2="{fmt(Y(lg(57.07)))}" style="stroke:var(--rubi);stroke-dasharray:2 4"/><text x="400" y="{fmt(Y(lg(57.07))-6)}" font-size="11" text-anchor="middle" class="t2">fp32 (57,07)</text>')
for modo, cls, dash in (("tensor", "lv", None), ("canal", "la", "6 3"), ("bloco", "lg", None)):
    pts = sorted(Q[modo])
    c.append(curva(X, Y, [p[0] for p in pts], [lg(p[1]) for p in pts], cls, dash))
    for b, p in pts:
        c.append(f'<circle cx="{fmt(X(b))}" cy="{fmt(Y(lg(p)))}" r="3.5" class="{cls}" style="fill:var(--papel);stroke-width:2"/>')
c += legenda([("lv", "escala por tensor", None), ("la", "por canal", "6 3"), ("lg", "por bloco de 64", None)], 40, 318, 190)
salvar("fig_c10_quant.svg", 640, 340, "Perplexidade do modelo pré-treinado depois da quantização dos pesos dos blocos, em função dos bits por peso, com escala por tensor, por canal e por bloco", c)

# ---------- Figura 10.4: energia retida pelos primeiros r valores singulares da atualização ----------
E = {}
nome = None
for lin in open("codigo/p7_svd.out"):
    if lin.startswith("ajuste completo"):
        nome = "completo"
    elif lin.startswith("LoRA"):
        nome = "lora"
    m = re.match(r"^\s*(\d+)\s+([0-9.]+)%\s+([0-9.]+)%\s+([0-9.]+)%\s+([0-9.]+)%", lin)
    if m and nome:
        E.setdefault(nome, []).append((int(m.group(1)), float(m.group(2)), float(m.group(5))))
c = []
s, X, Y = painel(70, 20, 520, 250, 0, 16, 0, 100, [1, 2, 4, 8, 16], [0, 20, 40, 60, 80, 100], "posto r (matrizes dos blocos têm posto máximo 128)", "energia retida pelos r primeiros valores singulares (%)")
c += s
for chave, cls, dash in (("completo", "lv", None), ("lora", "la", "6 3")):
    c.append(curva(X, Y, [p[0] for p in E[chave]], [p[1] for p in E[chave]], cls, dash))
    for r, e, _ in E[chave]:
        c.append(f'<circle cx="{fmt(X(r))}" cy="{fmt(Y(e))}" r="3.5" class="{cls}" style="fill:var(--papel);stroke-width:2"/>')
c.append(curva(X, Y, [p[0] for p in E["completo"]], [p[2] for p in E["completo"]], "lr", "2 4"))
c += legenda([("lv", "ajuste completo", None), ("la", "LoRA r=16 (fundida)", "6 3"), ("lr", "aleatória (controle)", "2 4")], 40, 318, 200)
salvar("fig_c10_svd.svg", 640, 340, "Energia retida pelos r primeiros valores singulares da atualização dos pesos no ajuste completo e na LoRA de posto 16, comparada a uma matriz aleatória", c)
print("figs c10 ok")
