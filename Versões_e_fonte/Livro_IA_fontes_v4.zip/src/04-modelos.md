<div class="objetivos">

Objetivos do capítulo

- Derivar os estimadores de mínimos quadrados da regressão linear simples e múltipla e interpretá-los geometricamente.
- Ler coeficientes, erros padrão, p-valores e $R^2$ sem cometer os enganos mais comuns.
- Derivar a regressão logística por máxima verossimilhança e interpretar odds e odds ratio.
- Explicar o funcionamento do KNN e das árvores de decisão, com impureza de Gini, entropia e poda.
- Implementar cada modelo de forma didática e com as bibliotecas profissionais, e comparar os resultados.

**Pré-requisitos:** Capítulos 1 e 3.

</div>

## 4.1 Quatro respostas para a mesma pergunta

O Capítulo 3 deixou uma tarefa: estimar a média condicional $\mathbb{E}[Y\mid X=x]$, em regressão, ou as probabilidades $P(Y=j\mid X=x)$, em classificação. Este capítulo apresenta quatro modelos clássicos que a cumprem de maneiras diferentes.

| Modelo | Tipo | Hipótese sobre $f$ | Uso principal |
|---|---|---|---|
| Regressão linear | Paramétrico | Linear nas preditoras | Regressão |
| Regressão logística | Paramétrico | Log-odds lineares nas preditoras | Classificação |
| K-vizinhos mais próximos | Não paramétrico | Suavidade local | Ambos |
| Árvore de decisão | Não paramétrico | Constante por regiões retangulares | Ambos |

Eles não são peças de museu. Em dados tabulares, continuam competitivos e frequentemente são a escolha correta. Além disso, cada um introduz uma ideia que reaparece adiante: a regressão logística é um neurônio (Capítulo 6); a busca de vizinhos é o mecanismo de recuperação dos sistemas RAG (Capítulo 12); e as árvores são a base dos métodos de conjunto que dominam aplicações tabulares.

## 4.2 Regressão linear simples

### Modelo

Com uma única preditora, supõe-se

$$
Y = \beta_0+\beta_1X+\varepsilon,
$$

em que $\beta_0$ é o **intercepto** (valor esperado de $Y$ quando $X=0$) e $\beta_1$ é a **inclinação** (variação esperada de $Y$ por unidade de $X$). Os dois parâmetros são desconhecidos e devem ser estimados a partir de pares $(x_1,y_1),\dots,(x_n,y_n)$.

### Mínimos quadrados

Para valores candidatos $b_0$ e $b_1$, o **resíduo** do exemplo $i$ é $e_i = y_i-(b_0+b_1x_i)$. O método dos Mínimos Quadrados Ordinários (*Ordinary Least Squares*, OLS) escolhe os valores que minimizam a **soma dos quadrados dos resíduos** (*Residual Sum of Squares*, RSS):

$$
\operatorname{RSS}(b_0,b_1) = \sum_{i=1}^n\bigl(y_i-b_0-b_1x_i\bigr)^2 .
$$

::: teorema 4.1 · Estimadores de mínimos quadrados na regressão simples
Se os $x_i$ não são todos iguais, a RSS tem um único minimizador:

$$
\hat\beta_1 = \frac{\sum_{i=1}^n(x_i-\bar x)(y_i-\bar y)}{\sum_{i=1}^n(x_i-\bar x)^2},\qquad \hat\beta_0 = \bar y-\hat\beta_1\bar x ,
$$

em que $\bar x$ e $\bar y$ são as médias amostrais.
:::

::: demonstracao
Igualando a zero as derivadas parciais da RSS:

$$
\frac{\partial\operatorname{RSS}}{\partial b_0} = -2\sum_i(y_i-b_0-b_1x_i) = 0,\qquad \frac{\partial\operatorname{RSS}}{\partial b_1} = -2\sum_ix_i(y_i-b_0-b_1x_i) = 0 .
$$

A primeira equação dá $b_0 = \bar y-b_1\bar x$. Substituindo na segunda: $\sum_ix_i\bigl((y_i-\bar y)-b_1(x_i-\bar x)\bigr) = 0$. Como $\sum_i\bar x\,(y_i-\bar y) = 0$ e $\sum_i\bar x\,(x_i-\bar x)=0$, pode-se trocar $x_i$ por $x_i-\bar x$ no fator externo, o que fornece a expressão de $\hat\beta_1$. A Hessiana da RSS é $2\begin{bmatrix}n&\sum x_i\\\sum x_i&\sum x_i^2\end{bmatrix}$, definida positiva quando os $x_i$ não são todos iguais; pelo Teorema 1.6 e pela convexidade, o ponto crítico é o mínimo global.
:::

As fórmulas têm leitura direta. A inclinação é a covariância amostral entre $x$ e $y$ dividida pela variância amostral de $x$. E a primeira equação normal diz duas coisas: os resíduos somam zero, e a reta ajustada passa pelo ponto $(\bar x,\bar y)$.

::: exemplo 4.1 · Regressão simples feita à mão
Dados: $x = (1,2,3,4,5)$ e $y = (2{,}1;\ 3{,}9;\ 6{,}2;\ 7{,}8;\ 10{,}1)$. Médias: $\bar x = 3$, $\bar y = 6{,}02$.

| $x_i-\bar x$ | $y_i-\bar y$ | produto | $(x_i-\bar x)^2$ |
|---|---|---|---|
| $-2$ | $-3{,}92$ | $7{,}84$ | 4 |
| $-1$ | $-2{,}12$ | $2{,}12$ | 1 |
| $0$ | $0{,}18$ | $0$ | 0 |
| $1$ | $1{,}78$ | $1{,}78$ | 1 |
| $2$ | $4{,}08$ | $8{,}16$ | 4 |

Somas: $19{,}90$ e $10$. Logo $\hat\beta_1 = 1{,}99$ e $\hat\beta_0 = 6{,}02-1{,}99\times3 = 0{,}05$. A reta ajustada é $\hat y = 0{,}05+1{,}99\,x$: cada unidade a mais em $x$ associa-se a um aumento médio de $1{,}99$ em $y$.
:::

## 4.3 Regressão linear múltipla

### Modelo em forma matricial

Com $d$ preditoras, o modelo é $Y = \beta_0+\beta_1X_1+\dots+\beta_dX_d+\varepsilon$. Reunindo os $n$ exemplos em uma matriz $\mathbf{X}\in\mathbb{R}^{n\times p}$, com uma primeira coluna de uns para o intercepto e $p = d+1$, e os parâmetros em $\boldsymbol\beta\in\mathbb{R}^p$:

$$
\mathbf{y} = \mathbf{X}\boldsymbol\beta+\boldsymbol\varepsilon ,\qquad \operatorname{RSS}(\boldsymbol\beta) = \lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert_2^2 .
$$

::: teorema 4.2 · Equações normais
Se as colunas de $\mathbf{X}$ são linearmente independentes, a RSS tem um único minimizador, solução das **equações normais**

$$
\mathbf{X}^\top\mathbf{X}\,\hat{\boldsymbol\beta} = \mathbf{X}^\top\mathbf{y},\qquad\text{isto é,}\qquad \hat{\boldsymbol\beta} = (\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top\mathbf{y}.
$$
:::

::: demonstracao
Pelo Exemplo 1.5, $\nabla\operatorname{RSS}(\boldsymbol\beta) = 2\mathbf{X}^\top(\mathbf{X}\boldsymbol\beta-\mathbf{y})$, que se anula exatamente nas soluções das equações normais. A Hessiana é $2\mathbf{X}^\top\mathbf{X}$. Para $\mathbf{v}\ne\mathbf{0}$, $\mathbf{v}^\top\mathbf{X}^\top\mathbf{X}\mathbf{v} = \lVert\mathbf{X}\mathbf{v}\rVert_2^2>0$, pois colunas independentes implicam $\mathbf{X}\mathbf{v}\neq\mathbf{0}$. A Hessiana é definida positiva, logo invertível, a função é estritamente convexa e o ponto crítico é o único mínimo global.
:::

A hipótese de colunas independentes falha quando uma preditora é combinação linear exata de outras (**colinearidade perfeita**), por exemplo ao incluir a mesma medida em duas unidades. Nesse caso há infinitas soluções. Quando as colunas são quase dependentes, a solução existe, mas $\mathbf{X}^\top\mathbf{X}$ é mal condicionada (seção 1.7) e os coeficientes tornam-se instáveis.

### Interpretação geométrica

A geometria esclarece o que os mínimos quadrados fazem. O vetor $\mathbf{y}$ vive em $\mathbb{R}^n$. Os vetores da forma $\mathbf{X}\boldsymbol\beta$ formam o **espaço coluna** de $\mathbf{X}$ (seção 1.3), um subespaço de dimensão $p$. Minimizar $\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert_2$ é procurar, nesse subespaço, o ponto mais próximo de $\mathbf{y}$. Esse ponto é a **projeção ortogonal** de $\mathbf{y}$:

$$
\hat{\mathbf{y}} = \mathbf{X}\hat{\boldsymbol\beta} = \underbrace{\mathbf{X}(\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top}_{\mathbf{H}}\,\mathbf{y}.
$$

<figure>
<svg class="fig" viewBox="0 0 640 270" role="img" aria-label="O vetor y é projetado ortogonalmente sobre o plano gerado pelas colunas de X; o resíduo é perpendicular ao plano">
<defs><marker id="seta4" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pt"/></marker><marker id="seta4a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pa"/></marker></defs>
<polygon class="cx" points="60,210 430,210 580,120 210,120"/>
<text x="436" y="200" font-size="13" class="t2">espaço coluna de X</text>
<line class="lv" x1="150" y1="190" x2="400" y2="160" marker-end="url(#seta4)"/>
<line class="lv" x1="150" y1="190" x2="400" y2="40" marker-end="url(#seta4)"/>
<line class="la" x1="400" y1="160" x2="400" y2="46" stroke-dasharray="6 4" marker-end="url(#seta4a)"/>
<path class="ln" d="M400 146H386V161"/>
<text x="410" y="38" font-size="15" font-weight="700">y</text>
<text x="408" y="178" font-size="15" font-weight="700">ŷ = Hy</text>
<text x="410" y="104" font-size="14">resíduo r = y − ŷ</text>
<text x="132" y="206" font-size="13" class="t2">0</text>
</svg>
<figcaption><b>Figura 4.1.</b> Mínimos quadrados como projeção. O vetor de valores ajustados é o ponto do espaço coluna mais próximo de <b>y</b>, e o resíduo é perpendicular a esse espaço.</figcaption>
</figure>

A matriz $\mathbf{H}$ é chamada **matriz chapéu**, porque "põe o chapéu" em $\mathbf{y}$. Ela é simétrica e satisfaz $\mathbf{H}^2 = \mathbf{H}$: projetar duas vezes é o mesmo que projetar uma. O resíduo $\mathbf{r} = \mathbf{y}-\hat{\mathbf{y}}$ é perpendicular ao subespaço, o que equivale a

$$
\mathbf{X}^\top\mathbf{r} = \mathbf{0}.
$$

Essa é a mesma equação normal, lida de outra forma: **o resíduo não tem correlação amostral com nenhuma preditora**. O que as preditoras podiam explicar linearmente, já explicaram. É a condição verificada no teste 4 do Projeto 1.

O teorema de Pitágoras, aplicado ao triângulo retângulo da figura depois de subtrair a média, fornece a decomposição que define o $R^2$ na próxima seção.

### Interpretação dos coeficientes

Na regressão múltipla, $\hat\beta_j$ é a variação média de $Y$ associada a uma unidade a mais em $X_j$, **mantidas fixas as demais preditoras**. A ressalva final muda tudo em relação à regressão simples.

::: erro Ler um coeficiente da regressão múltipla como efeito isolado ou causal
O coeficiente de uma variável pode mudar de valor, e até de sinal, quando outra variável entra no modelo, se as duas forem correlacionadas. E "associada a" não significa "causa": a regressão descreve como a média de $Y$ varia com $X$ nos dados observados. Afirmar que intervir em $X_j$ alteraria $Y$ exige hipóteses adicionais ou experimento controlado.
:::

## 4.4 Interpretação estatística: erros padrão, p-valores e R²

### Os coeficientes são variáveis aleatórias

Outro conjunto de dados, do mesmo fenômeno, produziria outros coeficientes. A inferência estatística quantifica essa variação. Ela requer hipóteses além das usadas até aqui:

1. **Linearidade:** $\mathbf{y} = \mathbf{X}\boldsymbol\beta+\boldsymbol\varepsilon$, com $\mathbf{X}$ tratada como fixa.
2. **Erros de média zero** e **não correlacionados**, com **variância constante** $\sigma^2$ (homocedasticidade): a matriz de covariância de $\boldsymbol\varepsilon$ é $\sigma^2\mathbf{I}$.
3. Para testes e intervalos exatos: **erros Gaussianos**.

::: proposicao 4.3 · Média e covariância do estimador de mínimos quadrados
Sob as hipóteses 1 e 2, $\mathbb{E}[\hat{\boldsymbol\beta}] = \boldsymbol\beta$ e a matriz de covariância de $\hat{\boldsymbol\beta}$ é $\sigma^2(\mathbf{X}^\top\mathbf{X})^{-1}$.
:::

::: demonstracao
Substituindo o modelo no estimador: $\hat{\boldsymbol\beta} = (\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top(\mathbf{X}\boldsymbol\beta+\boldsymbol\varepsilon) = \boldsymbol\beta+\mathbf{A}\boldsymbol\varepsilon$, com $\mathbf{A} = (\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top$. Como $\mathbb{E}[\boldsymbol\varepsilon] = \mathbf{0}$, a esperança é $\boldsymbol\beta$. Pela Proposição 1.11, a covariância é $\mathbf{A}(\sigma^2\mathbf{I})\mathbf{A}^\top = \sigma^2(\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top\mathbf{X}(\mathbf{X}^\top\mathbf{X})^{-1} = \sigma^2(\mathbf{X}^\top\mathbf{X})^{-1}$.
:::

O estimador é **não viesado**: em média, acerta. O teorema de Gauss–Markov acrescenta que, sob essas hipóteses, ele tem a menor variância entre todos os estimadores lineares não viesados. A ressalva é importante: estimadores **viesados**, como os do Capítulo 5, podem ter erro total menor.

### Erro padrão, estatística t e p-valor

A variância do ruído é estimada por $\hat\sigma^2 = \operatorname{RSS}/(n-p)$, em que a divisão por $n-p$, e não por $n$, compensa os $p$ parâmetros ajustados. O **erro padrão** do coeficiente $j$ é a raiz do elemento correspondente da diagonal:

$$
\operatorname{EP}(\hat\beta_j) = \sqrt{\hat\sigma^2\,\bigl[(\mathbf{X}^\top\mathbf{X})^{-1}\bigr]_{jj}}.
$$

Ele mede quanto $\hat\beta_j$ variaria entre amostras. Um **intervalo de confiança** aproximado de 95% é $\hat\beta_j\pm2\operatorname{EP}(\hat\beta_j)$.

Para avaliar se há evidência de associação entre $X_j$ e $Y$, testa-se a **hipótese nula** $H_0:\beta_j = 0$ com a estatística

$$
t_j = \frac{\hat\beta_j}{\operatorname{EP}(\hat\beta_j)},
$$

que, sob $H_0$ e erros Gaussianos, segue a distribuição $t$ de Student com $n-p$ graus de liberdade.

::: definicao 4.1 · p-valor
O **p-valor** é a probabilidade, calculada supondo a hipótese nula verdadeira, de obter uma estatística de teste tão ou mais extrema do que a observada.
:::

Um p-valor pequeno indica que os dados seriam surpreendentes se $\beta_j$ fosse zero. Por convenção, e apenas por convenção, usa-se com frequência o limiar de $0{,}05$.

::: erro Quatro leituras erradas do p-valor
1. **"É a probabilidade de a hipótese nula ser verdadeira."** O p-valor é $P(\text{dados}\mid H_0)$, e não $P(H_0\mid\text{dados})$. É a inversão de condicional do Capítulo 1.
2. **"p pequeno significa efeito grande."** Com $n$ grande, efeitos minúsculos têm p-valores minúsculos. O tamanho do efeito está no coeficiente e em seu intervalo.
3. **"p grande prova que não há efeito."** Ausência de evidência não é evidência de ausência; o estudo pode ter poucos dados.
4. **"Testei 20 variáveis e uma deu p < 0,05."** Sob a hipótese nula, isso é esperado por acaso. Comparações múltiplas exigem correção.

A Associação Americana de Estatística publicou uma declaração específica sobre esses equívocos (Wasserstein e Lazar, 2016).
:::

### Coeficiente de determinação

Seja $\operatorname{TSS} = \sum_i(y_i-\bar y)^2$ a soma total dos quadrados: a RSS do modelo que só tem intercepto e prevê sempre $\bar y$.

::: definicao 4.2 · Coeficiente de determinação
$$
R^2 = 1-\frac{\operatorname{RSS}}{\operatorname{TSS}} .
$$
:::

O $R^2$ é a fração da variabilidade de $y$, em torno da média, que o modelo explica nos dados de ajuste. Vale 0 quando o modelo não melhora a previsão pela média e 1 quando o ajuste é perfeito. Na regressão simples, coincide com o quadrado da correlação entre $x$ e $y$.

::: atencao O R² de treinamento nunca diminui ao acrescentar variáveis
Acrescentar uma coluna a $\mathbf{X}$ amplia o espaço coluna, e a projeção em um espaço maior nunca fica mais longe de $\mathbf{y}$. O $R^2$ cresce, ou fica igual, mesmo que a nova variável seja ruído puro. Por isso ele não serve para comparar modelos com números diferentes de preditoras. O $R^2$ ajustado, $1-\frac{\operatorname{RSS}/(n-d-1)}{\operatorname{TSS}/(n-1)}$, penaliza o número de variáveis; a solução geral é avaliar em dados não usados no ajuste (Capítulo 5).

Não existe valor de $R^2$ universalmente "bom". Em física experimental, $0{,}9$ pode ser fraco; em comportamento humano, $0{,}2$ pode ser informativo.
:::

### Implementação

<<< codigo/c4_ols.py

>>> codigo/c4_ols.out

O programa confirma o Exemplo 4.1 e depois ajusta, ao conjunto *diabetes* do scikit-learn (442 pacientes), um modelo com três preditoras: índice de massa corporal, pressão arterial e uma medida sérica. As quatro quantidades calculadas à mão coincidem com as do `statsmodels`, que é o **código de produção** quando se quer inferência; o scikit-learn, voltado à previsão, não calcula erros padrão.

Leitura da tabela. Os três coeficientes têm p-valores muito pequenos: há forte evidência de associação com a progressão da doença. Os valores numéricos dos coeficientes são grandes porque, nesse conjunto, as colunas já vêm centradas e reescaladas pelos autores; eles não se leem "por unidade" da medida original. O $R^2$ de $0{,}48$ diz que o modelo explica cerca de metade da variabilidade, e que a outra metade está em variáveis não incluídas, em relações não lineares ou em ruído.

::: atencao As hipóteses precisam ser examinadas
Erros padrão e p-valores valem sob as hipóteses listadas. O diagnóstico usual é gráfico: resíduos contra valores ajustados. Um padrão curvo indica não linearidade; um formato de funil indica variância não constante; resíduos em sequência temporal com padrão indicam correlação. Nesses casos, os coeficientes ainda podem prever razoavelmente, mas a inferência fica comprometida.
:::

## 4.5 Regressão logística

### Por que não usar a regressão linear

Em classificação binária, codifica-se a resposta como $Y\in\{0,1\}$ e deseja-se estimar $p(x) = P(Y=1\mid X=x)$. Ajustar uma reta diretamente a essa probabilidade tem dois defeitos: a reta produz valores abaixo de 0 e acima de 1, que não são probabilidades, e a hipótese de variância constante é falsa, pois a variância de uma Bernoulli é $p(1-p)$.

### Modelo

A solução é transformar a saída linear por uma função que leve a reta real ao intervalo $(0,1)$.

::: definicao 4.3 · Regressão logística
A **função sigmoide** (ou logística) é

$$
\sigma(z) = \frac{1}{1+e^{-z}} .
$$

O modelo de **regressão logística** supõe

$$
p(\mathbf{x}) = P(Y=1\mid\mathbf{x}) = \sigma(\beta_0+\boldsymbol\beta^\top\mathbf{x}).
$$
:::

A sigmoide é crescente, vale $0{,}5$ em $z=0$, tende a 0 quando $z\to-\infty$ e a 1 quando $z\to+\infty$. Duas propriedades serão usadas repetidamente: $1-\sigma(z) = \sigma(-z)$ e $\sigma'(z) = \sigma(z)\bigl(1-\sigma(z)\bigr)$.

### Odds e odds ratio

::: definicao 4.4 · Odds e logit
A **chance** (*odds*) de um evento de probabilidade $p$ é $p/(1-p)$. O **logit** é o logaritmo da chance, $\log\dfrac{p}{1-p}$.
:::

Probabilidade $0{,}8$ corresponde a chance $4$ ("quatro para um"); probabilidade $0{,}5$, a chance 1. Invertendo a sigmoide, o modelo logístico equivale a

$$
\log\frac{p(\mathbf{x})}{1-p(\mathbf{x})} = \beta_0+\beta_1x_1+\dots+\beta_dx_d .
$$

A regressão logística é, portanto, um modelo **linear no logit**. Disso vem a interpretação dos coeficientes. Aumentar $x_j$ em uma unidade, mantidas as demais, soma $\beta_j$ ao logit e, portanto, **multiplica a chance por $e^{\beta_j}$**. Esse fator é a **razão de chances** (*odds ratio*).

::: exemplo 4.2 · Interpretação de um odds ratio
Se $\beta_j = 0{,}7$, então $e^{0{,}7}\approx2{,}01$: cada unidade a mais em $x_j$ dobra a chance do evento. Se a chance era 1 para 4 (probabilidade $0{,}20$), passa a cerca de 2 para 4 (probabilidade $0{,}33$). Se era 4 para 1 (probabilidade $0{,}80$), passa a 8 para 1 (probabilidade $0{,}89$). O efeito sobre a **chance** é constante; o efeito sobre a **probabilidade** depende do ponto de partida.
:::

::: erro Confundir razão de chances com razão de probabilidades
Um odds ratio de 2 não significa que a probabilidade dobra. As duas razões só se aproximam quando o evento é raro. Relatar "o risco dobrou" a partir de um odds ratio de 2 é um erro frequente em divulgação científica.
:::

### Estimação por máxima verossimilhança

Não há resíduo quadrático natural para respostas binárias. Usa-se a máxima verossimilhança (seção 1.13), com $Y_i\sim\operatorname{Bernoulli}(p_i)$ e $p_i = \sigma(\mathbf{x}_i^\top\boldsymbol\beta)$, incluindo em $\mathbf{x}_i$ o 1 do intercepto. O negativo da log-verossimilhança média é a entropia cruzada binária do Exercício 1.16:

$$
\mathcal{L}(\boldsymbol\beta) = -\frac1n\sum_{i=1}^n\bigl[y_i\log p_i+(1-y_i)\log(1-p_i)\bigr].
$$

::: proposicao 4.4 · Gradiente e Hessiana da regressão logística
Com $\mathbf{p} = (p_1,\dots,p_n)^\top$ e $\mathbf{W} = \operatorname{diag}\bigl(p_i(1-p_i)\bigr)$,

$$
\nabla\mathcal{L}(\boldsymbol\beta) = \frac1n\mathbf{X}^\top(\mathbf{p}-\mathbf{y}),\qquad \mathbf{H}_{\mathcal{L}}(\boldsymbol\beta) = \frac1n\mathbf{X}^\top\mathbf{W}\mathbf{X}.
$$

A Hessiana é semidefinida positiva; logo, $\mathcal{L}$ é convexa.
:::

::: demonstracao
Seja $z_i = \mathbf{x}_i^\top\boldsymbol\beta$. Como $\log p_i = -\log(1+e^{-z_i})$ e $\log(1-p_i) = -z_i-\log(1+e^{-z_i})$, a contribuição do exemplo $i$ é $\ell_i = (1-y_i)z_i+\log(1+e^{-z_i})$. Derivando em $z_i$: $\partial\ell_i/\partial z_i = (1-y_i)-\dfrac{e^{-z_i}}{1+e^{-z_i}} = (1-y_i)-(1-p_i) = p_i-y_i$. Pela regra da cadeia, com $\partial z_i/\partial\boldsymbol\beta = \mathbf{x}_i$, o gradiente de $\ell_i$ é $(p_i-y_i)\mathbf{x}_i$; a média sobre $i$ é $\tfrac1n\mathbf{X}^\top(\mathbf{p}-\mathbf{y})$. Derivando outra vez, com $\partial p_i/\partial z_i = p_i(1-p_i)$, obtém-se $\tfrac1n\sum_ip_i(1-p_i)\,\mathbf{x}_i\mathbf{x}_i^\top = \tfrac1n\mathbf{X}^\top\mathbf{W}\mathbf{X}$. Para qualquer $\mathbf{v}$, $\mathbf{v}^\top\mathbf{X}^\top\mathbf{W}\mathbf{X}\mathbf{v} = \sum_ip_i(1-p_i)(\mathbf{x}_i^\top\mathbf{v})^2\ge0$.
:::

Três observações sobre o resultado.

**O gradiente tem a mesma forma do da regressão linear.** Compare com o Exemplo 1.5: em ambos, é $\mathbf{X}^\top$ vezes (previsão menos resposta). A coincidência decorre de as duas perdas virem da máxima verossimilhança em famílias de distribuições aparentadas, e reaparecerá na camada de saída das redes neurais (Capítulo 6).

**Não há solução em forma fechada.** A equação $\mathbf{X}^\top(\mathbf{p}-\mathbf{y}) = \mathbf{0}$ é não linear em $\boldsymbol\beta$. Resolve-se por métodos iterativos: descida do gradiente ou métodos de segunda ordem.

**A convexidade garante que qualquer mínimo encontrado é global.** Há, porém, um caso em que o mínimo não existe: se as classes são **perfeitamente separáveis** por um hiperplano, a verossimilhança cresce indefinidamente com a norma de $\boldsymbol\beta$, e os coeficientes divergem. A regularização (Capítulo 5) resolve o problema.

### Limite de decisão

Classifica-se como positivo quando $p(\mathbf{x})\ge0{,}5$, o que equivale a $\beta_0+\boldsymbol\beta^\top\mathbf{x}\ge0$. O **limite de decisão** é o conjunto em que a expressão se anula:

$$
\beta_0+\boldsymbol\beta^\top\mathbf{x} = 0 ,
$$

um hiperplano (uma reta, com duas preditoras), perpendicular ao vetor $\boldsymbol\beta$. A regressão logística é um **classificador linear**: a sigmoide curva a probabilidade, mas a fronteira é plana. Outro limiar que não $0{,}5$ desloca a fronteira paralelamente, sem mudar sua orientação.

### Implementação

<<< codigo/c4_logistica.py

>>> codigo/c4_logistica.out

Os dados são do conjunto *breast cancer* de Wisconsin (569 tumores), com duas preditoras padronizadas: raio médio e textura média. A descida do gradiente e o scikit-learn chegam, na prática, à mesma perda e a coeficientes iguais até a segunda casa decimal.

::: atencao O scikit-learn regulariza por padrão
`LogisticRegression()` aplica penalidade $\ell_2$ com intensidade `C=1.0`; os coeficientes que devolve **não** são os de máxima verossimilhança. Para obtê-los, como no programa, usa-se `C=np.inf` (comportamento conferido na versão 1.9). Quem compara coeficientes entre bibliotecas sem saber disso encontra diferenças inexplicáveis.
:::

Interpretação: o odds ratio de $41{,}35$ para o raio diz que, mantida a textura, um desvio padrão a mais no raio multiplica por cerca de 41 a chance de malignidade. O da textura é $2{,}55$. Como as variáveis foram padronizadas, a unidade é o desvio padrão de cada uma.

## 4.6 K-vizinhos mais próximos

### Ideia

O método dos K-vizinhos mais próximos (*K-Nearest Neighbors*, KNN) aplica diretamente o Teorema 3.3. O classificador de Bayes precisa de $P(Y=j\mid X=x_0)$; o KNN estima essa probabilidade pela proporção da classe $j$ entre os $K$ exemplos de treinamento mais próximos de $x_0$.

::: definicao 4.5 · Classificador KNN
Seja $\mathcal{N}_K(x_0)$ o conjunto dos $K$ exemplos de treinamento mais próximos de $x_0$ segundo uma distância, usualmente a euclidiana. O KNN estima

$$
\hat P(Y=j\mid X=x_0) = \frac1K\sum_{i\in\mathcal{N}_K(x_0)}\mathbb{1}[y_i=j]
$$

e prevê a classe de maior proporção. Em regressão, prevê a média das respostas dos vizinhos.
:::

O KNN não tem fase de treinamento: guarda os dados. Todo o custo está na previsão. Por isso é chamado de método **baseado em instâncias**. Não supõe nenhuma forma para a fronteira de decisão, que pode ser arbitrariamente irregular.

### O papel de K

O parâmetro $K$ controla a flexibilidade, em sentido inverso ao que o nome sugere.

- **$K=1$:** cada ponto de treinamento é classificado por si mesmo. O erro de treinamento é zero, e a fronteira contorna cada exemplo, inclusive os ruidosos. Máxima flexibilidade.
- **$K$ grande:** a previsão é uma média sobre regiões amplas. A fronteira torna-se suave e, no limite $K=n$, o modelo prevê sempre a classe majoritária. Mínima flexibilidade.

### Implementação

<<< codigo/c4_knn.py

>>> codigo/c4_knn.out

Três fatos na saída.

**O erro de treinamento não informa a qualidade.** Com $K=1$, a acurácia de treino é 100%, por construção. Só a acurácia de teste diz algo.

**Flexibilidade de menos também custa.** Com $K=151$, a acurácia de teste cai para $0{,}883$: o modelo ficou rígido demais. A escolha de $K$ é um problema de seleção de modelo, tratado no Capítulo 5.

**A escala das variáveis decide quem é vizinho.** Sem padronização, a acurácia de teste com $K=5$ é $0{,}912$; com padronização, $0{,}947$. A distância euclidiana soma diferenças ao quadrado, e uma variável com valores na casa dos milhares domina outra com valores decimais. O padronizador é ajustado apenas no treino e depois aplicado ao teste; ajustá-lo com todos os dados deixaria informação do teste vazar para o modelo.

### Limitações

**Custo.** Cada previsão calcula distâncias a todos os $n$ exemplos. Com milhões de exemplos, usam-se estruturas de busca aproximada, as mesmas dos bancos vetoriais do Capítulo 12.

**Maldição da dimensionalidade.** Em dimensão alta, "vizinho próximo" deixa de significar "parecido". Com pontos uniformes em um cubo de lado 1 em $\mathbb{R}^d$, uma vizinhança cúbica que contenha 1% dos dados precisa de lado $0{,}01^{1/d}$. Para $d=2$, isso é $0{,}1$. Para $d=10$, é $0{,}63$: a vizinhança "local" cobre quase dois terços da amplitude de cada variável. Com $d=100$, cobre $0{,}95$. O número de exemplos necessário para manter vizinhanças realmente locais cresce exponencialmente com $d$.

::: aplicacao Por que a busca vetorial funciona apesar disso
A maldição vale para dados que preenchem o espaço. *Embeddings* aprendidos por redes neurais concentram-se em regiões de dimensão efetiva muito menor, organizadas de modo que proximidade corresponda a semelhança de significado. A busca de vizinhos volta a ser útil porque a representação foi **aprendida** para isso. Essa é uma das razões do sucesso do Aprendizado Profundo: em vez de escolher a distância, aprende-se o espaço.
:::

## 4.7 Árvores de decisão

### Ideia

Uma árvore de decisão divide o espaço das preditoras em regiões retangulares por uma sequência de perguntas do tipo "$x_j\le s$?" e faz a mesma previsão para todos os pontos de uma região: a classe majoritária, em classificação, ou a média das respostas, em regressão. Cada pergunta é um **nó interno**; cada região final é uma **folha**.

O atrativo é a interpretabilidade: o modelo é uma lista de regras que uma pessoa lê. Árvores aceitam variáveis numéricas e categóricas, não exigem padronização (uma pergunta "$x_j\le s$?" não muda se $x_j$ for reescalada) e capturam interações entre variáveis.

### Como a árvore é construída

Encontrar a árvore ótima é computacionalmente inviável. Usa-se a **divisão binária recursiva**, um algoritmo guloso: em cada nó, examinam-se todas as variáveis e todos os pontos de corte e escolhe-se a divisão que mais reduz a **impureza**; repete-se o processo em cada nó filho. "Guloso" significa que cada divisão é a melhor naquele momento, sem considerar as seguintes.

### Medidas de impureza

Seja $\hat p_k$ a proporção da classe $k$ entre os exemplos de um nó.

::: definicao 4.6 · Impureza de Gini e entropia
A **impureza de Gini** e a **entropia** de um nó com $K$ classes são

$$
G = \sum_{k=1}^K\hat p_k(1-\hat p_k) = 1-\sum_{k=1}^K\hat p_k^2,\qquad H = -\sum_{k=1}^K\hat p_k\log_2\hat p_k ,
$$

com a convenção $0\log0 = 0$.
:::

Ambas valem zero em um nó puro, com uma única classe, e são máximas quando as classes estão igualmente representadas. A impureza de Gini é a probabilidade de errar ao rotular um exemplo do nó sorteando o rótulo segundo as proporções do próprio nó. A entropia, da teoria da informação, é o número médio de bits necessários para comunicar a classe de um exemplo do nó.

A qualidade de uma divisão é a redução da impureza, ponderada pelo tamanho dos filhos. Para um nó com $n$ exemplos, dividido em filhos com $n_E$ e $n_D$ exemplos e impureza $I$:

$$
\Delta = I(\text{pai})-\frac{n_E}{n}\,I(\text{esquerdo})-\frac{n_D}{n}\,I(\text{direito}).
$$

Com a entropia, $\Delta$ chama-se **ganho de informação**.

::: exemplo 4.3 · Escolha de uma divisão
Um nó tem 10 exemplos: 6 positivos e 4 negativos.

$G = 1-0{,}6^2-0{,}4^2 = 0{,}48$ e $H = -0{,}6\log_20{,}6-0{,}4\log_20{,}4\approx0{,}971$.

**Divisão A:** esquerda com (4 positivos, 0 negativos); direita com (2, 4). O filho esquerdo é puro, com impureza zero. No direito, $G = 1-(1/3)^2-(2/3)^2\approx0{,}444$. Impureza ponderada: $0{,}4\times0+0{,}6\times0{,}444 = 0{,}267$. Redução: $0{,}213$.

**Divisão B:** esquerda com (4, 1); direita com (2, 3). $G_E = 1-0{,}8^2-0{,}2^2 = 0{,}32$ e $G_D = 1-0{,}4^2-0{,}6^2 = 0{,}48$. Ponderada: $0{,}40$. Redução: $0{,}08$.

A divisão A é escolhida. Pela entropia, as impurezas ponderadas são $0{,}551$ e $0{,}846$, e a conclusão é a mesma. O programa adiante confere esses números.
:::

Na prática, os dois critérios produzem árvores muito parecidas. Por que não usar diretamente a taxa de erro do nó? Porque ela é pouco sensível: há divisões que tornam os filhos mais puros sem alterar a classe majoritária de nenhum deles, e a taxa de erro não as distingue. Em regressão, a impureza é a soma dos quadrados dos desvios em relação à média do nó.

### Poda

Deixada crescer até que cada folha seja pura, a árvore classifica perfeitamente o treinamento e ajusta o ruído. Parar cedo, por um limiar de ganho, é míope: uma divisão fraca pode preparar outra muito boa. A estratégia preferida é crescer uma árvore grande e depois **podá-la**.

::: definicao 4.7 · Poda por custo-complexidade
Para $\alpha\ge0$, o custo de uma subárvore $T$ é

$$
R_\alpha(T) = R(T)+\alpha\,\lvert T\rvert ,
$$

em que $R(T)$ é o erro de treinamento de $T$ (impureza total das folhas, ponderada) e $\lvert T\rvert$ é o número de folhas. Para cada $\alpha$, escolhe-se a subárvore da árvore completa que minimiza $R_\alpha$.
:::

O parâmetro $\alpha$ é o preço de cada folha. Com $\alpha=0$, fica-se com a árvore completa. À medida que $\alpha$ cresce, ramos cujo ganho não paga o preço são removidos, até restar apenas a raiz. Breiman et al. (1984) mostraram que as subárvores ótimas formam uma sequência aninhada, que pode ser calculada com eficiência; o valor de $\alpha$ é então escolhido por validação cruzada (Capítulo 5). A expressão tem a forma "erro mais penalidade por complexidade", a mesma da regularização Ridge e Lasso.

### Implementação

<<< codigo/c4_arvore.py

>>> codigo/c4_arvore.out

A primeira parte reproduz o Exemplo 4.3. A segunda mostra a poda em dados reais. A árvore completa tem 16 folhas e acurácia de treino de 100%. Conforme $\alpha$ aumenta, o número de folhas e a acurácia de treino diminuem, enquanto a acurácia em validação cruzada sobe ligeiramente e depois cai. A árvore escolhida tem 5 folhas e desempenho de teste um pouco superior ao da árvore completa ($0{,}918$ contra $0{,}906$), com um terço do tamanho.

A diferença de teste é pequena, de dois exemplos em 171, e não deve ser lida como demonstração de superioridade. O ganho seguro é outro: um modelo com 5 regras, que uma pessoa confere, faz o mesmo que um com 16.

### Limitações

::: atencao Fraquezas das árvores isoladas
- **Instabilidade.** Uma pequena mudança nos dados pode alterar a primeira divisão e, com ela, toda a árvore. Em termos do Capítulo 5, árvores têm variância alta.
- **Fronteiras em degraus.** Uma relação linear simples entre duas variáveis é aproximada por uma escada, com muitas divisões.
- **Acurácia inferior** à de outros métodos em muitos problemas.

A instabilidade é explorada pelos **métodos de conjunto**: as florestas aleatórias promediam muitas árvores ajustadas a reamostragens dos dados, e o *boosting* soma árvores pequenas ajustadas em sequência aos erros das anteriores. Esses métodos perdem a interpretabilidade e ganham acurácia, e estão entre os mais eficazes para dados tabulares (James et al., 2023, cap. 8).
:::

## 4.8 Comparação dos modelos

| | Regressão linear | Regressão logística | KNN | Árvore de decisão |
|---|---|---|---|---|
| Fronteira ou forma | Hiperplano | Hiperplano | Arbitrária | Retângulos |
| Parâmetros | $d+1$ | $d+1$ | Nenhum (guarda os dados) | Divisões e folhas |
| Controle da flexibilidade | Número de variáveis, regularização | Idem | $K$ | Profundidade, $\alpha$ |
| Exige padronização | Não (sim, com regularização) | Idem | Sim | Não |
| Interpretação | Coeficientes | Odds ratios | Exemplos vizinhos | Regras |
| Custo de treino / previsão | Baixo / baixo | Baixo / baixo | Nulo / alto | Baixo / baixo |
| Fraqueza principal | Não linearidade | Fronteira linear | Dimensão alta | Instabilidade |

Não existe melhor modelo em geral. Se a relação verdadeira é aproximadamente linear, os modelos lineares vencem com poucos dados. Se é muito não linear e há dados em abundância, vencem os flexíveis. A escolha é empírica e exige um método de avaliação confiável. Esse método é o assunto do próximo capítulo.

## 4.9 Resumo do capítulo

::: resumo Ideias centrais
- Os **mínimos quadrados** minimizam a soma dos quadrados dos resíduos. A solução satisfaz as equações normais $\mathbf{X}^\top\mathbf{X}\hat{\boldsymbol\beta} = \mathbf{X}^\top\mathbf{y}$ e é a **projeção ortogonal** de $\mathbf{y}$ no espaço coluna de $\mathbf{X}$.
- O estimador é não viesado, com covariância $\sigma^2(\mathbf{X}^\top\mathbf{X})^{-1}$. **Erros padrão e p-valores** dependem de hipóteses sobre os erros. O p-valor não é a probabilidade da hipótese nula.
- O **$R^2$** mede a fração de variabilidade explicada no treinamento e nunca diminui ao acrescentar variáveis.
- A **regressão logística** é linear no logit. Coeficientes exponenciados são **odds ratios**. A perda é a entropia cruzada, convexa, com gradiente $\tfrac1n\mathbf{X}^\top(\mathbf{p}-\mathbf{y})$ e fronteira linear.
- O **KNN** estima probabilidades pela vizinhança. $K$ pequeno é flexível; $K$ grande é rígido. Exige padronização e sofre em dimensão alta.
- **Árvores** dividem o espaço para reduzir a impureza (Gini ou entropia) e são controladas pela **poda por custo-complexidade**.
:::

## 4.10 Exercícios

### Nível I: consolidação

**4.1** Para os dados $x = (0,1,2,3)$ e $y = (1,3,4,8)$, calcule à mão $\hat\beta_0$ e $\hat\beta_1$, os valores ajustados, os resíduos e o $R^2$. Verifique que os resíduos somam zero.

**4.2** Em uma regressão logística, o coeficiente de "anos de tabagismo" é $0{,}05$. Interprete. Qual é o odds ratio associado a 10 anos a mais?

**4.3** Converta: (a) probabilidade $0{,}75$ em chance; (b) chance $0{,}25$ em probabilidade; (c) logit $0$ em probabilidade.

**4.4** Um nó tem 8 exemplos da classe A e 2 da classe B. Calcule a impureza de Gini e a entropia.

**4.5** Um modelo relata $R^2 = 0{,}95$ no treinamento, com 40 preditoras e 50 observações. Que cuidado esse resultado exige?

### Nível II: desenvolvimento

**4.6** Mostre que a matriz chapéu satisfaz $\mathbf{H}^\top = \mathbf{H}$ e $\mathbf{H}^2 = \mathbf{H}$, e que seu traço é $p$. Conclua que a soma das alavancagens $h_{ii}$ é igual ao número de parâmetros.

**4.7** Prove que, na regressão simples, $R^2$ é o quadrado da correlação amostral entre $x$ e $y$.

**4.8** Demonstre que $\sigma'(z) = \sigma(z)(1-\sigma(z))$ e que $1-\sigma(z) = \sigma(-z)$.

**4.9** Mostre que, se os dados são perfeitamente separáveis por um hiperplano, a perda da regressão logística não tem mínimo: para qualquer $\boldsymbol\beta$ que separe os dados, $\mathcal{L}(c\boldsymbol\beta)\to0$ quando $c\to\infty$.

**4.10** (Computacional) Implemente o método de Newton para a regressão logística, $\boldsymbol\beta\leftarrow\boldsymbol\beta-\mathbf{H}^{-1}\nabla\mathcal{L}$, nos dados da seção 4.5. Compare o número de iterações com o da descida do gradiente e explique a diferença com base no Capítulo 1.

**4.11** Para um nó binário com proporção $p$ da classe positiva, escreva o erro de classificação, a impureza de Gini e a entropia como funções de $p$. Mostre, com um exemplo numérico, uma divisão que reduz o Gini sem reduzir o erro de classificação.

### Nível III: avançado

**4.12** (Experimento) Gere dados em que a fronteira de Bayes é linear e dados em que ela é circular. Em cada caso, compare regressão logística, KNN e árvore de decisão para $n\in\{50, 500, 5000\}$. Relacione os resultados à seção 4.8.

**4.13** (Estudo de caso) Um modelo de regressão para preços de imóveis apresenta coeficiente negativo para "número de quartos", quando a área construída também está no modelo. Explique como isso pode ocorrer sem erro de cálculo e o que responder a quem conclui que "quartos desvalorizam o imóvel".

**4.14** (Análise crítica) Um relatório afirma: "a variável é significativa (p = 0,03); logo, há 97% de probabilidade de o efeito ser real". Identifique os erros e reescreva a frase corretamente.

## 4.11 Soluções comentadas

::: solucao 4.1
$\bar x = 1{,}5$, $\bar y = 4$. $\sum(x_i-\bar x)(y_i-\bar y) = (-1{,}5)(-3)+(-0{,}5)(-1)+(0{,}5)(0)+(1{,}5)(4) = 11$. $\sum(x_i-\bar x)^2 = 5$. Logo $\hat\beta_1 = 2{,}2$ e $\hat\beta_0 = 4-2{,}2\times1{,}5 = 0{,}7$. Valores ajustados: $0{,}7;\ 2{,}9;\ 5{,}1;\ 7{,}3$. Resíduos: $0{,}3;\ 0{,}1;\ -1{,}1;\ 0{,}7$, com soma zero. $\operatorname{RSS} = 0{,}09+0{,}01+1{,}21+0{,}49 = 1{,}8$; $\operatorname{TSS} = 9+1+0+16 = 26$; $R^2 = 1-1{,}8/26\approx0{,}931$.
:::

::: solucao 4.2
Cada ano a mais de tabagismo, mantidas as demais variáveis, multiplica a chance do desfecho por $e^{0{,}05}\approx1{,}051$, um aumento de cerca de 5% na chance. Dez anos: $e^{0{,}5}\approx1{,}65$. O efeito é multiplicativo na chance, e não aditivo na probabilidade.
:::

::: solucao 4.3
(a) $0{,}75/0{,}25 = 3$. (b) $0{,}25/1{,}25 = 0{,}2$. (c) $\sigma(0) = 0{,}5$.
:::

::: solucao 4.4
$G = 1-0{,}8^2-0{,}2^2 = 0{,}32$. $H = -0{,}8\log_20{,}8-0{,}2\log_20{,}2\approx0{,}722$ bit.
:::

::: solucao 4.5
Com 41 parâmetros e 50 observações, o espaço coluna tem quase a dimensão de $\mathbb{R}^{50}$, e a projeção fica próxima de $\mathbf{y}$ mesmo com preditoras sem relação alguma com a resposta. Com 49 preditoras, o $R^2$ seria exatamente 1. O valor relatado praticamente não informa sobre capacidade preditiva; é preciso avaliar em dados não usados no ajuste.
:::

::: solucao 4.6
$\mathbf{H}^\top = \mathbf{X}\bigl[(\mathbf{X}^\top\mathbf{X})^{-1}\bigr]^\top\mathbf{X}^\top = \mathbf{H}$, pois a inversa de uma matriz simétrica é simétrica. $\mathbf{H}^2 = \mathbf{X}(\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top\mathbf{X}(\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top = \mathbf{H}$. Usando a propriedade cíclica do traço, $\operatorname{tr}(\mathbf{H}) = \operatorname{tr}\bigl((\mathbf{X}^\top\mathbf{X})^{-1}\mathbf{X}^\top\mathbf{X}\bigr) = \operatorname{tr}(\mathbf{I}_p) = p$. Como o traço é a soma da diagonal, $\sum_ih_{ii} = p$. O número de parâmetros é, nesse sentido, a "quantidade de ajuste" que o modelo distribui entre as observações, interpretação retomada no Capítulo 5.
:::

::: solucao 4.7
Sejam $S_{xy} = \sum(x_i-\bar x)(y_i-\bar y)$, $S_{xx}$ e $S_{yy}$ definidos de modo análogo. Como $\hat y_i-\bar y = \hat\beta_1(x_i-\bar x)$, a soma dos quadrados explicada é $\hat\beta_1^2S_{xx} = S_{xy}^2/S_{xx}$. Pela ortogonalidade entre resíduos e valores ajustados, $\operatorname{TSS} = \operatorname{RSS}+$ soma explicada, e portanto $R^2 = \dfrac{S_{xy}^2}{S_{xx}S_{yy}} = r^2$.
:::

::: solucao 4.8
$\sigma'(z) = \dfrac{e^{-z}}{(1+e^{-z})^2} = \dfrac{1}{1+e^{-z}}\cdot\dfrac{e^{-z}}{1+e^{-z}} = \sigma(z)\bigl(1-\sigma(z)\bigr)$. E $1-\sigma(z) = \dfrac{e^{-z}}{1+e^{-z}} = \dfrac{1}{e^{z}+1} = \sigma(-z)$. A derivada é máxima em $z=0$, onde vale $0{,}25$, e tende a zero nos extremos, fato que reaparece no problema da dissipação de gradientes (Capítulo 6).
:::

::: solucao 4.9
Separabilidade significa que existe $\boldsymbol\beta$ com $\mathbf{x}_i^\top\boldsymbol\beta>0$ quando $y_i=1$ e $<0$ quando $y_i=0$. Para exemplos positivos, a contribuição à perda é $\log(1+e^{-c\,\mathbf{x}_i^\top\boldsymbol\beta})$, que tende a 0 quando $c\to\infty$; para os negativos, $\log(1+e^{c\,\mathbf{x}_i^\top\boldsymbol\beta})$, que também tende a 0. A perda é sempre positiva e aproxima-se de 0 sem atingi-lo: o ínfimo não é alcançado, e um otimizador faz os coeficientes crescerem indefinidamente. Uma penalidade $\lambda\lVert\boldsymbol\beta\rVert^2$ torna a perda estritamente convexa com mínimo finito.
:::

::: solucao 4.10 (orientação)
Use a Proposição 4.4: a cada iteração, calcule $\mathbf{p}$, o gradiente $\tfrac1n\mathbf{X}^\top(\mathbf{p}-\mathbf{y})$ e a Hessiana $\tfrac1n\mathbf{X}^\top\mathbf{W}\mathbf{X}$, e resolva o sistema com `np.linalg.solve`. O método converge em cerca de 6 a 8 iterações, contra milhares da descida do gradiente. A razão é a do Exercício 1.18: o passo de Newton leva em conta a curvatura em todas as direções e elimina o efeito do mau condicionamento. O custo por iteração é maior, da ordem de $p^3$, aceitável quando $p$ é pequeno.
:::

::: solucao 4.11
Erro: $\min(p,1-p)$. Gini: $2p(1-p)$. Entropia: $-p\log_2p-(1-p)\log_2(1-p)$. Exemplo: nó com (40 positivos, 10 negativos), erro $0{,}2$. Divisão em (20, 0) e (20, 10): a classe majoritária continua positiva nos dois filhos, e o erro ponderado é $0{,}4\times0+0{,}6\times(1/3) = 0{,}2$, sem redução. O Gini passa de $0{,}32$ para $0{,}6\times0{,}444 = 0{,}267$: a divisão criou um filho puro, o que facilita divisões futuras, e só as medidas estritamente côncavas percebem isso.
:::

::: solucao 4.12 (orientação)
Com fronteira linear, a regressão logística é a melhor em todos os tamanhos e a vantagem é maior com $n=50$: ela supõe a forma correta e só precisa estimar três números. Com fronteira circular, a regressão logística com as variáveis originais fica perto do acaso em qualquer $n$, pois nenhum hiperplano separa um círculo de seu entorno (erro redutível que não desaparece, Exercício 3.11); KNN e árvore melhoram com $n$. Acrescentar $x_1^2$ e $x_2^2$ como preditoras torna a fronteira linear nas novas variáveis e recupera a regressão logística. Essa ideia, de mudar a representação para tornar o problema linear, é o que as redes neurais fazem automaticamente.
:::

::: solucao 4.13 (orientação)
O coeficiente mede a variação do preço por quarto adicional **mantida a área constante**. Com a área fixa, mais quartos significam quartos menores, o que pode de fato associar-se a preços menores. Na regressão simples, sem a área, o coeficiente de quartos seria positivo, porque quartos e área são correlacionados e o coeficiente absorveria o efeito da área. Não há contradição: são perguntas diferentes. Além disso, com preditoras correlacionadas os erros padrão aumentam, e o intervalo de confiança do coeficiente deve ser examinado antes de qualquer conclusão.
:::

::: solucao 4.14 (orientação)
Erros: (i) o p-valor não é a probabilidade de a hipótese nula ser verdadeira, de modo que $1-p$ não é a probabilidade de o efeito ser real; (ii) "significativa" não informa o tamanho do efeito; (iii) falta saber quantas variáveis foram testadas. Redação correta: "Se não houvesse associação entre a variável e a resposta, e valendo as hipóteses do modelo, uma estatística tão extrema quanto a observada ocorreria em cerca de 3% das amostras. O coeficiente estimado é tal, com intervalo de confiança de 95% de tal a tal."
:::

## 4.12 Referências e leituras

**O que estudar primeiro.** James et al. (2023): capítulo 3 (regressão linear), capítulo 4 (classificação) e capítulo 8 (árvores), com os laboratórios em Python.

### Livros didáticos fundamentais

- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Capítulos 3, 4 e 8.
- HASTIE, T.; TIBSHIRANI, R.; FRIEDMAN, J. *The Elements of Statistical Learning*. 2. ed. New York: Springer, 2009. Capítulos 3, 4, 9 e 13.

### Textos e artigos originais

- BREIMAN, L.; FRIEDMAN, J. H.; OLSHEN, R. A.; STONE, C. J. *Classification and Regression Trees*. Belmont: Wadsworth, 1984.
- COVER, T.; HART, P. Nearest neighbor pattern classification. *IEEE Transactions on Information Theory*, v. 13, n. 1, p. 21–27, 1967.
- WASSERSTEIN, R. L.; LAZAR, N. A. The ASA statement on p-values: context, process, and purpose. *The American Statistician*, v. 70, n. 2, p. 129–133, 2016.

### Documentação técnica

- scikit-learn, guia do usuário: modelos lineares, vizinhos mais próximos e árvores de decisão (incluindo poda por custo-complexidade). scikit-learn.org/stable/user_guide.html. Versão 1.9.
- statsmodels: regressão por mínimos quadrados (`OLS`). www.statsmodels.org. Versão 0.15.
- Códigos de apoio em português: github.com/guilhermesilveira/machine-learning e github.com/mattharrison/ml_pocket_reference.
