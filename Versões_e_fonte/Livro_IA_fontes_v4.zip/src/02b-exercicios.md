## 2.12 Exercícios

### Nível I: consolidação

**2.1** Escreva a especificação PEAS de: (a) um sistema de recomendação de filmes; (b) um drone de entregas; (c) um assistente que tria a caixa de e-mails de um profissional.

**2.2** Classifique, nas seis dimensões da seção 2.6, os ambientes de: (a) um sistema de recomendação de filmes; (b) um robô que separa peças em uma esteira; (c) um agente que negocia preços com fornecedores por mensagens. Registre as hipóteses adotadas.

**2.3** Explique a diferença entre função do agente e programa do agente. Dois programas diferentes podem implementar a mesma função? Uma função do agente pode não ter programa que a implemente em uma dada arquitetura?

**2.4** Julgue cada afirmação como verdadeira ou falsa e justifique: (a) um agente racional nunca toma uma decisão que termina mal; (b) um agente reativo simples nunca é racional; (c) em um ambiente totalmente observável e determinístico, um agente não precisa de estado interno para agir racionalmente; (d) se dois agentes têm a mesma função de utilidade, tomam sempre as mesmas decisões.

### Nível II: desenvolvimento

**2.5** Um agente recebe, a cada passo, uma percepção entre 10 possíveis. (a) Quantas entradas tem a tabela completa da função do agente para um horizonte de 12 passos? (b) Se cada entrada ocupasse 1 byte, quanta memória seria necessária? (c) Que propriedade do ambiente permitiria reduzir a tabela a 10 entradas?

**2.6** (Computacional) Modifique o mundo do aspirador para que cada sala volte a ficar suja com probabilidade $0{,}1$ a cada passo. Use 50 passos e custo de movimento $0{,}2$. Compare o agente reativo e o agente baseado em modelo da seção 2.8. Explique o resultado e proponha uma correção para o agente baseado em modelo.

**2.7** No exemplo de rotas da seção 2.7, suponha que cada minuto além do prazo custe $c$ vezes um minuto normal (no programa, $c = 5$). (a) Escreva a utilidade esperada de cada rota em função de $c$. (b) A partir de que valor de $c$ a avenida passa a ser preferida? (c) Interprete $c$ em termos de atitude diante do risco.

**2.8** Um sensor de sujeira acerta em 80% das leituras, e a crença inicial de que a sala está suja é $0{,}3$. O sensor indica "suja" e, em seguida, "limpa". Calcule a crença após cada leitura, supondo leituras independentes dado o estado. O resultado final depende da ordem das leituras?

**2.9** Demonstre que, em um grafo em que todas as ações têm o mesmo custo, a busca em largura devolve um plano com o menor número possível de ações.

### Nível III: avançado

**2.10** (Estudo de caso) Uma empresa avalia seu assistente de atendimento com LLM por uma única métrica: a proporção de conversas encerradas sem transferência para um atendente humano. (a) Descreva três comportamentos indesejados que maximizariam essa métrica. (b) Proponha uma medida de desempenho composta que os desestimule. (c) Indique como cada componente da sua medida poderia ser observado na prática.

**2.11** (Análise crítica) Jones e Bergen (2025) relatam que um LLM, instruído a adotar uma persona, foi tomado por humano com mais frequência que os próprios humanos em um Teste de Turing de três participantes. Em até duas páginas, discuta o que esse resultado estabelece e o que não estabelece, à luz das seções 2.2 e 2.3. Considere ao menos uma objeção à sua própria posição.

**2.12** (Projeto) Estenda o mundo do aspirador para um ambiente parcialmente observável e estocástico: a sujeira reaparece com probabilidade desconhecida, e o sensor erra em 10% das leituras. Implemente um agente que mantenha um estado de crença sobre cada sala, estime a probabilidade de reaparecimento a partir das próprias observações e escolha ações por máxima utilidade esperada com horizonte de um passo. Compare-o com os agentes do Exercício 2.6.

**2.13** (Pesquisa) Leia Simon (1955). Relacione o conceito de racionalidade limitada a duas práticas de engenharia de agentes: limitar o número de passos de raciocínio de um agente e interromper uma busca quando uma solução "boa o bastante" é encontrada. Em que condições interromper cedo é a decisão racional?

## 2.13 Soluções comentadas

::: solucao 2.1
Há mais de uma resposta aceitável; o essencial é que a medida de desempenho descreva resultados no ambiente.

(a) *Desempenho:* satisfação com o que foi assistido, diversidade, retenção de longo prazo (e não apenas cliques). *Ambiente:* usuários, catálogo, contexto de uso. *Atuadores:* lista ordenada de títulos exibida. *Sensores:* histórico de reprodução, avaliações, buscas, abandono.

(b) *Desempenho:* entregas concluídas no prazo, segurança de pessoas e bens, energia, respeito ao espaço aéreo. *Ambiente:* espaço aéreo urbano, clima, obstáculos, outros veículos, destinatários. *Atuadores:* rotores, mecanismo de liberação da carga, sinalização. *Sensores:* GPS, câmeras, unidade inercial, altímetro, nível de bateria.

(c) *Desempenho:* mensagens importantes destacadas a tempo, poucas classificações erradas, nenhuma ação irreversível indevida. *Ambiente:* caixa de entrada, remetentes, agenda e hábitos do profissional. *Atuadores:* rotular, arquivar, rascunhar respostas, pedir confirmação. *Sensores:* conteúdo e metadados das mensagens, ações anteriores do usuário.
:::

::: solucao 2.2
(a) Parcialmente observável (as preferências não são visíveis), estocástico, sequencial se o objetivo for satisfação de longo prazo (cada recomendação altera o que o usuário verá e preferirá depois) ou episódico se cada recomendação for tratada isoladamente, dinâmico, discreto, multiagente em sentido fraco (os usuários reagem ao sistema).

(b) Parcialmente observável (uma câmera, oclusões), estocástico (peças em posições variáveis, falhas de preensão), episódico (cada peça independe da anterior), dinâmico (a esteira não espera), contínuo, agente único.

(c) Parcialmente observável (o preço mínimo do fornecedor é oculto), estocástico, sequencial, dinâmico, discreto nas mensagens e contínuo nos valores, multiagente com componentes competitivos e cooperativos.
:::

::: solucao 2.3
A função do agente é o mapeamento abstrato de sequências de percepções em ações; o programa é um algoritmo concreto que o realiza em uma arquitetura. Dois programas diferentes podem implementar a mesma função: uma tabela e um conjunto de regras que produzam as mesmas ações em todos os casos, por exemplo. E sim, há funções sem programa viável em uma dada arquitetura, por falta de memória ou de tempo: a função que joga xadrez perfeitamente existe matematicamente, mas nenhum computador físico a implementa.
:::

::: solucao 2.4
(a) Falsa. Racionalidade maximiza o resultado esperado; resultados ruins podem ocorrer por acaso ou por informação indisponível.

(b) Falsa. No mundo do aspirador sem custo de movimento, o agente reativo é racional (seção 2.8). A racionalidade é relativa ao ambiente de tarefa.

(c) Verdadeira quanto ao estado interno: a percepção atual contém tudo o que é relevante, e a ação ótima pode ser função apenas dela. Isso não significa que calcular essa ação seja fácil; no xadrez, a função existe e é intratável.

(d) Falsa. As decisões dependem também das crenças (probabilidades), das percepções recebidas e das ações disponíveis.
:::

::: solucao 2.5
(a) $\sum_{t=1}^{12}10^t = (10^{13}-10)/9 = 1\,111\,111\,111\,110$ entradas, cerca de $1{,}1\times10^{12}$. (b) Aproximadamente 1,1 terabyte, para um problema minúsculo. (c) Se o ambiente for totalmente observável, a ação ótima depende apenas da percepção atual, e bastam 10 entradas: é o agente reativo simples.
:::

::: solucao 2.6
<<< codigo/c2_ex6.py

>>> codigo/c2_ex6.out

O agente baseado em modelo, que antes era o melhor, passa a ser o pior. Seu modelo de transição afirma que salas limpas permanecem limpas; depois de verificar as duas, ele para para sempre, enquanto a sujeira se acumula. O agente reativo, que não supõe nada, patrulha sem parar e sai-se bem.

A correção consiste em consertar o modelo, e não em abandoná-lo: informação antiga deve voltar a ser tratada como incerta. Com validade de três passos, o agente corrigido empata com o reativo nesta configuração; a validade ideal depende da probabilidade de reaparecimento e do custo de movimento, e vale a pena variá-las. A lição geral é que conhecimento prévio errado pode ser pior que nenhum, e que um estado interno precisa de um modelo de como a informação envelhece. O tratamento completo é o estado de crença do Exercício 2.12.
:::

::: solucao 2.7
(a) Via expressa: com probabilidade $0{,}8$ leva 20 minutos; com $0{,}2$, leva 70, isto é, 25 minutos além do prazo. $\operatorname{UE} = 0{,}8(-20)+0{,}2(-70-25c) = -30-5c$. Avenida: nenhum resultado excede 45 minutos, logo $\operatorname{UE} = -(0{,}95\times32+0{,}05\times40) = -32{,}4$.

(b) A avenida é preferida quando $-32{,}4>-30-5c$, ou seja, $c>0{,}48$. Para $c = 5$, obtém-se $-55$, como no programa.

(c) $c = 0$ corresponde a neutralidade ao risco: só o tempo médio importa. Quanto maior $c$, maior a aversão a atrasos, e mais o agente aceita piorar a média para reduzir a chance de um resultado muito ruim. Basta um custo modesto de atraso para inverter a decisão.
:::

::: solucao 2.8
Primeira leitura ("suja"): $b = \dfrac{0{,}8\times0{,}3}{0{,}8\times0{,}3+0{,}2\times0{,}7} = \dfrac{0{,}24}{0{,}38}\approx0{,}632$.

Segunda leitura ("limpa"): a verossimilhança de "limpa" é $0{,}2$ se a sala está suja e $0{,}8$ se está limpa. $b' = \dfrac{0{,}2\times0{,}632}{0{,}2\times0{,}632+0{,}8\times0{,}368} = \dfrac{0{,}1263}{0{,}4211} = 0{,}3$.

Duas leituras contraditórias de mesma confiabilidade cancelam-se, e a crença volta ao valor inicial. A ordem não importa: a posterior é proporcional à priori multiplicada pelo produto das verossimilhanças, e o produto é comutativo. Isso vale porque as leituras são independentes dado o estado e o estado não muda entre elas.
:::

::: solucao 2.9
Chame de nível $k$ o conjunto dos estados cuja menor distância ao estado inicial é $k$ ações. Mostra-se por indução que a busca em largura retira da fila todos os estados do nível $k$ antes de qualquer estado do nível $k+1$, e que cada estado é registrado pela primeira vez por um caminho de comprimento igual ao seu nível. O nível 0 contém apenas o estado inicial, que é o primeiro a sair. Se a afirmação vale até o nível $k$, os estados do nível $k+1$ são inseridos na fila exatamente quando seus vizinhos do nível $k$ são expandidos, portanto depois de todos os estados do nível $k$ já estarem na fila, e a fila preserva a ordem de inserção. Como um estado só é registrado na primeira vez em que é alcançado, o caminho registrado para o objetivo tem comprimento igual ao seu nível, que é o mínimo por definição.
:::

::: solucao 2.10 (orientação)
(a) Exemplos: dar respostas vagas que encerram a conversa sem resolver o problema; nunca oferecer a transferência, mesmo quando necessária; afirmar com segurança informações incorretas para evitar a transferência. (b) Uma medida composta deve incluir resolução confirmada do problema (e não apenas encerramento), fidelidade das respostas às fontes, transferência correta nos casos que a exigem, satisfação posterior e custo. (c) Resolução: ausência de novo contato pelo mesmo motivo em um intervalo definido. Fidelidade: avaliação amostral, humana ou automatizada, contra os documentos recuperados. Transferência correta: auditoria de casos rotulados. O Capítulo 15 desenvolve essas métricas.
:::

::: solucao 2.11 (orientação)
Uma boa resposta separa três camadas. *O que o resultado estabelece:* nas condições do experimento, interrogadores não distinguem o modelo de uma pessoa em conversas curtas; a capacidade depende da instrução dada. *O que não estabelece:* correção factual, raciocínio confiável, compreensão no sentido discutido por Searle, ou racionalidade no sentido da Definição 2.1, que exige uma medida de desempenho sobre resultados no ambiente. *Objeção a considerar:* se nenhum teste comportamental bastar, o critério de inteligência torna-se inverificável; uma resposta possível é exigir baterias amplas de tarefas com medidas de desempenho explícitas, em vez de um teste único de imitação.
:::

::: solucao 2.12 (orientação)
Mantenha, para cada sala, $b$ = probabilidade de estar suja. A cada passo: (1) previsão, $b\leftarrow b+(1-b)\,\hat p$, em que $\hat p$ é a estimativa da probabilidade de reaparecimento; (2) se a sala foi observada, correção pelo Teorema de Bayes com acerto de 90%, como no Exemplo 2.3; (3) após aspirar, $b\leftarrow0$. Estime $\hat p$ pela frequência com que salas deixadas limpas são encontradas sujas, ponderada pelo tempo decorrido. Para a decisão, compare a utilidade esperada de aspirar, de mover-se (ganho esperado de limpar a outra sala, proporcional à sua crença, menos o custo de movimento) e de permanecer. Espera-se que o agente supere o reativo quando o custo de movimento é alto e a sujeira é rara, e se aproxime dele no caso contrário.
:::

::: solucao 2.13 (orientação)
Pontos esperados: deliberar tem custo (tempo, tokens, dinheiro), e esse custo entra na medida de desempenho; a decisão racional é continuar deliberando enquanto o ganho esperado da próxima etapa superar seu custo; interromper cedo é racional quando a solução corrente já atende ao limiar de qualidade exigido ou quando o ambiente é dinâmico e o atraso degrada o resultado. Limites de passos em agentes são uma forma rudimentar dessa regra, fixada pelo projetista e não calculada pelo agente.
:::

## 2.14 Referências e leituras

**O que estudar primeiro.** Russell e Norvig (2021), capítulos 1 e 2: é a fonte primária da estrutura deste capítulo e deve ser lida na íntegra. Em seguida, Turing (1950), artigo curto e acessível.

### Livro didático fundamental

- RUSSELL, S.; NORVIG, P. *Artificial Intelligence: A Modern Approach*. 4. ed. Hoboken: Pearson, 2021. Material suplementar e implementações: aima.cs.berkeley.edu.

### Artigos e textos originais

- BROOKS, R. A. Intelligence without representation. *Artificial Intelligence*, v. 47, n. 1–3, p. 139–159, 1991.
- JONES, C. R.; BERGEN, B. K. *Large Language Models Pass the Turing Test*. Preprint arXiv:2503.23674, 2025.
- LEGG, S.; HUTTER, M. Universal intelligence: a definition of machine intelligence. *Minds and Machines*, v. 17, n. 4, p. 391–444, 2007.
- McCARTHY, J.; MINSKY, M. L.; ROCHESTER, N.; SHANNON, C. E. *A Proposal for the Dartmouth Summer Research Project on Artificial Intelligence*. 1955.
- SEARLE, J. R. Minds, brains, and programs. *Behavioral and Brain Sciences*, v. 3, n. 3, p. 417–424, 1980.
- SIMON, H. A. A behavioral model of rational choice. *The Quarterly Journal of Economics*, v. 69, n. 1, p. 99–118, 1955.
- TURING, A. M. Computing machinery and intelligence. *Mind*, v. 59, n. 236, p. 433–460, 1950.

### Referências complementares

- RUSSELL, S. *Human Compatible: Artificial Intelligence and the Problem of Control*. New York: Viking, 2019.
- SUTTON, R. S.; BARTO, A. G. *Reinforcement Learning: An Introduction*. 2. ed. Cambridge, MA: MIT Press, 2018.
- VON NEUMANN, J.; MORGENSTERN, O. *Theory of Games and Economic Behavior*. Princeton: Princeton University Press, 1944.
- WOOLDRIDGE, M. *An Introduction to MultiAgent Systems*. 2. ed. Chichester: Wiley, 2009.

### Documentação técnica

- Repositório de implementações em Python dos algoritmos de Russell e Norvig: github.com/aimacode/aima-python.
- Curso de agentes da Hugging Face, unidade introdutória: huggingface.co/learn/agents-course. Usado como referência de terminologia para o Módulo VI.

---

**Fim do Módulo I.** O Capítulo 1 forneceu a linguagem matemática; este capítulo, a moldura conceitual. O Módulo II une as duas: um agente que melhora com a experiência precisa aprender a partir de dados, e o Capítulo 3 formula esse problema com as ferramentas de probabilidade da seção 1.12 em diante.
