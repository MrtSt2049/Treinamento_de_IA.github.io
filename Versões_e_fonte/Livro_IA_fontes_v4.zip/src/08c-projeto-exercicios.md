## 8.6 Projeto 6: memória de longo prazo e previsão de séries

::: projeto Sequências com RNN, GRU e LSTM
O projeto mede, em um problema sintético em que o atraso é controlado, **quando** cada célula consegue lembrar, e compara as três com modelos de referência simples em uma previsão de série temporal. O objetivo é distinguir o que a teoria promete (Teoremas 8.3 e 8.4) do que o treino entrega.
:::

### Objetivo

Responder a três perguntas com experimentos controlados: (1) até que atraso uma RNN, uma GRU e uma LSTM aprendem a lembrar uma informação, com a inicialização padrão? (2) O viés alto das portas (Proposição 8.5) muda esse limite? (3) Em uma previsão de série, uma rede recorrente supera um modelo linear simples?

### Problema

**Parte A (memória atrasada).** No instante $0$, a entrada é um vetor *one-hot* de dimensão $5$ que codifica uma classe; nos instantes $1,\dots,T-1$, a entrada é ruído gaussiano $\mathcal{N}(0,0{,}5^2)$ sem relação com a classe. O modelo lê a sequência inteira e deve **classificar** a classe do instante $0$ no último passo. O atraso é $T$, e o acaso vale $0{,}20$.

**Parte B (previsão).** A série $s_t=\sin(2\pi t/25)+0{,}5\sin(2\pi t/7+1)+\varepsilon_t$, com $\varepsilon_t\sim\mathcal{N}(0,0{,}1^2)$ e $3\,000$ pontos. O modelo recebe uma janela de $30$ valores e prevê o seguinte. A divisão é **cronológica**: $70\%$ treino, $15\%$ validação e $15\%$ teste.

### Requisitos

- Um único `nn.Module` (`Modelo`), com camada recorrente intercambiável (RNN, GRU, LSTM) e uma cabeça linear sobre o **último** estado.
- Recorte de gradiente (norma $1$) e otimizador Adam em todos os treinos.
- Parte A: $T\in\{5,10,20,40,80\}$, estado oculto $32$, $500$ passos, $3$ sementes, avaliação em $2\,000$ sequências novas; variante com viés $+5$ na porta de esquecimento (LSTM) ou de atualização (GRU).
- Parte B: referências simples (média do treino, persistência, regressão linear sobre a janela) e seleção da época pela perda de validação; teste usado uma única vez.
- Testes automáticos de formas, de **ausência de vazamento temporal**, do bloco do viés alterado e do recorte de gradiente.

### Arquitetura

O modelo é $\hat{\mathbf{y}}=\mathbf{W}\,\mathbf{h}_T+\mathbf{b}$, em que $\mathbf{h}_T$ é o último estado oculto de uma camada recorrente de $32$ unidades. A Parte A usa a saída de $5$ dimensões como logits de uma entropia cruzada, e a Parte B usa uma saída escalar com erro quadrático médio. Na Parte A ($F=5$, $H=32$), a camada recorrente tem $1\,248$ parâmetros (RNN), $3\,744$ (GRU) ou $4\,992$ (LSTM) (Proposição 8.1), mais $165$ da cabeça. Na Parte B ($F=1$), são $1\,120$, $3\,360$ e $4\,480$, mais $33$ da cabeça.

### Fundamentos teóricos

- **Teorema 8.3:** o sinal de aprendizado da classe, no instante $0$, percorre $T-1$ jacobianos até o fim. Se o produto decai exponencialmente, o gradiente de longo prazo é pequeno demais para ser aprendido em um número limitado de passos.
- **Teorema 8.4 e Proposição 8.5:** o viés $5$ coloca a porta em $\sigma(5)\approx0{,}993$, com meia-vida de $103$ passos; espera-se que isso empurre o limite de atraso para a frente, até algo da ordem de $T\approx100$.
- **Erro irredutível (Capítulo 3):** na Parte B, o alvo contém um ruído novo de variância $0{,}01$ que nenhum modelo prevê. O $\text{EQM}$ de teste não pode ficar abaixo de cerca de $0{,}01$ (um **piso**, não um valor garantido, porque a parte determinística também precisa ser inferida do passado ruidoso).

### Implementação

<<< codigo/projeto6.py

### Testes e resultados

<<< codigo/projeto6_testes.py

>>> codigo/projeto6_testes.out

**Parte A: memória atrasada.** Acurácia no teste, média $\pm$ desvio em $3$ sementes, com a inicialização padrão:

>>> codigo/projeto6A.out

Com o viés da porta fixado em $+5$ na inicialização (somado ao valor sorteado):

>>> codigo/projeto6C.out

<figure>
+++ fig_c8_memoria.svg
<figcaption><b>Figura 8.5.</b> Acurácia na tarefa de memória atrasada em função do atraso $T$ (médias de $3$ sementes). As curvas com viés alto foram medidas apenas para $T\ge20$.</figcaption>
</figure>

O que os números sustentam:

- **Com atraso curto ($T=5$), as três células resolvem a tarefa** ($1{,}000$). Não há problema de longo prazo a resolver.
- **Com a inicialização padrão e $500$ passos, o limite é baixo.** Em $T=10$, a GRU acerta quase tudo ($0{,}999$), enquanto a RNN e a LSTM ficam em $0{,}80\pm0{,}28$ e $0{,}77\pm0{,}18$, com enorme variação entre sementes. Em $T=20$, a GRU e a LSTM caem ao acaso ($0{,}20$), e em $T\ge40$ **as três** estão no acaso. Isso concorda com a Figura 8.4: a inicialização padrão não deixa o gradiente chegar.
- **Um resultado que a teoria não prevê.** Em $T=20$, a RNN simples obteve $0{,}45\pm0{,}35$, acima da GRU e da LSTM. O desvio alto indica que **uma** semente aprendeu e as outras não; com $3$ sementes não se pode concluir que a RNN seja melhor, e não investiguei por que essa semente teve sucesso. O que o resultado mostra é que o desempenho nessa tarefa **é muito sensível à inicialização**.
- **O viés alto muda o quadro.** Com $T=20$ e $T=40$, GRU e LSTM passam a $0{,}99$ a $1{,}00$ (LSTM: $1{,}000$ e $0{,}997$; GRU: $0{,}995$ e $0{,}989$), contra o acaso com a inicialização padrão. A diferença entre "porta aberta" e "porta fechada" é maior do que a diferença entre as arquiteturas.
- **Mas há um limite.** Em $T=80$, a GRU atinge $0{,}93\pm0{,}02$ e a LSTM, $0{,}73\pm0{,}37$: o desvio enorme da LSTM mostra que algumas sementes aprendem e outras ficam no acaso. O viés alto não torna o aprendizado de longo prazo **confiável**; torna-o **possível**.

**Parte B: previsão da série.** EQM no conjunto de teste ($446$ janelas):

| Método | EQM de teste |
|---|---|
| Média do treino | $0{,}6360$ |
| Persistência (último valor) | $0{,}1436$ |
| Regressão linear sobre a janela de $30$ | $0{,}0111$ |
| RNN, $32$ unidades | $0{,}0112\pm0{,}0000$ |
| GRU, $32$ unidades | $0{,}0110\pm0{,}0000$ |
| LSTM, $32$ unidades | $0{,}0114\pm0{,}0001$ |
| Piso (ruído do gerador) | $\approx0{,}0100$ |

- As três redes recorrentes e a regressão linear estão a menos de $0{,}0015$ do piso. **Nenhuma rede recorrente se distingue do modelo linear**: as diferenças ($0{,}0001$ a $0{,}0003$) são menores do que o erro de amostragem de um EQM estimado com $446$ pontos, cujo erro-padrão é de cerca de $0{,}0007$ quando o ruído é gaussiano com variância $0{,}01$.
- A **persistência** é pior do que prometeria a intuição ($0{,}14$), porque a série oscila e o último valor é uma má previsão do seguinte.

### Limitações

- **A Parte A é sintética** e extrema: informação em um único instante, ruído independente e nenhum sinal intermediário. Tarefas reais têm dependências mais difusas.
- **Orçamento fixo de $500$ passos e $3$ sementes.** Um treino mais longo, outras taxas de aprendizado ou um estado oculto maior podem mudar os limites de atraso; não foram testados. Os desvios grandes ($0{,}28$, $0{,}35$, $0{,}37$) mostram que $3$ sementes são pouco.
- **A série da Parte B é linearmente previsível.** Uma soma de duas senoides obedece a uma recorrência linear de ordem $4$ (Exercício 8.15), de modo que um modelo linear já é praticamente ótimo, e a Parte B **não** testa a vantagem possível das redes recorrentes, que está em dinâmicas **não lineares**.
- **O piso de $0{,}01$** é aproximado, e não foi calculado de forma exata.
- Nada aqui foi comparado com modelos de atenção, que são o tema do próximo capítulo.

### Melhorias possíveis

- Repetir a Parte A com mais sementes, treinos mais longos e outros tamanhos de estado, e medir o **número de passos até aprender**, em vez da acurácia final em um orçamento fixo.
- Medir diretamente a norma do gradiente em cada instante durante o treino da Parte A, ligando o resultado ao Teorema 8.3.
- Trocar a série da Parte B por uma **não linear** (por exemplo, um sistema caótico simples ou uma série com regime que depende de limiares) e repetir a comparação.
- Acrescentar um modelo de **linguagem de caracteres** treinado em um texto, com perda em bits por caractere, e, depois do Capítulo 9, comparar a LSTM com um Transformer pequeno.

## 8.7 Resumo do capítulo

::: resumo Ideias centrais
- Dados sequenciais têm **ordem** e **comprimento variável**. Um modelo com **estado** resume o passado em $\mathbf{h}_t=f_\theta(\mathbf{h}_{t-1},\mathbf{x}_t)$, com os **mesmos** parâmetros em todos os instantes.
- A **RNN de Elman** usa $\mathbf{h}_t=\tanh(\mathbf{W}_{xh}\mathbf{x}_t+\mathbf{W}_{hh}\mathbf{h}_{t-1}+\mathbf{b})$. Uma camada recorrente tem $n_\text{blocos}\cdot H(F+H+2)$ parâmetros no PyTorch ($1$, $3$ ou $4$ blocos), independentes de $T$.
- A **BPTT** é a retropropagação na rede desdobrada: os gradientes dos pesos compartilhados **somam** as contribuições de todos os instantes, e o erro de cada instante recebe o do seguinte por $\mathbf{W}_{hh}^{\top}$.
- O efeito de um estado distante é um **produto de jacobianos**, limitado por $(\gamma\sigma)^k$. Se $\gamma\sigma<1$, o gradiente de longo prazo **some exponencialmente**; no caso linear, $\rho>1$ faz o produto **explodir**. Com $\tanh$, a saturação encolhe o gradiente mesmo com $\rho=1$.
- O **recorte de gradiente** trata a explosão e preserva a direção. **Não** trata a dissipação.
- A **LSTM** e a **GRU** têm um caminho **aditivo** com jacobiano diagonal $\operatorname{diag}(\mathbf{f}_t)$ ou $\operatorname{diag}(\mathbf{z}_t)$, controlado por portas. Mas, com a inicialização padrão, as portas começam em $\tfrac12$ e o gradiente **ainda decai**; é o **viés positivo** nas portas de esquecimento ou de atualização que abre o caminho (meia-vida de $103$ passos com $\beta=5$).
- Na prática: **empacote** ou **mascare** o preenchimento, use **bidirecionais** só quando o futuro está disponível, **recorte** o gradiente, e trunque a BPTT em sequências longas.
- Experimentalmente (Projeto 6), o limite de atraso com treino padrão foi baixo; o viés alto o estendeu a $T=40$ de forma confiável e a $T=80$ de forma parcial. Em uma série **linearmente previsível**, as redes recorrentes **não** superaram um modelo linear.
- A recorrência **impede a paralelização** no tempo e força a informação a percorrer $t-s$ passos. O mecanismo de **atenção** remove ambos os obstáculos e é o assunto do Capítulo 9.
:::

**Ponte para o Capítulo 9.** Reunimos aqui as três limitações das redes recorrentes: o gargalo de um estado de tamanho fixo, a dissipação do gradiente mesmo com portas e a impossibilidade de calcular os passos em paralelo. O Capítulo 9 parte da ideia de Bahdanau e colegas, deixar cada posição consultar diretamente todas as outras, e a leva ao extremo: eliminar a recorrência e construir a arquitetura **Transformer** apenas com atenção, cuja fórmula $\operatorname{softmax}(\mathbf{Q}\mathbf{K}^{\top}/\sqrt{d_k})\mathbf{V}$ deduziremos.

## 8.8 Exercícios

### Nível I: consolidação

**8.1** Quantos parâmetros têm `nn.RNN(10, 20)`, `nn.GRU(10, 20)` e `nn.LSTM(10, 20)`?

**8.2** Uma RNN escalar tem $W_{xh}=0{,}5$, $W_{hh}=1{,}2$, $b=0$ e $h_0=0$. Calcule $h_1,h_2,h_3$ para a entrada $(1,-1,2)$.

**8.3** Para cada tarefa, indique a configuração (muitos-para-um, muitos-para-muitos etc.) e se uma camada bidirecional é adequada: (a) identificar o idioma de uma frase; (b) prever o próximo caractere de um texto; (c) marcar as entidades nomeadas de cada palavra de uma frase; (d) prever o consumo de energia da próxima hora.

**8.4** Pela Proposição 8.5, calcule a meia-vida da porta de esquecimento para $\beta=2$ e $\beta=3$. Que valor de $\beta$ dá meia-vida de $1\,000$ passos?

**8.5** Recorte o gradiente $\mathbf{g}=(3,4,12)$ com limiar $c=5$.

### Nível II: desenvolvimento

**8.6** Na recorrência linear escalar $h_t=wh_{t-1}+x_t$, com $h_0=0$, mostre que $\partial h_T/\partial w=\sum_{s=1}^{T}(T-s)\,w^{T-s-1}x_s$. Para $x_s=1$ e $0<w<1$, calcule o limite quando $T\to\infty$. O que isso diz sobre o gradiente em relação ao peso compartilhado, mesmo quando o jacobiano de longo prazo decai?

**8.7** Na LSTM, o que ocorre com a memória quando $\mathbf{f}_t=\mathbf{1}$ e $\mathbf{i}_t=\mathbf{0}$? E quando $\mathbf{f}_t=\mathbf{0}$ e $\mathbf{i}_t=\mathbf{1}$?

**8.8** Calcule o número de parâmetros de uma LSTM de duas camadas, bidirecional, com $F=4$ e $H=6$, e confira com o programa.

**8.9** Mostre que uma GRU contém a RNN simples como caso limite e confira numericamente com 50 passos.

**8.10** Um lote tem duas sequências de comprimentos $2$ e $4$, preenchidas com zeros até $4$. Explique por que a média dos estados de todos os $4$ instantes é errada para a sequência curta e escreva a **média mascarada**. Dê um exemplo numérico.

**8.11** Uma RNN com $\tanh$ tem $\lVert\mathbf{W}_{hh}\rVert_2=0{,}8$. Pelo Teorema 8.3, a partir de que distância $k$ a influência de um estado sobre outro é garantidamente menor que $10^{-6}$?

### Nível III: avançado

**8.12** Considere $\mathbf{W}=\bigl(\begin{smallmatrix}0{,}5&2\\0&0{,}5\end{smallmatrix}\bigr)$. Calcule $\rho(\mathbf{W})$ e $\lVert\mathbf{W}\rVert_2$ e compare $\lVert\mathbf{W}^k\rVert_2$ com os limites $\rho^k$ (inferior) e $\lVert\mathbf{W}\rVert_2^k$ (superior) do Teorema 8.3. Qual dos dois descreve melhor o comportamento?

**8.13** Implemente a LSTM da Definição 8.4 à mão e compare com `nn.LSTM`.

**8.14** (BPTT truncada) Seja $\gamma\sigma<1$ e suponha que a derivada imediata de cada estado em relação aos pesos tenha norma no máximo $C$. Limite a norma da parte do gradiente de $L_T$ em relação a $\mathbf{W}_{hh}$ que a BPTT truncada em $K$ passos **omite**.

**8.15** (a) Mostre que $s_t=\sin(\omega t+\phi)$ satisfaz $s_t=2\cos\omega\,s_{t-1}-s_{t-2}$. (b) Conclua que uma soma de duas senoides obedece a uma recorrência linear de ordem $4$. (c) Explique, com isso, o resultado da Parte B do Projeto 6.

## 8.9 Soluções comentadas

::: solucao 8.1
$H(F+H+2)=20\cdot32=640$ por bloco. RNN: $1\cdot640=640$; GRU: $3\cdot640=1\,920$; LSTM: $4\cdot640=2\,560$. O programa `c8_ex_numeros.py` confirma os três valores.
:::

::: solucao 8.2
$h_1=\tanh(0{,}5\cdot1+0)=\tanh0{,}5=0{,}4621$. $h_2=\tanh(0{,}5\cdot(-1)+1{,}2\cdot0{,}4621)=\tanh(0{,}0545)=0{,}0545$. $h_3=\tanh(0{,}5\cdot2+1{,}2\cdot0{,}0545)=\tanh(1{,}0654)=0{,}7877$. A entrada negativa quase **apaga** o estado ($0{,}46\to0{,}05$): a recorrência com $W_{hh}>1$ não garante memória, porque a entrada nova pesa tanto quanto o passado.
:::

::: solucao 8.3
(a) Muitos-para-um; bidirecional é adequado (a frase inteira está disponível). (b) Muitos-para-muitos sincronizado (o alvo em $t$ é a entrada em $t+1$); **não** bidirecional, porque ele veria o caractere que deve prever. (c) Muitos-para-muitos sincronizado; bidirecional é adequado e útil, pois o contexto à direita ajuda a classificar a palavra. (d) Muitos-para-um (ou um passo à frente); **não** bidirecional, porque o futuro não existe no momento da previsão.
:::

::: solucao 8.4
$\beta=2$: $f=0{,}8808$ e $k_{1/2}=0{,}6931/0{,}1269\approx5{,}5$ passos. $\beta=3$: $f=0{,}9526$ e $k_{1/2}\approx14{,}3$. Para $k_{1/2}=1\,000$: $\ln(1+e^{-\beta})=\ln2/1\,000\approx6{,}93\times10^{-4}$, logo $e^{-\beta}\approx6{,}93\times10^{-4}$ e $\beta\approx7{,}27$. A meia-vida cresce **exponencialmente** com $\beta$ (os valores $1{,}0$; $2{,}2$; $5{,}5$; $14{,}3$; $103{,}2$ para $\beta=0,1,2,3,5$ saem do programa).
:::

::: solucao 8.5
$\lVert\mathbf{g}\rVert=\sqrt{9+16+144}=13>5$, logo $\tilde{\mathbf{g}}=\mathbf{g}\cdot5/13=(1{,}154;\,1{,}538;\,4{,}615)$, de norma $5$ e na mesma direção.
:::

::: solucao 8.6
Desenrolando, $h_T=\sum_{s=1}^{T}w^{T-s}x_s$; derivando termo a termo em $w$, obtém-se a fórmula dada. Com $x_s=1$, $\partial h_T/\partial w=\sum_{k=0}^{T-1}kw^{k-1}\to1/(1-w)^2$ quando $T\to\infty$ (série geométrica derivada), que é **finito**, mas pode ser enorme: $100$ para $w=0{,}9$ e $10^4$ para $w=0{,}99$. O jacobiano de longo prazo $w^k$ decai, mas o gradiente em relação ao peso **compartilhado** **soma** as contribuições de todas as distâncias, e quando $w$ se aproxima de $1$ essa soma cresce sem limite. A sensibilidade ao peso é grande exatamente na região em que a rede começa a ter memória longa, o que ajuda a explicar a superfície de custo com variações abruptas e motiva o recorte.
:::

::: solucao 8.7
Com $\mathbf{f}_t=\mathbf{1}$ e $\mathbf{i}_t=\mathbf{0}$: $\mathbf{c}_t=\mathbf{c}_{t-1}$, a memória é **copiada** sem alteração (e o jacobiano do caminho direto é a identidade). Com $\mathbf{f}_t=\mathbf{0}$ e $\mathbf{i}_t=\mathbf{1}$: $\mathbf{c}_t=\mathbf{g}_t$, a memória é **apagada e substituída** pelo candidato, e a célula se comporta como uma RNN simples (o estado depende só da entrada e do estado anterior por $\mathbf{g}_t$).
:::

::: solucao 8.8
Na camada $1$, cada direção tem $4\cdot6\cdot(4+6+2)=288$ parâmetros, totalizando $576$ com as duas direções. Na camada $2$, a entrada tem dimensão $2H=12$ (saída concatenada das duas direções), logo cada direção tem $4\cdot6\cdot(12+6+2)=480$ e o total é $960$. Soma: $576+960=1\,536$, que é o valor impresso por `c8_ex_numeros.py`. Esquecer que a segunda camada recebe $2H$ e não $H$ é o erro mais frequente.
:::

::: solucao 8.9
Zerando todos os pesos da GRU e copiando os da RNN para o bloco do **candidato** $\mathbf{n}$, com viés $+40$ na porta $\mathbf{r}$ (logo $\mathbf{r}\approx\mathbf{1}$) e $-40$ na porta $\mathbf{z}$ (logo $\mathbf{z}\approx\mathbf{0}$), a interpolação $\mathbf{h}_t=(1-\mathbf{z}_t)\odot\mathbf{n}_t+\mathbf{z}_t\odot\mathbf{h}_{t-1}$ reduz-se a $\mathbf{h}_t=\mathbf{n}_t=\tanh(\mathbf{W}_n\mathbf{x}_t+\mathbf{U}_n\mathbf{h}_{t-1}+\mathbf{b})$, a RNN simples. A GRU é, portanto, uma **generalização** da RNN: contém-na como caso limite.

<<< codigo/c8_ex_gru_rnn.py

>>> codigo/c8_ex_gru_rnn.out
:::

::: solucao 8.10
A saída do preenchimento não é informação: ao incluir as posições $3$ e $4$ da sequência curta, a média **dilui** o valor com termos que dependem de zeros inventados. Com a máscara $m_t\in\{0,1\}$ ($1$ nas posições reais), $\bar{\mathbf{h}}=\sum_tm_t\mathbf{h}_t/\sum_tm_t$. Exemplo: estados escalares $(2,4,0,0)$ em uma sequência de comprimento $2$: a média correta é $(2+4)/2=3$, e a média ingênua é $6/4=1{,}5$, **metade** do valor correto.
:::

::: solucao 8.11
Com $\gamma=1$ e $\sigma=0{,}8$, a influência é limitada por $0{,}8^k$. Exige-se $0{,}8^k<10^{-6}$, ou seja, $k>6\ln10/(-\ln0{,}8)=13{,}8/0{,}223\approx61{,}9$, logo $k\ge62$ ($0{,}8^{62}=9{,}8\times10^{-7}$ e $0{,}8^{61}=1{,}2\times10^{-6}$). Em uma sequência de $100$ passos, o jacobiano entre o início e o fim tem norma abaixo de $10^{-6}$ para todos os instantes com mais de $61$ passos de distância.
:::

::: solucao 8.12
$\rho(\mathbf{W})=0{,}5$ (autovalor duplo) e $\lVert\mathbf{W}\rVert_2=2{,}118$. Em $k=10$: $\rho^k=9{,}8\times10^{-4}$, $\lVert\mathbf{W}\rVert_2^k=1{,}8\times10^{3}$ e o valor real é $\lVert\mathbf{W}^{10}\rVert_2=0{,}039$. O valor real está **entre** os limites, muito longe do superior: o teorema afirma $\le(\gamma\sigma)^k$, uma garantia **muito frouxa** para matrizes não normais, em que a norma de uma potência pode ficar acima de $\rho^k$ por muitos passos (aqui, a razão é $0{,}039/9{,}8\times10^{-4}\approx40$). O comportamento **assintótico** é governado por $\rho$ (decaimento como $k\rho^{k-1}$), o transitório pela norma. O limite superior só é informativo quando $\gamma\sigma<1$, e quando $\gamma\sigma>1$ nada se conclui, como a observação (iii) da seção 8.3 mostrou.

<<< codigo/c8_ex_naonormal.py

>>> codigo/c8_ex_naonormal.out
:::

::: solucao 8.13
<<< codigo/c8_ex_lstm_manual.py

>>> codigo/c8_ex_lstm_manual.out

As diferenças são de arredondamento em precisão simples. O ponto técnico é a ordem dos blocos de `weight_ih_l0`: $(\mathbf{i},\mathbf{f},\mathbf{g},\mathbf{o})$, e a soma dos dois vieses (`bias_ih` e `bias_hh`).
:::

::: solucao 8.14
Seja $\mathbf{r}_s$ a derivada imediata de $\mathbf{h}_s$ em relação a $\mathbf{W}_{hh}$ (por exemplo, $\mathbf{r}_s=\operatorname{diag}(1-\mathbf{h}_s^{\odot2})\,\mathbf{h}_{s-1}^{\top}$ no sentido tensorial), com $\lVert\mathbf{r}_s\rVert\le C$. O gradiente completo é $\sum_{s}(\partial L_T/\partial\mathbf{h}_T)(\partial\mathbf{h}_T/\partial\mathbf{h}_s)\mathbf{r}_s$. A BPTT truncada em $K$ passos retém os termos com $T-s\le K$ e omite os de $k=T-s>K$. Pelo Teorema 8.3, cada termo omitido tem norma no máximo $\lVert\partial L_T/\partial\mathbf{h}_T\rVert(\gamma\sigma)^kC$, e a soma geométrica dá
$$\lVert\text{omitido}\rVert\le\lVert\partial L_T/\partial\mathbf{h}_T\rVert\,C\sum_{k>K}(\gamma\sigma)^k=\lVert\partial L_T/\partial\mathbf{h}_T\rVert\,C\,\frac{(\gamma\sigma)^{K+1}}{1-\gamma\sigma}.$$
O erro **decai exponencialmente em $K$**: no regime de dissipação, a truncagem custa pouco **justamente porque** o que ela omite é pequeno. Isso é consistente, e ao mesmo tempo preocupante: a truncagem só é inofensiva quando a rede não consegue aprender dependências longas; quando o treino abre um caminho longo (portas abertas), a BPTT truncada **impede** que o gradiente o encontre.
:::

::: solucao 8.15
(a) Pela identidade $\sin(a+b)+\sin(a-b)=2\sin a\cos b$, com $a=\omega(t-1)+\phi$ e $b=\omega$: $s_t+s_{t-2}=\sin(\omega t+\phi)+\sin(\omega t-2\omega+\phi)=2\sin(\omega(t-1)+\phi)\cos\omega=2\cos\omega\,s_{t-1}$. (b) Se $\mathcal{A}_i$ é o operador $\mathcal{A}_is_t=s_t-2\cos\omega_i\,s_{t-1}+s_{t-2}$, ele anula as senoides de frequência $\omega_i$ e comuta com $\mathcal{A}_j$. A composição $\mathcal{A}_1\mathcal{A}_2$ anula a soma das duas senoides, e é uma recorrência linear de ordem $4$ com coeficientes constantes. (c) No caso sem ruído, um modelo AR de ordem $4$ prevê a série **exatamente**; com ruído, a regressão linear sobre $30$ valores faz uma média que reduz o efeito do ruído nas entradas, e por isso chega a $0{,}0111$, próximo do piso de $0{,}0100$. Não há estrutura **não linear** para a rede recorrente aproveitar, e o empate com o modelo linear é o esperado. Para testar a vantagem das redes, é preciso uma série não linear (Melhorias possíveis).
:::

## 8.10 Referências e leituras

### Livros didáticos fundamentais

- GOODFELLOW, I.; BENGIO, Y.; COURVILLE, A. *Deep Learning*. Cambridge: MIT Press, 2016. Capítulo 10 (redes recorrentes e recursivas). Texto completo em deeplearningbook.org.
- ZHANG, A.; LIPTON, Z. C.; LI, M.; SMOLA, A. J. *Dive into Deep Learning*. Cambridge: Cambridge University Press, 2023. Capítulos sobre redes recorrentes. Texto completo em d2l.ai.

### Artigos originais

- BAHDANAU, D.; CHO, K.; BENGIO, Y. Neural machine translation by jointly learning to align and translate. In: *3rd International Conference on Learning Representations (ICLR)*, 2015.
- BENGIO, Y.; SIMARD, P.; FRASCONI, P. Learning long-term dependencies with gradient descent is difficult. *IEEE Transactions on Neural Networks*, v. 5, n. 2, p. 157–166, 1994.
- CHO, K. et al. Learning phrase representations using RNN encoder–decoder for statistical machine translation. In: *Proceedings of the Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2014. p. 1724–1734.
- ELMAN, J. L. Finding structure in time. *Cognitive Science*, v. 14, n. 2, p. 179–211, 1990.
- GERS, F. A.; SCHMIDHUBER, J.; CUMMINS, F. Learning to forget: continual prediction with LSTM. *Neural Computation*, v. 12, n. 10, p. 2451–2471, 2000.
- HOCHREITER, S. *Untersuchungen zu dynamischen neuronalen Netzen*. Diplomarbeit, Technische Universität München, 1991.
- HOCHREITER, S.; SCHMIDHUBER, J. Long short-term memory. *Neural Computation*, v. 9, n. 8, p. 1735–1780, 1997.
- JOZEFOWICZ, R.; ZAREMBA, W.; SUTSKEVER, I. An empirical exploration of recurrent network architectures. In: *Proceedings of the 32nd International Conference on Machine Learning (ICML)*, 2015.
- PASCANU, R.; MIKOLOV, T.; BENGIO, Y. On the difficulty of training recurrent neural networks. In: *Proceedings of the 30th International Conference on Machine Learning (ICML)*, 2013.
- SUTSKEVER, I.; VINYALS, O.; LE, Q. V. Sequence to sequence learning with neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 27, 2014.

### Documentação técnica

- PyTorch: `torch.nn.RNN`, `GRU`, `LSTM` e `torch.nn.utils.rnn` (`pad_sequence`, `pack_padded_sequence`), `torch.nn.utils.clip_grad_norm_`; pytorch.org/docs. Versão 2.15 nas execuções deste livro.
