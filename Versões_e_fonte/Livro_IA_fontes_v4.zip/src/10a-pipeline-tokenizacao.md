<div class="objetivos">

Objetivos do capítulo

- Descrever o *pipeline* moderno de processamento de linguagem natural, da cadeia de caracteres ao tensor de identificadores e à perda de treinamento, e dizer o que cada componente da biblioteca `transformers` faz.
- Explicar por que modelos de linguagem usam **subpalavras**, e quantificar o compromisso entre o tamanho do vocabulário, o comprimento das sequências e o custo de cálculo.
- Implementar do zero o algoritmo **BPE** em nível de bytes, **demonstrar** que a codificação é sem perdas e que não existe token desconhecido, e medir o efeito do número de fusões.
- Distinguir BPE, WordPiece e Unigram (SentencePiece) pelo critério de construção do vocabulário e pela regra de codificação.
- Usar tokens especiais, preenchimento, truncamento e máscara de atenção, e relacioná-los às máscaras do Capítulo 9.
- Explicar o ajuste fino completo e o custo de memória do treino, a adaptação de baixo posto **LoRA** (com a dedução do número de parâmetros, do posto e dos gradientes) e a quantização de pesos, e executar um experimento que compara o ajuste completo com a LoRA.

**Pré-requisitos:** Capítulo 1 (posto, SVD), Capítulo 6 (retropropagação, otimizadores, PyTorch), Capítulo 9 (Transformer, máscaras, contagem de parâmetros).

</div>

## 10.1 O pipeline moderno de linguagem

O Capítulo 9 descreveu a arquitetura. Para usá-la sobre **texto**, falta tudo o que vem antes e depois dela: transformar uma cadeia de caracteres em números, empacotá-los em lotes, treinar, e medir. Esse caminho é, hoje, bastante padronizado.

| Etapa | O que acontece | Objeto típico na biblioteca |
|---|---|---|
| 1. Normalização | Padroniza o texto (por exemplo, minúsculas, remoção de acentos, normalização Unicode). Opcional, e **destrutiva** quando remove informação. | `normalizer` do tokenizador |
| 2. Pré-tokenização | Separa o texto em "pedaços" (palavras, números, pontuação) **dentro dos quais** a subdivisão ocorre. | `pre_tokenizer` |
| 3. Modelo de subpalavras | Divide cada pedaço em subpalavras do vocabulário (BPE, WordPiece, Unigram). | `model` |
| 4. Identificadores | Cada subpalavra vira um inteiro $\in\{0,\dots,V-1\}$; acrescentam-se tokens especiais. | `Tokenizer`, `PreTrainedTokenizerFast` |
| 5. Lotes | Sequências de comprimentos diferentes são preenchidas (*padding*) e truncadas; gera-se a máscara de atenção. | tokenizador e *data collator* |
| 6. Modelo | Os identificadores indexam a matriz de embeddings; o Transformer produz *logits* de dimensão $V$ em cada posição. | `AutoModel...`, `GPT2LMHeadModel` |
| 7. Perda e otimização | Entropia cruzada com o próximo token (modelos de linguagem) ou com o rótulo (classificação); otimizador AdamW. | `Trainer`, laço manual |

O **tokenizador é parte do modelo**. Os identificadores só fazem sentido para a matriz de embeddings com a qual o modelo foi treinado: trocar o tokenizador de um modelo pré-treinado invalida seus pesos de entrada e de saída. Por isso, um modelo pré-treinado é distribuído **junto** com seu tokenizador, e o tokenizador deve ser construído **somente com dados de treino** (como qualquer outro ajuste de parâmetros, ele pode vazar informação da validação se tiver visto esses dados).

## 10.2 Por que subpalavras

Há três escolhas naturais para a unidade do modelo de linguagem.

- **Palavras.** O vocabulário cresce sem limite (flexões, nomes próprios, erros de digitação, termos técnicos), e qualquer palavra fora dele precisa virar um token "desconhecido", que descarta a informação. Em português, cada verbo tem dezenas de formas.
- **Caracteres (ou bytes).** O vocabulário é minúsculo e fechado, mas as sequências ficam longas: um parágrafo de $1\,000$ caracteres tem cerca de $1\,000$ posições. Como a autoatenção custa $O(T^2d)$ (seção 9.1), o custo cresce com o quadrado desse comprimento, e o contexto útil, medido em ideias, encolhe.
- **Subpalavras.** Palavras frequentes ficam inteiras, e palavras raras são decompostas em pedaços frequentes (radicais, prefixos, sufixos). O vocabulário tem de centenas a algumas centenas de milhares de entradas, e as sequências ficam, em média, de 2 a 4 vezes mais curtas que em caracteres.

Dois números resumem a eficiência de um tokenizador sobre um texto. A **razão de bytes por token** é $\rho=n_{\text{bytes}}/n_{\text{tokens}}$ (quanto maior, mais compacto); seu inverso, os **tokens por mil bytes**, é a medida usada nas tabelas deste capítulo, porque, ao contrário de "tokens por palavra", não depende de como se define uma palavra.

::: proposicao 10.1 · O compromisso do tamanho do vocabulário
Seja $V$ o tamanho do vocabulário, $d$ a dimensão do modelo e $T$ o número de tokens de um texto fixo. Se o modelo tem $N$ blocos, então: (a) a matriz de embeddings tem $Vd$ parâmetros (e outros $Vd$ na camada de saída, a menos que os pesos sejam amarrados); (b) o custo das projeções e da rede por posição é $O(T\,Nd^2)$, linear em $T$; (c) o custo das pontuações de atenção é $O(T^2Nd)$, quadrático em $T$. Aumentar $V$ **aumenta** (a) e, ao encurtar o texto, **diminui** (b) e (c).
:::

::: demonstracao
Cada item é uma contagem direta. (a) A tabela de embeddings tem uma linha de $d$ números por token do vocabulário. (b) Em cada bloco, as projeções e a rede por posição aplicam matrizes $d\times d$ ou $d\times4d$ a cada uma das $T$ posições (seção 9.6), logo $O(Td^2)$ por bloco. (c) A matriz de pontuações é $T\times T$ e cada entrada é um produto escalar de dimensão $d_k$ por cabeça (seção 9.3). Para um texto fixo, $T$ é uma função decrescente de $V$: se o tokenizador compacta o texto por um fator $c<1$ (isto é, $T\to cT$), (b) é multiplicado por $c$ e (c) por $c^2$.
:::

::: exemplo 10.1 · O que $1\,056$ tokens compram
O experimento da seção 10.3 treina um BPE com $V=256+800=1\,056$ sobre a prosa deste livro. Sobre a validação, um parágrafo de $1\,000$ bytes vira, em média, $349{,}3$ tokens (e não $1\,000$). Pela Proposição 10.1, com $c=0{,}349$, as projeções e a rede por posição custam $0{,}349$ do que custariam em bytes, e as pontuações de atenção $0{,}349^2\approx0{,}12$, isto é, cerca de **8 vezes menos**. O preço é a tabela de embeddings: com $d=128$, são $1\,056\times128=135\,168$ parâmetros que o modelo em bytes (com $256\times128=32\,768$) não teria. Em um modelo grande, com $d$ de milhares, os vocabulários de dezenas de milhares de tokens seguem a mesma lógica.
:::

Há ainda um efeito qualitativo: um tokenizador aprendido sobre um tipo de texto fragmenta mais os textos de outro tipo (outra língua, código, notação matemática), e isso aumenta tanto o custo quanto a dificuldade de aprendizagem para esses textos. A seção 10.3 mostra um exemplo em miniatura.

## 10.3 Byte-Pair Encoding (BPE)

O BPE foi proposto como algoritmo de compressão de dados por Gage (1994) e adaptado à tradução automática neural por Sennrich, Haddow e Birch (2016), para tratar palavras raras. Os modelos da família GPT usam uma variante que opera sobre **bytes** UTF-8.

::: definicao 10.1 · Treinamento do BPE
Dados um corpus, a **pré-tokenização** que o divide em pedaços e um número $K$ de fusões:

1. Represente cada pedaço como uma sequência de símbolos iniciais (aqui, os $256$ valores possíveis de byte) e conte a frequência de cada pedaço distinto.
2. Repita $K$ vezes: conte, sobre todos os pedaços (ponderados por sua frequência), todos os pares de símbolos adjacentes; escolha o par $(a,b)$ **mais frequente** (com desempate determinístico); crie o símbolo $ab$ e substitua $(a,b)$ por $ab$ em todos os pedaços.
3. A lista **ordenada** das fusões é o modelo. O vocabulário final tem os símbolos iniciais mais um símbolo novo por fusão.
:::

::: definicao 10.2 · Codificação com BPE
Para codificar um texto novo, aplica-se a pré-tokenização e, em cada pedaço, começando pelos símbolos iniciais, **aplica-se repetidamente a fusão de menor posto** (a que foi aprendida primeiro) entre as aplicáveis, até que nenhuma seja aplicável. A concatenação dos símbolos resultantes, em ordem, é a sequência de tokens do texto.
:::

Duas observações de implementação. Primeiro, a **pré-tokenização** impede que uma fusão atravesse a fronteira entre pedaços; sem ela, o algoritmo aprenderia pares como "o espaço seguido de $d$" e "a" seguido de "o" dentro de frases inteiras, e o vocabulário gastaria entradas em combinações de palavras. Aqui, a expressão regular separa palavras **junto com o espaço que as precede**, números, pontuação e espaços em branco, de modo que `" de"` e `"de"` sejam pedaços distintos. Segundo, quando o par é da forma $(a,a)$ em uma sequência $aaa$, existem dois pares sobrepostos, mas só uma fusão é possível; a substituição é feita da esquerda para a direita.

::: proposicao 10.2 · Propriedades do BPE em bytes
Seja $\mathcal{T}$ um BPE em bytes com $K$ fusões. Então: (a) **sem perdas:** a concatenação dos tokens de $x$ é exatamente a sequência de bytes de $x$, e portanto $\operatorname{decodificar}(\operatorname{codificar}(x))=x$ para todo texto $x$; (b) **sem token desconhecido:** todo texto, em qualquer língua ou alfabeto, é codificável; (c) **monotonia:** o número de tokens de qualquer texto não aumenta com $K$; (d) o vocabulário tem exatamente $256+K$ entradas (se houver $K$ pares a fundir).
:::

::: demonstracao
(a) Cada símbolo é uma cadeia de bytes, e fundir $(a,b)$ em $ab$ **concatena** as cadeias; portanto, a concatenação dos símbolos de um pedaço não muda em nenhuma fusão. Como a pré-tokenização particiona o texto (os pedaços, concatenados em ordem, dão o texto original), a concatenação de todos os tokens é a sequência de bytes de $x$, e decodificar é concatenar e interpretar como UTF-8. (b) Os $256$ símbolos iniciais cobrem todo byte, e todo texto UTF-8 é uma sequência de bytes. (c) Passar de $K$ para $K+1$ fusões substitui, em cada pedaço, algumas ocorrências de $(a,b)$ por um único símbolo, o que reduz o comprimento por uma unidade por substituição e não altera mais nada. (d) Cada fusão cria um símbolo novo.
:::

O programa abaixo implementa as Definições 10.1 e 10.2 em Python puro e confere a Proposição 10.2 sobre a validação inteira.

<<< codigo/c10_bpe_manual.py

>>> codigo/c10_bpe_manual.out

Leitura dos resultados.

- **Efeito do número de fusões** (Figura 10.1). Com $K=0$, são $1\,000$ tokens por mil bytes, o texto em bytes. Com $K=800$, são $349{,}3$, ou $2{,}86$ bytes por token. A curva é decrescente, como a Proposição 10.2(c) exige, e tem **retornos decrescentes**: as primeiras $100$ fusões reduzem $1\,000$ para $581$, e as últimas $400$, de $420$ para $349$. As fusões mais frequentes são as mais úteis, por construção.
- **O que o algoritmo aprende.** As primeiras fusões juntam o espaço com letras frequentes (`" d"`, `" e"`, `" a"`) e pares comuns do português (`re`, `nt`, `ad`, `os`); a fusão `(�|�)` seguida de `(ã|o)` é a formação de `ã` e `ão`, em que o símbolo é um **byte isolado** de um caractere de dois bytes e, por isso, é exibido como o caractere de substituição. As últimas fusões já são pedaços de palavras longas e termos do próprio livro (`icamente`, `STM`, `Capítulo`).
- **Palavra frequente, palavra rara.** A frase comum é dividida em $18$ tokens, quase todos palavras ou radicais inteiros. A palavra `hiperparametrização`, que **não aparece** no corpus de treino com essa grafia, é decomposta em $8$ pedaços: `h`, `i`, `per`, `par`, `am`, `et`, `r`, `ização`. O vocabulário não a conhece, mas ainda a representa, e o final `ização` foi aprendido de outras palavras.
- **Sem token desconhecido.** O texto com `∑` e `日本`, que não ocorrem no treino, é codificado e decodificado sem perda, porque cai nos bytes. Este é o ponto forte do BPE em bytes frente a um vocabulário de caracteres.

<figure>
+++ fig_c10_bpe.svg
<figcaption><b>Figura 10.1.</b> Retornos decrescentes das fusões do BPE. Eixo horizontal: número $K$ de fusões; eixo vertical: tokens por mil bytes na validação (valores do programa acima). A primeira centena de fusões faz a maior parte da compressão.</figcaption>
</figure>

::: nota Bytes e a notação de `Ġ`
Na biblioteca `tokenizers`, o BPE em bytes representa cada byte por um caractere imprimível (uma tabela fixa, herdada do GPT-2), para que o vocabulário possa ser salvo em texto. É por isso que, na saída do próximo programa, o espaço aparece como `Ġ` e `ção` como `Ã§Ã£` (os bytes `0xC3 0xA7 0xC3 0xA3` mostrados como caracteres). A decodificação desfaz o mapeamento, e o texto volta idêntico.
:::

## 10.4 WordPiece, Unigram e SentencePiece

O BPE não é o único modo de construir um vocabulário de subpalavras. Três famílias aparecem na prática.

**WordPiece** (Schuster e Nakajima, 2012, para reconhecimento de voz em japonês e coreano; usado no BERT). Duas diferenças em relação ao BPE. Primeira, as subpalavras que **continuam** uma palavra levam um prefixo (`##`), de modo que `##ização` é distinto de `ização` no início de uma palavra. Segunda, a regra de codificação é gulosa por **maior prefixo**: a cada passo, toma-se do início da palavra a **mais longa** subpalavra do vocabulário e prossegue-se com o resto; se nem um único caractere restante estiver no vocabulário, a palavra inteira vira `[UNK]`. Na descrição original, o critério para escolher **quais** subpalavras entram no vocabulário é a verossimilhança de um modelo de linguagem sobre o corpus, e não a frequência bruta do par.

**Unigram** (Kudo, 2018). Parte de um vocabulário grande e o **poda** iterativamente. Cada subpalavra $s$ tem uma probabilidade $p(s)$, e a segmentação de uma palavra é a que **maximiza** o produto das probabilidades das subpalavras (obtida por programação dinâmica). Como várias segmentações têm probabilidade positiva, pode-se **sorteá-las** durante o treino (*subword regularization*), o que age como aumento de dados. É o modelo usado por vários sistemas da família T5.

**SentencePiece** (Kudo e Richardson, 2018) é uma **biblioteca** que treina BPE ou Unigram diretamente sobre o texto bruto, **sem** pré-tokenização por espaços: o espaço é tratado como um símbolo comum (`▁`). Isso a torna adequada a línguas escritas sem espaços entre palavras.

| | BPE | WordPiece | Unigram |
|---|---|---|---|
| Como o vocabulário é construído | **Fusão** gulosa do par mais frequente | Fusão (descrita pelo critério de verossimilhança) | **Poda** de um vocabulário grande |
| Regra de codificação | Fusões na ordem em que foram aprendidas | Maior prefixo, guloso | Segmentação de maior probabilidade (Viterbi) |
| Segmentação por texto | Única | Única | Várias possíveis (pode ser sorteada) |
| Sem token desconhecido? | Sim, se a base for o byte | Não (`[UNK]`) | Depende do alfabeto base |
| Usos típicos | Família GPT, Llama, muitos outros | BERT e derivados | T5, ALBERT, XLNet |

O programa a seguir treina um BPE em bytes e um WordPiece com a biblioteca `tokenizers` (ambos com vocabulário $1\,000$, sobre o mesmo corpus de treino do programa anterior) e compara-os.

<<< codigo/c10_tokenizers.py

>>> codigo/c10_tokenizers.out

::: atencao Os dois números de compressão não são comparáveis
O WordPiece produziu $320{,}2$ tokens por mil bytes, e o BPE $354{,}4$. **Isso não mostra que o WordPiece é mais eficiente.** O normalizador do WordPiece converte tudo para minúsculas e a pré-tokenização descarta os espaços, e, diferentemente do BPE, a decodificação **não** devolve o texto original: `A regularização...` voltou como `a regularização...`, e `∑` e `日本` viraram `[UNK]`. Compara-se, portanto, uma representação com perdas e uma sem perdas. Além disso, o treinador de WordPiece da biblioteca não reproduz necessariamente o critério de verossimilhança da descrição original; o que se pode afirmar é a diferença de **comportamento**, e não a de qualidade.
:::

Na saída, vê-se a regra de maior prefixo do WordPiece: `hiperparametrização` virou `hip`, `##er`, `##par`, `##am`, `##et`, `##ri`, `##za`, `##ção`, com os prefixos `##` marcando continuações, e a decodificação os remove.

## 10.5 Tokens especiais, preenchimento, truncamento e máscara

Além das subpalavras, o vocabulário reserva **tokens especiais**, cada um com uma função de interface entre os dados e o modelo.

- `[CLS]` e `[SEP]` (BERT): início da sequência (cuja saída resume a sequência na classificação) e separador entre segmentos. `[MASK]` marca a posição a prever no objetivo de linguagem mascarada (seção 9.7).
- `<eos>` / fim de texto (modelos decodificadores): separa documentos concatenados durante o pré-treino e sinaliza ao gerador quando parar.
- `[PAD]` / `<pad>`: preenche as sequências curtas de um lote até o comprimento da mais longa.
- `[UNK]`: substitui o que não está no vocabulário (inexistente no BPE em bytes).

Um lote precisa ser um tensor retangular, mas os textos têm comprimentos diferentes. O tokenizador **preenche** (*padding*) os curtos com `[PAD]`, **trunca** os longos ao máximo permitido pelo modelo (o comprimento do contexto, $P$ na contagem de parâmetros da seção 9.6) e devolve, além dos `input_ids`, a **máscara de atenção** (`attention_mask`): $1$ onde há token real e $0$ onde há preenchimento. É a **máscara de preenchimento** do Capítulo 9, que impede a atenção de consultar posições sem informação. A saída do programa anterior mostra um lote de duas frases, truncado em $12$ tokens:

- a primeira frase tem $5$ tokens e $7$ posições de preenchimento (identificador $0$, máscara $0$);
- a segunda foi truncada em $12$ tokens: `a reg ##ular ##ização reduz o super ##a ##jus ##te dos hip`, e perdeu o resto da frase.

O truncamento é uma perda silenciosa de informação, e escolher o comprimento máximo é uma decisão de projeto: texto cortado em um documento de classificação pode remover a evidência decisiva.

::: erro Armadilhas frequentes com tokenizadores
(1) **Treinar o tokenizador com todos os dados**, incluindo validação e teste: vaza a distribuição dos dados de avaliação. (2) **Misturar tokenizador e modelo** de origens diferentes: os identificadores perdem o sentido. (3) **Esquecer a máscara de atenção** ao usar preenchimento: o modelo passa a atender a posições de preenchimento. (4) **Calcular perplexidade por token e compará-la entre tokenizadores diferentes**: a perplexidade por token depende do tamanho do vocabulário e do comprimento médio dos tokens; para comparar tokenizadores, usa-se uma medida por byte (bits por byte), como o bpc do Capítulo 9. (5) **Perder informação na normalização** (minúsculas, remoção de acentos) em uma língua em que ela distingue palavras.
:::
