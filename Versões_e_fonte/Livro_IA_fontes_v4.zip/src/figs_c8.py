"""Figuras do Capítulo 8 (SVG), com valores lidos das saídas reais dos programas."""
import re
import numpy as np
from figs_c6 import painel, curva, legenda, salvar, fmt  # noqa: F401

SETA = '<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker></defs>'


def caixa(x, y, w, h, texto, cls="cx", fonte=14):
    return f'<rect class="{cls}" x="{x}" y="{y}" width="{w}" height="{h}" rx="8"/><text x="{x+w/2}" y="{y+h/2+5}" font-size="{fonte}" text-anchor="middle">{texto}</text>'


def seta(x1, y1, x2, y2, cls="seta"):
    return f'<line class="{cls}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/>'


# ---------- Figura 8.1: rede recorrente desdobrada no tempo ----------
c = [SETA]
xs = [70, 230, 390, 550]
rot = ["t−1", "t", "t+1", "t+2"]
for i, x in enumerate(xs):
    c.append(caixa(x - 40, 90, 80, 50, f"h<tspan font-size='10' dy='4'>{rot[i]}</tspan>", "cxa"))
    c.append(seta(x, 205, x, 142))
    c.append(f'<text x="{x}" y="226" font-size="14" text-anchor="middle">x<tspan font-size="10" dy="4">{rot[i]}</tspan></text>')
    c.append(seta(x, 88, x, 42))
    c.append(f'<text x="{x}" y="30" font-size="14" text-anchor="middle">ŷ<tspan font-size="10" dy="4">{rot[i]}</tspan></text>')
    if i:
        c.append(seta(xs[i - 1] + 42, 115, x - 42, 115))
c.append(seta(0, 115, 28, 115))
c.append(seta(xs[-1] + 42, 115, 636, 115))
c.append('<text x="150" y="104" font-size="12" text-anchor="middle" class="t2">W<tspan font-size="9" dy="3">hh</tspan></text>')
c.append('<text x="310" y="104" font-size="12" text-anchor="middle" class="t2">W<tspan font-size="9" dy="3">hh</tspan></text>')
c.append('<text x="470" y="104" font-size="12" text-anchor="middle" class="t2">W<tspan font-size="9" dy="3">hh</tspan></text>')
c.append('<text x="238" y="182" font-size="12" class="t2">W<tspan font-size="9" dy="3">xh</tspan></text>')
c.append('<text x="238" y="66" font-size="12" class="t2">W<tspan font-size="9" dy="3">hy</tspan></text>')
c.append('<text x="320" y="252" font-size="13" text-anchor="middle">os mesmos W<tspan font-size="9" dy="3">xh</tspan><tspan dy="-3">, W</tspan><tspan font-size="9" dy="3">hh</tspan><tspan dy="-3">, W</tspan><tspan font-size="9" dy="3">hy</tspan><tspan dy="-3"> em todos os instantes (compartilhamento de parâmetros)</tspan></text>')
salvar("fig_c8_desdobrada.svg", 640, 266, "Rede recorrente desdobrada no tempo: o estado oculto de cada instante depende da entrada atual e do estado anterior, com pesos compartilhados", c)


# ---------- auxiliares: ler tabelas das saídas ----------
def tabela(arq, colunas):
    out = {}
    for lin in open(arq):
        m = re.match(r"^(\S.*?)\s{2,}((?:[0-9.e+\-]+\s*){%d})$" % colunas, lin.rstrip())
        if m:
            out[m.group(1)] = [float(v) for v in m.group(2).split()]
    return out


def lg(v):
    return np.log10(max(v, 1e-30))


# ---------- Figura 8.2: norma do jacobiano em função da distância (c8_gradiente_tempo.out) ----------
T = tabela("codigo/c8_gradiente_tempo.out", 6)
ks = [1, 5, 10, 20, 40, 60]
sel = [("identidade, ρ = 0.5", "lr", None), ("identidade, ρ = 1.0", "lv", None), ("identidade, ρ = 1.1", "lm", None),
       ("tanh, ρ = 0.9", "la", "6 3"), ("tanh, ρ = 1.5", "lg", "6 3")]
c = []
s, X, Y = painel(70, 20, 520, 250, 0, 60, -24, 12, [0, 10, 20, 30, 40, 50, 60], [-24, -18, -12, -6, 0, 6, 12], "distância k (passos no tempo)", "norma de ∂h_T/∂h_(T−k)", lambda v: f"1e{int(v)}")
c += s
for nome, cls, dash in sel:
    c.append(curva(X, Y, ks, [lg(v) for v in T[nome]], cls, dash))
c += legenda([(cls, n.replace("identidade", "linear").replace(".", ","), d) for n, cls, d in sel[:3]], 40, 330, 190)
c += legenda([(cls, n.replace(".", ","), d) for n, cls, d in sel[3:]], 40, 352, 190)
salvar("fig_c8_jacobiano.svg", 640, 372, "Norma do jacobiano entre estados distantes em uma rede recorrente: decai ou explode exponencialmente com a distância", c)

# ---------- Figura 8.3: gradiente por modelo (c8_gradiente_modelos.out) ----------
M = tabela("codigo/c8_gradiente_modelos.out", 5)
kk = [1, 10, 25, 50, 99]
sel = [("RNN", "lr", None), ("GRU", "la", None), ("LSTM", "lm", None), ("GRU viés z = 5", "lg", "6 3"), ("LSTM viés f = 5", "lv", "6 3")]
c = []
s, X, Y = painel(70, 20, 520, 250, 0, 100, -22, 0, [0, 25, 50, 75, 100], [-20, -15, -10, -5, 0], "distância k (passos no tempo), T = 100", "norma de ∂perda/∂x_(T−k)", lambda v: f"1e{int(v)}")
c += s
for nome, cls, dash in sel:
    chave = nome.replace(" viés", ", viés")
    pts = [(k, v) for k, v in zip(kk, M[chave]) if v > 0]                # a RNN em k = 99 é 0 em ponto flutuante: omitido
    c.append(curva(X, Y, [p[0] for p in pts], [lg(p[1]) for p in pts], cls, dash))
    for k, v in pts:
        c.append(f'<circle cx="{fmt(X(k))}" cy="{fmt(Y(lg(v)))}" r="3.5" style="fill:var(--papel);stroke-width:2" class="{cls}"/>')
c += legenda([(cls, n, d) for n, cls, d in sel[:3]], 40, 330, 150)
c += legenda([(cls, n, d) for n, cls, d in sel[3:]], 40, 352, 190)
salvar("fig_c8_gradiente_modelos.svg", 640, 372, "Norma do gradiente da perda em relação à entrada a k passos do fim, em RNN, GRU e LSTM, com inicialização padrão e com viés alto nas portas", c)

# ---------- Figura 8.4: célula LSTM ----------
c = [SETA]
c.append('<text x="22" y="30" font-size="14" text-anchor="middle">c<tspan font-size="10" dy="4">t−1</tspan></text>')
c.append('<text x="618" y="30" font-size="14" text-anchor="middle">c<tspan font-size="10" dy="4">t</tspan></text>')
c.append('<line class="lm" x1="40" y1="44" x2="596" y2="44" style="stroke-width:3.5" marker-end="url(#pt-seta)"/>')
def op(x, y, r):
    return f'<circle cx="{x}" cy="{y}" r="15" class="cxm"/><text x="{x}" y="{y+6}" font-size="17" text-anchor="middle">{r}</text>'
c += [op(170, 44, "⊙"), op(320, 44, "⊕"), op(320, 130, "⊙"), op(470, 165, "⊙")]
# porta f -> ⊙ sobre a memória
c.append(seta(170, 226, 170, 61))
# i e g -> ⊙ -> ⊕
c.append('<polyline class="seta" points="270,226 270,130 303,130"/>')
c.append('<polyline class="seta" points="370,226 370,130 337,130"/>')
c.append(seta(320, 113, 320, 61))
# leitura: c_t -> tanh -> ⊙ <- o
c.append('<line class="ln" x1="470" y1="44" x2="470" y2="70"/>')
c.append(seta(470, 70, 470, 78))
c.append(caixa(440, 78, 60, 30, "tanh", "cx", 13))
c.append(seta(470, 108, 470, 148))
c.append(seta(470, 226, 470, 182))
c.append(seta(485, 165, 600, 165))
c.append('<text x="618" y="170" font-size="14" text-anchor="middle">h<tspan font-size="10" dy="4">t</tspan></text>')
# portas
for x, f, n in ((170, "σ", "f"), (270, "σ", "i"), (370, "tanh", "g"), (470, "σ", "o")):
    c.append(caixa(x - 36, 226, 72, 34, f"{n} = {f}", "cxa" if f == "σ" else "cx", 13))
    c.append(seta(x, 296, x, 262))
c.append('<line class="ln" x1="150" y1="296" x2="470" y2="296"/><line class="ln" x1="60" y1="296" x2="150" y2="296"/>')
c.append(seta(10, 296, 60, 296))
c.append('<text x="108" y="318" font-size="13" text-anchor="middle">[h<tspan font-size="10" dy="4">t−1</tspan><tspan dy="-4">, x</tspan><tspan font-size="10" dy="4">t</tspan><tspan dy="-4">]</tspan></text>')
c.append('<text x="170" y="206" font-size="12" text-anchor="middle" class="t2">esquecer</text><text x="270" y="206" font-size="12" text-anchor="middle" class="t2">escrever</text><text x="370" y="206" font-size="12" text-anchor="middle" class="t2">candidato</text><text x="470" y="206" font-size="12" text-anchor="middle" class="t2">ler</text>')
salvar("fig_c8_lstm.svg", 640, 330, "Célula LSTM: o estado de memória atravessa a célula por uma linha aditiva, controlada por portas de esquecimento, escrita e leitura", c)

# ---------- Figura 8.5: Projeto 6, memória atrasada (lê projeto6A.out e projeto6C.out) ----------
def le(arq):
    d = {}
    for lin in open(arq):
        m = re.match(r"^\s*(\d+)\s+(.+)$", lin)
        if m:
            d[int(m.group(1))] = [float(a) for a in re.findall(r"([0-9.]+)±", m.group(2))]
    return d
A, C = le("codigo/projeto6A.out"), le("codigo/projeto6C.out")
Ts = [5, 10, 20, 40, 80]
curvas = [("RNN", "lr", None, [A[t][0] for t in Ts]), ("GRU", "la", None, [A[t][1] for t in Ts]), ("LSTM", "lm", None, [A[t][2] for t in Ts]),
          ("GRU, z + 5", "lg", "6 3", [C[t][0] for t in (20, 40, 80)]), ("LSTM, f + 5", "lv", "6 3", [C[t][1] for t in (20, 40, 80)])]
c = []
s, X, Y = painel(70, 20, 520, 240, 0, 80, 0, 1.05, [5, 10, 20, 40, 80], [0, 0.2, 0.4, 0.6, 0.8, 1.0], "atraso T (passos até a resposta)", "acurácia no teste")
c += s
c.append(f'<line class="fraco" x1="70" y1="{fmt(Y(0.2))}" x2="590" y2="{fmt(Y(0.2))}" style="stroke:var(--rubi);stroke-dasharray:2 4"/>')
c.append(f'<text x="588" y="{fmt(Y(0.2)-5)}" font-size="11" text-anchor="end" class="t2">acaso (0,20)</text>')
for nome, cls, dash, v in curvas:
    tt = Ts if len(v) == 5 else [20, 40, 80]                 # as variantes com viés alto foram medidas só para T >= 20
    c.append(curva(X, Y, tt, v, cls, dash))
    for t, a in zip(tt, v):
        c.append(f'<circle cx="{fmt(X(t))}" cy="{fmt(Y(a))}" r="3.5" style="fill:var(--papel);stroke-width:2" class="{cls}"/>')
c += legenda([(cls, n, d) for n, cls, d, _ in curvas[:3]], 40, 318, 150)
c += legenda([(cls, n, d) for n, cls, d, _ in curvas[3:]], 40, 340, 190)
salvar("fig_c8_memoria.svg", 640, 360, "Acurácia na tarefa de memória atrasada em função do atraso, para RNN, GRU e LSTM, com inicialização padrão e com viés alto nas portas", c)
print("ok")
