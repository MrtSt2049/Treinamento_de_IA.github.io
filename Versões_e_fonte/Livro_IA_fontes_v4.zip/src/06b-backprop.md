## 6.5 Retropropagação

Treinar uma rede é minimizar $\mathcal{L}(\boldsymbol\theta)$ pela descida do gradiente (seção 1.11), e isso exige o gradiente de $\mathcal{L}$ em relação a **todos** os parâmetros. Uma rede moderna tem de milhões a bilhões deles. A **retropropagação** (*backpropagation*) calcula todas as derivadas parciais com um custo da mesma ordem de uma avaliação da rede. Não é um algoritmo novo de otimização: é a **regra da cadeia** (seção 1.9) aplicada de modo sistemático e com reaproveitamento de cálculos.

### O grafo de computação

O cálculo da perda pode ser desenhado como um grafo em que cada nó é uma operação simples e cada aresta, um valor intermediário. A figura mostra a rede de duas camadas usada nos exemplos.

<figure>
+++ fig_c6_backprop.svg
<figcaption><b>Figura 6.2.</b> Grafo de computação de uma rede de duas camadas. O passo para frente (setas cinzentas) calcula e guarda os valores intermediários. O passo para trás (setas tracejadas) propaga o gradiente, reutilizando os valores guardados.</figcaption>
</figure>

O gradiente em relação a um parâmetro é o produto das derivadas ao longo do caminho que o liga à perda. Há dois ingredientes. Primeiro, o passo para frente deve **guardar** os valores intermediários, porque as derivadas dependem deles (a derivada da ReLU em $\mathbf{z}^{(1)}$, a entrada $\mathbf{h}^{(1)}$ que multiplica $\delta^{(2)}$). Segundo, o passo para trás percorre o grafo em ordem inversa e **reaproveita** o gradiente já calculado de cada nó para o nó anterior, em vez de recalcular cada caminho desde a perda.

### Dedução

::: definicao 6.6 · Erro (ou sensibilidade) da camada
O **erro** da camada $l$ é o gradiente da perda em relação à sua pré-ativação:
$$
\boldsymbol\delta^{(l)}=\frac{\partial\mathcal{L}}{\partial\mathbf{z}^{(l)}}\in\mathbb{R}^{n_l}.
$$
:::

::: teorema 6.8 · Equações da retropropagação
Em um MLP como o da Definição 6.3, com perda $\mathcal{L}$ de um exemplo, valem:

1. **Camada de saída:** $\boldsymbol\delta^{(L)}=\dfrac{\partial\mathcal{L}}{\partial\mathbf{h}^{(L)}}\odot\varphi^{(L)\prime}\bigl(\mathbf{z}^{(L)}\bigr)$. No caso da softmax com entropia cruzada, $\boldsymbol\delta^{(L)}=\mathbf{p}-\mathbf{y}$ (Teorema 6.7).
2. **Recursão:** $\boldsymbol\delta^{(l)}=\bigl(\mathbf{W}^{(l+1)}\boldsymbol\delta^{(l+1)}\bigr)\odot\varphi^{(l)\prime}\bigl(\mathbf{z}^{(l)}\bigr)$ para $l=L-1,\dots,1$.
3. **Gradientes dos parâmetros:**
$$
\frac{\partial\mathcal{L}}{\partial\mathbf{W}^{(l)}}=\mathbf{h}^{(l-1)}\,\boldsymbol\delta^{(l)\top},\qquad
\frac{\partial\mathcal{L}}{\partial\mathbf{b}^{(l)}}=\boldsymbol\delta^{(l)}.
$$
O símbolo $\odot$ é o produto elemento a elemento.
:::

::: demonstracao
*(1)* Como $h^{(L)}_j=\varphi(z^{(L)}_j)$ depende só de $z^{(L)}_j$, a regra da cadeia dá $\partial\mathcal{L}/\partial z^{(L)}_j=(\partial\mathcal{L}/\partial h^{(L)}_j)\,\varphi'(z^{(L)}_j)$.

*(2)* A pré-ativação $z^{(l)}_i$ influencia a perda apenas por meio de todas as pré-ativações $z^{(l+1)}_j$ da camada seguinte. Pela regra da cadeia multivariável, $\delta^{(l)}_i=\sum_j\delta^{(l+1)}_j\,\partial z^{(l+1)}_j/\partial z^{(l)}_i$. Como $z^{(l+1)}_j=\sum_iW^{(l+1)}_{ij}\varphi(z^{(l)}_i)+b^{(l+1)}_j$, vem $\partial z^{(l+1)}_j/\partial z^{(l)}_i=W^{(l+1)}_{ij}\varphi'(z^{(l)}_i)$. Logo $\delta^{(l)}_i=\varphi'(z^{(l)}_i)\sum_jW^{(l+1)}_{ij}\delta^{(l+1)}_j$, que é a forma vetorial do enunciado.

*(3)* Como $z^{(l)}_j=\sum_iW^{(l)}_{ij}h^{(l-1)}_i+b^{(l)}_j$, tem-se $\partial z^{(l)}_j/\partial W^{(l)}_{ij}=h^{(l-1)}_i$ e $\partial z^{(l)}_j/\partial b^{(l)}_j=1$. Multiplicando por $\delta^{(l)}_j$ pela regra da cadeia, obtêm-se $\partial\mathcal{L}/\partial W^{(l)}_{ij}=h^{(l-1)}_i\delta^{(l)}_j$ e $\partial\mathcal{L}/\partial b^{(l)}_j=\delta^{(l)}_j$.
:::

### Em lote

Com um lote de $B$ exemplos empilhados nas linhas de $\mathbf{H}^{(l-1)}\in\mathbb{R}^{B\times n_{l-1}}$ e $\boldsymbol\Delta^{(l)}\in\mathbb{R}^{B\times n_l}$, as equações viram produtos de matrizes:
$$
\frac{\partial\mathcal{L}}{\partial\mathbf{W}^{(l)}}=\mathbf{H}^{(l-1)\top}\boldsymbol\Delta^{(l)},\qquad
\boldsymbol\Delta^{(l)}=\bigl(\boldsymbol\Delta^{(l+1)}\mathbf{W}^{(l+1)\top}\bigr)\odot\varphi'\bigl(\mathbf{Z}^{(l)}\bigr),
$$
com $\boldsymbol\Delta^{(L)}$ dividido por $B$ quando a perda é a média do lote. Cada linha do código do Projeto 3 é uma dessas equações.

### Um exemplo numérico completo

O programa seguinte percorre uma rede $2\text{-}2\text{-}3$ com um exemplo, aplica as equações do Teorema 6.8 e confere o resultado com o autograd do PyTorch.

<<< codigo/c6_backprop_exemplo.py

>>> codigo/c6_backprop_exemplo.out

Dois pontos merecem atenção. Primeiro, $\boldsymbol\delta^{(2)}=\mathbf{p}-\mathbf{y}$ é o erro de previsão: a rede deu probabilidade $0{,}87$ à classe $0$ e $0{,}13$ à classe correta $2$, e o sinal negativo na posição $2$ diz que aumentar o logit da classe correta reduz a perda. Segundo, a segunda unidade oculta tem $z_2^{(1)}=-0{,}2<0$, de modo que a ReLU a anula: $\delta^{(1)}_2=0$, e **todos** os gradientes que entram nessa unidade (a segunda coluna de $\partial\mathcal{L}/\partial\mathbf{W}^{(1)}$ e a segunda linha de $\partial\mathcal{L}/\partial\mathbf{W}^{(2)}$) são nulos. Para este exemplo, a unidade não aprende. É o mecanismo dos neurônios mortos da seção 6.3. A concordância com o PyTorch é total (diferença da ordem de $10^{-19}$).

### Custo e memória

Cada camada exige dois produtos de matrizes no passo para trás (um para $\boldsymbol\delta$, outro para o gradiente dos pesos), contra um no passo para frente: o custo total de treinar é da ordem de **três vezes** o de avaliar. Em contrapartida, a memória cresce com a profundidade e com o tamanho do lote, porque os valores intermediários de todas as camadas ficam guardados até o passo para trás. Esse é, na prática, o limite dominante do tamanho de lote e de modelo em aceleradores.

::: nota Diferenciação automática
O que o Teorema 6.8 faz à mão para um MLP, bibliotecas como PyTorch fazem para **qualquer** composição de operações diferenciáveis. A técnica é a **diferenciação automática em modo reverso**: cada operação registra, no passo para frente, como calcular o produto vetor-jacobiano de sua saída; o passo para trás aplica esses produtos em ordem inversa. O modo reverso é o adequado quando há uma saída escalar (a perda) e muitas entradas (os parâmetros), pois todas as derivadas saem em uma única passada; o modo direto exigiria uma passada por parâmetro. Ver Baydin et al. (2018). A retropropagação de Rumelhart, Hinton e Williams (1986) é o caso particular para redes.
:::

### Verificação numérica do gradiente

Um erro em uma fórmula de gradiente não produz falha visível: a rede treina, só que mal. O teste padrão compara cada derivada analítica com a diferença central
$$
\frac{\partial\mathcal{L}}{\partial\theta_k}\approx\frac{\mathcal{L}(\boldsymbol\theta+\epsilon\mathbf{e}_k)-\mathcal{L}(\boldsymbol\theta-\epsilon\mathbf{e}_k)}{2\epsilon},
$$
cujo erro é $O(\epsilon^2)$. Mede-se o **erro relativo** $|g_\text{num}-g_\text{ana}|/(|g_\text{num}|+|g_\text{ana}|)$; com $\epsilon\approx10^{-6}$ e aritmética de 64 bits, valores abaixo de $10^{-6}$ indicam um gradiente correto. O método custa duas avaliações da perda por parâmetro, o que o torna inviável para treinar, mas ideal como teste automático em uma rede pequena e um lote pequeno. O Projeto 3 o inclui.

### Dissipação e explosão dos gradientes

Desenrolando a recursão do Teorema 6.8,
$$
\boldsymbol\delta^{(l)}=\mathbf{D}^{(l)}\mathbf{W}^{(l+1)}\mathbf{D}^{(l+1)}\mathbf{W}^{(l+2)}\cdots\mathbf{D}^{(L-1)}\mathbf{W}^{(L)}\,\boldsymbol\delta^{(L)},\qquad\mathbf{D}^{(k)}=\operatorname{diag}\bigl(\varphi'(\mathbf{z}^{(k)})\bigr).
$$
O gradiente que chega às camadas iniciais é um **produto de $L-l$ matrizes**. Se os fatores têm norma tipicamente menor que $1$, o produto decai exponencialmente com a profundidade (dissipação); se maior que $1$, cresce exponencialmente (explosão). Os dois fatores são as derivadas $\mathbf{D}$ (seção 6.3) e os pesos $\mathbf{W}$ (seção 6.7). O mesmo produto de matrizes reaparece, ao longo do tempo em vez de em camadas, nas redes recorrentes do Capítulo 8, onde o problema é central.

## 6.6 Otimização

Com o gradiente em mãos, resta decidir como usá-lo. O Capítulo 1 estudou a descida do gradiente determinística; aqui os dados são numerosos e a função é não convexa.

### Gradiente estocástico e minilotes

O gradiente da perda média nos $n$ exemplos exige passar por todos eles. A alternativa é estimá-lo com um subconjunto aleatório.

::: definicao 6.7 · Descida do gradiente estocástica (SGD) com minilotes
A cada passo, sorteia-se um **minilote** $\mathcal{B}$ de $B$ exemplos e atualiza-se
$$
\boldsymbol\theta\leftarrow\boldsymbol\theta-\eta\,\mathbf{g}_{\mathcal{B}},\qquad\mathbf{g}_{\mathcal{B}}=\frac1B\sum_{i\in\mathcal{B}}\nabla_{\boldsymbol\theta}\ell_i(\boldsymbol\theta),
$$
em que $\ell_i$ é a perda do exemplo $i$ e $\eta>0$ é a **taxa de aprendizado**. Uma **época** é uma passagem completa pelos dados (em ordem aleatória, sem reposição).
:::

::: proposicao 6.9 · O gradiente do minilote é não viesado
Se os $B$ exemplos são sorteados uniformemente com reposição, então $\mathbb{E}[\mathbf{g}_{\mathcal{B}}]=\nabla\hat{\mathcal{R}}(\boldsymbol\theta)$, o gradiente do risco empírico, e $\operatorname{Var}(g_{\mathcal{B},k})=\sigma_k^2/B$, em que $\sigma_k^2$ é a variância da $k$-ésima componente do gradiente de um único exemplo.
:::

::: demonstracao
Cada termo $\nabla\ell_i$ é uma observação de uma variável aleatória cuja média, sobre a escolha uniforme de $i$, é $\frac1n\sum_i\nabla\ell_i=\nabla\hat{\mathcal{R}}$. A média de $B$ observações independentes tem a mesma esperança e variância dividida por $B$ (seção 1.14).
:::

O compromisso é claro: o minilote custa $B/n$ do gradiente completo, e a variância do estimador cai com $1/B$. Dobrar $B$ reduz o desvio-padrão do ruído em apenas $\sqrt2$, mas dobra o custo por passo: lotes muito grandes têm retorno decrescente. Valores de $B$ entre 32 e 512 são comuns, em parte pelo hardware. O ruído do SGD tem custo (a trajetória oscila e exige uma taxa de aprendizado menor, ou decrescente) e benefício (cada passo é barato).

### O papel do condicionamento: *momentum*

A seção 1.11 mostrou que a descida do gradiente em uma quadrática converge a uma taxa que depende do número de condição $\kappa=L/\mu$ (maior sobre menor autovalor da Hessiana).

O Teorema 1.7 já deu a resposta para a descida do gradiente em uma quadrática $f(\mathbf{x})=\tfrac12\mathbf{x}^\top\mathbf{A}\mathbf{x}$ com autovalores em $[\mu,L]$: a iteração converge com taxa $\rho(\eta)=\max\{|1-\eta\mu|,|1-\eta L|\}$, minimizada por $\eta^\star=2/(L+\mu)$, o que dá
$$
\rho(\eta^\star)=\frac{\kappa-1}{\kappa+1}.
$$
Com $\kappa=100$, $\rho=0{,}980$: cada passo reduz o erro em apenas 2%. Mal condicionamento é lento mesmo com o melhor $\eta$, porque a direção de curvatura alta limita o passo e a de curvatura baixa avança devagar. O **momentum** (Polyak, 1964) acumula uma "velocidade":
$$
\mathbf{v}\leftarrow\beta\mathbf{v}+\mathbf{g},\qquad\boldsymbol\theta\leftarrow\boldsymbol\theta-\eta\mathbf{v},\qquad\beta\in[0,1).
$$
Em direções em que o gradiente tem sinal constante, as contribuições se somam e o passo efetivo é até $\eta/(1-\beta)$; em direções em que o sinal alterna, elas se cancelam, e a oscilação é amortecida. Para quadráticas, com $\eta=4/(\sqrt L+\sqrt\mu)^2$ e $\beta=\bigl(\frac{\sqrt\kappa-1}{\sqrt\kappa+1}\bigr)^2$, a taxa de contração assintótica melhora de $\frac{\kappa-1}{\kappa+1}$ para $\frac{\sqrt\kappa-1}{\sqrt\kappa+1}$ (Polyak, 1964): a dependência passa de $\kappa$ para $\sqrt\kappa$. Para $\kappa=100$, de $0{,}980$ para $0{,}818$.

### RMSProp e Adam: passos adaptativos

Em redes, as coordenadas do gradiente têm escalas muito diferentes (camadas distintas, pesos de entradas raras). Os métodos adaptativos usam uma **taxa de aprendizado por parâmetro**, inversamente proporcional a uma estimativa da magnitude recente do gradiente.

::: definicao 6.8 · RMSProp e Adam
**RMSProp** (Tieleman e Hinton, 2012), com $\rho\approx0{,}9$ e $\epsilon\approx10^{-8}$:
$$
\mathbf{s}\leftarrow\rho\mathbf{s}+(1-\rho)\,\mathbf{g}\odot\mathbf{g},\qquad\boldsymbol\theta\leftarrow\boldsymbol\theta-\eta\,\frac{\mathbf{g}}{\sqrt{\mathbf{s}}+\epsilon}.
$$
**Adam** (Kingma e Ba, 2015), com $\beta_1=0{,}9$, $\beta_2=0{,}999$ e $\epsilon=10^{-8}$:
$$
\begin{aligned}
\mathbf{m}_t&=\beta_1\mathbf{m}_{t-1}+(1-\beta_1)\mathbf{g}_t,&\mathbf{v}_t&=\beta_2\mathbf{v}_{t-1}+(1-\beta_2)\mathbf{g}_t\odot\mathbf{g}_t,\\
\hat{\mathbf{m}}_t&=\frac{\mathbf{m}_t}{1-\beta_1^t},&\hat{\mathbf{v}}_t&=\frac{\mathbf{v}_t}{1-\beta_2^t},\qquad
\boldsymbol\theta_t=\boldsymbol\theta_{t-1}-\eta\,\frac{\hat{\mathbf{m}}_t}{\sqrt{\hat{\mathbf{v}}_t}+\epsilon}.
\end{aligned}
$$
Todas as operações são componente a componente, com $\mathbf{m}_0=\mathbf{v}_0=\mathbf{0}$.
:::

O Adam combina o momentum (média móvel $\mathbf{m}$ do gradiente) com a normalização do RMSProp (média móvel $\mathbf{v}$ do gradiente ao quadrado). O que são as divisões por $1-\beta^t$?

::: proposicao 6.10 · Correção de viés das médias móveis
Se os gradientes $\mathbf{g}_i$ têm a mesma esperança $\boldsymbol\mu$, então $\mathbb{E}[\mathbf{m}_t]=(1-\beta_1^t)\,\boldsymbol\mu$. Assim, $\hat{\mathbf{m}}_t$ é um estimador não viesado de $\boldsymbol\mu$; o mesmo vale para $\hat{\mathbf{v}}_t$ e $\mathbb{E}[\mathbf{g}\odot\mathbf{g}]$.
:::

::: demonstracao
Desenrolando, $\mathbf{m}_t=(1-\beta_1)\sum_{i=1}^{t}\beta_1^{\,t-i}\mathbf{g}_i$. Tomando a esperança, $\mathbb{E}[\mathbf{m}_t]=(1-\beta_1)\boldsymbol\mu\sum_{i=1}^{t}\beta_1^{\,t-i}=(1-\beta_1)\boldsymbol\mu\,\frac{1-\beta_1^t}{1-\beta_1}=(1-\beta_1^t)\boldsymbol\mu$.
:::

Sem a correção, as primeiras estimativas, iniciadas em zero, seriam subestimadas. Um efeito curioso aparece já no primeiro passo ($t=1$): $\hat{\mathbf{m}}_1=\mathbf{g}_1$ e $\hat{\mathbf{v}}_1=\mathbf{g}_1\odot\mathbf{g}_1$, de modo que o passo vale $\eta\,g/(|g|+\epsilon)\approx\eta\operatorname{sinal}(g)$: **em módulo, igual a $\eta$ em toda coordenada, qualquer que seja a escala do gradiente**. A última parte do programa abaixo confirma o valor com gradientes de $10^{-3}$ a $10^{3}$; sem a correção o primeiro passo seria $3{,}2$ vezes maior.

### Experimento

O programa compara os métodos na quadrática do Capítulo 1 com $\mathbf{A}=\operatorname{diag}(1,100)$, $\kappa=100$, partindo de $(10,1)$, com critério $f<10^{-6}$. Os hiperparâmetros foram escolhidos à mão, e outros valores mudariam os números; o objetivo é ilustrar mecanismos, não eleger o melhor otimizador.

<<< codigo/c6_otimizadores.py

>>> codigo/c6_otimizadores.out

<figure>
+++ fig_c6_otim.svg
<figcaption><b>Figura 6.3.</b> Valor de $f$ (em escala logarítmica) ao longo das iterações, para os quatro métodos. O GD usa o passo ótimo $2/(L+\mu)$. As curvas do <i>momentum</i> e do Adam ficam quase sobrepostas. A escala vertical é cortada em $10^{-13}$.</figcaption>
</figure>

Os resultados confirmam a teoria e mostram um comportamento que a teoria ainda não explica sozinha.

- **GD** com o passo ótimo precisou de $461$ iterações. A previsão do Teorema 1.7 é consistente: o erro cai por $0{,}980$ a cada passo, e reduzir $f$ por um fator $10^{8}$ exige da ordem de $\ln(10^{8})/(2\cdot0{,}0200)\approx460$ iterações.
- **Momentum com parâmetros de Polyak** reduziu isso a $69$ iterações, um fator de cerca de $6{,}7$, da mesma ordem do ganho previsto pela passagem de $\kappa$ para $\sqrt\kappa$ (que seria $10$ nas taxas assintóticas). Com valores escolhidos sem teoria ($\beta=0{,}9$; $\beta=0{,}95$), o ganho existe mas é menor, e **$\beta$ maior não é melhor**: com $\beta=0{,}95$ foram necessárias $306$ iterações, porque a velocidade acumulada demora a ser amortecida.
- **RMSProp** com taxa constante **não atingiu** o critério em 20 000 iterações, e o menor valor de $f$ foi $3{,}1\times10^{-2}$ ($\eta=0{,}05$) e $3{,}1\times10^{-4}$ ($\eta=0{,}005$). Reduzir $\eta$ dez vezes reduziu o piso cem vezes. Uma explicação plausível é que o passo $\eta\,g/\sqrt s$ tem módulo próximo de $\eta$ mesmo quando o gradiente é pequeno, de modo que o método oscila em torno do mínimo com amplitude proporcional a $\eta$ (e $f$ proporcional a $\eta^2$, como observado). Na prática, usa-se decaimento da taxa de aprendizado.
- **Adam** chegou a $f<10^{-6}$ em $152$ iterações, e segue caindo (na iteração 299, $f\approx7\times10^{-13}$, Figura 6.3). Uma explicação plausível é que a média móvel $\mathbf{m}$ do gradiente cancela parte da oscilação, algo que o RMSProp não tem. Não se deve concluir daí que o Adam é sempre melhor: com $\eta$ diferente ele se comportaria de outra forma, e em problemas reais não há garantia de que ele generalize melhor que o SGD com *momentum* (Wilson et al., 2017).

| Método | Estado por parâmetro | Hiperparâmetros usuais | Observação |
|---|---|---|---|
| SGD | nenhum | $\eta$ | simples; sensível ao condicionamento |
| SGD com *momentum* | $\mathbf{v}$ | $\eta$; $\beta=0{,}9$ | amortece oscilações |
| RMSProp | $\mathbf{s}$ | $\eta$; $\rho=0{,}9$ | passo por coordenada; oscila com $\eta$ constante |
| Adam | $\mathbf{m},\mathbf{v}$ | $\eta=10^{-3}$; $\beta_1=0{,}9$; $\beta_2=0{,}999$ | padrão em muitas arquiteturas modernas |
| AdamW | $\mathbf{m},\mathbf{v}$ | como o Adam, mais $\lambda$ | *weight decay* desacoplado (seção 6.7) |

::: atencao A taxa de aprendizado é o hiperparâmetro mais importante
Com $\eta$ pequeno demais, o treinamento é lento; com $\eta$ grande demais, a perda oscila ou diverge (Teorema 1.7: $\eta<2/L$ em uma quadrática). Para o Adam, $10^{-3}$ é um ponto de partida usual. Em redes grandes, usa-se ainda um **agendamento** (*learning rate schedule*): um aquecimento inicial com $\eta$ crescente, seguido de decaimento (linear ou por cosseno). O Capítulo 10 retoma o tema no ajuste fino de modelos de linguagem.
:::

## 6.7 Inicialização, normalização e regularização

### Inicialização dos pesos

Os pesos iniciais não podem ser todos iguais (os neurônios de uma camada seriam idênticos e permaneceriam idênticos) nem arbitrários: a escala decide se os sinais atravessam a rede ou se dissipam, no passo para frente e no passo para trás.

::: proposicao 6.11 · Variância da pré-ativação
Seja $z=\sum_{i=1}^{n}w_ih_i$ com $w_i$ independentes, média zero e variância $\sigma_w^2$, independentes de $h_i$. Então $\operatorname{Var}(z)=n\,\sigma_w^2\,\mathbb{E}[h^2]$ (supondo as $h_i$ com o mesmo segundo momento).
:::

::: demonstracao
$\operatorname{Var}(w_ih_i)=\mathbb{E}[w_i^2]\mathbb{E}[h_i^2]-\mathbb{E}[w_ih_i]^2=\sigma_w^2\mathbb{E}[h_i^2]$, pois $\mathbb{E}[w_ih_i]=0$. Os termos são não correlacionados, e as variâncias se somam.
:::

Para que a escala do sinal se **conserve** de camada em camada, $\operatorname{Var}(z^{(l)})\approx\operatorname{Var}(z^{(l-1)})$. Em uma camada linear (ou tanh na região quase linear), $\mathbb{E}[h^2]=\operatorname{Var}(z^{(l-1)})$ e a condição é $\sigma_w^2=1/n_\text{ent}$. Glorot e Bengio (2010) propõem a média harmônica entre entradas e saídas, $\sigma_w^2=2/(n_\text{ent}+n_\text{saí})$, para equilibrar os passos para frente e para trás (**inicialização de Xavier**). Com a **ReLU**, que anula metade das pré-ativações, $\mathbb{E}[h^2]=\frac12\operatorname{Var}(z)$, e a condição se torna $\sigma_w^2=2/n_\text{ent}$ (**inicialização de He**, He et al., 2015).

<<< codigo/c6_inicializacao.py

>>> codigo/c6_inicializacao.out

O experimento propaga entradas com desvio-padrão $1$ por $20$ camadas de largura $500$.

- Com tanh e pesos $\mathcal{N}(0,0{,}01^2)$, cada camada multiplica o desvio por $\sqrt{500}\cdot0{,}01\approx0{,}22$: após $20$ camadas, $9\times10^{-14}$. A rede praticamente zerou o sinal, e os gradientes sofrem o mesmo destino.
- Com ReLU e Xavier, cada camada reduz a variância à metade (desvio por $1/\sqrt2$): após $20$ camadas, $7\times10^{-4}$, próximo de $2^{-10}\approx10^{-3}$.
- Com ReLU e He, o desvio se mantém na faixa de $0{,}8$ a $1$ ao longo das $20$ camadas.

A inicialização correta é condição para treinar redes profundas. O Projeto 3 usa a de He.

### Regularização

O Capítulo 5 mostrou que modelos flexíveis superajustam. Redes têm muitos parâmetros (a rede do Projeto 4 tem cerca de $85$ mil, para $300$ exemplos de treino) e precisam de regularização, que assume as formas abaixo.

**Penalidade $\ell_2$ e *weight decay*.** Somar $\frac\lambda2\lVert\boldsymbol\theta\rVert^2$ à perda (a penalidade Ridge da seção 5.5) acrescenta $\lambda\boldsymbol\theta$ ao gradiente, e o passo do SGD vira
$$
\boldsymbol\theta\leftarrow(1-\eta\lambda)\,\boldsymbol\theta-\eta\,\mathbf{g}.
$$
Os pesos são **encolhidos** um pouco a cada passo: por isso o nome *weight decay*. Para o SGD, a penalidade $\ell_2$ e o *weight decay* coincidem. Para o Adam, não: a penalidade entra no gradiente e é então reescalada pelo denominador adaptativo, de modo que o efeito deixa de ser uniforme. Loshchilov e Hutter (2019) propõem o **AdamW**, que aplica o decaimento diretamente nos pesos, fora do gradiente, e é a escolha usual. Um detalhe prático: no AdamW o encolhimento por passo é $\eta\lambda$. Com $\eta=2\times10^{-3}$ e $\lambda=10^{-2}$ (valores do Projeto 4), é $2\times10^{-5}$ por passo, quase nada; é um dos motivos pelos quais o *weight decay* não fez diferença no experimento.

**Dropout** (Srivastava et al., 2014). Durante o treinamento, cada neurônio de uma camada é desligado com probabilidade $p$, de modo independente a cada passo. Na forma usual, "invertida", os neurônios mantidos são reescalados por $1/(1-p)$:
$$
\tilde{\mathbf{h}}=\frac{\mathbf{m}\odot\mathbf{h}}{1-p},\qquad m_i\sim\text{Bernoulli}(1-p)\ \text{independentes}.
$$
O fator garante $\mathbb{E}[\tilde{\mathbf{h}}]=\mathbf{h}$, e na **inferência o Dropout é a identidade**: nenhum ajuste de escala é necessário. Cada passo treina uma sub-rede diferente, o que impede que um neurônio dependa de outro específico; a rede final aproxima a média de um *ensemble* exponencialmente grande de sub-redes que compartilham pesos.

**Normalização em lote** (*Batch Normalization*; Ioffe e Szegedy, 2015). Para cada neurônio, normaliza-se a pré-ativação com a média e a variância **do minilote** e aplica-se uma transformação afim aprendida:
$$
\hat z_i=\frac{z_i-\mu_{\mathcal{B}}}{\sqrt{\sigma_{\mathcal{B}}^2+\epsilon}},\qquad y_i=\gamma\,\hat z_i+\beta,
$$
com $\gamma,\beta$ parâmetros do neurônio. Durante o treinamento, o método guarda médias móveis de $\mu_{\mathcal{B}}$ e $\sigma^2_{\mathcal{B}}$ e, na inferência, usa essas estatísticas acumuladas no lugar das do lote. O resultado é que o BatchNorm **se comporta de forma diferente em treinamento e em avaliação**, como o Dropout. Na prática, ele permite taxas de aprendizado maiores, acelera o treinamento e age como regularizador (o ruído do lote atua como perturbação). Por que funciona é um tema debatido: a explicação original, a redução da "mudança interna de covariáveis", foi questionada por Santurkar et al. (2018), que atribuem o benefício sobretudo a tornar a superfície de perda mais suave. A **normalização de camada** (*LayerNorm*), que normaliza sobre os neurônios de cada exemplo e dispensa o lote, é a variante usada em Transformers (Capítulo 9).

**Parada antecipada** (*early stopping*). Monitora-se a perda em validação e guarda-se o estado de menor perda. É a regularização mais barata e foi usada em todo o Projeto 4.

**Aumento de dados** (*data augmentation*). Aplicar transformações que preservam o rótulo (deslocamentos, rotações, ruído) multiplica os exemplos de treino. Será essencial em visão computacional (Capítulo 7).

