<div class="objetivos">

Objetivos do capítulo

- Explicar por que o erro de treinamento subestima o erro em dados novos, e quantificar essa diferença.
- Demonstrar a decomposição do erro em viés, variância e ruído, e reconhecer subajuste e superajuste.
- Estimar o erro de generalização por validação cruzada, sem vazamento de informação.
- Derivar as soluções de Ridge e Lasso e explicar encolhimento e esparsidade.
- Calcular e interpretar matriz de confusão, precisão, recall, F1, curva ROC e AUC.
- Conduzir a seleção de modelos em um projeto completo com scikit-learn.

**Pré-requisitos:** Capítulos 1, 3 e 4.

</div>

## 5.1 O problema da generalização

O Capítulo 4 deixou quatro modelos e uma constatação incômoda: o KNN com $K=1$ e a árvore completa acertam 100% do treinamento e não são os melhores no teste. O desempenho nos dados usados para ajustar não mede o que interessa.

::: definicao 5.1 · Erro de treinamento, erro de teste e generalização
O **erro de treinamento** é a perda média nos exemplos usados para ajustar o modelo: o risco empírico da Definição 3.2. O **erro de teste** (ou de generalização) é a perda esperada em um exemplo novo, da mesma distribuição e não usado no ajuste: o risco. **Generalizar** é ter erro de teste baixo.
:::

A diferença entre os dois tem uma causa simples. O procedimento de ajuste escolhe os parâmetros **olhando** para os dados de treinamento, e os escolhe justamente para que o erro neles seja pequeno. Parte dessa pequenez vem de ter capturado a função $f$; outra parte vem de ter-se acomodado ao ruído particular daquela amostra. A segunda parte não se repete em dados novos.

Para a regressão linear, a diferença pode ser calculada exatamente.

::: proposicao 5.1 · Otimismo do erro de treinamento
No modelo linear com $p$ parâmetros, corretamente especificado, com erros não correlacionados de variância $\sigma^2$ e $\mathbf{X}$ fixa, o erro quadrático médio de treinamento e o erro em novas respostas observadas nos mesmos pontos têm esperanças

$$
\mathbb{E}[\text{erro de treino}] = \sigma^2\Bigl(1-\frac pn\Bigr),\qquad \mathbb{E}[\text{erro de teste}] = \sigma^2\Bigl(1+\frac pn\Bigr).
$$
:::

::: demonstracao
O resíduo é $\mathbf{r} = (\mathbf{I}-\mathbf{H})\mathbf{y} = (\mathbf{I}-\mathbf{H})\boldsymbol\varepsilon$, pois $(\mathbf{I}-\mathbf{H})\mathbf{X} = \mathbf{0}$. Como $\mathbf{I}-\mathbf{H}$ é simétrica e idempotente, $\mathbb{E}\lVert\mathbf{r}\rVert^2 = \mathbb{E}[\boldsymbol\varepsilon^\top(\mathbf{I}-\mathbf{H})\boldsymbol\varepsilon] = \sigma^2\operatorname{tr}(\mathbf{I}-\mathbf{H}) = \sigma^2(n-p)$, usando $\operatorname{tr}(\mathbf{H}) = p$ (Exercício 4.6). Dividindo por $n$, obtém-se a primeira expressão. Para novas respostas $\mathbf{y}' = \mathbf{X}\boldsymbol\beta+\boldsymbol\varepsilon'$, com $\boldsymbol\varepsilon'$ independente, o erro é $\boldsymbol\varepsilon'-\mathbf{H}\boldsymbol\varepsilon$, cuja norma ao quadrado tem esperança $n\sigma^2+\sigma^2\operatorname{tr}(\mathbf{H}) = \sigma^2(n+p)$.
:::

A diferença, $2\sigma^2p/n$, é o **otimismo** do erro de treinamento. Ele cresce com o número de parâmetros e diminui com o número de exemplos. O erro de treinamento fica **abaixo** do ruído irredutível, o que só é possível porque o modelo ajustou parte do ruído. A proposição explica a divisão por $n-p$ na estimativa de $\sigma^2$ do Capítulo 4 e será conferida numericamente na seção 5.3.

## 5.2 Viés e variância

### A decomposição

A Proposição 3.1 tratava $\hat f$ como fixa. Na realidade, $\hat f$ depende do conjunto de treinamento, que é uma amostra aleatória: outro conjunto produziria outra $\hat f$. Tomando a esperança também sobre os conjuntos de treinamento, o erro redutível divide-se em duas partes.

::: teorema 5.2 · Decomposição viés-variância
Seja $Y = f(X)+\varepsilon$, com $\mathbb{E}[\varepsilon]=0$ e $\operatorname{Var}(\varepsilon) = \sigma^2$. Seja $\hat f$ ajustada a um conjunto de treinamento aleatório, independente do novo par $(x_0,y_0)$. Então

$$
\mathbb{E}\bigl[(y_0-\hat f(x_0))^2\bigr] = \underbrace{\bigl(\mathbb{E}[\hat f(x_0)]-f(x_0)\bigr)^2}_{\text{viés}^2}+\underbrace{\operatorname{Var}\bigl(\hat f(x_0)\bigr)}_{\text{variância}}+\underbrace{\sigma^2}_{\text{ruído}},
$$

em que as esperanças são tomadas sobre os conjuntos de treinamento e sobre $\varepsilon$.
:::

::: demonstracao
Escreva $y_0-\hat f(x_0) = \varepsilon+\bigl(f(x_0)-\bar f\bigr)+\bigl(\bar f-\hat f(x_0)\bigr)$, com $\bar f = \mathbb{E}[\hat f(x_0)]$. Ao elevar ao quadrado e tomar a esperança, os três termos cruzados se anulam: $\varepsilon$ tem média zero e é independente de $\hat f$; o termo do meio é constante; e $\mathbb{E}[\bar f-\hat f(x_0)] = 0$ por definição de $\bar f$. Restam $\mathbb{E}[\varepsilon^2] = \sigma^2$, o quadrado da constante $f(x_0)-\bar f$ e $\mathbb{E}[(\hat f(x_0)-\bar f)^2] = \operatorname{Var}(\hat f(x_0))$.
:::

### Interpretação

O **viés** é o erro da previsão média: quanto o método erraria se fosse possível promediar seus resultados sobre infinitos conjuntos de treinamento. Vem de hipóteses simplificadoras. Uma reta ajustada a uma senoide tem viés, por mais dados que receba.

A **variância** é quanto a previsão muda de um conjunto de treinamento para outro. Vem da sensibilidade do método à amostra particular. O KNN com $K=1$ tem variância alta: trocar um exemplo muda a previsão em toda uma região.

O **ruído** é o erro irredutível do Capítulo 3.

A decomposição é uma **identidade matemática** sob perda quadrática. Para outras perdas, como a 0-1, existem generalizações menos limpas, mas a intuição se mantém.

### O compromisso

Aumentar a flexibilidade de um método costuma reduzir o viés, porque ele passa a poder representar mais funções, e aumentar a variância, porque há mais parâmetros a estimar com os mesmos dados. O erro de teste, soma dos dois, tipicamente diminui e depois aumenta. O ponto de mínimo é o nível de flexibilidade a escolher.

::: definicao 5.2 · Subajuste e superajuste
Há **subajuste** (*underfitting*) quando o modelo é rígido demais para capturar a estrutura dos dados: viés alto, com erros de treino e de teste ambos altos. Há **superajuste** (*overfitting*) quando o modelo se ajusta ao ruído do treinamento: variância alta, com erro de treino baixo e erro de teste bem maior.
:::

| Sintoma | Erro de treino | Erro de teste | Diagnóstico | O que tentar |
|---|---|---|---|---|
| Ambos altos e próximos | Alto | Alto | Subajuste | Modelo mais flexível, novas variáveis, menos regularização |
| Grande diferença | Baixo | Alto | Superajuste | Mais dados, modelo mais simples, mais regularização |
| Ambos baixos e próximos | Baixo | Baixo | Ajuste adequado | Nada; conferir se o teste é confiável |

## 5.3 Curvas de treinamento e teste: um experimento

O programa a seguir mede cada termo do Teorema 5.2. Ele ajusta polinômios de vários graus a 25 pontos de $f(x) = \operatorname{sen}(2\pi x)$ com ruído de desvio padrão $0{,}3$, repete o ajuste em 2 000 conjuntos de respostas ruidosas e calcula viés e variância das previsões.

<<< codigo/c5_viesvar.py

>>> codigo/c5_viesvar.out

<figure>
+++ fig_viesvar.svg
<figcaption><b>Figura 5.1.</b> Erros médios de treino e de teste da tabela acima. O erro de treino decresce sempre com a flexibilidade e cruza para baixo do erro irredutível. O erro de teste é mínimo no grau 3 e volta a crescer.</figcaption>
</figure>

Cada afirmação teórica aparece nos números.

- **A decomposição vale.** A quarta coluna (soma dos três termos) coincide com a quinta (erro de teste medido), a menos de erro de simulação.
- **Subajuste no grau 1.** Viés ao quadrado de $0{,}22$; treino e teste altos e próximos.
- **O viés desaparece a partir do grau 5; a variância só cresce.** Do grau 3 em diante, toda piora do teste é variância.
- **A variância segue a Proposição 5.1.** Um polinômio de grau $g$ tem $p = g+1$ parâmetros, e a variância média prevista é $\sigma^2p/n$. Para o grau 3, $0{,}09\times4/25 = 0{,}0144$; para o grau 17, $0{,}09\times18/25 = 0{,}0648$. São os valores medidos.
- **O erro de treino engana.** Ele cai de $0{,}08$ para $0{,}025$ entre os graus 3 e 17, enquanto o erro de teste sobe de $0{,}11$ para $0{,}15$. Para o grau 5, a previsão $\sigma^2(1-p/n) = 0{,}0684$ confere com o valor medido de $0{,}0682$.

::: atencao A curva em U não é uma lei universal
O formato em U descreve bem os modelos clássicos deste módulo. Em modelos com muito mais parâmetros do que exemplos, como as redes profundas, observa-se com frequência que o erro de teste volta a **diminuir** depois do ponto em que o modelo interpola os dados de treinamento, fenômeno chamado de descida dupla (Belkin et al., 2019). A decomposição do Teorema 5.2 continua válida; o que muda é que a variância deixa de crescer monotonicamente com o número de parâmetros, por efeito do método de otimização e da regularização implícita. As explicações teóricas ainda são objeto de pesquisa. O tema volta no Capítulo 6.
:::

## 5.4 Validação cruzada

### Motivação

Para escolher o grau do polinômio, o $K$ do KNN ou o $\alpha$ da poda, é preciso estimar o erro de teste. No experimento anterior, isso foi possível porque os dados eram simulados à vontade. Em um problema real, há um único conjunto de dados.

A abordagem mais simples reserva parte dos dados como **conjunto de validação**: ajusta-se no restante e mede-se o erro na parte reservada. Ela tem dois defeitos. A estimativa varia muito conforme a divisão sorteada. E o modelo é ajustado com menos dados do que o disponível, o que tende a superestimar o erro.

### k-fold

::: definicao 5.3 · Validação cruzada k-fold
Dividem-se os $n$ exemplos, ao acaso, em $k$ partes (*folds*) de tamanhos aproximadamente iguais. Para cada parte $j$, ajusta-se o modelo nas outras $k-1$ partes e calcula-se o erro $E_j$ na parte $j$. A estimativa de **validação cruzada k-fold** é

$$
\operatorname{CV}_{(k)} = \frac1k\sum_{j=1}^kE_j .
$$
:::

Cada exemplo é usado para validação exatamente uma vez e para treino $k-1$ vezes. O procedimento exige $k$ ajustes.

### LOOCV

O caso extremo, $k=n$, é a validação cruzada deixando um de fora (*Leave-One-Out Cross-Validation*, LOOCV): cada exemplo é, por sua vez, o conjunto de validação. Não há sorteio, e cada ajuste usa $n-1$ exemplos, quase todos. O custo são $n$ ajustes. Para modelos lineares ajustados por mínimos quadrados, existe um atalho notável.

::: proposicao 5.3 · LOOCV com um único ajuste
Na regressão linear por mínimos quadrados, com valores ajustados $\hat y_i$ e alavancagens $h_{ii}$, os elementos da diagonal da matriz chapéu,

$$
\operatorname{CV}_{(n)} = \frac1n\sum_{i=1}^n\Bigl(\frac{y_i-\hat y_i}{1-h_{ii}}\Bigr)^2 .
$$
:::

A demonstração usa a fórmula de atualização da inversa de uma matriz quando se remove uma linha e está em Hastie, Tibshirani e Friedman (2009, cap. 7). A leitura é direta: o resíduo de cada ponto é inflado pelo fator $1/(1-h_{ii})$, tanto maior quanto mais o ponto influencia o próprio ajuste.

### Qual k escolher

A escolha de $k$ é, ela mesma, um compromisso entre viés e variância, agora do **estimador do erro**.

- Com $k$ pequeno, cada ajuste usa bem menos dados que o total, e a estimativa tende a ser pessimista (viés).
- Com $k=n$, o viés é mínimo, mas os $n$ modelos são ajustados a conjuntos quase idênticos; seus erros são muito correlacionados, e a média de quantidades correlacionadas tem variância maior.

A prática consagrada, sustentada por evidência empírica, é $k=5$ ou $k=10$ (James et al., 2023, cap. 5).

### Implementação

<<< codigo/c5_cv.py

>>> codigo/c5_cv.out

Observações. As versões didática e do scikit-learn dão valores próximos, e não idênticos, porque sorteiam partições diferentes: a própria estimativa tem variabilidade. O desvio entre as partes, de centenas de unidades, mostra quão instável seria confiar em uma única divisão. O atalho da Proposição 5.3 reproduz os 442 ajustes do LOOCV até a terceira casa decimal. E o erro de treino ($2859{,}7$) fica abaixo de todas as estimativas de validação (cerca de $3000$), com a diferença prevista pela Proposição 5.1.

### Vazamento de informação

::: erro Usar os dados de validação em qualquer etapa do ajuste
Toda operação que **aprende algo dos dados** faz parte do modelo e deve ser refeita dentro de cada partição, usando apenas a parte de treino: padronização, imputação de valores ausentes, seleção de variáveis, redução de dimensionalidade. Executá-la uma vez, com todos os dados, antes da validação cruzada deixa informação da parte de validação vazar para o treino, e a estimativa de erro fica otimista. O defeito é silencioso: o código roda e os números parecem ótimos.
:::

O programa a seguir mostra a gravidade do problema em um caso extremo: dados em que **não há nada a aprender**.

<<< codigo/c5_ex11.py

>>> codigo/c5_ex11.out

Com rótulos sorteados, nenhum modelo pode acertar mais que 50% em dados novos. Selecionando variáveis antes da validação cruzada, obtém-se 98% de acurácia aparente: entre 5 000 colunas de ruído, sempre há 20 que, por acaso, se correlacionam com os rótulos daquela amostra, **incluindo os exemplos de validação**. Com a seleção dentro do `Pipeline`, a estimativa volta para perto de 50%; a diferença para $0{,}5$ é flutuação de uma amostra de 60 exemplos. O `Pipeline` do scikit-learn existe para tornar o procedimento correto o caminho mais fácil.

### Treino, validação e teste

Quando a validação cruzada é usada para **escolher** entre muitos modelos ou hiperparâmetros, o erro do vencedor também fica otimista: ganhou, em parte, por sorte naquelas partições. A proteção é um terceiro conjunto.

1. **Separa-se um conjunto de teste** logo no início, que não é tocado.
2. **No restante, usa-se validação cruzada** para comparar modelos e escolher hiperparâmetros.
3. **O modelo escolhido é reajustado** em todo o conjunto de treino e avaliado **uma única vez** no teste.

Se o resultado no teste motivar novas alterações no modelo, o teste deixou de ser teste. Quando não há dados para reservar, usa-se a validação cruzada aninhada, em que um laço externo estima o erro e um interno escolhe os hiperparâmetros.

## 5.5 Regularização

### Motivação

A variância de um modelo linear cresce com o número de parâmetros e com a colinearidade entre preditoras. Reduzir o número de variáveis é uma forma de controlá-la. A **regularização** é outra, mais gradual: mantêm-se todas as variáveis e penaliza-se o tamanho dos coeficientes. Aceita-se um pouco de viés em troca de uma redução maior de variância.

### Ridge

::: definicao 5.4 · Regressão Ridge
A regressão **Ridge** (Hoerl e Kennard, 1970) minimiza a soma dos quadrados dos resíduos mais uma penalidade $\ell_2$:

$$
\hat{\boldsymbol\beta}^{\text{ridge}} = \arg\min_{\boldsymbol\beta}\;\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert_2^2+\lambda\lVert\boldsymbol\beta\rVert_2^2,\qquad\lambda\ge0 .
$$

O intercepto não é penalizado; na prática, centram-se $\mathbf{y}$ e as colunas de $\mathbf{X}$.
:::

::: proposicao 5.4 · Solução da regressão Ridge
Para $\lambda>0$, a solução existe, é única e vale

$$
\hat{\boldsymbol\beta}^{\text{ridge}} = (\mathbf{X}^\top\mathbf{X}+\lambda\mathbf{I})^{-1}\mathbf{X}^\top\mathbf{y}.
$$

Se as colunas de $\mathbf{X}$ são ortonormais, $\hat\beta_j^{\text{ridge}} = \hat\beta_j^{\text{OLS}}/(1+\lambda)$.
:::

::: demonstracao
A primeira parte é o Exercício 1.10: o gradiente é $2\mathbf{X}^\top(\mathbf{X}\boldsymbol\beta-\mathbf{y})+2\lambda\boldsymbol\beta$, e a matriz $\mathbf{X}^\top\mathbf{X}+\lambda\mathbf{I}$ é definida positiva. Com colunas ortonormais, $\mathbf{X}^\top\mathbf{X} = \mathbf{I}$, e a solução reduz-se a $\mathbf{X}^\top\mathbf{y}/(1+\lambda)$, em que $\mathbf{X}^\top\mathbf{y}$ é a solução de mínimos quadrados.
:::

O caso geral lê-se pela SVD, $\mathbf{X} = \mathbf{U}\mathbf{D}\mathbf{V}^\top$, com valores singulares $d_j$. Os valores ajustados são

$$
\hat{\mathbf{y}}^{\text{ridge}} = \sum_j\mathbf{u}_j\,\frac{d_j^2}{d_j^2+\lambda}\,\mathbf{u}_j^\top\mathbf{y}.
$$

Cada direção principal dos dados é **encolhida** pelo fator $d_j^2/(d_j^2+\lambda)$. As direções de valor singular pequeno, aquelas em que os dados quase não variam e nas quais os coeficientes de mínimos quadrados são mais instáveis, são as mais encolhidas. A Ridge reduz a variância exatamente onde ela é maior. Quando $\lambda\to0$, recupera-se o ajuste de mínimos quadrados; quando $\lambda\to\infty$, os coeficientes tendem a zero, sem nunca se anularem.

### Lasso

::: definicao 5.5 · Lasso
O **Lasso** (Tibshirani, 1996) substitui a penalidade $\ell_2$ pela $\ell_1$:

$$
\hat{\boldsymbol\beta}^{\text{lasso}} = \arg\min_{\boldsymbol\beta}\;\frac12\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert_2^2+\lambda\lVert\boldsymbol\beta\rVert_1 .
$$
:::

A troca parece pequena e muda a natureza da solução: o Lasso **zera** coeficientes. Com isso, realiza seleção de variáveis e produz modelos **esparsos**, mais fáceis de interpretar. Não há fórmula fechada no caso geral, porque $\lvert\beta\rvert$ não é diferenciável em zero; o caso ortonormal, porém, resolve-se à mão e revela o mecanismo.

::: proposicao 5.5 · Limiarização suave
Se as colunas de $\mathbf{X}$ são ortonormais, a solução do Lasso é

$$
\hat\beta_j^{\text{lasso}} = \operatorname{sinal}(\hat\beta_j^{\text{OLS}})\,\bigl(\lvert\hat\beta_j^{\text{OLS}}\rvert-\lambda\bigr)_+ ,
$$

em que $(a)_+ = \max(a,0)$.
:::

::: demonstracao
Com $\mathbf{X}^\top\mathbf{X} = \mathbf{I}$ e $\hat{\boldsymbol\beta} = \mathbf{X}^\top\mathbf{y}$, tem-se $\tfrac12\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert^2 = \tfrac12\lVert\boldsymbol\beta-\hat{\boldsymbol\beta}\rVert^2+\text{constante}$. O problema separa-se por coordenada: minimizar $g(b) = \tfrac12(b-\hat\beta)^2+\lambda\lvert b\rvert$. Para $b>0$, $g'(b) = b-\hat\beta+\lambda$, que se anula em $b = \hat\beta-\lambda$; esse ponto só é positivo se $\hat\beta>\lambda$. Para $b<0$, $g'(b) = b-\hat\beta-\lambda$, que se anula em $b = \hat\beta+\lambda$, negativo apenas se $\hat\beta<-\lambda$. Quando $\lvert\hat\beta\rvert\le\lambda$, não há ponto crítico de nenhum dos lados: $g$ decresce até zero e cresce depois, e o mínimo está em $b=0$.
:::

A comparação entre as duas proposições explica tudo. A Ridge **divide** cada coeficiente por uma constante: um coeficiente pequeno fica menor, e nunca nulo. O Lasso **subtrai** uma constante do módulo: coeficientes menores que $\lambda$ em módulo vão exatamente a zero. Geometricamente, é a Figura 1.1: a bola da norma $\ell_1$ tem vértices sobre os eixos, e as soluções tendem a cair neles.

| | Ridge | Lasso |
|---|---|---|
| Penalidade | $\lambda\sum_j\beta_j^2$ | $\lambda\sum_j\lvert\beta_j\rvert$ |
| Efeito | Encolhimento proporcional | Encolhimento por subtração; zeros exatos |
| Seleção de variáveis | Não | Sim |
| Solução | Forma fechada | Algoritmo iterativo (descida por coordenadas) |
| Preditoras muito correlacionadas | Distribui o peso entre elas | Tende a manter uma e zerar as outras |
| Leitura bayesiana (seção 1.13) | Priori Gaussiana | Priori de Laplace |
| Quando tende a ser melhor | Muitas variáveis com efeitos pequenos | Poucas variáveis relevantes |

A rede elástica (*elastic net*) combina as duas penalidades e é útil quando há grupos de preditoras correlacionadas.

::: atencao Duas condições de uso
**Padronize as preditoras.** A penalidade soma coeficientes de variáveis diferentes; se as escalas diferem, variáveis em unidades pequenas são penalizadas de modo desproporcional. Com mínimos quadrados sem penalidade, a escala não altera as previsões; com regularização, altera.

**Escolha $\lambda$ por validação cruzada.** Não existe valor correto a priori. O $\lambda$ é um hiperparâmetro que controla a flexibilidade, como o $K$ do KNN.
:::

### Implementação

<<< codigo/c5_regularizacao.py

>>> codigo/c5_regularizacao.out

A tabela da Ridge mostra a norma dos coeficientes caindo com $\lambda$ sem que nenhum se anule, e o número de condição melhorando de 470 para 2,8, como previsto no Exercício 1.10. A do Lasso mostra os coeficientes sendo zerados um a um, até o modelo vazio. Por validação cruzada, o Lasso mantém sete das dez variáveis.

::: atencao Convenções diferentes de parametrização
No scikit-learn, o parâmetro chama-se `alpha`. `Ridge` minimiza $\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert^2+\alpha\lVert\boldsymbol\beta\rVert_2^2$, e `Lasso` minimiza $\tfrac{1}{2n}\lVert\mathbf{y}-\mathbf{X}\boldsymbol\beta\rVert^2+\alpha\lVert\boldsymbol\beta\rVert_1$. Já `LogisticRegression` usa `C`, o **inverso** da intensidade da penalidade. Valores de $\lambda$ não são comparáveis entre estimadores nem entre bibliotecas sem conferir a função objetivo na documentação.
:::

## 5.6 Métricas de classificação

### Matriz de confusão

Em classificação binária, com uma classe designada como **positiva** (em geral, a de interesse ou a mais rara), cada previsão cai em uma de quatro categorias.

| | Previsto positivo | Previsto negativo |
|---|---|---|
| **Real positivo** | Verdadeiro positivo (VP) | Falso negativo (FN) |
| **Real negativo** | Falso positivo (FP) | Verdadeiro negativo (VN) |

::: definicao 5.6 · Métricas derivadas da matriz de confusão
$$
\text{Acurácia} = \frac{VP+VN}{VP+VN+FP+FN},\qquad \text{Precisão} = \frac{VP}{VP+FP},\qquad \text{Recall} = \frac{VP}{VP+FN},
$$

$$
\text{Especificidade} = \frac{VN}{VN+FP},\qquad F_1 = \frac{2\cdot\text{Precisão}\cdot\text{Recall}}{\text{Precisão}+\text{Recall}} .
$$
:::

Cada métrica responde a uma pergunta diferente.

- **Acurácia:** de todas as previsões, que fração está correta?
- **Precisão:** dos exemplos que o modelo apontou como positivos, que fração realmente é? Mede a confiabilidade do alarme.
- **Recall** (sensibilidade): dos positivos reais, que fração o modelo encontrou? Mede a cobertura.
- **Especificidade:** dos negativos reais, que fração foi corretamente descartada?

Em termos do Capítulo 1: o recall estima $P(\text{previsto positivo}\mid\text{positivo})$, e a precisão estima $P(\text{positivo}\mid\text{previsto positivo})$. São as duas condicionais do Teorema de Bayes, e o Exemplo 1.7 mostrou quão diferentes podem ser.

### Por que a acurácia não basta

::: exemplo 5.1 · Acurácia em classes desbalanceadas
Em 10 000 transações, 50 são fraudes. Um modelo que responde "não é fraude" para todas tem acurácia de $9\,950/10\,000 = 99{,}5\%$ e recall de 0%: não detecta nenhuma fraude. Outro modelo detecta 40 das 50 fraudes e gera 200 alarmes falsos. Sua acurácia é $(40+9\,750)/10\,000 = 97{,}9\%$, **menor**. Seu recall é 80% e sua precisão é $40/240\approx16{,}7\%$. O segundo é útil; o primeiro, não.
:::

A acurácia só é informativa quando as classes têm frequências parecidas e os dois tipos de erro custam o mesmo. Em todo caso, deve ser comparada à do modelo trivial que prevê sempre a classe majoritária.

### F1

Precisão e recall puxam em direções opostas: é fácil ter recall 1 (basta prever tudo como positivo) ou precisão alta (basta prever positivo apenas nos casos óbvios). O $F_1$ é a **média harmônica** das duas, e a média harmônica é dominada pelo menor valor: precisão 1 e recall $0{,}1$ dão $F_1\approx0{,}18$, e não $0{,}55$. Um $F_1$ alto exige as duas métricas altas. Ele atribui a mesma importância às duas, o que nem sempre corresponde ao problema; a generalização $F_\beta$ permite pesos diferentes.

### Limiar de decisão

Modelos como a regressão logística produzem um escore $\hat p(x)$, e a classe é definida por um **limiar** $t$: positivo se $\hat p(x)\ge t$. O valor $0{,}5$ é uma convenção, ótima apenas sob perda 0-1 e com probabilidades bem calibradas. Baixar o limiar aumenta o recall e reduz a precisão; elevá-lo faz o oposto.

Quando os custos dos erros são conhecidos, o limiar ótimo pode ser calculado.

::: proposicao 5.6 · Limiar que minimiza o custo esperado
Sejam $c_{FP}$ o custo de um falso positivo e $c_{FN}$ o de um falso negativo, sem custo para acertos. Dada a probabilidade $p = P(Y=1\mid x)$, o custo esperado é minimizado prevendo positivo quando

$$
p\ge\frac{c_{FP}}{c_{FP}+c_{FN}} .
$$
:::

::: demonstracao
Prever positivo custa, em esperança, $(1-p)\,c_{FP}$; prever negativo custa $p\,c_{FN}$. Prefere-se positivo quando $(1-p)\,c_{FP}\le p\,c_{FN}$, o que equivale à expressão do enunciado.
:::

Com custos iguais, o limiar é $0{,}5$. Se deixar de detectar uma doença custa nove vezes mais do que um alarme falso, o limiar é $0{,}1$. A proposição supõe probabilidades **calibradas**, isto é, que entre os casos com $\hat p = 0{,}3$ cerca de 30% sejam positivos, propriedade que precisa ser verificada e que voltará no Capítulo 11.

### Curva ROC e AUC

Em vez de fixar um limiar, pode-se avaliar o modelo em todos.

::: definicao 5.7 · Curva ROC e AUC
A **curva ROC** (*Receiver Operating Characteristic*) é o gráfico da taxa de verdadeiros positivos (recall) contra a taxa de falsos positivos ($1-$ especificidade), quando o limiar percorre todos os valores. A **AUC** (*Area Under the Curve*) é a área sob essa curva.
:::

Com limiar muito alto, nada é previsto como positivo: ponto $(0,0)$. Com limiar muito baixo, tudo é: ponto $(1,1)$. Um classificador perfeito passa por $(0,1)$. Um que sorteia as respostas fica sobre a diagonal, com AUC de $0{,}5$.

::: proposicao 5.7 · Interpretação probabilística da AUC
A AUC é a probabilidade de que um exemplo positivo sorteado ao acaso receba escore maior do que um exemplo negativo sorteado ao acaso (contando empates como metade).
:::

A demonstração consiste em escrever a área como uma integral sobre os limiares e reconhecer nela essa probabilidade (Fawcett, 2006). A proposição dá à AUC um significado concreto: ela mede a qualidade da **ordenação** produzida pelo escore, independentemente de limiar e da proporção das classes.

<figure>
+++ fig_roc.svg
<figcaption><b>Figura 5.2.</b> Curva ROC do classificador do programa a seguir, no conjunto de teste, com os três limiares da tabela marcados. Baixar o limiar desloca o ponto de operação para cima e para a direita.</figcaption>
</figure>

::: atencao Limites da AUC
- **Com classes muito desbalanceadas, a curva ROC pode parecer excelente** enquanto a precisão é baixa, porque a taxa de falsos positivos é calculada sobre um número enorme de negativos. Nesses casos, a curva de precisão contra recall é mais informativa (Davis e Goadrich, 2006).
- **A AUC resume todos os limiares**, inclusive os que nunca seriam usados. Dois modelos de mesma AUC podem ter desempenhos diferentes na região de interesse.
- **A AUC não mede calibração.** Multiplicar todos os escores por uma constante não altera a AUC e destrói as probabilidades.
:::

### Implementação

<<< codigo/c5_metricas.py

>>> codigo/c5_metricas.out

A tabela mostra o compromisso. Com limiar $0{,}2$, o modelo encontra 96% dos tumores malignos e gera 26 alarmes falsos. Com $0{,}8$, não gera alarme falso e deixa de detectar 27 malignos. A maior acurácia ocorre em $0{,}5$, mas, em um contexto de triagem, em que não detectar um tumor é muito mais grave do que pedir um exame adicional, o limiar $0{,}2$ é a escolha defensável, mesmo com acurácia menor. A AUC calculada pela contagem de pares coincide com a da biblioteca, confirmando a Proposição 5.7.

## 5.7 Seleção de modelos em cenários reais

O procedimento da seção 5.4 supõe exemplos independentes e uma métrica única. Quatro situações comuns exigem adaptações.

**Classes desbalanceadas.** Em detecção de fraude, 1% de positivos é comum. Use partições **estratificadas**, que preservam a proporção das classes em cada parte (`StratifiedKFold`). Selecione por AUC, por área sob a curva de precisão e recall ou pelo custo esperado, e nunca pela acurácia. Escolha o limiar depois, com base nos custos.

**Dados temporais.** Ao prever demanda ou preços, sortear as partições deixa o modelo treinar com o futuro e validar no passado. A validação deve respeitar a ordem: treina-se em um período e valida-se no seguinte (`TimeSeriesSplit`). O erro obtido é geralmente maior do que com sorteio, e é o correto.

**Dados agrupados.** Se há várias observações por paciente, por cliente ou por documento, observações do mesmo grupo no treino e na validação permitem ao modelo reconhecer o grupo em vez de aprender o fenômeno. As partições devem manter cada grupo inteiro de um lado (`GroupKFold`).

**Mudança de distribuição.** Toda a teoria supõe que os dados futuros seguem a distribuição dos dados de treino. Em produção, isso deixa de valer com o tempo: mudam os clientes, os produtos, o comportamento. Nenhuma validação feita hoje garante o desempenho de amanhã. A consequência prática é monitorar o modelo depois de implantado, assunto do Capítulo 15.

::: aplicacao Os mesmos princípios nos módulos seguintes
Tudo o que foi dito aqui aplica-se a redes neurais e a LLMs, com nomes às vezes diferentes. A parada antecipada do treinamento usa um conjunto de validação (Capítulo 6). A decaída de pesos (*weight decay*) é a penalidade Ridge. Avaliar um sistema RAG com as mesmas perguntas usadas para ajustar seus prompts é vazamento de informação (Capítulo 15). E precisão e recall são as métricas da etapa de recuperação (Capítulo 12).
:::

## 5.8 Projeto 2: pipeline de Machine Learning

::: projeto Regressão e classificação com scikit-learn
O projeto reúne os Capítulos 3 a 5 em um procedimento completo e reutilizável de seleção e avaliação de modelos.
:::

### Objetivo

Construir um pipeline que compare modelos de regressão e de classificação, escolha hiperparâmetros por validação cruzada sem vazamento de informação e relate o desempenho em um conjunto de teste usado uma única vez.

### Problema

**Regressão:** prever a progressão do diabetes após um ano, a partir de dez medidas clínicas (442 pacientes). **Classificação:** distinguir tumores malignos de benignos a partir de 30 medidas de imagens de células (569 tumores). Os dois conjuntos acompanham o scikit-learn e dispensam acesso à rede.

### Requisitos

- Conjunto de teste separado antes de qualquer análise (25% dos dados).
- Pré-processamento dentro de um `Pipeline`.
- Um modelo de referência trivial em cada problema.
- Busca de hiperparâmetros por validação cruzada em 5 partes, estratificada na classificação.
- Métrica de seleção definida de antemão: $R^2$ na regressão, AUC na classificação.
- Sementes fixas e testes automáticos (`assert`).

### Arquitetura

<figure>
<svg class="fig" viewBox="0 0 720 150" role="img" aria-label="Fluxo do projeto: dados, separação de teste, pipeline com padronização e modelo, busca em grade com validação cruzada, escolha, avaliação final no teste">
<defs><marker id="seta5" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pt"/></marker></defs>
<g font-size="12" font-weight="700" text-anchor="middle">
<rect class="cx" x="2" y="20" width="96" height="52" rx="6"/><text x="50" y="50">Dados</text>
<rect class="cx" x="118" y="20" width="110" height="52" rx="6"/><text x="173" y="43">Separação</text><text x="173" y="60" class="t2" font-weight="400">treino 75%</text>
<rect class="cx" x="248" y="20" width="150" height="52" rx="6"/><text x="323" y="43">Pipeline</text><text x="323" y="60" class="t2" font-weight="400">padronização + modelo</text>
<rect class="cx" x="418" y="20" width="150" height="52" rx="6"/><text x="493" y="43">Busca em grade</text><text x="493" y="60" class="t2" font-weight="400">validação cruzada 5×</text>
<rect class="cx" x="588" y="20" width="130" height="52" rx="6"/><text x="653" y="43">Melhor modelo</text><text x="653" y="60" class="t2" font-weight="400">reajuste no treino</text>
<rect class="cxa" x="118" y="96" width="110" height="44" rx="6"/><text x="173" y="123">teste 25%</text>
<rect class="cxa" x="588" y="96" width="130" height="44" rx="6"/><text x="653" y="123">Avaliação final</text>
</g>
<g class="ln" marker-end="url(#seta5)"><path d="M98 46H116"/><path d="M228 46H246"/><path d="M398 46H416"/><path d="M568 46H586"/><path d="M653 72V94"/><path d="M228 118H586"/></g>
<path class="ln" d="M60 72V118H116" marker-end="url(#seta5)"/>
</svg>
<figcaption><b>Figura 5.3.</b> Arquitetura do Projeto 2. O conjunto de teste (em azul) percorre um caminho separado e só encontra o modelo na avaliação final.</figcaption>
</figure>

### Fundamentos teóricos

- **Referência trivial.** Prever a média (regressão) ou a classe majoritária (classificação) estabelece o piso que qualquer modelo deve superar (seção 5.6).
- **Pipeline.** Garante que o padronizador seja ajustado apenas na parte de treino de cada partição (seção 5.4).
- **Busca em grade.** Para cada combinação de hiperparâmetros, calcula a média da métrica nas partições e reajusta o melhor modelo em todo o treino.
- **Estratificação.** Mantém a proporção de classes em cada partição (seção 5.7).

### Implementação

<<< codigo/projeto2.py

### Testes e resultados

>>> codigo/projeto2.out

**Regressão.** A referência trivial tem $R^2$ ligeiramente negativo em validação: prever a média do treino é um pouco pior do que prever a média da própria parte de validação, o que mostra que $R^2$ fora da amostra pode ser negativo. Os três modelos lineares ficam em $0{,}461\pm0{,}001$. A vantagem do Lasso sobre a regressão sem penalidade, na terceira casa decimal, é muito menor que a variação entre partições; os três são equivalentes, e seria igualmente defensável escolher o mais simples. KNN e árvore ficam atrás: com 331 exemplos de treino e relação aproximadamente linear, a flexibilidade adicional custa mais variância do que economiza em viés. No teste, o $R^2$ é $0{,}49$, com raiz do erro quadrático médio de 53 unidades, em uma resposta que varia de 25 a 346.

**Classificação.** A regressão logística regularizada vence com AUC de $0{,}992$ em validação e $0{,}998$ no teste. A matriz de confusão mostra nenhum falso positivo e três falsos negativos em 143 tumores: três malignos classificados como benignos. Pela discussão da seção 5.6, em uso clínico o limiar deveria ser reduzido para trocar esses falsos negativos por alguns alarmes falsos.

### Limitações

- Um único sorteio de treino e teste. Com 143 exemplos de teste, a incerteza das métricas é considerável; a diferença entre AUC de validação e de teste está dentro dela.
- Os conjuntos são pequenos, limpos e sem valores ausentes. Dados reais exigem tratamento de ausentes, de variáveis categóricas e de valores atípicos, também dentro do pipeline.
- O limiar de classificação não foi otimizado, e a calibração das probabilidades não foi verificada.
- Nenhuma conclusão clínica pode ser tirada: os dados servem apenas como exemplo.

### Melhorias possíveis

1. Repetir a divisão em treino e teste com várias sementes e relatar média e desvio das métricas.
2. Acrescentar florestas aleatórias e *gradient boosting* aos candidatos.
3. Escolher o limiar pela Proposição 5.6, com custos explícitos, usando apenas dados de treino.
4. Avaliar a calibração com `CalibrationDisplay`.
5. Adotar validação cruzada aninhada no lugar do teste único.

## 5.9 Resumo do capítulo

::: resumo Ideias centrais
- O **erro de treinamento é otimista**. Na regressão linear, a diferença esperada para o erro de teste é $2\sigma^2p/n$.
- O erro de teste decompõe-se em **viés², variância e ruído**. Flexibilidade reduz viés e aumenta variância; **subajuste** e **superajuste** são os dois lados do compromisso.
- A **validação cruzada** estima o erro de teste com os dados disponíveis. Todo pré-processamento que aprende dos dados deve ficar dentro das partições; o conjunto de teste é usado uma única vez.
- **Ridge** encolhe coeficientes proporcionalmente; **Lasso** subtrai e zera, produzindo esparsidade. Ambos trocam viés por variância e exigem padronização e escolha de $\lambda$ por validação cruzada.
- **Acurácia** engana em classes desbalanceadas. **Precisão** e **recall** medem aspectos opostos; o **F1** é sua média harmônica. O **limiar** deve refletir os custos dos erros.
- A **AUC** é a probabilidade de ordenar corretamente um positivo e um negativo.
- A forma de validar deve respeitar a estrutura dos dados: estratificação, tempo e grupos.
:::

**Fim do Módulo II.** Os modelos deste módulo dependem de variáveis preditoras fornecidas por quem analisa os dados. O Módulo III remove essa dependência: redes neurais aprendem as próprias representações, e o Capítulo 6 começa mostrando que um neurônio é a regressão logística da seção 4.5.

## 5.10 Exercícios

### Nível I: consolidação

**5.1** Uma matriz de confusão tem $VP=30$, $FP=10$, $FN=20$ e $VN=940$. Calcule acurácia, precisão, recall, especificidade e $F_1$.

**5.2** No exercício anterior, qual seria a acurácia de um modelo que previsse sempre a classe negativa? O que isso diz sobre a acurácia obtida?

**5.3** Três modelos têm erros (treino; teste): A $(0{,}30;\ 0{,}32)$, B $(0{,}10;\ 0{,}12)$, C $(0{,}01;\ 0{,}25)$. Diagnostique cada um.

**5.4** Uma busca em grade avalia 20 valores de um hiperparâmetro por validação cruzada em 10 partes. Quantos ajustes de modelo são feitos?

**5.5** Você tem 200 preditoras e suspeita que poucas sejam relevantes. Ridge ou Lasso? E se suspeitar que quase todas contribuem um pouco?

### Nível II: desenvolvimento

**5.6** Para estimar a média $\mu$ de uma população com variância $\sigma^2$, considere o estimador $c\,\bar X$, com $0\le c\le1$ e $\bar X$ a média de $n$ observações. (a) Calcule o viés e a variância. (b) Encontre o $c$ que minimiza o erro quadrático médio. (c) Interprete o fato de que o valor ótimo é menor que 1.

**5.7** Mostre que, com colunas ortonormais, os valores ajustados da Ridge são os de mínimos quadrados multiplicados por $1/(1+\lambda)$, e calcule o viés e a variância de $\hat\beta_j^{\text{ridge}}$ sob as hipóteses da Proposição 4.3.

**5.8** Aplique a limiarização suave com $\lambda = 1$ aos coeficientes de mínimos quadrados $(3{,}0;\ -0{,}4;\ 1{,}2;\ -2{,}5;\ 0{,}9)$. Compare com a Ridge com $\lambda=1$ no caso ortonormal.

**5.9** Um modelo atribui os escores $0{,}9;\ 0{,}6;\ 0{,}4$ a três exemplos positivos e $0{,}7;\ 0{,}3;\ 0{,}2;\ 0{,}1$ a quatro negativos. Calcule a AUC pela Proposição 5.7.

**5.10** Em um sistema de triagem, um falso negativo custa 10 vezes mais do que um falso positivo. Qual é o limiar de decisão ótimo? Que hipótese sobre o modelo precisa valer?

**5.11** (Computacional) Repita o experimento de vazamento da seção 5.4 trocando a seleção de variáveis por padronização (`StandardScaler` aplicado a todos os dados antes da validação cruzada). O efeito é da mesma magnitude? Explique.

### Nível III: avançado

**5.12** (Experimento) No conjunto *breast cancer*, escolha o melhor entre os modelos do Projeto 2 por validação cruzada simples e relate o erro de validação do vencedor. Depois estime o erro por validação cruzada aninhada. Repita com 20 sementes e compare as duas distribuições.

**5.13** (Pesquisa) Leia Belkin et al. (2019). Reproduza a descida dupla com regressão de mínimos quadrados de norma mínima sobre características aleatórias, variando o número de características de muito menor a muito maior que $n$. Explique por que o erro tem um pico quando o número de parâmetros se aproxima de $n$, usando o conceito de número de condição.

**5.14** (Estudo de caso) Uma empresa quer prever o cancelamento de assinaturas (3% dos clientes por mês), com dados dos últimos 24 meses e várias linhas por cliente. Projete o protocolo de avaliação: partições, métricas, referência trivial, escolha do limiar e monitoramento após a implantação. Justifique cada decisão com base neste capítulo.

## 5.11 Soluções comentadas

::: solucao 5.1
Total: 1 000. Acurácia: $970/1000 = 0{,}97$. Precisão: $30/40 = 0{,}75$. Recall: $30/50 = 0{,}60$. Especificidade: $940/950\approx0{,}989$. $F_1 = 2\times0{,}75\times0{,}60/1{,}35\approx0{,}667$.
:::

::: solucao 5.2
Há 950 negativos: a acurácia seria $0{,}95$. O modelo do exercício supera a referência por apenas dois pontos percentuais; os 97% dizem pouco. As métricas informativas são precisão e recall: o modelo encontra 60% dos positivos, e três em cada quatro de seus alarmes são corretos.
:::

::: solucao 5.3
A: subajuste (ambos altos e próximos). B: ajuste adequado. C: superajuste (treino quase perfeito, teste muito pior). Entre os três, B é o melhor, e C é pior que B apesar do menor erro de treino.
:::

::: solucao 5.4
$20\times10 = 200$ ajustes na busca, mais um reajuste final do melhor modelo em todo o treino: 201.
:::

::: solucao 5.5
Lasso no primeiro caso, pois produz um modelo esparso. Ridge no segundo: zerar variáveis que contribuem aumentaria o viés. Na dúvida, a rede elástica, com a mistura escolhida por validação cruzada.
:::

::: solucao 5.6
(a) $\mathbb{E}[c\bar X] = c\mu$: viés $(c-1)\mu$. Variância: $c^2\sigma^2/n$. (b) O erro quadrático médio é $(1-c)^2\mu^2+c^2\sigma^2/n$. Derivando e igualando a zero: $c^\star = \dfrac{\mu^2}{\mu^2+\sigma^2/n}$. (c) Como $c^\star<1$, um estimador viesado, que encolhe a média amostral em direção a zero, tem erro menor do que o estimador não viesado. É a regularização em sua forma mais simples. O valor ótimo depende de $\mu$ e $\sigma^2$, desconhecidos, e por isso, na prática, a intensidade do encolhimento é escolhida por validação cruzada.
:::

::: solucao 5.7
Com $\mathbf{X}^\top\mathbf{X} = \mathbf{I}$, $\hat{\mathbf{y}}^{\text{ridge}} = \mathbf{X}\mathbf{X}^\top\mathbf{y}/(1+\lambda) = \hat{\mathbf{y}}^{\text{OLS}}/(1+\lambda)$. Como $\hat\beta_j^{\text{OLS}}$ tem média $\beta_j$ e variância $\sigma^2$ (pois $(\mathbf{X}^\top\mathbf{X})^{-1} = \mathbf{I}$), o estimador Ridge tem média $\beta_j/(1+\lambda)$, viés $-\lambda\beta_j/(1+\lambda)$ e variância $\sigma^2/(1+\lambda)^2$. O viés cresce e a variância decresce com $\lambda$: é o compromisso do Teorema 5.2 em forma explícita, e a estrutura é a do exercício anterior, com $c = 1/(1+\lambda)$.
:::

::: solucao 5.8
Lasso: $(2{,}0;\ 0;\ 0{,}2;\ -1{,}5;\ 0)$. Dois coeficientes, de módulo menor que 1, foram zerados; os demais perderam uma unidade em módulo. Ridge: cada coeficiente dividido por 2, $(1{,}5;\ -0{,}2;\ 0{,}6;\ -1{,}25;\ 0{,}45)$, nenhum nulo. Note que o Lasso encolhe mais os coeficientes pequenos, em termos relativos, e a Ridge encolhe mais os grandes, em termos absolutos.
:::

::: solucao 5.9
Há $3\times4 = 12$ pares. O positivo com $0{,}9$ supera os 4 negativos; o de $0{,}6$ supera 3 (perde para $0{,}7$); o de $0{,}4$ supera 3. Total: 10 pares corretos. $\text{AUC} = 10/12\approx0{,}833$.
:::

::: solucao 5.10
Pela Proposição 5.6, $t = 1/(1+10)\approx0{,}091$: prevê-se positivo sempre que a probabilidade estimada passar de 9%. A regra supõe que as probabilidades do modelo sejam calibradas; se o modelo for sistematicamente confiante demais ou de menos, o limiar calculado estará errado, e é preciso calibrá-lo ou escolher o limiar empiricamente, minimizando o custo em dados de validação.
:::

::: solucao 5.11 (orientação)
O efeito é muito menor, em geral imperceptível. A padronização usa apenas médias e desvios das preditoras, sem olhar para a resposta, e essas estatísticas mudam pouco ao incluir a parte de validação. A seleção de variáveis usa a resposta e, com 5 000 candidatas, tem enorme liberdade para ajustar o ruído. A gravidade do vazamento depende de quanta informação sobre a **resposta** vaza e de quão flexível é a etapa contaminada. A prática correta é a mesma nos dois casos: tudo dentro do `Pipeline`.
:::

::: solucao 5.12 (orientação)
Use `cross_val_score` com um `GridSearchCV` como estimador para a versão aninhada. Espera-se que o erro de validação do vencedor seja, em média, um pouco menor (mais otimista) do que a estimativa aninhada. Com poucos candidatos e um conjunto bem comportado como este, a diferença é pequena; ela cresce com o número de configurações comparadas e diminui com o tamanho dos dados.
:::

::: solucao 5.13 (orientação)
Com $p<n$, o erro de teste segue a curva em U. Perto de $p=n$, a matriz de características torna-se quase singular: seu menor valor singular aproxima-se de zero, o número de condição explode e a solução que interpola os dados tem norma enorme, amplificando o ruído (seção 1.7). Para $p\gg n$, existem infinitas soluções interpoladoras, e a de norma mínima, selecionada pela pseudoinversa (`np.linalg.lstsq`), torna-se progressivamente mais suave: a variância volta a cair. Acrescentar uma penalidade Ridge elimina o pico, o que mostra que ele é um fenômeno de condicionamento.
:::

::: solucao 5.14 (orientação)
Elementos esperados. *Partições:* temporais (treinar em meses anteriores, validar nos seguintes) e por cliente, para que o mesmo cliente não apareça dos dois lados. *Métricas:* área sob a curva de precisão e recall e recall entre os $k$% de clientes de maior escore, pois a ação de retenção tem orçamento limitado; a acurácia é descartada, já que prever "não cancela" acerta 97%. *Referência:* uma regra simples, como "clientes sem uso no último mês". *Limiar:* definido pelo custo da ação de retenção e pelo valor de um cliente retido (Proposição 5.6), ou pela capacidade da equipe. *Vazamento:* excluir variáveis registradas depois do cancelamento. *Monitoramento:* acompanhar mensalmente as métricas e a distribuição das preditoras, com critério definido para reajustar o modelo.
:::

## 5.12 Referências e leituras

**O que estudar primeiro.** James et al. (2023): capítulo 5 (reamostragem), capítulo 6 (regularização) e seção 4.4 (métricas e curva ROC), com os laboratórios.

### Livros didáticos fundamentais

- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Capítulos 2, 4, 5 e 6.
- HASTIE, T.; TIBSHIRANI, R.; FRIEDMAN, J. *The Elements of Statistical Learning*. 2. ed. New York: Springer, 2009. Capítulos 3 e 7.

### Artigos originais

- BELKIN, M.; HSU, D.; MA, S.; MANDAL, S. Reconciling modern machine-learning practice and the classical bias–variance trade-off. *Proceedings of the National Academy of Sciences*, v. 116, n. 32, p. 15849–15854, 2019.
- DAVIS, J.; GOADRICH, M. The relationship between Precision-Recall and ROC curves. In: *Proceedings of the 23rd International Conference on Machine Learning*, 2006. p. 233–240.
- FAWCETT, T. An introduction to ROC analysis. *Pattern Recognition Letters*, v. 27, n. 8, p. 861–874, 2006.
- GEMAN, S.; BIENENSTOCK, E.; DOURSAT, R. Neural networks and the bias/variance dilemma. *Neural Computation*, v. 4, n. 1, p. 1–58, 1992.
- HOERL, A. E.; KENNARD, R. W. Ridge regression: biased estimation for nonorthogonal problems. *Technometrics*, v. 12, n. 1, p. 55–67, 1970.
- STONE, M. Cross-validatory choice and assessment of statistical predictions. *Journal of the Royal Statistical Society: Series B*, v. 36, n. 2, p. 111–147, 1974.
- TIBSHIRANI, R. Regression shrinkage and selection via the lasso. *Journal of the Royal Statistical Society: Series B*, v. 58, n. 1, p. 267–288, 1996.

### Documentação técnica

- scikit-learn, guia do usuário: validação cruzada, ajuste de hiperparâmetros, métricas de avaliação, `Pipeline` e armadilhas comuns (vazamento de dados). scikit-learn.org/stable/user_guide.html. Versão 1.9.
