<div class="objetivos">

Objetivos do capítulo

- Descrever dados sequenciais (texto, áudio, séries temporais) e as principais configurações de tarefa: muitos-para-um, muitos-para-muitos e sequência-para-sequência.
- Definir a rede recorrente de Elman, desdobrá-la no tempo, contar seus parâmetros e reproduzi-la à mão, conferindo com `torch.nn.RNN`.
- Deduzir a retropropagação através do tempo (BPTT) e demonstrar o limite exponencial do produto de jacobianos que explica a dissipação e a explosão do gradiente.
- Medir esse fenômeno numericamente e aplicar o recorte de gradiente (*gradient clipping*).
- Deduzir a LSTM e a GRU, demonstrar por que o caminho aditivo do estado de memória preserva o gradiente e verificar o efeito da inicialização das portas.
- Tratar sequências de comprimentos diferentes (preenchimento, empacotamento, máscaras) e usar camadas bidirecionais e empilhadas.
- Avaliar, em experimentos controlados, quando RNN, GRU e LSTM conseguem memorizar a longo prazo e quando um modelo linear simples basta.

**Pré-requisitos:** Capítulo 1 (normas, autovalores, regra da cadeia), Capítulo 5 (validação) e Capítulo 6 (retropropagação, otimizadores, PyTorch).

</div>

## 8.1 Dados sequenciais

Nos capítulos anteriores, cada exemplo era um vetor de tamanho fixo (as variáveis de uma tabela, os pixels de uma imagem). Muitos dados têm outra natureza: são **sequências** $\mathbf{x}_1,\mathbf{x}_2,\dots,\mathbf{x}_T$, em que a **ordem importa** e o comprimento $T$ **varia** de um exemplo para outro.

- **Texto:** uma sequência de palavras ou caracteres. "O cão mordeu o homem" e "O homem mordeu o cão" têm as mesmas palavras e significados opostos.
- **Áudio:** uma sequência de amostras de pressão, ou de quadros espectrais, ao longo do tempo.
- **Séries temporais:** consumo de energia, preços, sinais de sensores, batimentos cardíacos.
- **Outras:** trajetórias, sequências de DNA ou de proteínas, registros de cliques de um usuário.

### Configurações de tarefa

O que se pede ao modelo define a arquitetura da saída. As configurações mais comuns são:

| Configuração | Entrada $\to$ saída | Exemplo |
|---|---|---|
| Muitos-para-um | $\mathbf{x}_{1:T}\to y$ | classificar o sentimento de uma avaliação; prever o próximo valor de uma série |
| Muitos-para-muitos sincronizado | $\mathbf{x}_{1:T}\to y_{1:T}$ | marcar a classe gramatical de cada palavra; modelo de linguagem (o alvo em $t$ é a entrada em $t+1$) |
| Sequência-para-sequência | $\mathbf{x}_{1:T}\to y_{1:T'}$, com $T'\ne T$ | tradução automática; resumo |
| Um-para-muitos | $\mathbf{x}\to y_{1:T'}$ | legendar uma imagem |

### A regra da cadeia e o problema do contexto

Para **modelar** uma sequência, isto é, atribuir-lhe probabilidade, a regra da cadeia da probabilidade (Capítulo 1) dá, sem aproximação alguma,

$$p(\mathbf{x}_1,\dots,\mathbf{x}_T)=\prod_{t=1}^{T}p(\mathbf{x}_t\mid\mathbf{x}_1,\dots,\mathbf{x}_{t-1}).$$

Cada fator condiciona em **todo o passado**, que cresce com $t$. Há duas saídas clássicas. A primeira trunca o passado em uma janela fixa de $n-1$ elementos (modelo de $n$-gramas, ou, para séries, uma regressão sobre as últimas $J$ observações); o número de parâmetros e de contextos possíveis cresce exponencialmente (ou, em regressão, com $J$), e dependências além da janela são perdidas. A segunda resume todo o passado em um **estado** de tamanho fixo, atualizado a cada passo. Esta é a ideia das redes recorrentes.

::: definicao 8.1 · Modelo de sequência com estado
Um **modelo com estado** mantém um vetor $\mathbf{h}_t\in\mathbb{R}^H$ (o **estado oculto**) que resume a entrada vista até o instante $t$, atualizado por uma função fixa
$$\mathbf{h}_t=f_\theta(\mathbf{h}_{t-1},\mathbf{x}_t),\qquad \mathbf{h}_0\ \text{dado (em geral } \mathbf{0}),$$
e produz saídas por uma função $\hat{y}_t=g_\theta(\mathbf{h}_t)$. A **mesma** função $f_\theta$, com os **mesmos** parâmetros $\theta$, é aplicada em todos os instantes.
:::

O compartilhamento de $\theta$ no tempo cumpre para sequências o papel que o compartilhamento de filtros no espaço cumpriu nas CNNs (Capítulo 7): o número de parâmetros não depende de $T$, e um padrão aprendido em uma posição é reconhecido em qualquer outra. A diferença essencial é que aqui há **dependência**: $\mathbf{h}_t$ depende de $\mathbf{h}_{t-1}$, e o cálculo não pode ser paralelizado ao longo do tempo. Retomaremos este ponto no Capítulo 9.

## 8.2 A rede recorrente simples

::: definicao 8.2 · Rede recorrente de Elman
A **rede recorrente simples** (de Elman, 1990), com entrada $\mathbf{x}_t\in\mathbb{R}^F$ e estado $\mathbf{h}_t\in\mathbb{R}^H$, é
$$\begin{aligned}\mathbf{a}_t&=\mathbf{W}_{xh}\mathbf{x}_t+\mathbf{W}_{hh}\mathbf{h}_{t-1}+\mathbf{b},\\ \mathbf{h}_t&=\tanh(\mathbf{a}_t),\end{aligned}$$
com $\mathbf{W}_{xh}\in\mathbb{R}^{H\times F}$, $\mathbf{W}_{hh}\in\mathbb{R}^{H\times H}$ e $\mathbf{b}\in\mathbb{R}^{H}$. A saída, quando necessária, é $\hat{\mathbf{y}}_t=\mathbf{W}_{hy}\mathbf{h}_t+\mathbf{b}_y$, seguida da função de ativação adequada à tarefa (por exemplo, a softmax).
:::

Se $\mathbf{W}_{hh}=\mathbf{0}$, o estado depende só da entrada atual, e a rede degenera em um MLP aplicado a cada instante separadamente. É o termo $\mathbf{W}_{hh}\mathbf{h}_{t-1}$ que injeta o passado.

### Desdobramento no tempo

Aplicando a recorrência $T$ vezes, a rede recorrente torna-se uma rede **profunda** de $T$ camadas, uma por instante, com os pesos **compartilhados** entre as camadas e com uma entrada em cada camada (Figura 8.1). É por meio dessa visão que a retropropagação do Capítulo 6 se aplica sem alteração conceitual.

<figure>
+++ fig_c8_desdobrada.svg
<figcaption><b>Figura 8.1.</b> Rede recorrente desdobrada no tempo. As setas horizontais carregam o estado oculto, e as verticais levam a entrada ao estado e o estado à saída. Os mesmos pesos $\mathbf{W}_{xh}$, $\mathbf{W}_{hh}$ e $\mathbf{W}_{hy}$ são usados em todos os instantes.</figcaption>
</figure>

### Formatos e contagem de parâmetros no PyTorch

No PyTorch, com `batch_first=True`, uma sequência em lote tem formato $(N,T,F)$: $N$ exemplos, $T$ instantes e $F$ características. A camada devolve duas coisas: a saída de **todos** os instantes, de formato $(N,T,H)$, e o estado **final** de cada camada, de formato $(\text{camadas}\cdot\text{direções},N,H)$. O programa abaixo implementa a recorrência da Definição 8.2 com um laço explícito, confere o resultado com `nn.RNN` e compara o número de parâmetros com a fórmula da proposição seguinte.

::: proposicao 8.1 · Número de parâmetros de uma camada recorrente
Seja uma camada recorrente com entrada de dimensão $F$ e estado de dimensão $H$. Cada **bloco de transformação** (a pré-ativação de uma porta ou do candidato) tem $H(F+H)$ pesos e, no PyTorch, **dois** vetores de viés de tamanho $H$ (`bias_ih` e `bias_hh`). Logo, a camada tem
$$n_\text{blocos}\cdot H\cdot(F+H+2)$$
parâmetros, com $n_\text{blocos}=1$ na RNN simples, $3$ na GRU e $4$ na LSTM. O número **não depende** de $T$.
:::

::: demonstracao
Em cada bloco, a pré-ativação é $\mathbf{W}_{i}\mathbf{x}_t+\mathbf{b}_{i}+\mathbf{W}_{h}\mathbf{h}_{t-1}+\mathbf{b}_{h}$, com $\mathbf{W}_i\in\mathbb{R}^{H\times F}$ e $\mathbf{W}_h\in\mathbb{R}^{H\times H}$. Isso dá $HF+H\cdot H+2H=H(F+H+2)$ parâmetros por bloco. A contagem de blocos (1, 3 ou 4) decorre das definições da RNN, da GRU (portas $r$ e $z$ e candidato) e da LSTM (portas $i$, $f$, $o$ e candidato), nas seções seguintes.
:::

<<< codigo/c8_rnn_manual.py

>>> codigo/c8_rnn_manual.out

A diferença entre a implementação manual e `nn.RNN` é de $10^{-7}$, o nível do erro de arredondamento em precisão simples. O programa também confirma a fórmula da Proposição 8.1 nos três tipos de célula.

::: nota Um viés a mais
Os dois vieses por bloco no PyTorch são redundantes (sua soma é o que importa) e existem por compatibilidade com outras bibliotecas. Na definição matemática usamos um só vetor $\mathbf{b}$.
:::

## 8.3 Retropropagação através do tempo e o gradiente que some ou explode

### O gradiente em uma rede desdobrada

Seja $L=\sum_{t=1}^{T}L_t$ a perda total, em que $L_t$ depende de $\hat{\mathbf{y}}_t$ (e portanto de $\mathbf{h}_t$). Aplicar a retropropagação à rede desdobrada é chamado de **retropropagação através do tempo** (*backpropagation through time*, BPTT).

::: teorema 8.2 · Retropropagação através do tempo
Na rede da Definição 8.2, defina o erro da pré-ativação $\boldsymbol\delta_t=\partial L/\partial\mathbf{a}_t$ e o gradiente total em relação ao estado $\mathbf{g}_t=\partial L/\partial\mathbf{h}_t$. Então, para $t=T,T-1,\dots,1$, com $\boldsymbol\delta_{T+1}=\mathbf{0}$:
$$\mathbf{g}_t=\frac{\partial L_t}{\partial\mathbf{h}_t}+\mathbf{W}_{hh}^{\top}\boldsymbol\delta_{t+1},\qquad \boldsymbol\delta_t=(1-\mathbf{h}_t^{\odot2})\odot\mathbf{g}_t,$$
e os gradientes dos parâmetros, **somados sobre os instantes**, são
$$\frac{\partial L}{\partial\mathbf{W}_{hh}}=\sum_{t=1}^{T}\boldsymbol\delta_t\,\mathbf{h}_{t-1}^{\top},\qquad \frac{\partial L}{\partial\mathbf{W}_{xh}}=\sum_{t=1}^{T}\boldsymbol\delta_t\,\mathbf{x}_t^{\top},\qquad \frac{\partial L}{\partial\mathbf{b}}=\sum_{t=1}^{T}\boldsymbol\delta_t.$$
:::

::: demonstracao
O estado $\mathbf{h}_t$ influencia a perda por dois caminhos: diretamente, por $L_t$, e indiretamente, por $\mathbf{a}_{t+1}=\mathbf{W}_{xh}\mathbf{x}_{t+1}+\mathbf{W}_{hh}\mathbf{h}_t+\mathbf{b}$, que alimenta todo o futuro. Pela regra da cadeia multivariável, $\mathbf{g}_t=\partial L_t/\partial\mathbf{h}_t+(\partial\mathbf{a}_{t+1}/\partial\mathbf{h}_t)^{\top}\boldsymbol\delta_{t+1}=\partial L_t/\partial\mathbf{h}_t+\mathbf{W}_{hh}^{\top}\boldsymbol\delta_{t+1}$. Como $\mathbf{h}_t=\tanh(\mathbf{a}_t)$ atua componente a componente e $\tanh'(a)=1-\tanh^2(a)$, vale $\boldsymbol\delta_t=(1-\mathbf{h}_t^{\odot2})\odot\mathbf{g}_t$. Por fim, $\mathbf{W}_{hh}$ aparece em **todas** as pré-ativações $\mathbf{a}_t=\dots+\mathbf{W}_{hh}\mathbf{h}_{t-1}+\dots$; como a perda depende de uma matriz compartilhada, os gradientes de cada uso se somam, e o gradiente de $\mathbf{a}_t$ em relação a $\mathbf{W}_{hh}$ é, por componente, $\delta_{t,i}h_{t-1,j}$. O mesmo vale para $\mathbf{W}_{xh}$ e $\mathbf{b}$.
:::

A recursão do Teorema 8.2 é a recursão de erro do Teorema 6.8 (retropropagação em MLP), com uma diferença: o "erro da camada seguinte" é o do **instante** seguinte, e os pesos são os mesmos em todas as camadas. O custo de memória é $O(T\cdot H)$, porque todos os estados $\mathbf{h}_t$ precisam ser guardados até a volta.

### O produto de jacobianos

Expandindo a recursão, o efeito de um estado distante $\mathbf{h}_{s}$ sobre o estado atual $\mathbf{h}_t$ ($s<t$) é um **produto de jacobianos**:

$$\frac{\partial\mathbf{h}_t}{\partial\mathbf{h}_s}=\prod_{u=s+1}^{t}\frac{\partial\mathbf{h}_u}{\partial\mathbf{h}_{u-1}}=\prod_{u=s+1}^{t}\mathbf{D}_u\mathbf{W}_{hh},\qquad \mathbf{D}_u=\operatorname{diag}\bigl(1-\mathbf{h}_u^{\odot2}\bigr).$$

Um produto de $k=t-s$ matrizes tende a crescer ou a encolher **exponencialmente** em $k$. O teorema seguinte dá o limite superior preciso.

::: teorema 8.3 · Limite exponencial do jacobiano
Sejam $\mathbf{J}_u=\mathbf{D}_u\mathbf{W}_{hh}$ os jacobianos da Definição 8.2, $\sigma=\lVert\mathbf{W}_{hh}\rVert_2$ o maior valor singular de $\mathbf{W}_{hh}$ e $\gamma=\sup|\varphi'|$ o supremo da derivada da ativação ($\gamma=1$ para a $\tanh$, $\gamma=\tfrac14$ para a sigmoide). Então, para todo $k\ge1$,
$$\Bigl\lVert\frac{\partial\mathbf{h}_t}{\partial\mathbf{h}_{t-k}}\Bigr\rVert_2\le(\gamma\sigma)^k.$$
Em particular, se $\gamma\sigma<1$, a influência de um estado sobre outro $k$ passos adiante **decai exponencialmente** com $k$. Reciprocamente, no caso **linear** ($\varphi$ a identidade, $\mathbf{D}_u=\mathbf{I}$), $\lVert\partial\mathbf{h}_t/\partial\mathbf{h}_{t-k}\rVert_2=\lVert\mathbf{W}_{hh}^k\rVert_2\ge\rho(\mathbf{W}_{hh})^k$, em que $\rho$ é o raio espectral; se $\rho>1$, a influência **cresce exponencialmente**.
:::

::: demonstracao
A norma espectral é submultiplicativa: $\lVert\mathbf{A}\mathbf{B}\rVert_2\le\lVert\mathbf{A}\rVert_2\lVert\mathbf{B}\rVert_2$. Como $\mathbf{D}_u$ é diagonal com entradas em $[0,\gamma]$, $\lVert\mathbf{D}_u\rVert_2\le\gamma$, e $\lVert\mathbf{J}_u\rVert_2\le\gamma\sigma$. O produto de $k$ fatores tem norma no máximo $(\gamma\sigma)^k$. No caso linear, $\partial\mathbf{h}_t/\partial\mathbf{h}_{t-k}=\mathbf{W}_{hh}^k$, e o raio espectral satisfaz $\rho(\mathbf{A})^k=\rho(\mathbf{A}^k)\le\lVert\mathbf{A}^k\rVert_2$, porque a norma espectral limita por cima o módulo de qualquer autovalor.
:::

::: atencao O que o teorema não diz
O limite superior $(\gamma\sigma)^k$ não garante que o gradiente **explode** quando $\gamma\sigma>1$: é apenas um majorante. Com a $\tanh$, a saturação (as entradas de $\mathbf{D}_u$ ficam próximas de zero) pode conter o crescimento, como a tabela a seguir mostra. Já a condição de **dissipação**, $\gamma\sigma<1$, é suficiente: nela o decaimento é garantido.
:::

### Medindo o fenômeno

O programa abaixo calcula, para uma rede de $H=32$ unidades com $\mathbf{W}_{hh}=\rho\mathbf{Q}$ ($\mathbf{Q}$ ortogonal, de modo que todos os valores singulares de $\mathbf{W}_{hh}$ valem $\rho$), a norma espectral exata de $\partial\mathbf{h}_T/\partial\mathbf{h}_{T-k}$ ao longo de uma trajetória com entradas aleatórias, para a identidade e para a $\tanh$.

<<< codigo/c8_gradiente_tempo.py

>>> codigo/c8_gradiente_tempo.out

<figure>
+++ fig_c8_jacobiano.svg
<figcaption><b>Figura 8.2.</b> Norma de $\partial\mathbf{h}_T/\partial\mathbf{h}_{T-k}$ em escala logarítmica (valores de <code>c8_gradiente_tempo.out</code>). No caso linear, $\rho=1$ conserva a norma e $\rho\ne1$ leva a decaimento ou crescimento exponencial; com a $\tanh$, a norma cai bem abaixo da linear mesmo em $\rho=1$.</figcaption>
</figure>

Três observações. **(i)** No caso linear, a norma é exatamente $\rho^k$: $0{,}5^{60}\approx8{,}7\times10^{-19}$, e $1{,}5^{60}\approx3{,}7\times10^{10}$. **(ii)** Com a $\tanh$, **mesmo com $\rho=1$**, a norma cai para $9\times10^{-7}$ em $k=60$, porque a derivada da $\tanh$ é menor que $1$ fora da origem; o valor $\rho=1$, que conserva a norma no caso linear, não basta aqui. **(iii)** Com $\rho=1{,}5$ e $\tanh$, a norma **não** explode: fica em torno de $2$ a $3$, porque as unidades saturam; este é um regime caótico, em que a dinâmica é sensível às condições iniciais, mas a norma do jacobiano permanece limitada neste experimento. Em redes reais treinadas, a explosão costuma aparecer como picos esporádicos da norma do gradiente (Pascanu e colegas falam em "penhascos" da superfície de custo), e o remédio para isso é o recorte, descrito adiante.

### Consequências para o aprendizado

Uma dependência de longo prazo é uma situação em que a saída no instante $t$ depende da entrada no instante $s\ll t$. Seu sinal de aprendizado percorre o produto de jacobianos de $t-s$ fatores. Se esse produto é exponencialmente pequeno, **o gradiente do termo de longo prazo é irrelevante frente aos termos de curto prazo**, que dominam a soma. A rede aprende o curto prazo e ignora o longo prazo, não por falta de capacidade (a rede **pode** representar a dependência), mas porque o **algoritmo de treino** não a enxerga. Esse é o problema da **dissipação do gradiente** (*vanishing gradient*), analisado por Hochreiter (1991) e por Bengio, Simard e Frasconi (1994). O problema dual, a **explosão** (*exploding gradient*), produz atualizações gigantescas e instáveis.

### Recorte de gradiente

Para a explosão, usa-se o **recorte de gradiente** (*gradient clipping*), proposto no contexto de redes recorrentes por Pascanu, Mikolov e Bengio (2013).

::: definicao 8.3 · Recorte de gradiente pela norma
Dado um limiar $c>0$ e o gradiente $\mathbf{g}$ de todos os parâmetros (concatenados), o gradiente recortado é
$$\tilde{\mathbf{g}}=\mathbf{g}\cdot\min\Bigl(1,\ \frac{c}{\lVert\mathbf{g}\rVert_2}\Bigr).$$
:::

O recorte **preserva a direção** do gradiente (apenas reduz o comprimento quando $\lVert\mathbf{g}\rVert>c$), o que o distingue de cortar cada componente separadamente. A parte final de `c8_gradiente_tempo.out` mostra o efeito: um gradiente de norma $1\,558{,}5$ é reduzido a $5{,}0$, com cosseno $1{,}0000$ em relação ao original. No PyTorch, a função `clip_grad_norm_(parametros, c)`, do módulo `torch.nn.utils`, faz o mesmo, **depois** de `loss.backward()` e **antes** de `otimizador.step()`. Note que o recorte trata da explosão; **não** resolve a dissipação, porque aumentar um gradiente minúsculo não recupera a informação que se perdeu. Para isso, é preciso mudar a arquitetura.
