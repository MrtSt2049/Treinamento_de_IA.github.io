## 9.11 Exercícios

### Nível I: consolidação

**9.1** Com $d_k=2$, $\mathbf{q}=(1,1)$, chaves $(1,0)$, $(0,1)$, $(-1,0)$ e valores $(2,0)$, $(0,4)$, $(6,6)$, calcule as pontuações, os pesos de atenção e a saída.

**9.2** Quantos parâmetros tem uma camada de atenção multi-cabeça com $d=512$ e $h=8$? E um bloco Transformer pré-LN com $d=512$ e $d_\mathrm{ff}=2\,048$? Muda algo se $h=16$?

**9.3** Para cada tarefa, indique a família (codificador, decodificador ou codificador-decodificador) mais natural e justifique: (a) classificar o sentimento de avaliações; (b) traduzir do português para o inglês; (c) completar código-fonte; (d) marcar nomes de pessoas em um texto.

**9.4** Se as componentes de $\mathbf{q}$ e de $\mathbf{k}$ são independentes, de média $0$ e **variância $4$**, e $d_k=16$, qual é a variância de $\mathbf{q}^{\top}\mathbf{k}$? Que fator $c$ deve multiplicar o produto para ter variância $1$? Compare com $1/\sqrt{d_k}$.

**9.5** Um decodificador com $N=24$ camadas e $d=2\,048$ guarda o cache de chaves e valores em *float16* ($2$ bytes). Quanta memória o cache ocupa por token, por sequência de $8\,192$ tokens e para um lote de $4$ sequências?

### Nível II: desenvolvimento

**9.6** Mostre que o jacobiano da softmax, $\mathbf{J}=\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^{\top}$, é simétrico, satisfaz $\mathbf{J}\mathbf{1}=\mathbf{0}$ e é semidefinido positivo. O que cada propriedade diz sobre o gradiente em relação às pontuações?

**9.7** Mostre que, com a máscara causal, a saída da posição $i$ é igual à atenção da consulta $\mathbf{q}_i$ **apenas** sobre as chaves e os valores das posições $1,\dots,i$, com a softmax renormalizada sobre esse conjunto.

**9.8** Particione $\mathbf{W}_O$ em $h$ blocos de linhas, $\mathbf{W}_O^{(i)}\in\mathbb{R}^{(d/h)\times d}$. Mostre que $[\operatorname{head}_1\cdots\operatorname{head}_h]\mathbf{W}_O=\sum_{i=1}^{h}\operatorname{head}_i\mathbf{W}_O^{(i)}$ e interprete.

**9.9** Com $d=4$ (logo $\omega_0=1$ e $\omega_1=10000^{-1/2}=0{,}01$), calcule $\operatorname{PE}(0)$, $\operatorname{PE}(1)$ e $\operatorname{PE}(0)^{\top}\operatorname{PE}(1)$, e confira com a Proposição 9.7(b).

**9.10** Mostre que um bloco Transformer pré-LN **sem máscara** e sem codificação posicional é equivariante a permutações das posições. Por que a máscara causal quebra essa propriedade?

**9.11** Calcule o número de parâmetros de um decodificador com $V=32\,000$, $P=2\,048$ posições aprendidas, $N=24$, $d=1\,024$ e $d_\mathrm{ff}=4d$.

### Nível III: avançado

**9.12** Conte as operações de multiplicação-acumulação de um bloco por sequência de comprimento $T$: projeções e rede por posição (termo linear em $T$) e matrizes $\mathbf{Q}\mathbf{K}^{\top}$ e $\mathbf{A}\mathbf{V}$ (termo quadrático). A partir de que $T$ o termo quadrático domina? Calcule para $d=768$ e $d=4\,096$.

**9.13** Implemente um bloco pré-LN e verifique, por experimento, que ele é equivariante a permutações sem máscara e sem posição, que deixa de ser com a máscara causal e que deixa de ser quando se soma uma codificação posicional.

**9.14** Meça, para $d_k\in\{4,16,64,256,1\,024\}$, a norma do gradiente de uma perda arbitrária em relação às **pontuações** e a $\mathbf{Q}$, e a probabilidade máxima média da softmax, com e sem a escala $1/\sqrt{d_k}$. O que os números sustentam sobre a justificativa da escala?

**9.15** Interprete os resultados do laboratório da seção 9.9: o que eles permitem concluir sobre a comparação entre o Transformer e a GRU, e o que **não** permitem?

## 9.12 Soluções comentadas

::: solucao 9.1
As pontuações são $(\mathbf{q}\cdot\mathbf{k}_j)/\sqrt2=(1,1,-1)/\sqrt2=(0{,}707;\,0{,}707;\,-0{,}707)$. As exponenciais são $(2{,}028;\,2{,}028;\,0{,}493)$, com soma $4{,}549$, e os pesos, $(0{,}446;\,0{,}446;\,0{,}108)$. A saída é $0{,}446(2,0)+0{,}446(0,4)+0{,}108(6,6)=(1{,}542;\ 2{,}434)$. Confira que cada coordenada fica dentro do intervalo dos valores ($[0,6]$), como exige a Proposição 9.1.
:::

::: solucao 9.2
Atenção: $4\cdot512^2+4\cdot512=1\,050\,624$. Bloco: $12\cdot512^2+13\cdot512=3\,152\,384$. Nada muda com $h=16$ (Proposição 9.6): $h$ divide $d$ em cabeças menores, mas o total de pesos continua sendo $4d^2$. O programa `c9_ex_numeros.py` confirma.
:::

::: solucao 9.3
(a) **Codificador** (BERT): a classificação usa a frase inteira, sem geração, e a atenção bidirecional ajuda. (b) **Codificador-decodificador** (T5, BART, o Transformer original): lê a entrada inteira e gera a saída em outra língua, com atenção cruzada. Hoje, decodificadores grandes, instruídos por *prompt*, também traduzem; é uma questão de custo e de escala. (c) **Decodificador**: é geração autorregressiva, sem outra sequência de entrada. (d) **Codificador**: classificação por token, em que o contexto à direita ajuda a desambiguar.
:::

::: solucao 9.4
Cada produto $q_ik_i$ tem variância $\mathbb{E}[q_i^2]\mathbb{E}[k_i^2]=4\cdot4=16$, e os $16$ termos independentes somam $\operatorname{Var}(\mathbf{q}^{\top}\mathbf{k})=16\cdot16=256$. Para variância $1$: $c^2\cdot256=1$, logo $c=1/16$, em vez de $1/\sqrt{d_k}=1/4$. Em geral, com variância $\sigma^2$ por componente, $c=1/(\sigma^2\sqrt{d_k})$. A escala $1/\sqrt{d_k}$ só dá variância $1$ quando as componentes têm variância $1$, e é por isso que a normalização de camada **antes** das projeções, com inicialização apropriada, faz parte do desenho.
:::

::: solucao 9.5
Por token: $2\cdot24\cdot2\,048\cdot2$ bytes $=196\,608$ B $=192$ KiB. Por sequência de $8\,192$ tokens: $192\text{ KiB}\times8\,192=1{,}5$ GiB. Para $4$ sequências: $6$ GiB. Só o cache, sem contar os pesos do modelo.
:::

::: solucao 9.6
**Simetria:** $\operatorname{diag}(\mathbf{p})$ e $\mathbf{p}\mathbf{p}^{\top}$ são simétricas. **Núcleo:** $\mathbf{J}\mathbf{1}=\mathbf{p}-\mathbf{p}(\mathbf{p}^{\top}\mathbf{1})=\mathbf{p}-\mathbf{p}=\mathbf{0}$. **Semidefinida positiva:** $\mathbf{x}^{\top}\mathbf{J}\mathbf{x}=\sum_ip_ix_i^2-\bigl(\sum_ip_ix_i\bigr)^2=\operatorname{Var}_{\mathbf{p}}(x)\ge0$, com igualdade só se $\mathbf{x}$ é constante, isto é, $\mathbf{x}\propto\mathbf{1}$ (as $p_i$ são positivas). O posto é, portanto, $n-1$. **Interpretação:** pela regra da cadeia, o gradiente em relação às pontuações é $\mathbf{J}^{\top}\partial L/\partial\mathbf{p}=\mathbf{J}\,\partial L/\partial\mathbf{p}$, e, como $\mathbf{1}^{\top}\mathbf{J}=\mathbf{0}$, suas componentes **somam zero**: somar uma constante a todas as pontuações não altera a perda (invariância a deslocamentos, Proposição 9.1). A semidefinição positiva dá a variância de $x$ sob $\mathbf{p}$: se $\mathbf{p}$ é concentrada, essa variância é pequena, e o jacobiano, quase nulo (Proposição 9.3).
:::

::: solucao 9.7
Na linha $i$, as entradas $S_{ij}=-\infty$ para $j>i$ dão $e^{S_{ij}}=0$. Logo, $A_{ij}=e^{S_{ij}}/\sum_{l\le i}e^{S_{il}}$ para $j\le i$ e $A_{ij}=0$ para $j>i$. A saída é $\sum_{j\le i}A_{ij}\mathbf{v}_j$, que é exatamente a atenção de $\mathbf{q}_i$ sobre $(\mathbf{k}_j,\mathbf{v}_j)_{j\le i}$. É essa propriedade que torna o KV cache correto: a linha $i$ não depende do que vem depois.
:::

::: solucao 9.8
Escreva $[\operatorname{head}_1\cdots\operatorname{head}_h]$ como uma matriz $T\times d$ com $h$ blocos de $d/h$ colunas e $\mathbf{W}_O$ como $h$ blocos de $d/h$ linhas. O produto de matrizes em blocos é a soma dos produtos dos blocos correspondentes: $\sum_i\operatorname{head}_i\mathbf{W}_O^{(i)}$. **Interpretação:** cada cabeça contribui com sua própria parcela, projetada para o espaço do modelo, e a saída da camada é a **soma** das contribuições. É essa decomposição que permite estudar o que cada cabeça escreve no fluxo residual, e remover uma cabeça equivale a zerar a sua parcela.
:::

::: solucao 9.9
$\operatorname{PE}(0)=(\sin0,\cos0,\sin0,\cos0)=(0,1,0,1)$. $\operatorname{PE}(1)=(\sin1,\cos1,\sin0{,}01,\cos0{,}01)=(0{,}8415;\,0{,}5403;\,0{,}0100;\,1{,}0000)$. O produto escalar é $0\cdot0{,}8415+1\cdot0{,}5403+0\cdot0{,}01+1\cdot1{,}0000=1{,}5403$. Pela Proposição 9.7(b), é $\cos(\omega_0\cdot1)+\cos(\omega_1\cdot1)=\cos1+\cos0{,}01=0{,}5403+0{,}99995=1{,}5403$. ✓
:::

::: solucao 9.10
Seja $f_\mathrm{b}$ o bloco. **(i)** $\operatorname{LN}$ age em cada posição separadamente (usa só as $d$ coordenadas da própria linha): $\operatorname{LN}(\mathbf{P}\mathbf{X})=\mathbf{P}\operatorname{LN}(\mathbf{X})$. **(ii)** A FFN também: $\operatorname{FFN}(\mathbf{P}\mathbf{X})=\mathbf{P}\operatorname{FFN}(\mathbf{X})$. **(iii)** A atenção sem máscara é equivariante (Teorema 9.4), e a projeção de saída age linha a linha. **(iv)** A soma de funções equivariantes é equivariante, e a composição também. Logo, $f_\mathrm{b}(\mathbf{P}\mathbf{X})=\mathbf{P}f_\mathrm{b}(\mathbf{X})$. Com a máscara causal, a matriz de pontuações deixa de transformar-se como $\mathbf{P}\mathbf{S}\mathbf{P}^{\top}$: a máscara é um padrão **fixo** nas posições, que o embaralhamento não acompanha, e por isso a máscara **introduz** informação de ordem (a posição $i$ vê as anteriores, e só elas). O programa do Exercício 9.13 mostra isso.
:::

::: solucao 9.11
$Vd=32\,768\,000$; $Pd=2\,097\,152$; cada bloco tem $12d^2+13d=12\,596\,224$, e os $24$ blocos, $302\,309\,376$; a normalização final, $2d=2\,048$. O total é $337\,176\,576$, cerca de $337$ milhões (o programa `c9_ex_numeros.py` confirma). Os blocos respondem por $\approx90\%$ do total, e os *embeddings*, por $\approx10\%$.
:::

::: solucao 9.12
**Linear em $T$:** projeções $\mathbf{Q},\mathbf{K},\mathbf{V}$: $3Td^2$; projeção de saída: $Td^2$; FFN ($d\to4d\to d$): $8Td^2$. Total: $12Td^2$ multiplicações-acumulações, ou $24Td^2$ operações de ponto flutuante (cada multiplicação-acumulação conta duas). **Quadrático:** $\mathbf{Q}\mathbf{K}^{\top}$: $T^2d$; $\mathbf{A}\mathbf{V}$: $T^2d$; total $2T^2d$, ou $4T^2d$ operações de ponto flutuante. Igualando, $4T^2d=24Td^2\Rightarrow T=6d$. Para $d=768$, $T=4\,608$; para $d=4\,096$, $T=24\,576$. Abaixo de $T=6d$, o custo de um bloco é dominado pelas projeções e pela FFN, e a atenção é a parcela menor; é nos contextos longos que o termo quadrático passa a dominar (as contagens ignoram a softmax, as normalizações e os acessos à memória, que também importam).
:::

::: solucao 9.13
<<< codigo/c9_ex_equivariancia.py

>>> codigo/c9_ex_equivariancia.out

Sem máscara e sem posição, o erro é de arredondamento ($2\times10^{-7}$): o bloco é equivariante. Com a máscara causal, passa a $1{,}0$, e, ao somar à entrada um vetor de posição fixo, a $4{,}4$. A máscara e a codificação posicional são, assim, as duas fontes de informação sobre ordem em um Transformer.
:::

::: solucao 9.14
<<< codigo/c9_ex_gradiente_escala.py

>>> codigo/c9_ex_gradiente_escala.out

O que os números dizem: **(i) saturação:** sem a escala, a probabilidade máxima média sobe de $0{,}42$ ($d_k=4$) a $0{,}96$ ($d_k=1\,024$), enquanto com a escala fica em $0{,}24$, qualquer que seja $d_k$. **(ii) Escala do gradiente em relação a $\mathbf{Q}$:** com a escala, a norma fica estável (de $4{,}4$ para $3{,}8$); sem a escala, ela **cresce** de $12{,}6$ para $94$, porque o gradiente passa por $\mathbf{K}$, cujas entradas somam mais termos. **(iii) Gradiente em relação às pontuações:** com a escala, constante em torno de $3{,}8$; sem a escala, é **maior** que isso para $d_k$ pequeno e só cai abaixo ($2{,}95$ em $d_k=1\,024$) quando a saturação domina. Em resumo, nesta perda arbitrária, **não vi o gradiente em relação a $\mathbf{Q}$ sumir** sem a escala: o que vi foi a atenção ficar quase de tipo "tudo ou nada" e a **escala do gradiente depender de $d_k$**, o que dificulta escolher uma taxa de aprendizado. A justificativa de Vaswani e colegas, que apontam gradientes extremamente pequenos na softmax saturada, descreve o jacobiano da softmax (Proposição 9.3), e esse efeito, aqui, só aparece com clareza nas pontuações e com $d_k$ grande. O experimento é um sorteio de dados e pesos aleatórios, e não um treino.
:::

::: solucao 9.15
O resultado e as ressalvas estão na seção 9.9; o essencial é que se trata de **uma** execução, com **um** orçamento fixo de $1\,500$ passos, **uma** semente, hiperparâmetros **não** ajustados para nenhum dos dois modelos e um corpus de apenas $265$ mil caracteres de treino. Isso permite descrever o que ocorreu nesse orçamento e **não** permite concluir que uma arquitetura é melhor que a outra em geral.
:::

## 9.13 Referências e leituras

### Livros e cursos

- JURAFSKY, D.; MARTIN, J. H. *Speech and Language Processing*. 3. ed. (rascunho). Capítulos sobre Transformers e modelos de linguagem. Texto completo em web.stanford.edu/~jurafsky/slp3.
- ZHANG, A.; LIPTON, Z. C.; LI, M.; SMOLA, A. J. *Dive into Deep Learning*. Cambridge: Cambridge University Press, 2023. Capítulos sobre mecanismos de atenção e Transformers. Texto completo em d2l.ai.

### Artigos originais

- AINSLIE, J. et al. GQA: training generalized multi-query transformer models from multi-head checkpoints. In: *Proceedings of the Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2023.
- BA, J. L.; KIROS, J. R.; HINTON, G. E. Layer normalization. *arXiv:1607.06450*, 2016.
- BAHDANAU, D.; CHO, K.; BENGIO, Y. Neural machine translation by jointly learning to align and translate. In: *ICLR*, 2015.
- BROWN, T. et al. Language models are few-shot learners. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 33, 2020.
- DAO, T. et al. FlashAttention: fast and memory-efficient exact attention with IO-awareness. In: *NeurIPS*, v. 35, 2022.
- DEVLIN, J.; CHANG, M.-W.; LEE, K.; TOUTANOVA, K. BERT: pre-training of deep bidirectional transformers for language understanding. In: *Proceedings of NAACL-HLT*, 2019.
- LEWIS, M. et al. BART: denoising sequence-to-sequence pre-training for natural language generation, translation, and comprehension. In: *Proceedings of ACL*, 2020.
- MICHEL, P.; LEVY, O.; NEUBIG, G. Are sixteen heads really better than one? In: *NeurIPS*, v. 32, 2019.
- PRESS, O.; SMITH, N. A.; LEWIS, M. Train short, test long: attention with linear biases enables input length extrapolation. In: *ICLR*, 2022.
- RADFORD, A. et al. Language models are unsupervised multitask learners. OpenAI, 2019.
- RAFFEL, C. et al. Exploring the limits of transfer learning with a unified text-to-text transformer. *Journal of Machine Learning Research*, v. 21, n. 140, p. 1–67, 2020.
- SHAW, P.; USZKOREIT, J.; VASWANI, A. Self-attention with relative position representations. In: *Proceedings of NAACL-HLT*, 2018.
- SHAZEER, N. Fast transformer decoding: one write-head is all you need. *arXiv:1911.02150*, 2019.
- SU, J. et al. RoFormer: enhanced transformer with rotary position embedding. *arXiv:2104.09864*, 2021.
- VASWANI, A. et al. Attention is all you need. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017.
- XIONG, R. et al. On layer normalization in the transformer architecture. In: *Proceedings of the 37th International Conference on Machine Learning (ICML)*, 2020.

### Documentação técnica

- PyTorch: `torch.nn.MultiheadAttention`, `torch.nn.LayerNorm` e a função `scaled_dot_product_attention` (módulo `torch.nn.functional`); pytorch.org/docs.
- Hugging Face `transformers` (versão 5.22 nas execuções deste livro): `BertForMaskedLM`, `GPT2LMHeadModel`, `T5ForConditionalGeneration`; huggingface.co/docs/transformers.
