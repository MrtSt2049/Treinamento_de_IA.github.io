<div class="objetivos">

Objetivos do capítulo

- Distinguir as quatro concepções clássicas de IA e justificar a adoção da abordagem do agente racional.
- Descrever qualquer sistema de IA como um agente: sensores, programa do agente e atuadores.
- Especificar um problema pelo framework PEAS e classificar seu ambiente em seis dimensões.
- Comparar agentes reativos, baseados em modelos, em objetivos e em utilidade, implementando cada um.
- Relacionar essa arquitetura clássica aos agentes com LLMs do Módulo VI.

**Pré-requisitos:** Capítulo 1, seções 1.13 (Teorema de Bayes) e 1.14 (esperança).

</div>

## 2.1 O que se entende por Inteligência Artificial

### Motivação

Antes de construir um sistema inteligente, é preciso dizer o que se espera dele. A resposta não é óbvia, e respostas diferentes levaram a programas de pesquisa diferentes. O termo Inteligência Artificial foi cunhado na proposta de um seminário de verão no Dartmouth College, redigida em 1955 por McCarthy, Minsky, Rochester e Shannon, e desde então a área convive com mais de uma definição de seu próprio objeto.

Russell e Norvig (2021) organizam as definições históricas em duas perguntas. O sistema deve ser avaliado pelo que **pensa** ou pelo que **faz**? E o padrão de comparação é o **ser humano** ou um ideal de **racionalidade**? As combinações produzem quatro concepções.

| | Padrão humano | Padrão racional |
|---|---|---|
| **Pensamento** | *Pensar humanamente:* modelagem cognitiva. Reproduzir os processos mentais humanos | *Pensar racionalmente:* leis do pensamento. Derivar conclusões corretas por lógica |
| **Comportamento** | *Agir humanamente:* Teste de Turing. Comportar-se de modo indistinguível de uma pessoa | *Agir racionalmente:* agente racional. Escolher as ações que melhor atingem os objetivos |

As duas concepções da linha superior tratam de processos internos. A modelagem cognitiva é hoje domínio da ciência cognitiva, que testa teorias da mente contra experimentos com pessoas. A tradição das leis do pensamento produziu a lógica computacional, mas enfrenta dois obstáculos: boa parte do conhecimento é incerta, e derivar conclusões corretas ainda não diz o que **fazer**.

As duas concepções da linha inferior tratam de comportamento, e é entre elas que este capítulo precisa escolher.

## 2.2 Agir humanamente: o Teste de Turing

Em 1950, Alan Turing propôs substituir a pergunta "máquinas podem pensar?", que considerava mal definida, por um experimento. Um interrogador conversa por texto com dois interlocutores ocultos, uma pessoa e uma máquina. Se não conseguir distinguir de modo confiável qual é qual, a máquina passa no teste (Turing, 1950).

O teste tem um mérito duradouro: é **operacional**. Dispensa qualquer acordo prévio sobre o que é pensar e avalia apenas comportamento observável. Para passar, um sistema precisaria reunir processamento de linguagem natural, representação de conhecimento, raciocínio e aprendizado, lista que antecipou boa parte da agenda da área.

Apesar disso, a IA como disciplina nunca tomou o teste como objetivo. Há três razões.

**Imitar não é o que se quer.** A engenharia aeronáutica não progrediu tentando construir máquinas que enganassem pombos. Um sistema de diagnóstico não deve cometer os erros de um médico cansado, nem um sistema de cálculo deve hesitar para parecer humano.

**O teste premia o engano.** Para passar, o sistema precisa fingir limitações e esconder o que é. Essa propriedade é o oposto do que se exige de sistemas confiáveis.

**Comportamento indistinguível não resolve a questão da compreensão.** No argumento do quarto chinês, Searle (1980) sustenta que manipular símbolos segundo regras pode produzir respostas perfeitas sem que haja compreensão alguma. O argumento tem réplicas conhecidas e continua em disputa; o ponto relevante aqui é que o teste, por construção, não tem como decidir a disputa.

::: atencao O Teste de Turing na era dos LLMs
Em experimento controlado e pré-registrado, com conversas de cinco minutos e três participantes, Jones e Bergen (2025) relatam que um modelo de linguagem instruído a adotar uma persona humana foi apontado como o humano em 73% das vezes. O mesmo modelo, sem essa instrução, ficou bem abaixo de 50%.

O resultado mede **indistinguibilidade conversacional** nas condições do experimento. Ele não mede correção, raciocínio ou confiabilidade, e depende fortemente da instrução dada ao modelo. Ler esse tipo de resultado como prova de inteligência geral é confundir capacidade de geração com competência, erro contra o qual este livro adverte desde a Introdução.
:::

## 2.3 Agir racionalmente: o agente racional

### A ideia

A quarta concepção define a IA como o estudo de **agentes** que fazem a coisa certa. Um agente é algo que percebe e age. Um agente racional é aquele que age de modo a obter o melhor resultado ou, sob incerteza, o melhor resultado esperado.

Essa abordagem tem duas vantagens sobre as demais. É mais geral que a das leis do pensamento, porque a inferência correta passa a ser um dos meios de agir bem, e não o único: um reflexo rápido pode ser a ação certa sem dedução alguma. E é mais tratável cientificamente que as abordagens de padrão humano, porque a racionalidade pode ser definida com precisão matemática, enquanto o comportamento humano é o produto particular de uma história evolutiva.

### Definição

A definição precisa de quatro ingredientes, e todos importam.

::: definicao 2.1 · Agente racional
Para cada sequência de percepções possível, um **agente racional** seleciona a ação que se espera que maximize sua medida de desempenho, dadas as evidências fornecidas pela sequência de percepções e o conhecimento prévio que o agente possui (Russell e Norvig, 2021).
:::

O que é racional em um dado instante depende, portanto, de:

1. **a medida de desempenho**, que define o critério de sucesso;
2. **o conhecimento prévio** do agente sobre o ambiente;
3. **as ações** que o agente pode executar;
4. **a sequência de percepções** até aquele instante.

Mudando qualquer um dos quatro, muda a ação racional. Não existe comportamento racional em abstrato, apenas em relação a um problema especificado.

### O que a racionalidade não é

::: erro Confundir racionalidade com onisciência
Um agente onisciente conhece o resultado real de suas ações. Um agente racional maximiza o resultado **esperado**, com a informação que tem. Quem atravessa uma rua vazia depois de olhar para os dois lados agiu racionalmente, mesmo que seja atingido por um objeto que caiu de um avião. A racionalidade julga a decisão pela informação disponível; o resultado depende também da sorte.
:::

Três consequências da definição merecem destaque.

**Coletar informação é parte de agir racionalmente.** Se olhar antes de atravessar aumenta o desempenho esperado, um agente racional olha. Ações cuja finalidade é modificar percepções futuras fazem parte do repertório racional. No Módulo VI, a decisão de um agente de consultar uma base de documentos antes de responder é exatamente desse tipo.

**Aprender é parte de agir racionalmente.** O conhecimento prévio pode ser incompleto ou errado. Um agente racional usa as percepções para corrigi-lo.

**Autonomia é uma questão de grau.** Um agente que depende apenas do conhecimento embutido por seu projetista, sem usar as próprias percepções, tem pouca autonomia e falha quando o ambiente difere do previsto. Autonomia, nesse sentido técnico, é a capacidade de compensar conhecimento prévio parcial. Ela não significa ausência de limites: todo agente opera com as ações que lhe foram dadas.

### Racionalidade limitada

A definição pede a ação de máximo desempenho esperado, mas calcular essa ação pode ser impossível no tempo disponível. O número de partidas possíveis de xadrez excede em muito o número de átomos do universo observável; nenhum agente joga xadrez de forma perfeitamente racional.

Simon (1955) chamou de **racionalidade limitada** a condição de agentes reais, com informação, tempo e capacidade de cálculo finitos, que por isso buscam soluções satisfatórias em vez de ótimas. A racionalidade perfeita continua útil como referência teórica; na engenharia, o problema real é agir o melhor possível dentro de um orçamento de computação. Esse orçamento volta a aparecer, de forma muito concreta, no Capítulo 15, como latência, número de tokens e custo.

### O problema da especificação

A definição supõe que a medida de desempenho está dada. Na prática, alguém precisa escrevê-la, e um agente competente perseguirá o que foi escrito, e não o que se pretendia. Russell (2019) argumenta que supor objetivos perfeitamente especificados é a fragilidade central do modelo padrão da IA e propõe que agentes sejam projetados para tratar os objetivos humanos como incertos. A proposta é uma entre várias em debate; o problema que ela aponta, porém, é consensual, e a seção 2.5 mostra como ele surge mesmo em um exemplo trivial.

## 2.4 Arquitetura de agentes: sensores, programa e atuadores

::: definicao 2.2 · Agente, percepção e função do agente
Um **agente** é qualquer entidade que percebe seu **ambiente** por meio de **sensores** e atua sobre ele por meio de **atuadores**.

Uma **percepção** é o conteúdo que os sensores entregam em um instante. A **sequência de percepções** é o histórico completo do que o agente percebeu.

A **função do agente** é o mapeamento que associa uma ação a cada sequência de percepções possível:

$$
f : \mathcal{P}^{*}\to\mathcal{A},
$$

em que $\mathcal{P}$ é o conjunto das percepções, $\mathcal{P}^*$ o conjunto das sequências finitas de percepções e $\mathcal{A}$ o conjunto das ações.
:::

<figure>
<svg class="fig" viewBox="0 0 720 250" role="img" aria-label="Ciclo do agente: o ambiente envia percepções aos sensores, o programa do agente escolhe uma ação e os atuadores a executam sobre o ambiente">
<defs><marker id="seta2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pt"/></marker></defs>
<rect class="fraco" x="20" y="20" width="400" height="210" rx="10"/>
<text x="36" y="44" font-size="13" font-weight="800">AGENTE</text>
<rect class="cxa" x="530" y="20" width="170" height="210" rx="10"/>
<text x="615" y="130" font-size="15" font-weight="800" text-anchor="middle">AMBIENTE</text>
<g font-size="14" font-weight="700" text-anchor="middle">
<rect class="cx" x="250" y="40" width="150" height="42" rx="6"/><text x="325" y="66">Sensores</text>
<rect class="cx" x="60" y="100" width="220" height="56" rx="6"/><text x="170" y="125">Programa do agente</text><text x="170" y="144" font-size="12" font-weight="400" class="t2">percepções → ação</text>
<rect class="cx" x="250" y="174" width="150" height="42" rx="6"/><text x="325" y="200">Atuadores</text>
</g>
<g class="ln" marker-end="url(#seta2)"><path d="M530 61H402"/><path d="M250 61H170V98"/><path d="M170 156V195H248"/><path d="M400 195H528"/></g>
<text x="466" y="52" font-size="12" text-anchor="middle" class="t2">percepções</text>
<text x="466" y="186" font-size="12" text-anchor="middle" class="t2">ações</text>
</svg>
<figcaption><b>Figura 2.1.</b> Estrutura básica de um agente. O ciclo perceber, decidir e agir repete-se a cada passo de tempo.</figcaption>
</figure>

A função do agente é uma descrição matemática abstrata: uma tabela, possivelmente infinita, que diz o que fazer em cada situação. O **programa do agente** é a implementação concreta que roda em uma máquina física e realiza essa função. A relação é resumida por

$$
\text{agente} = \text{arquitetura} + \text{programa},
$$

em que a arquitetura é o dispositivo com sensores e atuadores (um robô, um computador com câmera, um servidor com acesso a uma API).

### Por que não basta uma tabela

A implementação mais direta da função do agente seria guardar a tabela e consultá-la. O tamanho da tabela mostra por que isso é inviável. Com $\lvert\mathcal{P}\rvert$ percepções possíveis por instante e horizonte de $T$ passos, o número de entradas é

$$
\sum_{t=1}^{T}\lvert\mathcal{P}\rvert^{t}.
$$

::: exemplo 2.1 · Tamanho da tabela no mundo do aspirador
No ambiente mais simples da literatura, um aspirador em duas salas percebe sua posição (A ou B) e o estado da sala (limpa ou suja): $\lvert\mathcal{P}\rvert = 4$. Para apenas 20 passos, só as sequências de comprimento 20 somam $4^{20} = 1\,099\,511\,627\,776$ entradas, mais de um trilhão. Uma câmera com resolução modesta tem um número de percepções possíveis com milhões de algarismos. O crescimento é exponencial no horizonte.
:::

O desafio central da IA pode ser enunciado assim: **produzir comportamento racional com um programa pequeno, em vez de uma tabela imensa**. Os quatro tipos de agente da seção 2.7 são quatro respostas a esse desafio, e um modelo treinado por aprendizado de máquina é outra: uma função compacta, com parâmetros ajustados a partir de dados, que substitui a tabela.

## 2.5 O framework PEAS

### Motivação

Projetar um agente começa por descrever o problema que ele resolverá, e não por escolher um algoritmo. O **ambiente de tarefa** é especificado por quatro elementos, reunidos na sigla PEAS.

::: definicao 2.3 · PEAS
A especificação **PEAS** de um ambiente de tarefa compreende:

- **Medida de desempenho** (*Performance measure*): o critério objetivo que avalia o sucesso do comportamento do agente.
- **Ambiente** (*Environment*): tudo aquilo com que o agente interage.
- **Atuadores** (*Actuators*): os meios pelos quais o agente age.
- **Sensores** (*Sensors*): os meios pelos quais o agente percebe.
:::

### Exemplos

| Agente | Medida de desempenho | Ambiente | Atuadores | Sensores |
|---|---|---|---|---|
| Táxi autônomo | Segurança, tempo de viagem, legalidade, conforto, custo | Vias, tráfego, pedestres, clima, passageiros | Direção, acelerador, freio, sinalização | Câmeras, radar, GPS, velocímetro |
| Filtro de spam | Spam bloqueado, mensagens legítimas preservadas | Fluxo de mensagens, remetentes, usuário | Marcar, mover para pasta, entregar | Texto, cabeçalhos, histórico de marcações |
| Apoio a diagnóstico | Acerto diagnóstico, custo de exames, segurança do paciente | Paciente, equipe, prontuário | Sugerir hipóteses, exames e condutas | Sintomas relatados, resultados de exames, imagens |
| Robô aspirador | Área limpa, energia, tempo, ruído | Cômodos, móveis, sujeira, pessoas | Rodas, escovas, sucção | Sensor de sujeira, de colisão, de posição |
| Assistente de atendimento com LLM | Problemas resolvidos, respostas fiéis às fontes, satisfação, custo | Clientes, base de conhecimento, sistemas internos | Mensagens ao cliente, chamadas de ferramentas, encaminhamento a humano | Mensagens do cliente, documentos recuperados, respostas de APIs |

A última linha mostra que o framework, concebido décadas antes dos LLMs, descreve sem esforço um sistema do Módulo VI. Os "sensores" de um agente de software são suas entradas de dados; os "atuadores" são as operações que ele pode disparar.

### A medida de desempenho é uma decisão de projeto

A medida de desempenho deve avaliar **o estado do ambiente**, e não o comportamento que o projetista imagina ser correto.

::: exemplo 2.2 · Uma medida de desempenho mal escolhida
Suponha que o robô aspirador seja avaliado pela **quantidade de sujeira aspirada** em um turno. Um agente que maximize essa medida pode aspirar, despejar a sujeira no chão e aspirar de novo, indefinidamente. O comportamento é perfeitamente racional para a medida dada, e inútil.

Uma medida melhor recompensa o que realmente se deseja: um ponto por sala limpa a cada intervalo de tempo, com descontos por energia consumida e ruído. Ainda assim, restam escolhas: é melhor um piso mediocremente limpo o tempo todo ou muito limpo com intervalos de sujeira? Essas perguntas não têm resposta técnica; são decisões de quem define o problema.
:::

O fenômeno tem nome em economia e em avaliação de políticas (lei de Goodhart: quando uma medida vira meta, deixa de ser boa medida) e reaparece em toda a IA. Um modelo treinado para maximizar cliques aprende a produzir títulos sensacionalistas. Um agente de atendimento avaliado apenas pelo número de conversas encerradas aprende a encerrar conversas. Como regra geral de projeto, **especifique a medida pelo que se quer no ambiente, e não por como se imagina que o agente deva agir**, e verifique que comportamentos indesejados também a maximizariam.

## 2.6 Propriedades dos ambientes de tarefa

### Motivação

Ambientes diferentes exigem agentes diferentes. Seis dimensões, propostas por Russell e Norvig (2021), bastam para caracterizar a dificuldade de um ambiente e orientar o projeto. Cada dimensão é apresentada com sua consequência prática.

### Totalmente observável ou parcialmente observável

O ambiente é **totalmente observável** quando os sensores dão acesso, a cada instante, a todo o estado relevante para a escolha da ação. É **parcialmente observável** quando há ruído nos sensores ou partes do estado ficam ocultas.

*Consequência:* em ambientes totalmente observáveis, o agente não precisa de memória. Nos parcialmente observáveis, precisa manter um **estado interno** que resuma o que já percebeu. No xadrez, o tabuleiro inteiro é visível. No pôquer, as cartas dos adversários não são. Um agente conversacional observa apenas o que o usuário escreve, e não suas intenções.

### Determinístico ou estocástico

O ambiente é **determinístico** quando o próximo estado é completamente determinado pelo estado atual e pela ação do agente. Caso contrário, é **estocástico** (ou não determinístico, quando não se atribuem probabilidades aos resultados).

*Consequência:* em ambientes estocásticos, planos fixos falham; o agente precisa considerar vários resultados possíveis para cada ação e ponderá-los, o que conduz à utilidade esperada da seção 2.7.

::: erro Confundir "parcialmente observável" com "estocástico"
São propriedades distintas. Um ambiente determinístico pode **parecer** estocástico a um agente que não o observa por inteiro: o trânsito segue leis físicas, mas, para um motorista que não vê o que há depois da curva, o que acontecerá é incerto. Na prática, a incerteza do agente combina as duas fontes, e o tratamento matemático é o mesmo: probabilidades sobre estados.
:::

### Episódico ou sequencial

Em um ambiente **episódico**, a experiência divide-se em episódios independentes: a ação tomada em um episódio não afeta os seguintes. Em um ambiente **sequencial**, a decisão atual pode afetar todas as decisões futuras.

*Consequência:* em ambientes episódicos, o agente não precisa pensar adiante. Classificar peças defeituosas em uma esteira é episódico. Dirigir, jogar xadrez e conduzir um diálogo são sequenciais. A distinção separa os problemas de classificação e regressão dos Capítulos 3 a 7, em que cada previsão é independente, dos problemas de decisão sequencial, tratados por aprendizado por reforço e por agentes.

### Estático ou dinâmico

O ambiente é **estático** quando não muda enquanto o agente delibera, e **dinâmico** quando muda. Chama-se **semidinâmico** o caso em que o ambiente não muda, mas o desempenho do agente depende do tempo gasto, como no xadrez com relógio.

*Consequência:* em ambientes dinâmicos, não decidir é uma decisão. Tempo de deliberação tem custo, e uma resposta boa agora pode valer mais que uma resposta ótima depois. Para sistemas com LLMs, a latência é uma restrição desse tipo.

### Discreto ou contínuo

A distinção aplica-se ao estado do ambiente, ao tempo, às percepções e às ações. O xadrez tem número finito de estados e de ações: é **discreto**. A direção de um veículo envolve posições, velocidades e ângulos que variam continuamente: é **contínuo**.

*Consequência:* problemas discretos admitem enumeração e busca em grafos; os contínuos pedem as ferramentas de cálculo e otimização do Capítulo 1.

### Agente único ou multiagente

Um ambiente é **multiagente** quando há outras entidades cujo comportamento é mais bem descrito como a maximização de uma medida de desempenho que depende das ações do nosso agente. O ambiente multiagente é **competitivo** quando os objetivos se opõem (xadrez), **cooperativo** quando coincidem (robôs que carregam juntos uma carga) e, frequentemente, uma mistura dos dois (trânsito).

*Consequência:* em ambientes multiagentes, surgem a comunicação, a negociação e, nos competitivos, o valor do comportamento imprevisível. Os sistemas com supervisor e agentes especialistas do Capítulo 14 são ambientes cooperativos projetados.

### Síntese

| Ambiente de tarefa | Observável | Determinístico | Episódico | Estático | Discreto | Agentes |
|---|---|---|---|---|---|---|
| Palavras cruzadas | Totalmente | Sim | Sequencial | Estático | Discreto | Único |
| Xadrez com relógio | Totalmente | Sim | Sequencial | Semidinâmico | Discreto | Multi |
| Pôquer | Parcialmente | Estocástico | Sequencial | Estático | Discreto | Multi |
| Inspeção de peças por imagem | Totalmente | Sim | Episódico | Semidinâmico | Contínuo | Único |
| Táxi autônomo | Parcialmente | Estocástico | Sequencial | Dinâmico | Contínuo | Multi |
| Assistente de atendimento com LLM | Parcialmente | Estocástico | Sequencial | Dinâmico | Discreto | Multi |

As classificações das cinco primeiras linhas seguem Russell e Norvig (2021); a última é uma aplicação do mesmo método. O caso mais difícil reúne todas as propriedades da direita: parcialmente observável, estocástico, sequencial, dinâmico, contínuo e multiagente. É o caso do táxi e, com exceção da continuidade, o de quase todo agente com LLM em produção.

::: atencao A classificação depende de como o problema é delimitado
As mesmas dimensões podem receber respostas diferentes conforme a definição do ambiente de tarefa. Um diagnóstico isolado pode ser tratado como episódico; o acompanhamento de um paciente é sequencial. Classificar é parte da modelagem, e a boa prática é registrar as hipóteses adotadas.
:::

Uma sétima distinção, de natureza diferente, é entre ambiente **conhecido** e **desconhecido**: refere-se ao conhecimento do agente sobre as regras do ambiente, e não ao ambiente em si. Em um ambiente desconhecido, o agente precisa aprender como o mundo funciona.

## 2.7 Tipos de agentes

Os quatro tipos a seguir diferem naquilo que o programa do agente representa internamente. Cada um acrescenta um componente ao anterior e, com isso, resolve uma limitação.

### Agente reativo simples

O **agente reativo simples** (*simple reflex agent*) escolhe a ação com base apenas na percepção atual, ignorando o histórico. Seu programa é um conjunto de **regras condição-ação**: se a sala está suja, aspire; se o carro da frente freia, freie.

- **Vantagem:** é simples, rápido e fácil de auditar.
- **Condição de correção:** só toma a decisão certa se ela puder ser determinada pela percepção atual, isto é, se o ambiente for totalmente observável.
- **Falha típica:** em ambientes parcialmente observáveis, pode entrar em laços infinitos. Um aspirador sem sensor de posição, em sala limpa, não tem como saber para que lado ir; qualquer regra fixa falha em alguma configuração. Sortear a ação pode romper o laço, e esse é um caso em que o comportamento aleatório é racional.

### Agente reativo baseado em modelo

Para lidar com a observabilidade parcial, o **agente baseado em modelo** (*model-based reflex agent*) mantém um **estado interno** que resume o histórico de percepções. Atualizar esse estado exige dois tipos de conhecimento:

- um **modelo de transição**: como o mundo evolui, por conta própria e em resposta às ações do agente;
- um **modelo de sensor**: como o estado do mundo se reflete nas percepções.

Em ambientes determinísticos, o estado interno é um palpite único sobre o estado do mundo. Em ambientes estocásticos, é uma distribuição de probabilidade sobre os estados possíveis, chamada **estado de crença** $b$. Sua atualização, após executar a ação $a$ e receber a percepção $e$, é uma aplicação direta do Teorema de Bayes (Teorema 1.8):

$$
b'(s') = \alpha\;\underbrace{P(e\mid s')}_{\text{modelo de sensor}}\;\sum_{s}\underbrace{P(s'\mid s,a)}_{\text{modelo de transição}}\,b(s),
$$

em que $b(s)$ é a crença anterior no estado $s$, a soma calcula a previsão do novo estado antes da percepção (probabilidade total), o fator $P(e\mid s')$ pondera essa previsão pela compatibilidade com o que foi percebido (verossimilhança) e $\alpha$ é a constante que faz as probabilidades somarem 1 (evidência). A crença anterior faz o papel de priori; a nova crença é a posterior.

::: exemplo 2.3 · Atualização de crença com sensor ruidoso
Um aspirador tem sensor de sujeira que acerta em 90% das leituras. Antes de medir, a crença de que a sala está suja é $0{,}5$. O sensor indica "suja". Sem ação intermediária, a soma reduz-se à crença anterior, e

$$
b'(\text{suja}) = \frac{0{,}9\times0{,}5}{0{,}9\times0{,}5+0{,}1\times0{,}5} = 0{,}9 .
$$

Uma segunda leitura independente, também "suja", leva a $0{,}9\times0{,}9/(0{,}9\times0{,}9+0{,}1\times0{,}1) = 0{,}81/0{,}82\approx0{,}988$. Evidências concordantes acumulam confiança; nenhuma quantidade finita delas produz certeza.
:::

### Agente baseado em objetivos

Saber o estado do mundo não basta para decidir. Em um cruzamento, a ação correta depende de para onde se quer ir. O **agente baseado em objetivos** (*goal-based agent*) acrescenta uma descrição dos estados desejáveis e usa o modelo de transição para **prever** as consequências de sequências de ações, escolhendo uma que leve ao objetivo. As técnicas correspondentes são a **busca** e o **planejamento**.

A diferença para os agentes reativos é de flexibilidade. Em um agente reativo, o conhecimento está compilado nas regras; mudar o destino exige reescrevê-las. Em um agente baseado em objetivos, basta trocar o objetivo.

<<< codigo/c2_objetivo.py

>>> codigo/c2_objetivo.out

O programa é **código didático**. A busca em largura examina os estados em ordem crescente de distância ao estado inicial e, por isso, o primeiro caminho que encontra tem o menor número possível de ações (Exercício 2.9). O agente não reage ao que vê: constrói um plano completo antes de dar o primeiro passo. Isso só é adequado porque este ambiente é totalmente observável, determinístico, estático e conhecido. Em qualquer outro caso, o plano precisa ser revisto durante a execução.

### Agente baseado em utilidade

Objetivos distinguem apenas estados satisfatórios de insatisfatórios. Muitas rotas levam ao destino; algumas são mais rápidas, mais seguras ou mais baratas. E quando os resultados são incertos, é preciso pesar a probabilidade de sucesso contra o valor do sucesso.

::: definicao 2.4 · Função de utilidade e utilidade esperada
Uma **função de utilidade** $U:\mathcal{S}\to\mathbb{R}$ associa a cada estado um número que expressa o grau de preferência do agente por ele. A **utilidade esperada** de uma ação $a$, dadas as evidências $e$, é

$$
\operatorname{UE}(a\mid e) = \sum_{s'}P(s'\mid a,e)\;U(s').
$$

O **princípio da máxima utilidade esperada** estabelece que um agente racional escolhe

$$
a^\star = \arg\max_{a}\;\operatorname{UE}(a\mid e).
$$
:::

A utilidade esperada é uma esperança no sentido da Definição 1.22: a média das utilidades dos resultados, ponderada por suas probabilidades. O princípio não é arbitrário. Von Neumann e Morgenstern (1944) demonstraram que qualquer agente cujas preferências entre resultados incertos satisfaçam certos axiomas de coerência (como a transitividade) comporta-se como se maximizasse a esperança de alguma função de utilidade.

A função de utilidade é a versão interna da medida de desempenho. Se as duas concordam, um agente que maximiza a utilidade esperada é racional no sentido da Definição 2.1.

<<< codigo/c2_utilidade.py

>>> codigo/c2_utilidade.out

O exemplo mostra que **as mesmas probabilidades levam a decisões diferentes sob utilidades diferentes**. Com utilidade linear no tempo, a via expressa tem tempo esperado menor (30 contra 32,4 minutos) e é escolhida. Quando cada minuto além de um prazo de 45 minutos custa cinco vezes mais, os 20% de chance de congestionamento pesam muito, e a avenida passa a ser a escolha racional. Um agente baseado em objetivos, que só distingue "chegar" de "não chegar", não consegue representar essa diferença.

### Comparação

| Tipo de agente | O que representa | Como decide | Limitação principal |
|---|---|---|---|
| Reativo simples | Percepção atual | Regras condição-ação | Exige ambiente totalmente observável |
| Baseado em modelo | Estado interno, modelos de transição e de sensor | Regras sobre o estado estimado | Não considera consequências futuras |
| Baseado em objetivos | Estado, modelo e objetivo | Busca ou planejamento até o objetivo | Não distingue graus de qualidade nem pondera incerteza |
| Baseado em utilidade | Estado, modelo e função de utilidade | Maximiza a utilidade esperada | Custo computacional; exige especificar utilidade e probabilidades |

Os tipos não são excludentes. Sistemas reais combinam camadas: reflexos para o que exige resposta imediata e deliberação para o restante.

### Agentes que aprendem

Qualquer um dos quatro tipos pode ser construído à mão ou **aprendido**. Na arquitetura geral de um agente que aprende, um **elemento de desempenho** escolhe as ações (é o agente das seções anteriores); um **crítico** avalia os resultados segundo um padrão de desempenho fixo; um **elemento de aprendizado** usa essa avaliação para modificar o elemento de desempenho; e um **gerador de problemas** sugere ações exploratórias, que podem ser piores no curto prazo e revelar algo melhor no longo. Os Módulos II a IV deste livro tratam, em essência, do elemento de aprendizado.

## 2.8 Implementação: o mundo do aspirador

O programa a seguir implementa o ambiente da seção 2.4 e dois agentes, e mede o desempenho de ambos sob duas medidas diferentes.

**Especificação PEAS.** *Medida de desempenho:* um ponto por sala limpa a cada passo, durante 20 passos, menos um custo por movimento (0 ou 1, conforme o experimento). *Ambiente:* duas salas, A e B; a sujeira não reaparece. *Atuadores:* mover para a esquerda, mover para a direita, aspirar, não fazer nada. *Sensores:* posição e estado de sujeira da sala atual.

<<< codigo/c2_aspirador.py

>>> codigo/c2_aspirador.out

A leitura dos resultados ilustra a Definição 2.1.

**Sem custo de movimento, os dois agentes empatam.** O agente reativo limpa a sala em que está, vai para a outra, limpa e passa a oscilar entre as duas, sem prejuízo algum. Sob essa medida de desempenho e essas hipóteses sobre o ambiente, o agente reativo simples é racional, como argumentam Russell e Norvig (2021): nenhum outro agente obtém desempenho esperado maior.

**Com custo de movimento, o mesmo agente deixa de ser racional.** A oscilação inútil consome quase metade dos pontos. O agente baseado em modelo, que lembra quais salas já verificou e sabe que a sujeira não reaparece, para de se mover quando não há mais nada a fazer.

O programa do agente reativo não mudou entre os dois experimentos. O que mudou foi a medida de desempenho, e com ela o veredito sobre sua racionalidade. Note também a origem da vantagem do segundo agente: ela vem de conhecimento prévio correto sobre o ambiente ("sujeira não reaparece"). Se essa hipótese for falsa, o agente para cedo demais (Exercício 2.6).

## 2.9 Dos agentes clássicos aos agentes com LLMs

O vocabulário deste capítulo foi criado para robôs e programas de busca. Ele se aplica, termo a termo, aos sistemas do Módulo VI.

| Conceito clássico | Em um agente baseado em LLM | Capítulo |
|---|---|---|
| Sensores | Mensagens do usuário, documentos recuperados, resultados de ferramentas | 12, 13 |
| Programa do agente | LLM mais o laço de orquestração que o invoca | 13, 14 |
| Atuadores | Chamadas de ferramentas (*tool calling*), respostas, escritas em sistemas externos | 13 |
| Estado interno | Histórico da conversa, memória, estado compartilhado do grafo | 14 |
| Modelo do mundo | Conhecimento nos parâmetros do LLM, complementado por recuperação | 11, 12 |
| Objetivo | Instruções e tarefa descritas no contexto | 11 |
| Medida de desempenho | Métricas de avaliação: fidelidade, relevância, custo, latência | 15 |
| Coleta de informação | Decisão de buscar antes de responder | 12, 13 |
| Autonomia limitada | Aprovação humana, *guardrails*, limites de passos | 14, 15 |

Três ressalvas evitam leituras apressadas dessa correspondência.

**Um agente com LLM não é, por construção, racional.** A Definição 2.1 é um padrão de avaliação. Um LLM produz a continuação de texto que seu treinamento tornou provável; se essa continuação corresponde à ação de maior desempenho esperado é uma questão empírica, a ser medida caso a caso (Capítulo 15).

**O "modelo do mundo" de um LLM não é um modelo de transição explícito.** Em que medida LLMs formam representações internas do mundo é tema de pesquisa ativa e de discordância entre pesquisadores. Para a engenharia, a postura prudente é não supor tal modelo e verificar as saídas contra fontes e ferramentas.

**Autonomia é concedida, e não inerente.** O conjunto de atuadores de um agente de software é exatamente a lista de ferramentas que o projetista registrou. Limitar essa lista, exigir confirmação humana para ações críticas e registrar cada passo são decisões de arquitetura, tratadas nos Capítulos 13 a 15.

## 2.10 Limitações e debates

A abordagem do agente racional é o quadro dominante da área, e tem limites reconhecidos.

- **A medida de desempenho precisa vir de fora.** A teoria diz como perseguir um objetivo, e não quais objetivos são bons. A especificação incorreta é uma fonte real de falhas (seção 2.5).
- **A racionalidade perfeita é inatingível** em problemas de tamanho realista (seção 2.3). Toda implementação é uma aproximação, e a qualidade da aproximação é uma questão empírica.
- **Probabilidades e utilidades precisas raramente estão disponíveis.** Na prática, são estimadas a partir de dados, com erro.
- **Não há definição consensual de inteligência.** Legg e Hutter (2007) reuniram dezenas de definições propostas e ofereceram uma formalização em termos de desempenho médio em muitos ambientes; outras tradições enfatizam a corporeidade e a interação com o mundo físico (Brooks, 1991). Este livro adota a definição operacional do agente racional por sua utilidade para a engenharia, sem a pretensão de encerrar o debate.

## 2.11 Resumo do capítulo

::: resumo Ideias centrais
- A IA é entendida aqui como o estudo de **agentes racionais**: sistemas que escolhem ações para maximizar o desempenho esperado, dado o que percebem e o que sabem.
- **Racionalidade não é onisciência nem perfeição.** Depende da medida de desempenho, do conhecimento prévio, das ações disponíveis e das percepções.
- Um agente é **arquitetura mais programa**. A função do agente é a especificação abstrata; o programa é a implementação compacta.
- **PEAS** especifica o problema: medida de desempenho, ambiente, atuadores e sensores. A medida de desempenho é uma decisão de projeto, e medidas mal escolhidas são maximizadas por comportamentos indesejados.
- Seis dimensões caracterizam o ambiente: observabilidade, determinismo, episódico ou sequencial, estático ou dinâmico, discreto ou contínuo, um ou vários agentes.
- Quatro tipos de agente acrescentam, sucessivamente, **estado interno, objetivos e utilidade**. O estado de crença é atualizado pelo Teorema de Bayes; a decisão sob incerteza, pela máxima utilidade esperada.
- O mesmo vocabulário descreve os **agentes com LLMs**, com a ressalva de que racionalidade é um padrão a ser verificado, e autonomia, um parâmetro de projeto.
:::
