## 9.9 Laboratório: Transformer decodificador contra GRU

A teoria da seção 9.1 promete que a autoatenção treina com mais paralelismo e conecta posições distantes com um caminho curto. O laboratório confronta essa promessa com uma medida, **em escala minúscula**, e o resultado, como se verá, **não** é o que a reputação do Transformer sugere.

**Montagem.** Os dois modelos são modelos de linguagem **de caracteres**, treinados **do zero** sobre a prosa deste livro (Capítulos 1 a 8, excluídas fórmulas, códigos e saídas): $937$ parágrafos de treino ($265\,226$ caracteres), $104$ de validação ($29\,914$ caracteres) sorteados com semente fixa, e um alfabeto de $V=107$ símbolos. A métrica é **bits por caractere** (bpc) na validação, isto é, a entropia cruzada em base $2$; quanto menor, melhor.

- **Transformer (MiniGPT):** $4$ blocos pré-LN com $d=128$, $4$ cabeças, máscara causal, codificação posicional aprendida, pesos de entrada e saída amarrados, inicialização $\mathcal{N}(0,0{,}02^2)$ no estilo GPT-2, *dropout* $0{,}1$. São $823\,424$ parâmetros.
- **GRU:** incorporação de $64$ dimensões, GRU de $2$ camadas com estado de $256$ e *dropout* $0{,}1$, e uma camada linear de saída. São $676\,395$ parâmetros.
- **Treino:** AdamW, $1\,500$ passos de lotes de $32$ janelas de $128$ caracteres, aquecimento de $50$ passos e decaimento em cosseno, recorte de gradiente em $1$. A taxa de aprendizado de pico é $10^{-3}$ para o Transformer e $3\times10^{-3}$ para a GRU. **Essas taxas não foram ajustadas por busca**: foram escolhidas uma vez, antes da execução.
- **Referências sem rede neural:** um modelo de **unigramas** (frequência de cada caractere) e um de **bigramas** (frequência do caractere dado o anterior), ambos com suavização de Laplace, estimados no mesmo treino.

O código está em `c9_lab_gpt.py`, e as três saídas (`c9_lab_base.out`, `c9_lab_gpt.out`, `c9_lab_gru.out`) são reproduzidas aqui.

| Modelo | Parâmetros | bpc na validação (passo $1\,500$) | bpc no treino (último lote) |
|---|---|---|---|
| Unigramas | $107$ | $4{,}497$ | |
| Bigramas | $107^2$ | $3{,}454$ | |
| Transformer decodificador | $823\,424$ | $2{,}332$ | $2{,}586$ |
| GRU de $2$ camadas | $676\,395$ | **$1{,}711$** | $1{,}455$ |

<figure>
+++ fig_c9_lab.svg
<figcaption><b>Figura 9.4.</b> Curvas do laboratório. Linhas cheias: bpc na validação, a cada $100$ passos. Linhas tracejadas: bpc do <b>último lote</b> de treino naquele passo (ruidoso, pois é um único lote e com <i>dropout</i> ligado). Linhas pontilhadas horizontais: as duas referências sem rede neural.</figcaption>
</figure>

**O que os números mostram.**

1. **Ambos aprendem estrutura além dos bigramas.** O Transformer chega a $2{,}33$ bpc e a GRU a $1{,}71$, ambos abaixo das referências de unigramas ($4{,}50$) e de bigramas ($3{,}45$).
2. **Neste orçamento, a GRU é melhor, e por margem grande.** $1{,}711$ contra $2{,}332$ bpc, uma diferença de $0{,}62$ bit por caractere. O Transformer ainda estava melhorando devagar ao final ($2{,}343$, $2{,}334$ e $2{,}332$ nos três últimos registros, com a taxa de aprendizado já quase nula pelo cosseno).
3. **As curvas têm formas diferentes.** A GRU desce depressa nos primeiros $300$ passos e depois mais devagar, e termina com **folga** entre treino e validação ($1{,}46$ contra $1{,}71$): começa a ajustar-se ao treino. O Transformer sai mais devagar (ele só ultrapassa os bigramas por volta do passo $200$) e, no fim, o bpc de treino **não** está abaixo do de validação: não há sinal de sobreajuste, e sim de que o modelo está longe de ter aprendido o que poderia.
4. **A qualidade do texto gerado pelo Transformer é baixa.** A amostra com temperatura $0{,}8$, a partir de `O gradiente `, produz sequências com aparência de português e de vocabulário do livro ("o gradiente não que percepto sestribuidade o intamento de logo que o tranvola...") mas sem sentido. É o que se espera de $2{,}3$ bpc.

::: atencao O que o laboratório NÃO mostra
Este é **um** experimento, com **uma** semente, **um** orçamento fixo de $1\,500$ passos ($4\,096$ caracteres por passo, $6{,}1\times10^{6}$ no total, isto é, cerca de $23$ passadas pelo treino de $265$ mil caracteres), taxas de aprendizado **não** ajustadas e um corpus minúsculo. Ele **não** permite concluir que "a GRU é melhor que o Transformer". Ele permite concluir que, **nessas condições**, um modelo recorrente de tamanho comparável aprendeu mais rápido do que um Transformer.

Há explicações plausíveis, **que este laboratório não testou**: (i) a recorrência é um *viés indutivo* forte, favorável a poucos dados e a poucas passagens, enquanto o Transformer precisa **aprender** a usar posições, que partem de embeddings aleatórios; (ii) a taxa de aprendizado do Transformer pode estar muito baixa ou muito alta para esse orçamento, e os Transformers são notoriamente sensíveis a ela e ao aquecimento; (iii) as vantagens do Transformer (paralelismo, caminhos curtos) se manifestam com **muito** mais dados, parâmetros e computação, e em contextos longos, e não em janelas de $128$ caracteres. Testar cada uma exigiria varrer taxas de aprendizado, repetir com várias sementes e escalar os dados (Exercício 9.15).
:::

A lição de método é a mais importante do laboratório: uma comparação justa entre arquiteturas exige **ajustar os hiperparâmetros de cada uma com o mesmo esforço**, **repetir** com sementes diferentes e **declarar o orçamento**. A literatura sobre leis de escala (por exemplo, Kaplan e colegas, 2020) mostra que as conclusões sobre arquiteturas podem mudar com a escala, e é por isso que o resultado de um laboratório minúsculo não se extrapola.

## 9.10 Resumo do capítulo

::: resumo Capítulo 9
- **Por que atenção.** A recorrência força um gargalo de estado, caminhos de comprimento $O(T)$ e cálculo sequencial. A autoatenção troca isso por caminho $O(1)$ e paralelismo, ao custo de $O(T^2d)$ operações e de memória quadrática no comprimento.
- **A fórmula.** $\operatorname{Attention}(\mathbf{Q},\mathbf{K},\mathbf{V})=\operatorname{softmax}(\mathbf{Q}\mathbf{K}^{\top}/\sqrt{d_k})\mathbf{V}$. Cada saída é uma **combinação convexa** dos valores (Proposição 9.1). O fator $1/\sqrt{d_k}$ mantém a variância das pontuações em $1$ (Proposição 9.2) e evita a saturação da softmax, em que o jacobiano $\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^{\top}$ se anula (Proposição 9.3).
- **Autoatenção sem ordem.** Sem codificação posicional, a camada é **equivariante a permutações** (Teorema 9.4): trata a sequência como um conjunto. A **máscara causal** impede a atenção ao futuro e isola cada posição do que vem depois (Proposição 9.5).
- **Multi-cabeça e posições.** Várias cabeças, com $4d^2+4d$ parâmetros no total (Proposição 9.6), observam subespaços distintos. As posições senoidais permitem expressar deslocamentos como rotações (Proposição 9.7).
- **O bloco.** Atenção e rede por posição, com normalização de camada e conexões residuais; a variante pré-LN treina de modo mais estável. Um bloco tem $12d^2+13d$ parâmetros (Proposição 9.8), e o modelo todo, $Vd+Pd+N(12d^2+13d)+2d$.
- **Famílias.** Codificador (BERT, máscara livre, objetivo de linguagem mascarada), decodificador (GPT, máscara causal, objetivo autoregressivo) e codificador-decodificador (T5, BART, atenção cruzada).
- **Inferência.** O **cache de chaves e valores** evita recalcular o passado ao gerar texto, ao custo de $2Nd$ números por token; a **FlashAttention** reorganiza o cálculo exato para reduzir o tráfego de memória.
- **Laboratório.** Em escala minúscula e com orçamento fixo, uma GRU ($1{,}711$ bpc) superou o Transformer ($2{,}332$ bpc). O resultado descreve **aquelas condições**, e não a superioridade de uma arquitetura.
:::

**Ponte para o Capítulo 10.** Os modelos deste capítulo operaram sobre **caracteres**, um vocabulário de $107$ símbolos. Modelos reais operam sobre **subpalavras**, e raramente são treinados do zero: partem de pesos pré-treinados e são **ajustados**. O Capítulo 10 mostra como o texto vira identificadores (tokenização), como as bibliotecas do ecossistema Hugging Face empacotam esse fluxo e como **adaptar** um modelo grande com poucos parâmetros treináveis (LoRA) e pouca memória (quantização).
