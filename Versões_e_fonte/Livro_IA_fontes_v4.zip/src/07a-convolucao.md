<div class="objetivos">

Objetivos do capítulo

- Representar imagens como tensores e explicar por que redes densas são inadequadas para elas.
- Definir a convolução de redes neurais (com canais, filtros, *stride* e *padding*), calcular o tamanho das saídas e o número de parâmetros.
- Demonstrar a equivariância da convolução a translações e calcular o campo receptivo de uma pilha de camadas.
- Descrever o *pooling* e a invariância parcial que ele oferece, com seus limites.
- Deduzir a retropropagação em camadas convolucionais e verificá-la numericamente.
- Explicar as ideias de LeNet, AlexNet, VGG e ResNet, e demonstrar por que conexões residuais preservam o gradiente.
- Aplicar aumento de dados e transferência de aprendizado, e avaliar com critério quando elas ajudam.

**Pré-requisitos:** Capítulos 1 (tensores) e 5, e Capítulo 6, em particular retropropagação, PyTorch, BatchNorm e regularização.

</div>

## 7.1 Imagens como dados em grade

Uma **imagem** em tons de cinza é uma matriz de intensidades, e uma imagem colorida é um **tensor** de três matrizes (canais vermelho, verde e azul). No PyTorch, um lote de imagens tem formato $(N,C,H,W)$: $N$ imagens, $C$ canais, altura $H$ e largura $W$. As imagens de dígitos usadas neste livro têm formato $(1,8,8)$; as do conjunto ImageNet, normalmente $(3,224,224)$. Os dados de imagens têm duas propriedades que os modelos anteriores ignoram:

- **Localidade.** Os pixels próximos são fortemente relacionados: uma borda, um canto ou uma textura é definido por uma vizinhança pequena.
- **Estacionariedade.** O mesmo padrão pode aparecer em qualquer posição. Um olho no canto esquerdo e um olho no canto direito são o mesmo objeto, e um detector de olhos deveria servir para os dois.

### Por que a rede densa falha

Uma rede densa vê a imagem como um vetor achatado, e a ordem dos pixels é irrelevante para ela: se todas as imagens, de treino e de teste, tiverem os pixels embaralhados pela **mesma** permutação fixa, uma rede densa aprende exatamente o mesmo (basta permutar as colunas de $\mathbf{W}^{(1)}$). A vizinhança, que é a informação mais valiosa da imagem, não é aproveitada. Além disso, o custo é proibitivo. O programa abaixo conta os parâmetros de uma camada densa e de uma convolucional que produzem a mesma quantidade de saídas.

<<< codigo/c7_parametros.py

>>> codigo/c7_parametros.out

Para uma imagem de $28\times28$, uma camada densa que gera seis mapas de $28\times28$ tem $3{,}69$ milhões de parâmetros; a camada convolucional equivalente (seis filtros $5\times5$) tem $156$, uma razão de quase $24$ mil. Para uma imagem $224\times224$ colorida, a camada densa equivalente a $64$ filtros $3\times3$ teria da ordem de $5\times10^{11}$ parâmetros, e a convolucional tem $1\,792$. O restante deste capítulo explica como essa economia é obtida sem perda de capacidade para dados em grade.

## 7.2 A operação de convolução

### Definição

A ideia é usar um detector pequeno, o **filtro** (ou *kernel*), e deslizá-lo por toda a imagem, aplicando em cada posição **os mesmos pesos**.

::: definicao 7.1 · Convolução de redes neurais (correlação cruzada 2D)
Seja $\mathbf{x}\in\mathbb{R}^{H\times W}$ uma imagem e $\mathbf{k}\in\mathbb{R}^{K\times K}$ um filtro. A **convolução** (no sentido usado em aprendizado profundo) produz o **mapa de características** $\mathbf{y}$ com
$$
y_{i,j}=\sum_{a=0}^{K-1}\sum_{b=0}^{K-1}x_{i+a,\;j+b}\;k_{a,b}\;+\;b_0,
$$
em que $b_0$ é um viés. Cada $y_{i,j}$ é o produto escalar entre o filtro e a janela $K\times K$ da imagem que começa em $(i,j)$.
:::

<figure>
+++ fig_c7_janela.svg
<figcaption><b>Figura 7.1.</b> Uma convolução. A janela destacada na entrada é multiplicada elemento a elemento pelo filtro (as cores indicam o sinal dos pesos) e os produtos são somados, dando um valor do mapa (destacado à direita). O filtro desliza por todas as posições, com os mesmos pesos.</figcaption>
</figure>

::: nota Convolução ou correlação?
A convolução matemática inverte o filtro ($x_{i-a,\,j-b}$ no lugar de $x_{i+a,\,j+b}$); a operação acima, chamada de **correlação cruzada**, não inverte. As bibliotecas de aprendizado profundo implementam a segunda e a chamam de convolução. Como os filtros são aprendidos, a diferença é irrelevante: um filtro aprendido na forma invertida é apenas o filtro girado em $180^\circ$. O programa da seção verifica que a correlação com o filtro girado coincide com a convolução matemática do SciPy.
:::

### *Padding* e *stride*

Duas escolhas controlam o tamanho do mapa. O ***padding*** $P$ acrescenta $P$ linhas e colunas de zeros em cada borda, o que permite que o filtro seja centrado nos pixels das bordas e que a saída mantenha o tamanho da entrada. O ***stride*** $S$ é o passo do deslizamento: com $S=2$, o filtro avança de dois em dois pixels e o mapa tem metade do tamanho em cada eixo.

::: proposicao 7.1 · Tamanho da saída
Para uma entrada de tamanho $H$ (em um eixo), filtro $K$, *padding* $P$ e *stride* $S$, a saída tem tamanho
$$
H_\text{saída}=\Bigl\lfloor\frac{H+2P-K}{S}\Bigr\rfloor+1.
$$
:::

::: demonstracao
Após o *padding*, a dimensão é $H+2P$. A janela na $t$-ésima posição ($t=0,1,\dots$) começa em $St$ e termina em $St+K-1$, que deve ser no máximo $H+2P-1$. Logo $St\le H+2P-K$, isto é, $t\le\lfloor(H+2P-K)/S\rfloor$. O número de posições é esse máximo mais um.
:::

Com $K$ ímpar, $S=1$ e $P=(K-1)/2$, a saída tem o mesmo tamanho da entrada (*same padding*). O programa a seguir implementa a convolução com laços, compara-a com a do PyTorch para quatro combinações de $S$ e $P$ e confere a fórmula.

<<< codigo/c7_convolucao.py

>>> codigo/c7_convolucao.out

A implementação por laços e `F.conv2d` coincidem até o arredondamento ($10^{-15}$), e os tamanhos obedecem à Proposição 7.1.

### Filtros e mapas de características

A saída mostra um filtro clássico, o de **Sobel vertical**, aplicado a uma imagem de um quadrado claro sobre fundo escuro. O filtro calcula a diferença entre a coluna direita e a esquerda de cada janela. Em regiões uniformes, o resultado é zero; na borda esquerda do quadrado (escuro à esquerda, claro à direita), é positivo; na borda direita, negativo.

<figure>
+++ fig_c7_mapa.svg
<figcaption><b>Figura 7.2.</b> O filtro de Sobel vertical responde às bordas verticais: positivamente à esquerda do quadrado e negativamente à direita. Os valores são os do programa.</figcaption>
</figure>

Em uma rede convolucional, os filtros não são desenhados à mão: seus pesos são **parâmetros** aprendidos por retropropagação, de modo que a rede descobre quais padrões detectar. Os filtros das primeiras camadas tendem a se parecer com detectores de bordas e de cores; os das camadas seguintes combinam esses padrões em estruturas maiores.

### Vários canais e vários filtros

::: definicao 7.2 · Camada convolucional
Uma **camada convolucional** com $C_\text{ent}$ canais de entrada e $C_\text{saí}$ filtros tem pesos $\mathbf{K}\in\mathbb{R}^{C_\text{saí}\times C_\text{ent}\times K\times K}$ e vieses $\mathbf{b}\in\mathbb{R}^{C_\text{saí}}$. O $o$-ésimo canal de saída é
$$
\mathbf{y}_o=b_o+\sum_{c=1}^{C_\text{ent}}\mathbf{k}_{o,c}\star\mathbf{x}_c,
$$
em que $\star$ é a correlação da Definição 7.1: cada filtro tem uma fatia $K\times K$ para cada canal de entrada, e os resultados são somados. O número de parâmetros é
$$
C_\text{saí}\bigl(C_\text{ent}\,K^2+1\bigr).
$$
:::

Com $3$ canais de entrada e $64$ filtros $3\times3$, são $64(3\cdot9+1)=1\,792$ parâmetros, o valor do programa. Note que o número de parâmetros **não depende do tamanho da imagem**: a mesma camada processa imagens de $28\times28$ ou de $1000\times1000$.

### Equivariância a translações

A propriedade que justifica a economia de parâmetros é que deslocar a entrada desloca a saída.

::: teorema 7.2 · Equivariância da convolução a translações
Seja $T_{u,v}$ a translação de uma imagem por $(u,v)$ pixels, com extensão periódica nas bordas. Então, para todo filtro $\mathbf{k}$,
$$
\mathbf{k}\star\bigl(T_{u,v}\mathbf{x}\bigr)=T_{u,v}\bigl(\mathbf{k}\star\mathbf{x}\bigr).
$$
Com *padding* de zeros, a igualdade vale para as posições afastadas das bordas.
:::

::: demonstracao
Com $(T_{u,v}\mathbf{x})_{i,j}=x_{i-u,\,j-v}$ (índices módulo $H$ e $W$), $(\mathbf{k}\star T_{u,v}\mathbf{x})_{i,j}=\sum_{a,b}x_{i+a-u,\,j+b-v}\,k_{a,b}=(\mathbf{k}\star\mathbf{x})_{i-u,\,j-v}=\bigl(T_{u,v}(\mathbf{k}\star\mathbf{x})\bigr)_{i,j}$. O filtro usa os mesmos pesos em todas as posições, e é isso que permite "puxar" o deslocamento para fora da soma.
:::

A última linha da saída do programa confirma a propriedade numericamente: deslocar a entrada e depois convoluir dá o mesmo que convoluir e depois deslocar. É importante distinguir **equivariância** (a saída se desloca junto com a entrada) de **invariância** (a saída não muda). A convolução é equivariante; a invariância, necessária para classificar uma imagem independentemente da posição do objeto, é construída em camadas posteriores, pelo *pooling* e pela camada final, e é só aproximada.

### A convolução como multiplicação de matrizes

Empilhando $\mathbf{x}$ e $\mathbf{y}$ como vetores, a convolução é uma transformação linear $\mathbf{y}=\mathbf{C}\mathbf{x}$ em que $\mathbf{C}$ é uma matriz **esparsa** (cada linha tem só $K^2$ entradas não nulas) e com **pesos repetidos** (as mesmas $K^2$ entradas aparecem em todas as linhas, deslocadas). Uma camada convolucional é, portanto, uma camada densa com duas restrições: **conectividade local** (cada saída vê só uma janela) e **compartilhamento de pesos** (cada janela usa o mesmo filtro). Estas restrições são o **viés indutivo** da arquitetura: uma suposição, embutida na estrutura, sobre os dados. Quando a suposição é adequada, como nas imagens, ela reduz drasticamente o número de parâmetros e melhora a generalização (Capítulo 5).

### Campo receptivo

O **campo receptivo** de uma unidade é a região da entrada que pode influenciar seu valor. Uma única convolução $3\times3$ tem campo $3\times3$; empilhar camadas o amplia.

::: proposicao 7.3 · Campo receptivo de uma pilha de camadas
Para camadas $l=1,\dots,L$ com filtros de tamanho $K_l$ e *strides* $S_l$, sejam $r_l$ o campo receptivo (em pixels da entrada, em um eixo) e $j_l$ o **salto** entre unidades vizinhas da camada $l$, medido em pixels da entrada. Com $r_0=1$ e $j_0=1$,
$$
r_l=r_{l-1}+(K_l-1)\,j_{l-1},\qquad j_l=j_{l-1}\,S_l.
$$
:::

::: demonstracao
Uma unidade da camada $l$ depende de $K_l$ unidades consecutivas da camada $l-1$. Duas unidades consecutivas da camada $l-1$ estão a $j_{l-1}$ pixels uma da outra, de modo que as $K_l$ unidades abrangem $(K_l-1)\,j_{l-1}$ pixels entre a primeira e a última, além do campo $r_{l-1}$ de uma delas: $r_l=r_{l-1}+(K_l-1)j_{l-1}$. Cada passo $S_l$ da camada $l$ multiplica por $S_l$ o salto entre unidades vizinhas.
:::

O programa calcula o campo teórico de uma pilha de sete camadas e o compara com o suporte medido do gradiente, isto é, a região da entrada em que a saída central tem derivada não nula.

<<< codigo/c7_receptivo.py

>>> codigo/c7_receptivo.out

O campo receptivo teórico após as sete camadas é $24$, e o suporte medido do gradiente tem $24\times24$ pixels, em concordância. Enquanto o salto é $1$, cada convolução $3\times3$ acrescenta $2$ pixels ($3\to5$). Depois do primeiro *pooling* o salto é $2$, e cada convolução acrescenta $4$ ($6\to10\to14$); depois do segundo, o salto é $4$, e a convolução seguinte acrescenta $8$ ($16\to24$). O próprio *pooling* acrescenta pouco ($1$ e $2$ pixels), mas é ele que acelera o crescimento posterior. A medida do campo receptivo teórico, porém, é um limite superior: o campo **efetivo**, ou seja, a região que de fato contribui de modo relevante, tende a ser menor e concentrado no centro (Luo et al., 2016).

## 7.3 Pooling

O ***pooling*** resume cada janela de um mapa em um único valor, com a função de resumo fixa (não aprendida).

::: definicao 7.3 · Max pooling e average pooling
Com janelas $P\times P$ não sobrepostas (*stride* $P$), o **max pooling** devolve o máximo de cada janela, e o **average pooling** devolve a média. O **pooling global** (*global average pooling*) usa uma janela do tamanho de todo o mapa e reduz cada canal a um número.
:::

O *pooling* tem três efeitos. Primeiro, **reduz a resolução** (um *pooling* $2\times2$ divide por quatro o número de posições), diminuindo o custo e a memória das camadas seguintes. Segundo, **amplia o campo receptivo**, porque aumenta o salto (Proposição 7.3). Terceiro, oferece **invariância local a pequenas translações**: se uma característica se desloca dentro da janela, o máximo da janela não muda.

::: atencao A invariância do pooling é parcial
A invariância é exata apenas enquanto a característica permanece dentro da mesma janela. Um deslocamento maior, ou um deslocamento que cruza a fronteira entre janelas, altera a saída. Uma CNN com duas camadas de *pooling* **não** é invariante a translações arbitrárias. O Projeto 5 mede isso: deslocar as imagens por um único pixel derruba a acurácia de uma CNN de $0{,}96$ para $0{,}45$, e a invariância só é obtida com **aumento de dados**.
:::

Na retropropagação, o *max pooling* encaminha o gradiente apenas à posição do máximo (nas demais o gradiente é zero), e o *average pooling* o divide igualmente pelas posições da janela (Exercício 7.7). O *pooling* global médio é usado no fim das redes modernas no lugar de "achatar e conectar a uma camada densa": ele elimina uma camada com muitos parâmetros. Uma alternativa ao *pooling* é a convolução com $S=2$, cujos pesos são aprendidos; muitas arquiteturas recentes a preferem.

## 7.4 Retropropagação em camadas convolucionais

O treinamento exige o gradiente da perda em relação aos filtros e à entrada da camada. Como a convolução é uma transformação linear, as derivadas têm forma simples, e são, elas próprias, convoluções.

::: proposicao 7.4 · Gradientes de uma camada convolucional
Seja $\mathbf{y}=\mathbf{k}\star\mathbf{x}$ uma convolução "válida" (sem *padding*), e seja $\mathbf{G}=\partial\mathcal{L}/\partial\mathbf{y}$ o gradiente que chega da camada seguinte. Então
$$
\frac{\partial\mathcal{L}}{\partial k_{a,b}}=\sum_{i,j}G_{i,j}\,x_{i+a,\,j+b}=(\mathbf{x}\star\mathbf{G})_{a,b},
\qquad
\frac{\partial\mathcal{L}}{\partial\mathbf{x}}=\operatorname{pad}_{K-1}(\mathbf{G})\star\operatorname{rot}_{180^\circ}(\mathbf{k}),
$$
em que $\operatorname{pad}_{K-1}$ acrescenta $K-1$ zeros em cada borda e $\operatorname{rot}_{180^\circ}$ gira o filtro em $180^\circ$. O gradiente em relação a $\mathbf{x}$ é uma convolução "completa" de $\mathbf{G}$ com o filtro invertido.
:::

::: demonstracao
*Filtro.* O peso $k_{a,b}$ aparece em todas as saídas: $y_{i,j}=\sum_{a,b}x_{i+a,j+b}k_{a,b}$. Pela regra da cadeia, $\partial\mathcal{L}/\partial k_{a,b}=\sum_{i,j}G_{i,j}\,\partial y_{i,j}/\partial k_{a,b}=\sum_{i,j}G_{i,j}\,x_{i+a,j+b}$. O gradiente do filtro é a **soma, sobre todas as posições**, das contribuições de cada janela, e é o compartilhamento de pesos que gera essa soma.

*Entrada.* O pixel $x_{p,q}$ participa das saídas $y_{i,j}$ com $i=p-a$, $j=q-b$, para cada $(a,b)$ em que esse índice é válido. Assim $\partial\mathcal{L}/\partial x_{p,q}=\sum_{a,b}G_{p-a,\,q-b}\,k_{a,b}$, em que $G$ vale zero fora de seu domínio. Com $a'=K-1-a$ e $b'=K-1-b$, a soma é $\sum_{a',b'}\widetilde G_{p+a',\,q+b'}\,k_{K-1-a',\,K-1-b'}$, em que $\widetilde G$ é $\mathbf{G}$ com $K-1$ zeros em cada borda (deslocamento de índices). Isto é a correlação de $\widetilde G$ com o filtro girado.
:::

<<< codigo/c7_gradiente_conv.py

>>> codigo/c7_gradiente_conv.out

As duas fórmulas reproduzem o gradiente do autograd até o arredondamento. Em camadas com vários canais, as mesmas expressões valem canal a canal, somando-se as contribuições onde a entrada alimenta mais de um filtro.

