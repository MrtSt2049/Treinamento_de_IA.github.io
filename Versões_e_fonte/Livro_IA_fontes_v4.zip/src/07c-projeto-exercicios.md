## 7.8 Projeto 5: CNN e transferência de aprendizado

::: projeto Visão computacional com redes convolucionais
O projeto constrói uma CNN em PyTorch, compara-a com o MLP do Capítulo 6, mede a invariância a deslocamentos com e sem aumento de dados e testa a transferência de aprendizado com um controle experimental.
:::

### Objetivo

Responder, com experimentos controlados, a três perguntas: (1) uma CNN pequena supera um MLP em imagens, e com quantos parâmetros? (2) A CNN é invariante a pequenos deslocamentos? (3) Características aprendidas em uma tarefa ajudam em outra com poucos dados rotulados?

### Problema

O conjunto `digits` ($8\times8$ pixels, $1\,797$ imagens, $10$ classes). **Parte A:** classificar os dez dígitos com $500$ imagens de treino, $300$ de validação e as $997$ restantes de teste. **Parte B:** simular uma transferência. A tarefa de origem é reconhecer os dígitos $0$ a $4$ (cinco classes, $901$ imagens); a tarefa alvo é reconhecer os dígitos $5$ a $9$ ($896$ imagens), com apenas $25$, $50$ ou $100$ exemplos rotulados de treino, $100$ de validação e o restante de teste. O ambiente não permite baixar modelos pré-treinados, e por isso o pré-treino é feito aqui mesmo, na tarefa de origem; o código para pesos do ImageNet está na seção 7.7.

### Requisitos

- CNN pequena como `nn.Module`, dividida em extrator de características e cabeça.
- Comparação com o MLP do Capítulo 6 em acurácia e em número de parâmetros, em $5$ sementes.
- Teste de **robustez a deslocamentos** de $1$ pixel, com e sem aumento de dados no treino.
- Quatro estratégias de transferência, com **controle**: do zero, extração de características com extrator pré-treinado, extração com extrator **aleatório** congelado e ajuste fino.
- Teste automático de que o extrator congelado **não muda** durante o treino.
- Seleção da época pela perda de validação; teste usado uma única vez por modelo.

### Arquitetura

<figure>
+++ fig_c7_arquitetura.svg
<figcaption><b>Figura 7.4.</b> CNN do projeto. O extrator (duas convoluções com ReLU e <i>max pooling</i>) produz $64$ características, e a cabeça é uma camada linear. Na Parte B, a cabeça tem $5$ saídas.</figcaption>
</figure>

| Camada | Formato de saída | Parâmetros |
|---|---|---|
| Entrada | $1\times8\times8$ | 0 |
| Conv $3\times3$, 8 filtros, $P=1$, ReLU | $8\times8\times8$ | $8(1\cdot9+1)=80$ |
| Max pooling $2\times2$ | $8\times4\times4$ | 0 |
| Conv $3\times3$, 16 filtros, $P=1$, ReLU | $16\times4\times4$ | $16(8\cdot9+1)=1\,168$ |
| Max pooling $2\times2$ | $16\times2\times2$ | 0 |
| Linear $64\to10$ | $10$ | $64\cdot10+10=650$ |

O total, $1\,898$ parâmetros, é $2{,}5$ vezes menor que o do MLP $64\text{-}64\text{-}10$ ($4\,810$).

### Fundamentos teóricos

- A **conectividade local** e o **compartilhamento de pesos** (seção 7.2) explicam o menor número de parâmetros.
- O ***pooling*** oferece invariância apenas local (seção 7.3); a invariância mais ampla deve vir do **aumento de dados** (seção 7.6).
- Na **extração de características**, só a cabeça é treinada, e o extrator é uma transformação fixa; o **extrator aleatório** é o **controle** que separa o efeito do pré-treino do efeito de simplesmente ter um extrator com a estrutura de uma CNN (seção 7.7).
- A comparação entre estratégias usa o mesmo orçamento de épocas e a mesma seleção por validação (Capítulo 5).

### Implementação

<<< codigo/projeto5.py

### Testes e resultados

>>> codigo/projeto5.out

**Parâmetros e forma.** Os testes de forma e de contagem passam ($1\,898$ e $4\,810$), e a asserção de que o extrator congelado não se alterou durante o treino da cabeça passa em todas as execuções.

**Parte A: CNN e MLP.** Médias e desvios em $5$ sementes, com $997$ imagens de teste:

| Modelo | Parâmetros | Acurácia | Acurácia com deslocamento de $1$ pixel |
|---|---|---|---|
| MLP $64\text{-}64\text{-}10$ | $4\,810$ | $0{,}954\pm0{,}010$ | $0{,}310\pm0{,}005$ |
| CNN | $1\,898$ | $0{,}964\pm0{,}010$ | $0{,}448\pm0{,}021$ |
| CNN com aumento ($\pm1$ pixel) | $1\,898$ | $0{,}945\pm0{,}003$ | $0{,}912\pm0{,}011$ |

- A CNN é cerca de um ponto percentual melhor que o MLP, com $2{,}5$ vezes menos parâmetros. A diferença é do tamanho do desvio entre sementes, de modo que **não é conclusiva**; o que o resultado sustenta com segurança é que a CNN **não perde** e usa menos parâmetros.
- **A invariância não é de graça.** Deslocar as imagens por um único pixel derruba o MLP de $0{,}95$ a $0{,}31$ e a CNN de $0{,}96$ a $0{,}45$. A CNN é menos frágil (a convolução é equivariante e o *pooling* acrescenta alguma tolerância), mas está longe de ser invariante: uma imagem de $8\times8$ tem janelas de *pooling* de $2\times2$, e um deslocamento de um pixel muda frequentemente a janela em que cada traço cai.
- **O aumento de dados resolve** a fragilidade: a CNN treinada com deslocamentos de $\pm1$ pixel mantém $0{,}91$ nas imagens deslocadas. O preço foi uma queda de cerca de dois pontos percentuais ($0{,}964\to0{,}945$) nas imagens **não** deslocadas: com apenas $1\,898$ parâmetros e $60$ épocas, a rede tem de usar sua capacidade para atender a uma tarefa mais variada. É o compromisso viés-variância do Capítulo 5, visível de novo.

**Parte B: transferência.** A CNN pré-treinada na origem atinge $0{,}998$ de acurácia de validação nos dígitos $0$ a $4$. Acurácia no alvo (média $\pm$ desvio em $5$ sementes):

| Estratégia | 25 exemplos | 50 exemplos | 100 exemplos |
|---|---|---|---|
| do zero | $0{,}882\pm0{,}015$ | $0{,}921\pm0{,}019$ | $0{,}949\pm0{,}012$ |
| extração, extrator aleatório (controle) | $0{,}761\pm0{,}041$ | $0{,}776\pm0{,}043$ | $0{,}771\pm0{,}063$ |
| extração, extrator pré-treinado | $0{,}812\pm0{,}038$ | $0{,}895\pm0{,}010$ | $0{,}920\pm0{,}014$ |
| ajuste fino, $\eta=10^{-3}$ | $0{,}723\pm0{,}062$ | $0{,}849\pm0{,}044$ | $0{,}909\pm0{,}029$ |
| ajuste fino, $\eta=3\times10^{-3}$ | $0{,}855\pm0{,}038$ | $0{,}929\pm0{,}014$ | $0{,}951\pm0{,}013$ |

<figure>
+++ fig_c7_transfer.svg
<figcaption><b>Figura 7.5.</b> Acurácia no alvo em função do número de exemplos rotulados. As barras verticais são $\pm1$ desvio entre sementes. Valores da tabela.</figcaption>
</figure>

O resultado merece uma leitura cuidadosa, porque **não é o que a ideia de transferência faria esperar**.

1. **O pré-treino carrega informação útil.** O extrator pré-treinado supera o extrator aleatório congelado por $5$, $12$ e $15$ pontos percentuais, uma diferença bem maior que o desvio. As características aprendidas nos dígitos $0$ a $4$ são melhores do que características aleatórias para reconhecer os dígitos $5$ a $9$.
2. **Mas não superam o treino do zero.** Treinar a CNN do zero com os mesmos exemplos dá $0{,}882$, $0{,}921$ e $0{,}949$, melhor que a extração em todos os tamanhos. O ajuste fino com a mesma taxa ($3\times10^{-3}$) empata com o treino do zero para $50$ e $100$ exemplos (diferenças de $0{,}008$ e $0{,}002$, abaixo do desvio) e fica atrás com $25$ ($0{,}855$ contra $0{,}882$; a diferença é comparável ao desvio de $0{,}038$ do ajuste fino). **Neste experimento, a transferência não trouxe ganho mensurável.**
3. **A taxa de aprendizado do ajuste fino importa.** Com a taxa menor, $10^{-3}$, o ajuste fino fica abaixo do treino do zero em todos os tamanhos: em $60$ épocas, a rede não chega a convergir. A convenção de "taxa menor no ajuste fino" foi desenhada para redes grandes e pré-treinos pesados; aqui, ela atrapalha (Exercício 7.14).

Não testamos por que a transferência não ajudou. Hipóteses plausíveis, que cada uma exigiria um experimento próprio: (a) a CNN de $1\,898$ parâmetros é tão pequena e a tarefa tão fácil que $25$ imagens já bastam para treiná-la do zero; (b) as características aprendidas em cinco classes são específicas delas, e os dígitos $5$ a $9$ pedem outras; (c) as imagens de $8\times8$ têm tão poucos traços que há pouco a reaproveitar. A transferência rende mais com **modelos grandes**, **imagens de alta resolução**, **tarefas de origem amplas** (como o ImageNet, com mil classes) e **muito poucos** rótulos alvo, condições que este experimento não reproduz. A conclusão defensável é restrita: *neste problema, nestas condições, a transferência não superou o treino do zero*.

### Limitações

- Imagens minúsculas e um problema fácil: nada garante que as conclusões valham para fotografias reais.
- A origem e o alvo (dígitos $0$ a $4$ e $5$ a $9$) são tarefas relacionadas, mas com classes diferentes; outras escolhas de origem e alvo dariam resultados diferentes.
- Cinco sementes por configuração e conjuntos de validação de $100$ exemplos, ruidosos para escolher a época. Diferenças de um a três pontos percentuais não são confiáveis.
- Os hiperparâmetros (taxas, $60$ épocas, tamanho do lote) foram escolhidos uma vez; apenas a taxa do ajuste fino foi variada.
- O deslocamento do teste usa só translações de $1$ pixel; rotações, mudanças de escala e ruído não foram testadas.
- O código com pesos do ImageNet (seção 7.7) **não foi executado**.

### Melhorias possíveis

1. Repetir com mais sementes e calcular a diferença pareada entre estratégias.
2. Variar o tamanho do extrator (largura e profundidade) e ver se a vantagem do pré-treino muda.
3. Usar uma tarefa de origem mais ampla (por exemplo, todas as dez classes com a cabeça ignorada) para estudar o papel da **semelhança** entre tarefas.
4. Congelar apenas a primeira convolução e ajustar o restante (descongelamento gradual).
5. Executar o ajuste fino de uma ResNet-18 com pesos do ImageNet em um conjunto de imagens reais, em um ambiente com acesso à rede.

## 7.9 Resumo do capítulo

::: resumo Ideias centrais
- Imagens são tensores em grade com **localidade** e **estacionariedade**. Uma camada densa as ignora e custa milhões de parâmetros; uma camada **convolucional** os usa e custa $C_\text{saí}(C_\text{ent}K^2+1)$, **independentemente** do tamanho da imagem.
- A convolução usa os mesmos pesos em todas as posições, o que a torna **equivariante a translações**. O tamanho da saída é $\lfloor(H+2P-K)/S\rfloor+1$.
- O **campo receptivo** cresce com a profundidade, e acelera após camadas com *stride*. Duas convoluções $3\times3$ têm o campo de uma $5\times5$ com $72\%$ dos parâmetros.
- O ***pooling*** reduz a resolução e dá invariância **apenas local**. A invariância mais ampla exige **aumento de dados**.
- O gradiente de uma convolução é outra convolução: em relação ao filtro, a correlação da entrada com o gradiente de saída; em relação à entrada, a convolução completa com o filtro girado.
- **LeNet** definiu o padrão; **AlexNet** mostrou o poder de redes profundas com ReLU, Dropout e GPUs; **VGG** empilhou filtros pequenos; **ResNet** introduziu **conexões residuais**, que preservam o gradiente: o jacobiano $\prod(\mathbf{I}+\mathbf{J}_i)$ contém a identidade.
- **Transferência de aprendizado** (extração de características e ajuste fino) reaproveita uma rede pré-treinada. É uma hipótese a **testar com controles**: neste livro, com dígitos pequenos, o pré-treino superou o extrator aleatório, mas **não** o treino do zero.
:::

**Para o próximo capítulo.** As CNNs supõem uma **grade** de dados. Texto, áudio e séries temporais são **sequências**: os elementos têm ordem, comprimento variável e dependências que podem se estender por longas distâncias. O Capítulo 8 introduz as redes recorrentes, que processam uma sequência um passo de cada vez, mantendo um estado oculto, e estuda a dissipação do gradiente ao longo do tempo, o problema que motivou a LSTM e a GRU.

## 7.10 Exercícios

### Nível I: consolidação

**7.1** Calcule o tamanho da saída (por eixo) de uma convolução com: (a) entrada $32$, $K=5$, $P=0$, $S=1$; (b) entrada $28$, $K=3$, $P=1$, $S=2$; (c) entrada $224$, $K=7$, $P=3$, $S=2$.

**7.2** Quantos parâmetros têm `Conv2d(3, 64, 3)` e `Conv2d(64, 128, 3)` (com vieses)?

**7.3** Calcule a convolução (correlação) "válida" da matriz $\mathbf{x}=\bigl(\begin{smallmatrix}1&2&3\\4&5&6\\7&8&9\end{smallmatrix}\bigr)$ com o filtro $\mathbf{k}=\bigl(\begin{smallmatrix}1&0\\0&-1\end{smallmatrix}\bigr)$.

**7.4** Aplique *max pooling* e *average pooling* $2\times2$ (*stride* $2$) a $\bigl(\begin{smallmatrix}1&3&2&0\\4&2&1&5\\0&1&3&2\\2&6&1&1\end{smallmatrix}\bigr)$.

**7.5** Qual é o campo receptivo de três camadas $3\times3$ consecutivas, com *stride* $1$? Compare o número de parâmetros (com $C$ canais) com o de uma camada $7\times7$.

### Nível II: desenvolvimento

**7.6** Generalize a Proposição 7.1 para uma convolução com **dilatação** $d$ (os elementos do filtro ficam espaçados de $d$ pixels). Qual é o tamanho efetivo do filtro e a fórmula da saída?

**7.7** No exercício 7.4, suponha que o gradiente que chega ao *pooling* seja $\mathbf{G}=\bigl(\begin{smallmatrix}1&2\\3&4\end{smallmatrix}\bigr)$. Calcule o gradiente em relação à entrada $4\times4$ para o *max pooling* e para o *average pooling*.

**7.8** Calcule os formatos e o número de parâmetros de cada camada da CNN do Projeto 5 e confira o total.

**7.9** Mostre que o estágio `layer2` da ResNet-18 (dois blocos residuais, o primeiro com *stride* $2$ e atalho com convolução $1\times1$, de $64$ para $128$ canais) tem $525\,568$ parâmetros. Cada convolução $3\times3$ é seguida de uma BatchNorm com $2$ parâmetros por canal (escala e deslocamento), e a convolução do atalho também; as convoluções não têm viés.

**7.10** Sejam $\mathbf{J}_i$ matrizes com norma espectral no máximo $\varepsilon<1$. Mostre que $\lVert(\mathbf{I}+\mathbf{J}_L)\cdots(\mathbf{I}+\mathbf{J}_1)\mathbf{v}\rVert\ge(1-\varepsilon)^L\lVert\mathbf{v}\rVert$. Para que valor de $\varepsilon$, em função de $L$, essa cota permanece limitada longe de zero? Compare com o produto $\mathbf{J}_L\cdots\mathbf{J}_1$.

**7.11** Para cada cenário, escolha entre treinar do zero, extração de características e ajuste fino de um modelo pré-treinado no ImageNet, e justifique: (a) $500$ fotos de $5$ espécies de aves; (b) $2$ milhões de imagens de satélite com $20$ classes; (c) $200$ radiografias, uma tarefa muito diferente de fotografias comuns.

### Nível III: avançado

**7.12** Demonstre a equivariância (Teorema 7.2) em uma dimensão, com extensão periódica. Dê um exemplo concreto em que o *padding* de zeros a viola nas bordas.

**7.13** Mostre que uma convolução $1\times1$ é uma camada densa aplicada independentemente a cada pixel. Compare o número de parâmetros de uma convolução $3\times3$ de $256$ para $256$ canais com o de um **gargalo** (*bottleneck*) $1\times1$ ($256\to64$), $3\times3$ ($64\to64$), $1\times1$ ($64\to256$), ignorando os vieses.

**7.14** Reproduza a sensibilidade do ajuste fino à taxa de aprendizado, com $50$ exemplos alvo, para $\eta\in\{10^{-4},3\times10^{-4},10^{-3},3\times10^{-3}\}$, comparando com o treino do zero. Interprete.

**7.15** No Projeto 5, o extrator pré-treinado superou o extrator aleatório, mas não o treino do zero. Liste três hipóteses para esse resultado e proponha, para cada uma, um experimento que a teste.

## 7.11 Soluções comentadas

::: solucao 7.1
(a) $(32+0-5)/1+1=28$. (b) $\lfloor(28+2-3)/2\rfloor+1=\lfloor13{,}5\rfloor+1=14$. (c) $\lfloor(224+6-7)/2\rfloor+1=\lfloor111{,}5\rfloor+1=112$, que é o tamanho após a primeira convolução da ResNet-18 (seguida do *pooling*, que o reduz a $56$, como na saída do programa).
:::

::: solucao 7.2
$3\cdot64\cdot9+64=1\,792$ e $64\cdot128\cdot9+128=73\,856$. A segunda tem $41$ vezes mais parâmetros: o custo cresce com o produto do número de canais de entrada e de saída.
:::

::: solucao 7.3
$y_{i,j}=x_{i,j}\cdot1+x_{i+1,j+1}\cdot(-1)=x_{i,j}-x_{i+1,j+1}$. Então $y_{0,0}=1-5=-4$, $y_{0,1}=2-6=-4$, $y_{1,0}=4-8=-4$, $y_{1,1}=5-9=-4$: $\mathbf{y}=\bigl(\begin{smallmatrix}-4&-4\\-4&-4\end{smallmatrix}\bigr)$. O filtro mede a diferença ao longo da diagonal, constante nesta matriz.
:::

::: solucao 7.4
Janelas: $\bigl(\begin{smallmatrix}1&3\\4&2\end{smallmatrix}\bigr)$, $\bigl(\begin{smallmatrix}2&0\\1&5\end{smallmatrix}\bigr)$, $\bigl(\begin{smallmatrix}0&1\\2&6\end{smallmatrix}\bigr)$, $\bigl(\begin{smallmatrix}3&2\\1&1\end{smallmatrix}\bigr)$. *Max pooling*: $\bigl(\begin{smallmatrix}4&5\\6&3\end{smallmatrix}\bigr)$. *Average pooling*: $\bigl(\begin{smallmatrix}2{,}5&2\\2{,}25&1{,}75\end{smallmatrix}\bigr)$.
:::

::: solucao 7.5
Pela Proposição 7.3 com $S=1$: $r=1+2+2+2=7$. Parâmetros: $3\cdot9C^2=27C^2$ contra $49C^2$ da $7\times7$, isto é, $55\%$, e com duas ReLU a mais entre as camadas.
:::

::: solucao 7.6
A dilatação $d$ espaça os elementos do filtro, e o tamanho efetivo do filtro é $K_\text{ef}=d(K-1)+1$ (a primeira e a última posições distam $d(K-1)$). Repetindo a demonstração da Proposição 7.1 com $K_\text{ef}$ no lugar de $K$: $H_\text{saída}=\lfloor(H+2P-d(K-1)-1)/S\rfloor+1$. É a fórmula usada pelo PyTorch para `Conv2d` com o argumento `dilation`. A dilatação amplia o campo receptivo sem aumentar o número de parâmetros.
:::

::: solucao 7.7
*Max pooling:* o gradiente vai apenas à posição do máximo de cada janela. Os máximos estão em $(1,0)$ (valor $4$), $(1,3)$ (valor $5$), $(3,1)$ (valor $6$) e $(2,2)$ (valor $3$), e recebem $1,2,3,4$. O gradiente $4\times4$ é
$$\begin{pmatrix}0&0&0&0\\1&0&0&2\\0&0&4&0\\0&3&0&0\end{pmatrix}.$$
*Average pooling:* cada posição da janela recebe $G/4$:
$$\begin{pmatrix}0{,}25&0{,}25&0{,}5&0{,}5\\0{,}25&0{,}25&0{,}5&0{,}5\\0{,}75&0{,}75&1&1\\0{,}75&0{,}75&1&1\end{pmatrix}.$$
A soma dos gradientes é conservada ($10$) nos dois casos. O *max pooling* concentra o aprendizado no que "ganhou" a janela.
:::

::: solucao 7.8
Entrada $1\times8\times8$. Conv $3\times3$ com $8$ filtros e $P=1$: $8\times8\times8$, $8(9+1)=80$ parâmetros. *Max pooling* $2$: $8\times4\times4$. Conv $3\times3$ com $16$ filtros, $P=1$: $16\times4\times4$, $16(72+1)=1\,168$. *Max pooling*: $16\times2\times2$, que ao achatar dá $64$ valores. Linear $64\to10$: $650$. Total $80+1\,168+650=1\,898$, igual ao do programa.
:::

::: solucao 7.9
*Bloco 1* ($64\to128$, *stride* $2$): primeira convolução $64\cdot128\cdot9=73\,728$; segunda convolução $128\cdot128\cdot9=147\,456$; atalho $1\times1$: $64\cdot128=8\,192$. Pesos: $229\,376$. BatchNorm: três (duas no ramo, uma no atalho), cada uma com $2\cdot128=256$ parâmetros: $768$. Total do bloco: $230\,144$. *Bloco 2* ($128\to128$): duas convoluções $3\times3$, $2\cdot147\,456=294\,912$, e duas BatchNorm, $512$: $295\,424$. Soma: $230\,144+295\,424=525\,568$, o valor do programa.
:::

::: solucao 7.10
Para qualquer $\mathbf{u}$, $\lVert(\mathbf{I}+\mathbf{J})\mathbf{u}\rVert\ge\lVert\mathbf{u}\rVert-\lVert\mathbf{J}\mathbf{u}\rVert\ge(1-\varepsilon)\lVert\mathbf{u}\rVert$. Aplicando isso $L$ vezes, obtém-se $(1-\varepsilon)^L\lVert\mathbf{v}\rVert$. Com $\varepsilon=c/L$, $(1-c/L)^L\to e^{-c}$: a cota fica limitada longe de zero se cada resíduo é pequeno, da ordem de $1/L$. Já o produto sem atalhos satisfaz apenas $\lVert\mathbf{J}_L\cdots\mathbf{J}_1\mathbf{v}\rVert\le\varepsilon^L\lVert\mathbf{v}\rVert$, que decai exponencialmente para qualquer $\varepsilon<1$ fixo. É a diferença entre os dois regimes observados no programa da seção 7.5.
:::

::: solucao 7.11
(a) **Extração de características** (ou ajuste fino leve): poucos dados e tarefa próxima das fotografias do ImageNet. Treinar do zero superajustaria. (b) Muitos dados e tarefa de domínio específico: **ajuste fino** de toda a rede (ou, com recursos, treino do zero); a quantidade de dados sustenta muitos parâmetros livres, e o pré-treino ainda tende a acelerar a convergência. (c) Poucos dados e domínio muito diferente: é o caso difícil. A extração de características das camadas iniciais (bordas, texturas) tende a ser útil; as finais podem ser inadequadas. Convém **testar** as estratégias por validação cruzada, incluindo o treino do zero com uma rede pequena, em vez de assumir que a transferência ajuda (como mostra o Projeto 5).
:::

::: solucao 7.12
Seja $x\in\mathbb{R}^n$ com índices módulo $n$, $y_i=\sum_{a=0}^{K-1}x_{i+a}k_a$ e $(T_ux)_i=x_{i-u}$. Então $(k\star T_ux)_i=\sum_ax_{i+a-u}k_a=y_{i-u}=(T_uy)_i$. Com zeros nas bordas, a igualdade falha perto delas: tome $x=(0,0,0,1)$, $k=(1,1)$ com $P=0$ (saída de tamanho $3$): $y=(0,0,1)$. Deslocando $x$ de uma posição à esquerda (o $1$ "sai" pela borda), $T x=(0,0,1,0)$ e a saída é $(0,1,1)$, que não é o deslocamento de $y$ à esquerda, $(0,1,0)$. A informação que atravessa a borda é perdida ou criada: por isso a equivariância é exata no interior da imagem.
:::

::: solucao 7.13
Em cada pixel $(i,j)$, uma convolução $1\times1$ calcula $\mathbf{y}[:,i,j]=\mathbf{K}\,\mathbf{x}[:,i,j]+\mathbf{b}$, com $\mathbf{K}\in\mathbb{R}^{C_\text{saí}\times C_\text{ent}}$ a mesma em todos os pixels: é uma camada densa que mistura os canais de cada pixel, com pesos compartilhados. O número de parâmetros da $3\times3$ de $256\to256$ é $256\cdot256\cdot9=589\,824$. O gargalo tem $256\cdot64+64\cdot64\cdot9+64\cdot256=16\,384+36\,864+16\,384=69\,632$, cerca de $8{,}5$ vezes menos, com o mesmo campo receptivo $3\times3$ e a mesma resolução de entrada e saída. É a ideia dos blocos "gargalo" das ResNets mais profundas.
:::

::: solucao 7.14
Resultado do programa (com $50$ exemplos alvo, $5$ sementes):

>>> codigo/c7_ex_ajustefino.out

Com $\eta=10^{-4}$ e $3\times10^{-4}$, a acurácia fica em $0{,}28$ e $0{,}52$ (o acaso, com cinco classes, é $0{,}20$): em $60$ épocas, o treino mal avançou. Com $10^{-3}$, chega a $0{,}849$, e com $3\times10^{-3}$, a $0{,}929$, comparável (e ligeiramente acima, dentro do desvio) ao treino do zero, $0{,}921$. A taxa é, de novo, o hiperparâmetro dominante: a convenção "ajuste fino pede taxa pequena" é uma regra prática para redes grandes e orçamentos de treino longos, e aqui, com uma rede minúscula e um orçamento curto, ela produz subajuste.
:::

::: solucao 7.15
Hipótese 1: **a CNN é pequena e a tarefa fácil**, de modo que poucos exemplos já bastam do zero. *Experimento:* diminuir o tamanho do alvo (por exemplo, $5$ e $10$ exemplos) e aumentar a dificuldade (adicionar ruído às imagens) e ver se o pré-treino passa a ajudar. Hipótese 2: **as características de origem são específicas** das classes $0$ a $4$. *Experimento:* usar como origem uma tarefa mais ampla (todas as dez classes, com a cabeça descartada) e medir se a vantagem aparece; ou variar a origem para medir o efeito da semelhança entre tarefas. Hipótese 3: **o ruído do protocolo** (validação de $100$ exemplos, $5$ sementes) esconde diferenças pequenas. *Experimento:* aumentar o número de sementes (por exemplo, $30$) e calcular a diferença pareada entre ajuste fino e treino do zero com seu intervalo de confiança. Em todos os casos, o critério é o mesmo: formular a hipótese, variar **uma** coisa por vez e manter os controles (o extrator aleatório do projeto é um exemplo).
:::

## 7.12 Referências e leituras

**O que estudar primeiro.** Goodfellow, Bengio e Courville (2016), capítulo 9 (redes convolucionais). Para a aritmética de convoluções, Dumoulin e Visin (2016). Para a prática, os tutoriais de visão computacional do PyTorch e a documentação do `torchvision`.

### Livros didáticos fundamentais

- GOODFELLOW, I.; BENGIO, Y.; COURVILLE, A. *Deep Learning*. Cambridge: MIT Press, 2016. Capítulo 9. Texto completo em deeplearningbook.org.
- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Capítulo 10 (redes convolucionais).

### Artigos originais

- DUMOULIN, V.; VISIN, F. A guide to convolution arithmetic for deep learning. *arXiv:1603.07285*, 2016.
- FUKUSHIMA, K. Neocognitron: a self-organizing neural network model for a mechanism of pattern recognition unaffected by shift in position. *Biological Cybernetics*, v. 36, p. 193–202, 1980.
- HE, K.; ZHANG, X.; REN, S.; SUN, J. Deep residual learning for image recognition. In: *Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016. p. 770–778.
- KRIZHEVSKY, A.; SUTSKEVER, I.; HINTON, G. E. ImageNet classification with deep convolutional neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 25, 2012.
- LECUN, Y.; BOTTOU, L.; BENGIO, Y.; HAFFNER, P. Gradient-based learning applied to document recognition. *Proceedings of the IEEE*, v. 86, n. 11, p. 2278–2324, 1998.
- LUO, W.; LI, Y.; URTASUN, R.; ZEMEL, R. Understanding the effective receptive field in deep convolutional neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 29, 2016.
- RUSSAKOVSKY, O. et al. ImageNet Large Scale Visual Recognition Challenge. *International Journal of Computer Vision*, v. 115, n. 3, p. 211–252, 2015.
- SHORTEN, C.; KHOSHGOFTAAR, T. M. A survey on image data augmentation for deep learning. *Journal of Big Data*, v. 6, art. 60, 2019.
- SIMONYAN, K.; ZISSERMAN, A. Very deep convolutional networks for large-scale image recognition. In: *3rd International Conference on Learning Representations (ICLR)*, 2015.
- YOSINSKI, J.; CLUNE, J.; BENGIO, Y.; LIPSON, H. How transferable are features in deep neural networks? In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 27, 2014.

### Documentação técnica

- PyTorch: `torch.nn.Conv2d`, `MaxPool2d`, `BatchNorm2d`; pytorch.org/docs. torchvision: modelos (`torchvision.models`) e transformações (`torchvision.transforms`); pytorch.org/vision. Versões 2.15 e 0.29 nas execuções deste livro.

