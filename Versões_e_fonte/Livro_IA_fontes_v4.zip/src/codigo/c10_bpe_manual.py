"""BPE (byte-pair encoding) em nível de bytes, implementado do zero, treinado na prosa do livro.

A pré-tokenização separa palavras (com o espaço que as precede), números, pontuação e espaços em branco."""
import re
from collections import Counter

import numpy as np

from corpus import carregar

def pre(texto):
    return [p.encode("utf-8") for p in re.findall(r" ?[^\W\d_]+| ?\d+| ?[^\s\w]+|\s+", texto)]


def treinar(corpus, n_fusoes):
    freq = Counter(pre(corpus))
    palavras = {p: tuple(bytes([b]) for b in p) for p in freq}            # cada palavra começa como sequência de bytes
    fusoes = []
    for _ in range(n_fusoes):
        pares = Counter()
        for p, simb in palavras.items():
            for a, b in zip(simb, simb[1:]):
                pares[(a, b)] += freq[p]
        if not pares:
            break
        melhor = max(pares.items(), key=lambda kv: (kv[1], kv[0]))[0]      # mais frequente; desempate determinístico
        fusoes.append(melhor)
        novo = melhor[0] + melhor[1]
        for p, simb in palavras.items():
            i, saida = 0, []
            while i < len(simb):
                if i < len(simb) - 1 and (simb[i], simb[i + 1]) == melhor:
                    saida.append(novo); i += 2
                else:
                    saida.append(simb[i]); i += 1
            palavras[p] = tuple(saida)
    return fusoes


def codificar_palavra(p, rank):
    simb = [bytes([b]) for b in p]
    while len(simb) > 1:
        cand = [(rank.get((a, b), 1 << 30), i) for i, (a, b) in enumerate(zip(simb, simb[1:]))]
        r, i = min(cand)
        if r == 1 << 30:
            break
        simb[i:i + 2] = [simb[i] + simb[i + 1]]
    return simb


def codificar(texto, fusoes):
    rank = {f: i for i, f in enumerate(fusoes)}
    return [t for p in pre(texto) for t in codificar_palavra(p, rank)]


if __name__ == "__main__":
    ps = carregar(list(range(1, 9)))
    ordem = np.random.default_rng(0).permutation(len(ps))
    nv = len(ps) // 10
    val = "\n".join(ps[i] for i in ordem[:nv])
    tr = "\n".join(ps[i] for i in ordem[nv:])
    print(f"treino: {len(tr)} caracteres; validação: {len(val)} caracteres ({len(val.encode())} bytes)")
    fusoes = treinar(tr, 800)
    leg = lambda b: b.decode("utf-8", errors="replace")
    print("primeiras fusões:", " ".join(f"({leg(a)}|{leg(b)})" for a, b in fusoes[:12]))
    print("últimas fusões  :", " ".join(f"({leg(a)}|{leg(b)})" for a, b in fusoes[-6:]))
    print(f"\nvocabulário = 256 bytes + {len(fusoes)} fusões = {256 + len(fusoes)}")
    print("\nK fusões   tokens por 1000 bytes (validação)   bytes por token")
    nb = len(val.encode())
    for K in (0, 25, 50, 100, 200, 400, 800):
        n = len(codificar(val, fusoes[:K]))
        print(f"{K:8d}   {1000 * n / nb:12.1f}                      {nb / n:8.2f}")
    frase = "A regularização reduz o superajuste dos hiperparâmetros."
    tok = codificar(frase, fusoes)
    print("\nfrase:", frase)
    print("tokens:", " ".join("[" + leg(t) + "]" for t in tok), f"({len(tok)} tokens)")
    novo = "hiperparametrização"
    print("palavra rara:", " ".join("[" + leg(t) + "]" for t in codificar(novo, fusoes)))
    ok = b"".join(codificar(val, fusoes)).decode("utf-8") == val
    print("\ndecodificar(codificar(x)) == x na validação inteira:", ok)
    print("texto com caractere nunca visto:", b"".join(codificar("ação ∑ 日本", fusoes)).decode("utf-8") == "ação ∑ 日本", "(sem token desconhecido: cai nos bytes)")
