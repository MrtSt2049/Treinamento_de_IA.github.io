"""Projeto 7: pré-treino em miniatura, ajuste fino completo vs LoRA, quantização e análise espectral das atualizações.

Uso: python3 projeto7.py {pretreino|varredura|final|quant|svd}  (final recebe as duas taxas escolhidas)
"""
import json
import math
import sys

import numpy as np
import torch
from transformers import GPT2LMHeadModel

from p7_comum import BASE, RAIZ, ajustar, contar, dados, novo_modelo, ppl, treinar

etapa = sys.argv[1]
d, tok, ds, ntok = dados()
nbytes = {k: sum(len(p.encode()) for p in v) for k, v in d.items()}


def salvar(res):
    with open(f"{RAIZ}/resultados.jsonl", "a") as f:
        f.write(json.dumps({"etapa": etapa, **res}) + "\n")


if etapa == "pretreino":
    print(f"tokenizador BPE de bytes, vocabulário {tok.get_vocab_size()}, treinado só no domínio de origem (Capítulos 1 a 5)")
    for k in d:
        print(f"{k:8s}: {len(d[k]):4d} parágrafos, {nbytes[k]:7d} bytes, {ntok[k]:6d} tokens ({nbytes[k] / ntok[k]:.2f} bytes/token), {len(ds[k]):3d} blocos de 128")
    torch.manual_seed(0)
    m = novo_modelo()
    print(f"\nmodelo: GPT-2 minúsculo, {contar(m)[0]} parâmetros")
    print(f"perplexidade inicial (sem treino): origem {ppl(m, ds['orig_va']):.1f}, alvo {ppl(m, ds['alvo_va']):.1f}   (V = {tok.get_vocab_size()})")
    curva, seg = treinar(m, ds["orig_tr"], ds["orig_va"], passos=600, lr=1e-3, seed=0, aquecimento=30, eval_cada=100)
    print("validação (origem) por passo:", " ".join(f"{s}:{p:.1f}" for s, p in curva), f"  [{seg:.0f} s]")
    m.save_pretrained(BASE)
    print(f"\nmodelo pré-treinado: perplexidade origem (validação) {ppl(m, ds['orig_va']):.1f}; alvo (validação) {ppl(m, ds['alvo_va']):.1f}; alvo (teste) {ppl(m, ds['alvo_te']):.1f}")

elif etapa == "varredura":
    # escolhe a taxa de aprendizado de cada método pela perplexidade de VALIDAÇÃO do domínio-alvo (uma semente)
    for metodo, r, lrs in (("completo", None, [3e-5, 1e-4, 3e-4, 1e-3]), ("lora", 4, [3e-4, 1e-3, 3e-3, 1e-2])):
        for lr in lrs:
            res = ajustar(metodo, r or 0, lr, 0, ds)
            salvar(res)
            print(f"{metodo:8s} r={r or '-'!s:>2}  lr={lr:7.0e}  alvo(val) {res['alvo_va']:7.2f}  origem(val) {res['orig_va']:7.2f}  [{res['segundos']:.0f} s]", flush=True)

elif etapa == "varredura2":
    # os melhores valores da primeira varredura estavam na borda da grade; estende-se a grade para além deles
    for metodo, r, lrs in (("completo", None, [3e-3, 1e-2]), ("lora", 4, [3e-2, 1e-1])):
        for lr in lrs:
            res = ajustar(metodo, r or 0, lr, 0, ds)
            salvar(res)
            print(f"{metodo:8s} r={r or '-'!s:>2}  lr={lr:7.0e}  alvo(val) {res['alvo_va']:7.2f}  origem(val) {res['orig_va']:7.2f}  [{res['segundos']:.0f} s]", flush=True)

elif etapa == "quant":
    from c10_quant import erro_rel, quantizar
    m0 = GPT2LMHeadModel.from_pretrained(BASE)
    base = ppl(m0, ds["orig_va"])
    print(f"modelo pré-treinado (fp32): perplexidade origem (validação) {base:.2f}")
    print(f"{'bits':>4} {'escala':>8} {'bits/peso':>10} {'erro rel. médio':>16} {'perplexidade':>13} {'variação':>9}")
    nomes = [n for n, p in m0.named_parameters() if p.ndim == 2 and ".h." in n]          # matrizes dos blocos (Conv1D: entrada x saída)
    for bits in (8, 4, 3, 2):
        for modo in ("tensor", "canal", "bloco"):
            m = GPT2LMHeadModel.from_pretrained(BASE)
            ps = dict(m.named_parameters())
            erros, bpp = [], []
            with torch.no_grad():
                for n in nomes:
                    W = ps[n].detach().numpy().astype(np.float64)
                    Wq, b = quantizar(W, bits, modo)
                    erros.append(erro_rel(W, Wq)); bpp.append(b)
                    ps[n].copy_(torch.tensor(Wq, dtype=torch.float32))
            p = ppl(m, ds["orig_va"])
            print(f"{bits:4d} {modo:>8} {np.mean(bpp):10.2f} {np.mean(erros):16.4f} {p:13.2f} {100 * (p / base - 1):+8.1f}%", flush=True)

elif etapa == "final":
    lr_c, lr_l = float(sys.argv[2]), float(sys.argv[3])
    print(f"taxas escolhidas na varredura: completo {lr_c:.0e}, LoRA {lr_l:.0e}")
    for seed in (0, 1, 2):
        for metodo, r, lr in (("zero", 0, 1e-3), ("completo", 0, lr_c), ("lora", 1, lr_l), ("lora", 4, lr_l), ("lora", 16, lr_l)):
            res = ajustar(metodo, r, lr, seed, ds, salvar=f"{RAIZ}/ft_{metodo}{r}_s{seed}" if seed == 0 else None)
            salvar(res)
            print(f"semente {seed}  {metodo:8s} r={r:2d}  treináveis {res['treinaveis']:7d}  alvo(val) {res['alvo_va']:7.2f}  alvo(teste) {res['alvo_te']:7.2f}  origem(val) {res['orig_va']:7.2f}", flush=True)

elif etapa == "svd":
    # espectro da atualização do ajuste completo (semente 0) e da fusão LoRA r=16 nas matrizes dos blocos
    base = dict(GPT2LMHeadModel.from_pretrained(BASE).named_parameters())
    rng = np.random.default_rng(0)
    for nome, arq in (("ajuste completo", f"{RAIZ}/ft_completo0_s0"), ("LoRA r=16 (fundida)", f"{RAIZ}/ft_lora16_s0")):
        ft = dict(GPT2LMHeadModel.from_pretrained(arq).named_parameters())
        alvo = [n for n, p in base.items() if p.ndim == 2 and ".h." in n]
        print(f"\n{nome}: {len(alvo)} matrizes dos blocos")
        print(f"{'r':>3} {'energia retida (média)':>24} {'mínimo':>8} {'máximo':>8} {'controle aleatório':>20}")
        E = {r: [] for r in (1, 2, 4, 8, 16)}
        C = {r: [] for r in (1, 2, 4, 8, 16)}
        for n in alvo:
            D = (ft[n] - base[n]).detach().numpy().astype(np.float64)
            sv = np.linalg.svd(D, compute_uv=False)
            R = np.linalg.svd(rng.normal(size=D.shape), compute_uv=False)
            for r in E:
                E[r].append((sv[:r] ** 2).sum() / (sv ** 2).sum()); C[r].append((R[:r] ** 2).sum() / (R ** 2).sum())
        for r in E:
            print(f"{r:3d} {100 * np.mean(E[r]):23.1f}% {100 * np.min(E[r]):7.1f}% {100 * np.max(E[r]):7.1f}% {100 * np.mean(C[r]):19.1f}%")
        norm = np.mean([np.linalg.norm((ft[n] - base[n]).detach().numpy()) / np.linalg.norm(base[n].detach().numpy()) for n in alvo])
        print(f"norma relativa média da atualização ||dW||_F/||W||_F: {norm:.4f}")
