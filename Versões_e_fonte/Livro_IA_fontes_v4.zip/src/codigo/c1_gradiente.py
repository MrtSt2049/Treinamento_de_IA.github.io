import numpy as np

A = np.array([[3.0, 1.0],
              [1.0, 2.0]])           # simétrica definida positiva
b = np.array([1.0, -1.0])


def f(x):
    return 0.5 * x @ A @ x - b @ x


def grad_f(x):
    return A @ x - b                 # gradiente analítico


def grad_numerico(f, x, h=1e-6):
    """Diferenças centrais: erro de truncamento O(h^2)."""
    g = np.zeros_like(x)
    for i in range(x.size):
        e = np.zeros_like(x)
        e[i] = h
        g[i] = (f(x + e) - f(x - e)) / (2 * h)
    return g


x0 = np.array([2.0, 2.0])
print("gradiente analítico:", grad_f(x0))
print("gradiente numérico :", np.round(grad_numerico(f, x0), 6))

x_otimo = np.linalg.solve(A, b)      # ponto em que o gradiente se anula
L = np.linalg.eigvalsh(A).max()      # maior autovalor da Hessiana
print("mínimo exato:", x_otimo, "| L =", round(float(L), 4), "| 2/L =", round(2 / L, 4))


def descida_do_gradiente(x, taxa, passos):
    for _ in range(passos):
        x = x - taxa * grad_f(x)
    return x


for taxa in (0.05, 1 / L, 0.5, 0.6):
    x = descida_do_gradiente(x0, taxa, passos=100)
    print(f"taxa={taxa:.4f}  distância ao mínimo após 100 passos = "
          f"{np.linalg.norm(x - x_otimo):.3e}")
