import torch
from torch import nn

n = lambda m: sum(p.numel() for p in m.parameters())

# 1. Uma camada densa e uma convolucional produzindo 6 mapas 28x28 a partir de uma imagem 1x28x28
densa = nn.Linear(28 * 28, 6 * 28 * 28)
conv = nn.Conv2d(1, 6, kernel_size=5, padding=2)
print(f"camada densa 784 -> {6*28*28}   : {n(densa):>10,d} parâmetros".replace(",", "."))
print(f"convolução 6 filtros 5x5 e P=2   : {n(conv):>10,d} parâmetros".replace(",", "."))
print(f"razão: {n(densa) / n(conv):,.0f}".replace(",", "."))

# 2. Uma imagem 224x224 RGB e 64 filtros 3x3 contra uma camada densa com a mesma saída
conv2 = nn.Conv2d(3, 64, 3, padding=1)
print(f"\nConv2d(3, 64, 3x3) em 224x224: {n(conv2)} parâmetros;  camada densa equivalente: {(3*224*224 + 1) * (64*224*224):.3e}")

# 3. LeNet-5 (LeCun et al., 1998), entrada 1x32x32
lenet = nn.Sequential(
    nn.Conv2d(1, 6, 5), nn.Tanh(), nn.AvgPool2d(2),
    nn.Conv2d(6, 16, 5), nn.Tanh(), nn.AvgPool2d(2),
    nn.Flatten(), nn.Linear(16 * 5 * 5, 120), nn.Tanh(), nn.Linear(120, 84), nn.Tanh(), nn.Linear(84, 10))
x = torch.zeros(1, 1, 32, 32)
print("\nLeNet-5: formato após cada camada")
for camada in lenet:
    x = camada(x)
    if not isinstance(camada, nn.Tanh):
        print(f"  {camada.__class__.__name__:10s} -> {tuple(x.shape)}")
print(f"parâmetros da LeNet-5: {n(lenet):,d}".replace(",", "."))
for i, m in enumerate(lenet):
    if n(m):
        print(f"  {m.__class__.__name__:8s} {n(m):>7,d}".replace(",", "."))
