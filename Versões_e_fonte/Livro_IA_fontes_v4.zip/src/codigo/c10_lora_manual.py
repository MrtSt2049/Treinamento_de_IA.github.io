"""LoRA (adaptação de baixo posto): implementação manual, propriedades e comparação com a biblioteca `peft`."""
import math
import torch
from torch import nn
from peft import LoraConfig, get_peft_model
from transformers import GPT2Config, GPT2LMHeadModel

torch.manual_seed(0)


class LoRALinear(nn.Module):
    """y = x W^T + b + (alpha/r) x A^T B^T, com W congelada; A: (r, k), B: (d, r), B = 0 no início."""

    def __init__(self, base: nn.Linear, r: int, alpha: float):
        super().__init__()
        self.base, self.r, self.escala = base, r, alpha / r
        for p in self.base.parameters():
            p.requires_grad_(False)
        self.A = nn.Parameter(torch.randn(r, base.in_features) / math.sqrt(base.in_features))
        self.B = nn.Parameter(torch.zeros(base.out_features, r))

    def forward(self, x):
        return self.base(x) + self.escala * (x @ self.A.T) @ self.B.T

    def delta(self):
        return self.escala * self.B @ self.A

    def fundir(self):
        with torch.no_grad():
            self.base.weight += self.delta()
        return self.base


d, k, r, alpha = 64, 48, 4, 8
base = nn.Linear(k, d)
lora = LoRALinear(base, r, alpha)
x = torch.randn(10, k)

print(f"parâmetros da camada completa: {d * k + d}; treináveis no LoRA (r = {r}): {r * (k + d)} ({100 * r * (k + d) / (d * k):.1f}% de d·k)")
print(f"saída idêntica à da camada base no início (B = 0): {torch.allclose(lora(x), base(x))}")

# gradientes no ponto inicial: dL/dA = escala * B^T (dL/dW) = 0 porque B = 0; dL/dB != 0
lora(x).pow(2).sum().backward()
print(f"início: ||dL/dB|| = {lora.B.grad.norm():.3f}; ||dL/dA|| = {lora.A.grad.norm():.1e}")

# depois de alguns passos, o posto de Delta W é no máximo r
otim = torch.optim.Adam([lora.A, lora.B], lr=1e-2)
alvo = torch.randn(10, d)
for _ in range(50):
    otim.zero_grad(); nn.functional.mse_loss(lora(x), alvo).backward(); otim.step()
dW = lora.delta().detach()
sv = torch.linalg.svdvals(dW)
print(f"posto numérico de Delta W: {(sv > 1e-6 * sv[0]).sum().item()} (limite r = {r}); valores singulares: {[round(v, 4) for v in sv[:6].tolist()]}")

# fusão: a inferência passa a custar o mesmo que a camada original
y = lora(x)
fundida = lora.fundir()
print(f"após fundir W' = W + Delta W: diferença máxima na saída = {(fundida(x) - y).abs().max().item():.1e}")

# Eckart-Young: o melhor posto-r de uma matriz é dado pela SVD; erro = valores singulares descartados
print("\nmelhor aproximação de posto r de uma matriz 256 x 256 com espectro decrescente (valores singulares ~ 1/i):")
U, _ = torch.linalg.qr(torch.randn(256, 256)); Vt, _ = torch.linalg.qr(torch.randn(256, 256))
s = 1.0 / torch.arange(1, 257).float()
M = U @ torch.diag(s) @ Vt
for rr in (1, 4, 16, 64):
    Mr = U[:, :rr] @ torch.diag(s[:rr]) @ Vt[:rr, :]
    print(f"  r = {rr:3d}: erro relativo ||M - M_r||_F / ||M||_F = {(M - Mr).norm() / M.norm():.3f}; energia retida = {100 * (s[:rr] ** 2).sum() / (s ** 2).sum():.1f}%")

# --- a mesma ideia com a biblioteca peft, em um GPT-2 minúsculo ---
cfg = GPT2Config(vocab_size=500, n_positions=64, n_embd=64, n_layer=2, n_head=4, bos_token_id=0, eos_token_id=0)
m = GPT2LMHeadModel(cfg).eval()
ids = torch.randint(0, 500, (2, 16))
saida0 = m(ids).logits
total = sum(p.numel() for p in m.parameters())
pm = get_peft_model(m, LoraConfig(r=4, lora_alpha=8, target_modules=["c_attn", "c_proj", "c_fc"], fan_in_fan_out=True, lora_dropout=0.0, task_type="CAUSAL_LM")).eval()
treinaveis = sum(p.numel() for p in pm.parameters() if p.requires_grad)
print(f"\npeft: total {sum(p.numel() for p in pm.parameters())}, treináveis {treinaveis} ({100 * treinaveis / total:.2f}% do modelo original de {total})")
print(f"peft: saída idêntica ao modelo original no início: {torch.allclose(pm(ids).logits, saida0, atol=1e-6)}")
for n_, p in pm.named_parameters():
    if "lora_B" in n_:
        p.data.normal_(0, 0.05)                                  # simula um treino
antes = pm(ids).logits
fundido = pm.merge_and_unload()
print(f"peft: merge_and_unload mantém a saída: {(fundido(ids).logits - antes).abs().max().item():.1e}; módulos LoRA restantes: {sum('lora' in n_ for n_, _ in fundido.named_parameters())}")

# contagem para o GPT-2 pequeno (d = 768, 12 blocos), LoRA em todas as camadas lineares dos blocos
r_ = 8
por_bloco = r_ * ((768 + 2304) + (768 + 768) + (768 + 3072) + (3072 + 768))
print(f"\nGPT-2 pequeno, r = {r_}, todas as lineares dos blocos: {12 * por_bloco} parâmetros treináveis = {100 * 12 * por_bloco / 124.44e6:.2f}% de 124,4 milhões")
