"""Exercício 8.13: LSTM implementada à mão (Definição 8.4) comparada com torch.nn.LSTM."""
import torch
from torch import nn

torch.manual_seed(0)
F, H, T, N = 4, 6, 7, 3
lstm = nn.LSTM(F, H, batch_first=True)
x = torch.randn(N, T, F)

W, U = lstm.weight_ih_l0, lstm.weight_hh_l0           # blocos empilhados na ordem (i, f, g, o)
b = lstm.bias_ih_l0 + lstm.bias_hh_l0
h, c = torch.zeros(N, H), torch.zeros(N, H)
saidas = []
for t in range(T):
    a = x[:, t] @ W.T + h @ U.T + b                    # (N, 4H)
    i, f, g, o = a.chunk(4, dim=1)
    i, f, o, g = torch.sigmoid(i), torch.sigmoid(f), torch.sigmoid(o), torch.tanh(g)
    c = f * c + i * g                                  # atualização aditiva da memória
    h = o * torch.tanh(c)
    saidas.append(h)
manual = torch.stack(saidas, dim=1)
ref, (h_n, c_n) = lstm(x)
print("maior diferença nas saídas :", f"{(manual - ref).abs().max().item():.2e}")
print("maior diferença em c_T     :", f"{(c - c_n[0]).abs().max().item():.2e}")
