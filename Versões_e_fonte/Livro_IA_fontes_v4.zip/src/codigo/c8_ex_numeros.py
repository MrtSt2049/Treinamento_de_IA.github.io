"""Conferência numérica de exercícios do Capítulo 8."""
import numpy as np
import torch
from torch import nn

# 8.1 parâmetros de camadas com F = 10, H = 20
for nome, cls in (("RNN", nn.RNN), ("GRU", nn.GRU), ("LSTM", nn.LSTM)):
    print(f"8.1  {nome:4s}", sum(p.numel() for p in cls(10, 20).parameters()))

# 8.2 RNN escalar: w_xh = 0.5, w_hh = 1.2, b = 0, h0 = 0, x = (1, -1, 2)
h = 0.0
for t, x in enumerate((1.0, -1.0, 2.0), 1):
    h = np.tanh(0.5 * x + 1.2 * h)
    print(f"8.2  h_{t} = {h:.4f}")

# 8.4 meia-vida de uma porta constante f = sigmoid(beta)
for beta in (0, 1, 2, 3, 5):
    f = 1 / (1 + np.exp(-beta))
    print(f"8.4  beta = {beta}: f = {f:.4f}, meia-vida = {np.log(2) / -np.log(f):.2f} passos, f^100 = {f ** 100:.3e}")

# 8.5 recorte
g = np.array([3.0, 4.0, 12.0])
print("8.5  ||g|| =", np.linalg.norm(g), "-> g recortado =", g * min(1, 5 / np.linalg.norm(g)))

# 8.8 LSTM bidirecional de 2 camadas com F = 4, H = 6
m = nn.LSTM(4, 6, num_layers=2, bidirectional=True)
print("8.8  parâmetros =", sum(p.numel() for p in m.parameters()))

# 8.11 menor k com 0.8^k < 1e-6
k = int(np.ceil(np.log(1e-6) / np.log(0.8)))
print(f"8.11 menor k com 0,8^k < 1e-6: {k} (0,8^{k} = {0.8 ** k:.2e}; 0,8^{k - 1} = {0.8 ** (k - 1):.2e})")
