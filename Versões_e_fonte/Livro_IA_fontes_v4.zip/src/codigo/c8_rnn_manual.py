import torch
from torch import nn

torch.manual_seed(0)
N, T, F, H = 3, 5, 4, 6                      # lote, passos de tempo, características, estado oculto
x = torch.randn(N, T, F)

# RNN de Elman escrita à mão: h_t = tanh(x_t W_xh^T + b_ih + h_{t-1} W_hh^T + b_hh)
rnn = nn.RNN(F, H, batch_first=True)          # nonlinearity="tanh" por padrão
h = torch.zeros(N, H)
estados = []
for t in range(T):
    h = torch.tanh(x[:, t] @ rnn.weight_ih_l0.T + rnn.bias_ih_l0 + h @ rnn.weight_hh_l0.T + rnn.bias_hh_l0)
    estados.append(h)
manual = torch.stack(estados, dim=1)
saida, h_final = rnn(x)
print("formato da entrada (N, T, F):", tuple(x.shape))
print("formato da saída   (N, T, H):", tuple(saida.shape), "| h_final (camadas, N, H):", tuple(h_final.shape))
print(f"maior diferença entre a RNN manual e nn.RNN: {(manual - saida).abs().max().item():.1e}")

# Contagem de parâmetros: fórmulas contra o PyTorch (o PyTorch usa dois vieses por porta)
n = lambda m: sum(p.numel() for p in m.parameters())
print(f"\nparâmetros com F = {F}, H = {H}")
for nome, mod, portas in [("RNN", nn.RNN(F, H), 1), ("GRU", nn.GRU(F, H), 3), ("LSTM", nn.LSTM(F, H), 4)]:
    formula = portas * H * (F + H + 2)
    print(f"  {nome:5s}: PyTorch = {n(mod):4d}   fórmula {portas}·H·(F+H+2) = {formula:4d}")

# Várias camadas e bidirecional
bi = nn.LSTM(F, H, num_layers=2, bidirectional=True, batch_first=True)
saida, (h, c) = bi(x)
print("\nLSTM de 2 camadas bidirecional: saída", tuple(saida.shape), "| h", tuple(h.shape), "(camadas*direções, N, H)")
