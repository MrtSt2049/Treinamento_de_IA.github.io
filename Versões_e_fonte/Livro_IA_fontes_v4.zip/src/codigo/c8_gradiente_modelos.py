import numpy as np
import torch
from torch import nn

T, F, H = 100, 8, 32
lags = (1, 10, 25, 50, 99)


def norma_por_lag(tipo, semente, vies_porta=None):
    torch.manual_seed(semente)
    modelo = {"RNN": nn.RNN, "GRU": nn.GRU, "LSTM": nn.LSTM}[tipo](F, H, batch_first=True)
    if vies_porta is not None:           # viés da porta de esquecimento (LSTM) ou de atualização (GRU): ordem (i,f,g,o) e (r,z,n)
        with torch.no_grad():
            modelo.bias_ih_l0[H:2 * H] = vies_porta
    x = torch.randn(16, T, F, requires_grad=True)
    saida, _ = modelo(x)
    saida[:, -1].pow(2).sum().backward()                     # perda sobre o ÚLTIMO estado
    g = x.grad.norm(dim=2).mean(0)                           # norma do gradiente em cada instante, média no lote
    return np.array([g[T - 1 - k].item() for k in lags])


print(f"Norma de ∂perda/∂x_(T-k) (T = {T}, H = {H}, inicialização padrão do PyTorch), média em 10 sementes")
print(f"{'':18s}" + "".join(f"{'k = ' + str(k):>11s}" for k in lags))
for nome, tipo, vies in [("RNN", "RNN", None), ("GRU", "GRU", None), ("LSTM", "LSTM", None),
                         ("GRU, viés z = 5", "GRU", 5.0), ("LSTM, viés f = 5", "LSTM", 5.0)]:
    m = np.mean([norma_por_lag(tipo, s, vies) for s in range(10)], axis=0)
    print(f"{nome:18s}" + "".join(f"{v:11.2e}" for v in m))
