import numpy as np
import torch
from sklearn.model_selection import train_test_split
from projeto5 import CNN, avaliar, carregar, treinar

X, y = carregar()
origem = y < 5
Xo, yo, Xd, yd = X[origem], y[origem], X[~origem], y[~origem] - 5
print("Ajuste fino com 50 exemplos rotulados: sensibilidade à taxa de aprendizado (5 sementes)")
print(f"{'η':>8s} {'acc. teste':>16s}")
resultados = {lr: [] for lr in (1e-4, 3e-4, 1e-3, 3e-3)}
resultados["do zero, 3e-3"] = []
for s in range(5):
    Xotr, Xova, yotr, yova = (torch.tensor(a) for a in train_test_split(Xo.numpy(), yo.numpy(), test_size=0.25, stratify=yo.numpy(), random_state=s))
    torch.manual_seed(s)
    pre = treinar(CNN(5), (Xotr, yotr), (Xova, yova), semente=s)
    Xtr, Xr, ytr, yr = train_test_split(Xd.numpy(), yd.numpy(), train_size=50, stratify=yd.numpy(), random_state=s)
    Xva, Xte, yva, yte = train_test_split(Xr, yr, train_size=100, stratify=yr, random_state=s)
    Xtr, Xva, Xte = (torch.tensor(a) for a in (Xtr, Xva, Xte)); ytr, yva, yte = (torch.tensor(a) for a in (ytr, yva, yte))
    for lr in (1e-4, 3e-4, 1e-3, 3e-3):
        torch.manual_seed(s); m = CNN(5); m.extrator.load_state_dict(pre.extrator.state_dict())
        m = treinar(m, (Xtr, ytr), (Xva, yva), lr=lr, semente=s)
        resultados[lr].append(avaliar(m, Xte, yte)[1])
    torch.manual_seed(s); m = CNN(5)
    m = treinar(m, (Xtr, ytr), (Xva, yva), lr=3e-3, semente=s)
    resultados["do zero, 3e-3"].append(avaliar(m, Xte, yte)[1])
for k, v in resultados.items():
    nome = f"{k:.0e}" if isinstance(k, float) else k
    print(f"{nome:>14s} {np.mean(v):10.4f}±{np.std(v):.4f}")
