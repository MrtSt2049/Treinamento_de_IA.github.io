import numpy as np

medias_reais = np.array([0.2, 0.5, 0.8])       # recompensa média de cada ação (desconhecida)


def executar(epsilon, passos=2000, semente=0):
    rng = np.random.default_rng(semente)
    Q = np.zeros(3)                            # estimativa do valor de cada ação
    N = np.zeros(3)                            # quantas vezes cada ação foi escolhida
    total = 0.0
    for _ in range(passos):
        if rng.random() < epsilon:
            a = rng.integers(3)                # exploração: ação ao acaso
        else:
            a = int(np.argmax(Q))              # aproveitamento: melhor estimativa atual
        r = rng.normal(medias_reais[a], 1.0)   # o ambiente devolve a recompensa
        N[a] += 1
        Q[a] += (r - Q[a]) / N[a]              # média incremental
        total += r
    return total / passos, Q


for eps in (0.0, 0.1, 0.5):
    medias = [executar(eps, semente=s)[0] for s in range(200)]
    print(f"epsilon = {eps:.1f}: recompensa média por passo = {np.mean(medias):.3f}")
print("melhor possível: 0.800")
