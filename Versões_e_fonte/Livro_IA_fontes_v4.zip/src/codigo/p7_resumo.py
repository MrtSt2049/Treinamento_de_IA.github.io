"""Agrega os resultados do Projeto 7 (média e desvio-padrão sobre as 3 sementes) a partir de p7_resultados.jsonl."""
import json
from collections import defaultdict

import numpy as np

R = [json.loads(l) for l in open("p7_resultados.jsonl")]
G = defaultdict(list)
for r in R:
    if r["etapa"] == "final":
        G[(r["metodo"], r["r"])].append(r)
print(f"{'método':22s} {'treináveis':>10s} {'%':>6s} {'alvo (teste)':>16s} {'alvo (val)':>14s} {'origem (val)':>16s} {'s/execução':>10s}")
ordem = [("zero", None), ("completo", None), ("lora", 1), ("lora", 4), ("lora", 16)]
nomes = {("zero", None): "sem pré-treino", ("completo", None): "ajuste completo", ("lora", 1): "LoRA r=1", ("lora", 4): "LoRA r=4", ("lora", 16): "LoRA r=16"}
for k in ordem:
    g = G[k]
    f = lambda c: (np.mean([x[c] for x in g]), np.std([x[c] for x in g], ddof=1))
    t, tot = g[0]["treinaveis"], g[0]["total"]
    print(f"{nomes[k]:22s} {t:10d} {100 * t / tot:5.1f}% {f('alvo_te')[0]:9.2f} ± {f('alvo_te')[1]:4.2f} {f('alvo_va')[0]:8.2f} ± {f('alvo_va')[1]:4.2f} {f('orig_va')[0]:9.2f} ± {f('orig_va')[1]:4.2f} {np.mean([x['segundos'] for x in g]):10.0f}")
print("\nvalores por semente (alvo teste):")
for k in ordem:
    print(f"  {nomes[k]:18s}", [round(x["alvo_te"], 2) for x in G[k]])
print("\nvarredura de taxas de aprendizado (semente 0, perplexidade de VALIDAÇÃO no alvo; origem entre parênteses):")
for r in R:
    if r["etapa"] in ("varredura", "varredura2"):
        print(f"  {r['metodo']:8s} r={r['r'] or '-'!s:>2} lr={r['lr']:6.0e}  {r['alvo_va']:7.2f} ({r['orig_va']:.1f})")
curvas = {k: np.mean([[p for _, p in x["curva"]] for x in G[k]], axis=0) for k in ordem}
passos = [s for s, _ in G[("completo", None)][0]["curva"]]
print("\ncurva de validação no alvo (média das 3 sementes) nos passos", passos)
for k in ordem:
    print(f"  {nomes[k]:18s}", " ".join(f"{v:6.1f}" for v in curvas[k]))
