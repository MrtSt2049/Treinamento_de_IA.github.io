"""Exercício 10.15: quantização por bloco com g = 32, 64 e 128 sobre o modelo pré-treinado do Projeto 7."""
import numpy as np
import torch
from transformers import GPT2LMHeadModel

from c10_quant import erro_rel, quantizar
from p7_comum import BASE, dados, ppl

d, tok, ds, ntok = dados()
base = ppl(GPT2LMHeadModel.from_pretrained(BASE), ds["orig_va"])
print(f"fp32: perplexidade {base:.2f}")
print(f"{'bits':>4} {'g':>4} {'bits/peso':>10} {'erro rel. médio':>16} {'perplexidade':>13} {'variação':>9}")
for bits in (4, 3):
    for g in (32, 64, 128):
        m = GPT2LMHeadModel.from_pretrained(BASE)
        ps = dict(m.named_parameters())
        er, bp = [], []
        with torch.no_grad():
            for n, p in ps.items():
                if p.ndim == 2 and ".h." in n:
                    W = p.detach().numpy().astype(np.float64)
                    Wq, b = quantizar(W, bits, "bloco", g)
                    er.append(erro_rel(W, Wq)); bp.append(b)
                    p.copy_(torch.tensor(Wq, dtype=torch.float32))
        v = ppl(m, ds["orig_va"])
        print(f"{bits:4d} {g:4d} {np.mean(bp):10.2f} {np.mean(er):16.4f} {v:13.2f} {100 * (v / base - 1):+8.1f}%")
