import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import Lasso, LassoCV, Ridge, RidgeCV
from sklearn.preprocessing import StandardScaler

X, y = load_diabetes(return_X_y=True)
X = StandardScaler().fit_transform(X)            # penalidades exigem variáveis na mesma escala
yc = y - y.mean()
n, d = X.shape

# Ridge: forma fechada (didático) e scikit-learn (produção)
lam = 10.0
beta_fechado = np.linalg.solve(X.T @ X + lam * np.eye(d), X.T @ yc)
beta_sk = Ridge(alpha=lam).fit(X, y).coef_
print("Ridge: forma fechada = sklearn:", np.allclose(beta_fechado, beta_sk))

print("\nRidge   lambda   norma L2 dos coef.   coef. nulos   cond(X^T X + lambda I)")
for lam in (0.0, 1.0, 10.0, 100.0, 1000.0):
    b = np.linalg.solve(X.T @ X + lam * np.eye(d), X.T @ yc)
    print(f"      {lam:8.1f}   {np.linalg.norm(b):18.2f}   {int(np.sum(b == 0)):11d}"
          f"   {np.linalg.cond(X.T @ X + lam * np.eye(d)):12.1f}")

print("\nLasso    alpha   norma L1 dos coef.   coef. nulos")
for alpha in (0.01, 0.5, 2.0, 5.0, 20.0, 50.0):
    b = Lasso(alpha=alpha, max_iter=50_000).fit(X, y).coef_
    print(f"      {alpha:8.2f}   {np.abs(b).sum():18.2f}   {int(np.sum(b == 0)):11d}")

ridge = RidgeCV(alphas=np.logspace(-2, 3, 50)).fit(X, y)
lasso = LassoCV(cv=10, random_state=0).fit(X, y)
print(f"\nescolhidos por validação cruzada: Ridge lambda = {ridge.alpha_:.2f}   Lasso alpha = {lasso.alpha_:.3f}")
nomes = np.array(load_diabetes().feature_names)
print("variáveis mantidas pelo Lasso:", [str(v) for v in nomes[lasso.coef_ != 0]])
