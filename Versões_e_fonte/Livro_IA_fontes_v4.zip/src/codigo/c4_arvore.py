import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.tree import DecisionTreeClassifier


def gini(contagens):
    p = np.asarray(contagens) / np.sum(contagens)
    return 1.0 - np.sum(p**2)


def entropia(contagens):
    p = np.asarray(contagens) / np.sum(contagens)
    p = p[p > 0]
    return -np.sum(p * np.log2(p))


def impureza_apos_divisao(medida, esquerda, direita):
    n_e, n_d = sum(esquerda), sum(direita)
    return (n_e * medida(esquerda) + n_d * medida(direita)) / (n_e + n_d)


# Exemplo do texto: nó com 6 positivos e 4 negativos
print(f"raiz: Gini = {gini([6, 4]):.4f}  entropia = {entropia([6, 4]):.4f}")
for nome, esq, dir_ in [("A", [4, 0], [2, 4]), ("B", [4, 1], [2, 3])]:
    print(f"divisão {nome}: Gini = {impureza_apos_divisao(gini, esq, dir_):.4f}  "
          f"entropia = {impureza_apos_divisao(entropia, esq, dir_):.4f}")

# Poda por custo-complexidade em dados reais
X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)
cheia = DecisionTreeClassifier(random_state=0).fit(X_tr, y_tr)
alphas = cheia.cost_complexity_pruning_path(X_tr, y_tr).ccp_alphas[:-1]

print("  alpha    folhas   treino   validação cruzada")
melhor = (0.0, -1.0)
for a in alphas:
    arv = DecisionTreeClassifier(random_state=0, ccp_alpha=a)
    cv = cross_val_score(arv, X_tr, y_tr, cv=5).mean()
    arv.fit(X_tr, y_tr)
    print(f"{a:7.4f}   {arv.get_n_leaves():6d}   {arv.score(X_tr, y_tr):6.4f}   {cv:8.4f}")
    if cv >= melhor[1]:
        melhor = (a, cv)

podada = DecisionTreeClassifier(random_state=0, ccp_alpha=melhor[0]).fit(X_tr, y_tr)
print(f"teste: árvore cheia = {cheia.score(X_te, y_te):.4f} ({cheia.get_n_leaves()} folhas)   "
      f"podada = {podada.score(X_te, y_te):.4f} ({podada.get_n_leaves()} folhas)")
