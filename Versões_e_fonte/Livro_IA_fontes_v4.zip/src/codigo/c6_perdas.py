import numpy as np

sig = lambda a: 1 / (1 + np.exp(-a))

# Gradiente em relação ao logit a para uma previsão muito errada: classe real y = 1 e a = -10
y, a = 1.0, -10.0
p = sig(a)
g_mse = (p - y) * p * (1 - p)           # d/da [ 1/2 (σ(a) - y)^2 ]
g_bce = p - y                           # d/da [ -y ln σ(a) - (1-y) ln(1-σ(a)) ]
print(f"σ(-10) = {p:.3e}")
print(f"gradiente com MSE            : {g_mse:+.3e}")
print(f"gradiente com entropia cruzada: {g_bce:+.6f}")
print(f"razão BCE/MSE = {g_bce / g_mse:.0f}")

# BCE com logits: forma estável  max(a,0) - a y + ln(1 + exp(-|a|))
def bce_logit(a, y):
    return np.maximum(a, 0) - a * y + np.log1p(np.exp(-np.abs(a)))

with np.errstate(all="ignore"):
    ingenua = -(y * np.log(sig(-800.0)) + (1 - y) * np.log(1 - sig(-800.0)))
print(f"\nBCE ingênua com a = -800 : {ingenua}")
print(f"BCE estável com a = -800 : {bce_logit(-800.0, 1.0)}")

# Referência: entropia cruzada de uma previsão uniforme entre K classes é ln K
for K in (2, 10, 1000):
    print(f"K = {K:4d}: perda de uma rede sem informação = ln K = {np.log(K):.4f}")
