"""Projeto 2: pipeline de regressão e de classificação com scikit-learn.

Executar:  python projeto2.py
Dependências: scikit-learn (testado com 1.9), NumPy.
"""
import numpy as np
from sklearn.datasets import load_breast_cancer, load_diabetes
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.linear_model import Lasso, LinearRegression, LogisticRegression, Ridge
from sklearn.metrics import (classification_report, confusion_matrix,
                             mean_squared_error, r2_score, roc_auc_score)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, KFold, train_test_split
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

SEMENTE = 42


def limpar(parametros):
    """Formata os hiperparâmetros escolhidos para impressão."""
    return {k.replace("modelo__", ""): (v if isinstance(v, int) else round(float(v), 4))
            for k, v in parametros.items()}


def selecionar(candidatos, X_tr, y_tr, cv, metrica):
    """Busca em grade com validação cruzada para cada candidato. Usa apenas o treino."""
    resultados = {}
    for nome, (estimador, grade) in candidatos.items():
        # O padronizador fica DENTRO do pipeline: é reajustado em cada partição
        pipeline = Pipeline([("escala", StandardScaler()), ("modelo", estimador)])
        busca = GridSearchCV(pipeline, grade, cv=cv, scoring=metrica).fit(X_tr, y_tr)
        resultados[nome] = busca
        print(f"  {nome:20s} cv = {busca.best_score_:8.4f}   {limpar(busca.best_params_)}")
    return resultados


def regressao():
    print("REGRESSÃO (diabetes): métrica = R2 em validação cruzada")
    X, y = load_diabetes(return_X_y=True)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=SEMENTE)
    candidatos = {
        "média (referência)": (DummyRegressor(), {}),
        "linear": (LinearRegression(), {}),
        "ridge": (Ridge(), {"modelo__alpha": np.logspace(-2, 3, 20)}),
        "lasso": (Lasso(max_iter=50_000), {"modelo__alpha": np.logspace(-2, 1.5, 20)}),
        "knn": (KNeighborsRegressor(), {"modelo__n_neighbors": [3, 5, 9, 15, 25, 41]}),
        "árvore": (DecisionTreeRegressor(random_state=SEMENTE), {"modelo__max_depth": [2, 3, 4, 6, 8]}),
    }
    cv = KFold(n_splits=5, shuffle=True, random_state=SEMENTE)
    res = selecionar(candidatos, X_tr, y_tr, cv, "r2")
    melhor = max(res, key=lambda k: res[k].best_score_)
    previsao = res[melhor].predict(X_te)                 # o teste é usado uma única vez
    print(f"  escolhido: {melhor} | teste: R2 = {r2_score(y_te, previsao):.4f}, "
          f"REQM = {np.sqrt(mean_squared_error(y_te, previsao)):.1f}")
    assert r2_score(y_te, previsao) > r2_score(y_te, res["média (referência)"].predict(X_te))


def classificacao():
    print("\nCLASSIFICAÇÃO (câncer de mama): métrica = AUC em validação cruzada")
    dados = load_breast_cancer()
    X, y = dados.data, (dados.target == 0).astype(int)   # positivo = maligno
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=SEMENTE, stratify=y)
    candidatos = {
        "classe majoritária": (DummyClassifier(strategy="prior"), {}),
        "logística": (LogisticRegression(max_iter=5000), {"modelo__C": np.logspace(-3, 2, 12)}),
        "knn": (KNeighborsClassifier(), {"modelo__n_neighbors": [1, 3, 5, 9, 15, 25]}),
        "árvore": (DecisionTreeClassifier(random_state=SEMENTE), {"modelo__ccp_alpha": [0.0, 0.002, 0.005, 0.01, 0.02]}),
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEMENTE)
    res = selecionar(candidatos, X_tr, y_tr, cv, "roc_auc")
    melhor = max(res, key=lambda k: res[k].best_score_)
    escore = res[melhor].predict_proba(X_te)[:, 1]
    previsao = (escore >= 0.5).astype(int)
    print(f"  escolhido: {melhor} | teste: AUC = {roc_auc_score(y_te, escore):.4f}")
    print("  matriz de confusão [[VN FP] [FN VP]]:", confusion_matrix(y_te, previsao).tolist())
    print(classification_report(y_te, previsao, target_names=["benigno", "maligno"], digits=3))
    assert roc_auc_score(y_te, escore) > 0.95


if __name__ == "__main__":
    regressao()
    classificacao()
