import numpy as np
from scipy.linalg import hilbert

print(" n   cond(A)      erro com solve   erro com inv")
for n in (4, 8, 12):
    A = hilbert(n)                     # matriz clássica mal condicionada
    x_real = np.ones(n)
    b = A @ x_real
    x_solve = np.linalg.solve(A, b)    # fatoração LU com pivoteamento
    x_inv = np.linalg.inv(A) @ b       # inversa explícita (evitar)
    print(f"{n:2d}   {np.linalg.cond(A):9.2e}   {np.linalg.norm(x_solve - x_real):12.2e}"
          f"   {np.linalg.norm(x_inv - x_real):12.2e}")
