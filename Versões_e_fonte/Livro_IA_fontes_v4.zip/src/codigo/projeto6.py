"""Projeto 6: sequências com RNN, GRU e LSTM. Parte A: memória de longo prazo. Parte B: previsão de série temporal."""
import copy
import sys
import time
import numpy as np
import torch
from torch import nn
from sklearn.linear_model import LinearRegression

torch.set_num_threads(2)
TIPOS = {"RNN": nn.RNN, "GRU": nn.GRU, "LSTM": nn.LSTM}


class Modelo(nn.Module):
    """Camada recorrente + cabeça linear aplicada ao último estado oculto."""

    def __init__(self, tipo, entrada, oculto, saida):
        super().__init__()
        self.rec = TIPOS[tipo](entrada, oculto, batch_first=True)
        self.cab = nn.Linear(oculto, saida)

    def forward(self, x):
        saida, _ = self.rec(x)
        return self.cab(saida[:, -1])


# ---------------------------------------------------------------- Parte A: memória atrasada
def gerar_memoria(n, T, gerador, classes=5):
    """No instante 0, um pulso unitário em uma de 5 dimensões (a classe); depois, ruído N(0, 0,5²). Alvo: a classe."""
    y = torch.randint(0, classes, (n,), generator=gerador)
    x = 0.5 * torch.randn(n, T, classes, generator=gerador)
    x[:, 0] = torch.nn.functional.one_hot(y, classes).float()
    return x, y


def aplicar_vies(m, tipo, valor, H=32):
    """Soma `valor` ao viés da porta de esquecimento (LSTM, bloco f) ou de atualização (GRU, bloco z)."""
    with torch.no_grad():
        bloco = {"LSTM": 1, "GRU": 1}[tipo]                       # PyTorch: LSTM [i,f,g,o]; GRU [r,z,n]
        m.rec.bias_ih_l0[bloco * H:(bloco + 1) * H] += valor


def treinar_memoria(tipo, T, semente, passos=500, lote=64, vies=0.0):
    torch.manual_seed(semente)
    g = torch.Generator().manual_seed(semente)
    m = Modelo(tipo, 5, 32, 5)
    if vies:
        aplicar_vies(m, tipo, vies)
    otim = torch.optim.Adam(m.parameters(), lr=3e-3)
    for _ in range(passos):
        x, y = gerar_memoria(lote, T, g)
        otim.zero_grad()
        nn.functional.cross_entropy(m(x), y).backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)       # recorte de gradiente (seção 8.3)
        otim.step()
    xt, yt = gerar_memoria(2000, T, torch.Generator().manual_seed(10_000 + semente))
    with torch.no_grad():
        return (m(xt).argmax(1) == yt).float().mean().item()


# ---------------------------------------------------------------- Parte B: previsão
def serie(n=3000, sigma=0.1, semente=0):
    t = np.arange(n)
    limpa = np.sin(2 * np.pi * t / 25) + 0.5 * np.sin(2 * np.pi * t / 7 + 1.0)
    return limpa + sigma * np.random.default_rng(semente).normal(size=n)


def janelas(s, J):
    X = np.stack([s[i:i + J] for i in range(len(s) - J)])
    return X, s[J:]


def treinar_previsao(tipo, Xtr, ytr, Xva, yva, semente, epocas=60, lote=64):
    torch.manual_seed(semente)
    m = Modelo(tipo, 1, 32, 1)
    otim = torch.optim.Adam(m.parameters(), lr=3e-3)
    tX, ty = torch.tensor(Xtr, dtype=torch.float32)[..., None], torch.tensor(ytr, dtype=torch.float32)
    vX, vy = torch.tensor(Xva, dtype=torch.float32)[..., None], torch.tensor(yva, dtype=torch.float32)
    melhor, estado = float("inf"), None
    for _ in range(epocas):
        m.train()
        ordem = torch.randperm(len(ty))
        for i in range(0, len(ty), lote):
            idx = ordem[i:i + lote]
            otim.zero_grad()
            nn.functional.mse_loss(m(tX[idx]).squeeze(1), ty[idx]).backward()
            nn.utils.clip_grad_norm_(m.parameters(), 1.0)
            otim.step()
        m.eval()
        with torch.no_grad():
            perda = nn.functional.mse_loss(m(vX).squeeze(1), vy).item()
        if perda < melhor:
            melhor, estado = perda, copy.deepcopy(m.state_dict())
    m.load_state_dict(estado)
    return m


if __name__ == "__main__":
    parte = sys.argv[1] if len(sys.argv) > 1 else "AB"
    if "A" in parte:
        print("Parte A: memória atrasada (acaso = 0,20); 500 passos, estado oculto 32, 3 sementes; acurácia em 2000 sequências novas")
        Ts = (5, 10, 20, 40, 80)
        print(f"{'T':>4s}" + "".join(f"{tipo:>18s}" for tipo in TIPOS))
        for T in Ts:
            linha = f"{T:4d}"
            for tipo in TIPOS:
                a = [treinar_memoria(tipo, T, s) for s in range(3)]
                linha += f"{np.mean(a):12.3f}±{np.std(a):.3f}"
            print(linha, flush=True)
    if "C" in parte:
        print("\nParte A2: mesma tarefa, com viés da porta de esquecimento (LSTM) / atualização (GRU) somado de +5 na inicialização")
        print(f"{'T':>4s}{'GRU (z+5)':>18s}{'LSTM (f+5)':>18s}")
        for T in (20, 40, 80):
            linha = f"{T:4d}"
            for tipo in ("GRU", "LSTM"):
                a = [treinar_memoria(tipo, T, s, vies=5.0) for s in range(3)]
                linha += f"{np.mean(a):12.3f}±{np.std(a):.3f}"
            print(linha, flush=True)
    if "B" in parte:
        s = serie()
        J = 30
        X, y = janelas(s, J)
        n = len(y)
        i1, i2 = int(0.7 * n), int(0.85 * n)                   # divisão cronológica: treino, validação, teste
        Xtr, ytr, Xva, yva, Xte, yte = X[:i1], y[:i1], X[i1:i2], y[i1:i2], X[i2:], y[i2:]
        print(f"\nParte B: previsão do próximo valor com janela de {J}; treino {len(ytr)}, validação {len(yva)}, teste {len(yte)}")
        print(f"ruído do gerador: σ = 0,1  ->  EQM irredutível = {0.1 ** 2:.4f}")
        mse = lambda p: float(np.mean((p - yte) ** 2))
        print(f"{'método':28s} {'EQM no teste':>14s}")
        print(f"{'média do treino':28s} {mse(np.full_like(yte, ytr.mean())):14.4f}")
        print(f"{'persistência (último valor)':28s} {mse(Xte[:, -1]):14.4f}")
        ar = LinearRegression().fit(Xtr, ytr)
        print(f"{'regressão linear (AR de 30)':28s} {mse(ar.predict(Xte)):14.4f}")
        vX = torch.tensor(Xte, dtype=torch.float32)[..., None]
        for tipo in TIPOS:
            r = []
            for sem in range(3):
                m = treinar_previsao(tipo, Xtr, ytr, Xva, yva, sem)
                with torch.no_grad():
                    r.append(mse(m(vX).squeeze(1).numpy()))
            print(f"{tipo + ' (32 unidades)':28s} {np.mean(r):8.4f} ± {np.std(r):.4f}", flush=True)
