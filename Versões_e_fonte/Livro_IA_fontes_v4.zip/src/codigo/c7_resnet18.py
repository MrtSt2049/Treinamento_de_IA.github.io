"""Estrutura da ResNet-18 (torchvision). Os pesos pré-treinados NÃO foram baixados: a rede é criada com pesos aleatórios."""
import torch
import torchvision
from torch import nn
from torchvision.models import ResNet18_Weights, resnet18

print("torchvision", torchvision.__version__)
modelo = resnet18(weights=None)                       # com weights=ResNet18_Weights.DEFAULT os pesos seriam baixados da internet
n = lambda m: sum(p.numel() for p in m.parameters())
print(f"parâmetros da ResNet-18 (1000 classes): {n(modelo):,d}".replace(",", "."))

# formato do tensor após cada estágio, para uma imagem 3x224x224
x = torch.zeros(1, 3, 224, 224)
x = modelo.maxpool(modelo.relu(modelo.bn1(modelo.conv1(x))))
print("após conv1 + pool        :", tuple(x.shape))
for nome in ("layer1", "layer2", "layer3", "layer4"):
    x = getattr(modelo, nome)(x)
    print(f"após {nome} ({n(getattr(modelo, nome)):>9,d} parâmetros):".replace(",", "."), tuple(x.shape))

# adaptação para 10 classes: congelar o corpo e trocar a cabeça
for p in modelo.parameters():
    p.requires_grad_(False)
modelo.fc = nn.Linear(modelo.fc.in_features, 10)      # a nova camada nasce com requires_grad=True
treinaveis = sum(p.numel() for p in modelo.parameters() if p.requires_grad)
print(f"parâmetros totais após trocar a cabeça: {n(modelo):,d};  treináveis: {treinaveis:,d}".replace(",", "."))

# pré-processamento associado aos pesos de referência (metadados; não requer download)
t = ResNet18_Weights.DEFAULT.transforms()
print("pré-processamento esperado:", f"redimensionar para {t.resize_size}, recortar {t.crop_size}, média {t.mean}, desvio {t.std}")
print("saída para um lote de 2 imagens:", tuple(modelo.eval()(torch.zeros(2, 3, 224, 224)).shape))
