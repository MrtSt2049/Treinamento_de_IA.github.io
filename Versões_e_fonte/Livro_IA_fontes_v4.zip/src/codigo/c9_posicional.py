"""Codificação posicional senoidal: propriedade de rotação, produto escalar que depende só da distância."""
import numpy as np

d, P = 16, 200
pos = np.arange(P)[:, None]
i = np.arange(d // 2)[None, :]
omega = 1.0 / 10000 ** (2 * i / d)                        # frequências w_i = 10000^(-2i/d)
PE = np.zeros((P, d))
PE[:, 0::2] = np.sin(pos * omega)                          # coordenada par: seno
PE[:, 1::2] = np.cos(pos * omega)                          # coordenada ímpar: cosseno
print("frequências w_i:", np.array2string(omega[0], precision=4, max_line_width=100))
print("comprimentos de onda 2*pi/w_i (em posições):", np.array2string(2 * np.pi / omega[0], precision=1, max_line_width=100))


def rotacao(k):
    """Matriz bloco-diagonal M_k tal que PE[p + k] = M_k PE[p] (blocos de rotação 2x2 de ângulo w_i k)."""
    M = np.zeros((d, d))
    for j, w in enumerate(omega[0]):
        c, s = np.cos(w * k), np.sin(w * k)
        M[2 * j:2 * j + 2, 2 * j:2 * j + 2] = [[c, s], [-s, c]]
    return M


for k in (1, 7, 50):
    err = max(np.abs(PE[p + k] - rotacao(k) @ PE[p]).max() for p in range(0, P - k))
    print(f"k = {k:2d}: max|PE[p+k] - M_k PE[p]| sobre todas as posições p = {err:.1e}")

# o produto escalar PE[p].PE[p+k] = sum_i cos(w_i k) depende só da distância k, não da posição p
for k in (0, 1, 5, 20, 100):
    v = np.array([PE[p] @ PE[p + k] for p in range(0, P - k)])
    print(f"k = {k:3d}: PE[p].PE[p+k] entre p=0..{P - k - 1}: min {v.min():7.4f}, max {v.max():7.4f}   (sum cos(w_i k) = {np.cos(omega[0] * k).sum():7.4f})")

# a norma de cada vetor é constante: ||PE[p]||^2 = d/2
n2 = (PE ** 2).sum(1)
print(f"||PE[p]||^2: mínimo {n2.min():.6f}, máximo {n2.max():.6f}  (d/2 = {d / 2})")
