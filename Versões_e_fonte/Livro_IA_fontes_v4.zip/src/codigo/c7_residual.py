import torch
from torch import nn

torch.manual_seed(0)
profundidade, canais = 30, 16
X = torch.randn(32, canais, 8, 8)
y = torch.randint(0, 10, (32,))


class Bloco(nn.Module):
    """F(x) = Conv - ReLU - Conv; opcionalmente soma a identidade: y = x + F(x)."""

    def __init__(self, residual):
        super().__init__()
        self.f = nn.Sequential(nn.Conv2d(canais, canais, 3, padding=1), nn.ReLU(), nn.Conv2d(canais, canais, 3, padding=1))
        self.residual = residual

    def forward(self, x):
        return torch.relu(x + self.f(x)) if self.residual else torch.relu(self.f(x))


def gradientes_por_bloco(residual):
    blocos = nn.ModuleList(Bloco(residual) for _ in range(profundidade // 2))
    cab = nn.Linear(canais, 10)
    h = X
    for b in blocos:
        h = b(h)
    nn.functional.cross_entropy(cab(h.mean((2, 3))), y).backward()
    return [b.f[0].weight.grad.norm().item() for b in blocos]


print(f"Norma do gradiente do 1º filtro de cada bloco ({profundidade} camadas convolucionais, inicialização padrão do PyTorch)")
print(f"{'':16s} {'bloco 1':>10s} {'bloco 5':>10s} {'bloco 10':>10s} {'bloco 15':>10s} {'1 / 15':>10s}")
for nome, res in [("sem residual", False), ("com residual", True)]:
    g = gradientes_por_bloco(res)
    print(f"{nome:16s} {g[0]:10.2e} {g[4]:10.2e} {g[9]:10.2e} {g[14]:10.2e} {g[0] / g[14]:10.2e}")
