"""Projeto 5: CNN em PyTorch, aumento de dados e transferência de aprendizado (sem pesos externos)."""
import copy
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

torch.set_num_threads(2)


class CNN(nn.Module):
    """Extrator de características (duas convoluções) + cabeça linear."""

    def __init__(self, n_classes=10):
        super().__init__()
        self.extrator = nn.Sequential(
            nn.Conv2d(1, 8, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),      # 8x8 -> 4x4
            nn.Conv2d(8, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),     # 4x4 -> 2x2
            nn.Flatten())                                                    # 16*2*2 = 64 características
        self.cabeca = nn.Linear(64, n_classes)

    def forward(self, x):
        return self.cabeca(self.extrator(x))


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.rede = nn.Sequential(nn.Flatten(), nn.Linear(64, 64), nn.ReLU(), nn.Linear(64, 10))

    def forward(self, x):
        return self.rede(x)


def carregar():
    X, y = load_digits(return_X_y=True)
    return torch.tensor(X / 16.0, dtype=torch.float32).reshape(-1, 1, 8, 8), torch.tensor(y)


def deslocar(x, dx, dy):
    """Desloca imagens (N,1,H,W) por (dx,dy) pixels, preenchendo com zeros."""
    h, w = x.shape[-2:]
    p = nn.functional.pad(x, (1, 1, 1, 1))
    return p[..., 1 - dy:1 - dy + h, 1 - dx:1 - dx + w]


def deslocar_aleatorio(x, gerador, incluir_zero=True):
    """Um deslocamento aleatório em {-1,0,1}² por imagem."""
    saida = torch.empty_like(x)
    for i in range(len(x)):
        while True:
            dx, dy = torch.randint(-1, 2, (2,), generator=gerador).tolist()
            if incluir_zero or (dx, dy) != (0, 0):
                break
        saida[i:i + 1] = deslocar(x[i:i + 1], dx, dy)
    return saida


@torch.no_grad()
def avaliar(m, X, y):
    m.eval()
    s = m(X)
    return nn.functional.cross_entropy(s, y).item(), (s.argmax(1) == y).float().mean().item()


def treinar(m, treino, val, epocas=60, lr=3e-3, lote=32, aumento=False, semente=0, parametros=None):
    g = torch.Generator().manual_seed(semente)
    torch.manual_seed(semente)
    carregador = DataLoader(TensorDataset(*treino), batch_size=lote, shuffle=True)
    otim = torch.optim.AdamW(parametros if parametros is not None else m.parameters(), lr=lr, weight_decay=0.0)
    melhor, estado = float("inf"), None
    for _ in range(epocas):
        m.train()
        for xb, yb in carregador:
            if aumento:
                xb = deslocar_aleatorio(xb, g)
            otim.zero_grad()
            nn.functional.cross_entropy(m(xb), yb).backward()
            otim.step()
        pv = avaliar(m, *val)[0]
        if pv < melhor:
            melhor, estado = pv, copy.deepcopy(m.state_dict())
    m.load_state_dict(estado)
    return m


def n_param(m):
    return sum(p.numel() for p in m.parameters())


if __name__ == "__main__":
    X, y = carregar()
    print(f"parâmetros: CNN {n_param(CNN())}, MLP 64-64-10 {n_param(MLP())}")
    assert CNN()(X[:4]).shape == (4, 10)

    # ---------------- Parte A: CNN × MLP, com e sem aumento de dados, e robustez a deslocamentos ----------------
    print("\nParte A: 10 classes, 500 exemplos de treino, 300 de validação, restante para teste (5 sementes)")
    print(f"{'modelo':24s} {'acc. teste':>14s} {'teste deslocado':>16s}")
    resultados = {}
    for s in range(5):
        Xtr, Xr, ytr, yr = train_test_split(X.numpy(), y.numpy(), train_size=500, stratify=y.numpy(), random_state=s)
        Xva, Xte, yva, yte = train_test_split(Xr, yr, train_size=300, stratify=yr, random_state=s)
        Xtr, Xva, Xte = (torch.tensor(a) for a in (Xtr, Xva, Xte)); ytr, yva, yte = (torch.tensor(a) for a in (ytr, yva, yte))
        g = torch.Generator().manual_seed(100 + s)
        Xte_des = deslocar_aleatorio(Xte, g, incluir_zero=False)
        for nome, mk, aum in [("MLP 64-64-10", MLP, False), ("CNN", CNN, False), ("CNN + aumento (±1 px)", CNN, True)]:
            torch.manual_seed(s)
            m = treinar(mk(), (Xtr, ytr), (Xva, yva), aumento=aum, semente=s)
            resultados.setdefault(nome, []).append([avaliar(m, Xte, yte)[1], avaliar(m, Xte_des, yte)[1]])
    for nome, r in resultados.items():
        r = np.array(r)
        print(f"{nome:24s} {r[:,0].mean():8.4f}±{r[:,0].std():.4f} {r[:,1].mean():10.4f}±{r[:,1].std():.4f}")

    # ---------------- Parte B: transferência de aprendizado (origem: dígitos 0-4; destino: dígitos 5-9) ----------------
    print("\nParte B: pré-treino em 0-4 (5 classes); alvo: 5-9 com poucos exemplos rotulados (5 sementes)")
    origem = (y < 5); destino = ~origem
    Xo, yo = X[origem], y[origem]
    Xd, yd = X[destino], y[destino] - 5
    tamanhos = (25, 50, 100)
    res = {n: {} for n in tamanhos}
    acc_origem = []
    for s in range(5):
        Xotr, Xova, yotr, yova = train_test_split(Xo.numpy(), yo.numpy(), test_size=0.25, stratify=yo.numpy(), random_state=s)
        Xotr, Xova, yotr, yova = (torch.tensor(a) for a in (Xotr, Xova, yotr, yova))
        torch.manual_seed(s)
        pre = treinar(CNN(5), (Xotr, yotr), (Xova, yova), semente=s)
        acc_origem.append(avaliar(pre, Xova, yova)[1])
        for n in tamanhos:
            Xtr, Xr, ytr, yr = train_test_split(Xd.numpy(), yd.numpy(), train_size=n, stratify=yd.numpy(), random_state=s)
            Xva, Xte, yva, yte = train_test_split(Xr, yr, train_size=100, stratify=yr, random_state=s)
            Xtr, Xva, Xte = (torch.tensor(a) for a in (Xtr, Xva, Xte)); ytr, yva, yte = (torch.tensor(a) for a in (ytr, yva, yte))

            def novo(origem_pesos):
                m = CNN(5)
                if origem_pesos == "pre":
                    m.extrator.load_state_dict(pre.extrator.state_dict())
                return m

            # (a) do zero
            torch.manual_seed(s); m = treinar(novo(None), (Xtr, ytr), (Xva, yva), semente=s)
            res[n].setdefault("do zero", []).append(avaliar(m, Xte, yte)[1])
            # (b) extração de características: extrator pré-treinado congelado, só a cabeça é treinada
            torch.manual_seed(s); m = novo("pre")
            for p in m.extrator.parameters():
                p.requires_grad_(False)
            antes = copy.deepcopy(m.extrator.state_dict())
            m = treinar(m, (Xtr, ytr), (Xva, yva), semente=s, parametros=m.cabeca.parameters())
            assert all(torch.equal(antes[k], v) for k, v in m.extrator.state_dict().items()), "o extrator congelado mudou"
            res[n].setdefault("extração (pré-treinado)", []).append(avaliar(m, Xte, yte)[1])
            # (c) controle: extrator ALEATÓRIO congelado
            torch.manual_seed(s); m = novo(None)
            for p in m.extrator.parameters():
                p.requires_grad_(False)
            m = treinar(m, (Xtr, ytr), (Xva, yva), semente=s, parametros=m.cabeca.parameters())
            res[n].setdefault("extração (aleatório)", []).append(avaliar(m, Xte, yte)[1])
            # (d) e (e) ajuste fino: todas as camadas, com taxa menor (1e-3) e com a mesma taxa do treino do zero (3e-3)
            for lr in (1e-3, 3e-3):
                torch.manual_seed(s); m = treinar(novo("pre"), (Xtr, ytr), (Xva, yva), lr=lr, semente=s)
                res[n].setdefault(f"ajuste fino η={lr:.0e}", []).append(avaliar(m, Xte, yte)[1])
    print(f"acurácia da CNN pré-treinada na tarefa de origem (validação): {np.mean(acc_origem):.4f}")
    metodos = ["do zero", "extração (aleatório)", "extração (pré-treinado)", "ajuste fino η=1e-03", "ajuste fino η=3e-03"]
    for n in tamanhos:
        print(f"\n{n} exemplos rotulados no alvo:")
        for m in metodos:
            print(f"  {m:26s} {np.mean(res[n][m]):.4f} ± {np.std(res[n][m]):.4f}")
