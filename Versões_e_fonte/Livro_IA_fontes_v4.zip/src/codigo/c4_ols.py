import numpy as np
from scipy import stats
import statsmodels.api as sm
from sklearn.datasets import load_diabetes

# 1) Regressão simples, conferindo a conta feita à mão no texto
x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
y = np.array([2.1, 3.9, 6.2, 7.8, 10.1])
b1 = np.sum((x - x.mean()) * (y - y.mean())) / np.sum((x - x.mean()) ** 2)
b0 = y.mean() - b1 * x.mean()
print(f"simples: beta0 = {b0:.3f}, beta1 = {b1:.3f}")

# 2) Regressão múltipla com inferência (código didático)
dados = load_diabetes()
X = np.column_stack([np.ones(dados.data.shape[0]), dados.data[:, [2, 3, 8]]])  # intercepto, bmi, bp, s5
nomes = ["intercepto", "bmi", "bp", "s5"]
y = dados.target
n, p = X.shape

beta = np.linalg.solve(X.T @ X, X.T @ y)             # equações normais
residuo = y - X @ beta
sigma2 = residuo @ residuo / (n - p)                 # estimativa não viesada de sigma^2
ep = np.sqrt(sigma2 * np.diag(np.linalg.inv(X.T @ X)))   # erros padrão
t = beta / ep
p_valor = 2 * stats.t.sf(np.abs(t), df=n - p)
r2 = 1 - residuo @ residuo / np.sum((y - y.mean()) ** 2)

print(f"{'':11s}{'coef':>9s}{'erro pad.':>11s}{'t':>8s}{'p-valor':>11s}")
for nome, b, e, ti, pi in zip(nomes, beta, ep, t, p_valor):
    print(f"{nome:11s}{b:9.2f}{e:11.2f}{ti:8.2f}{pi:11.2e}")
print(f"R2 = {r2:.4f}   X^T r = 0: {np.allclose(X.T @ residuo, 0, atol=1e-6)}")

# 3) Código de produção: statsmodels
modelo = sm.OLS(y, X).fit()
print("confere com statsmodels:", np.allclose(beta, modelo.params),
      np.allclose(ep, modelo.bse), np.allclose(p_valor, modelo.pvalues),
      np.isclose(r2, modelo.rsquared))
