"""Sequências de comprimentos diferentes: preenchimento (padding) e empacotamento (pack_padded_sequence)."""
import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_sequence

torch.manual_seed(0)
F, H = 3, 5
rede = nn.GRU(F, H, batch_first=True)
seqs = [torch.randn(n, F) for n in (6, 3, 4)]               # três sequências de comprimentos 6, 3 e 4
comp = torch.tensor([len(s) for s in seqs])

# referência: cada sequência processada sozinha; guarda o ÚLTIMO estado verdadeiro
ref = torch.stack([rede(s[None])[1][0, 0] for s in seqs])

# 1) preenchimento com zeros, ingênuo: o estado final é lido depois dos zeros
X = pad_sequence(seqs, batch_first=True)                    # (3, 6, F)
ingenuo = rede(X)[1][0]
print("formato do lote preenchido:", tuple(X.shape))
print("erro, estado final ingênuo (lê os zeros) :", [f"{(ingenuo[i] - ref[i]).abs().max().item():.2e}" for i in range(3)])

# 2) empacotamento: a rede ignora as posições de preenchimento
emp = pack_padded_sequence(X, comp, batch_first=True, enforce_sorted=False)
_, h = rede(emp)
print("erro, estado final com empacotamento     :", [f"{(h[0][i] - ref[i]).abs().max().item():.2e}" for i in range(3)])

# 3) máscara: pegar a saída no último passo VÁLIDO de cada sequência
saida, _ = rede(X)
idx = (comp - 1)[:, None, None].expand(-1, 1, H)
ultimo = saida.gather(1, idx)[:, 0]
print("erro, saída no último passo válido (máscara):", [f"{(ultimo[i] - ref[i]).abs().max().item():.2e}" for i in range(3)])
