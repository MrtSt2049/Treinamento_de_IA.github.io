import numpy as np

rng = np.random.default_rng(42)

# 1) Teorema de Bayes: teste diagnóstico
prevalencia, sensibilidade, especificidade = 0.01, 0.95, 0.90
p_positivo = sensibilidade * prevalencia + (1 - especificidade) * (1 - prevalencia)
posterior = sensibilidade * prevalencia / p_positivo
print(f"P(doença | teste positivo) = {posterior:.4f}")

# Conferência por simulação com 1 milhão de pessoas
doente = rng.random(1_000_000) < prevalencia
positivo = np.where(doente, rng.random(doente.size) < sensibilidade,
                    rng.random(doente.size) < 1 - especificidade)
print(f"frequência simulada        = {doente[positivo].mean():.4f}")

# 2) Esperança e variância: Bernoulli(0.3) e Gaussiana(2, 3^2)
x_bern = rng.random(200_000) < 0.3
x_gauss = rng.normal(loc=2.0, scale=3.0, size=200_000)
print(f"Bernoulli: média={x_bern.mean():.4f} (teoria 0.3)  "
      f"variância={x_bern.var():.4f} (teoria 0.21)")
print(f"Gaussiana: média={x_gauss.mean():.4f} (teoria 2)    "
      f"variância={x_gauss.var():.4f} (teoria 9)")

# 3) Gaussiana multivariada por fatoração de Cholesky: x = mu + L z
mu = np.array([1.0, -1.0])
Sigma = np.array([[2.0, 1.2],
                  [1.2, 1.0]])
L = np.linalg.cholesky(Sigma)                 # Sigma = L L^T
z = rng.normal(size=(200_000, 2))             # z ~ N(0, I)
x = mu + z @ L.T
print("média amostral      :", np.round(x.mean(axis=0), 3))
print("covariância amostral:\n", np.round(np.cov(x, rowvar=False), 3))
