import numpy as np

# f(x) = 1/2 x^T A x com A = diag(1, 100): condicionamento kappa = 100 (Capítulo 1)
A = np.diag([1.0, 100.0])
f = lambda x: 0.5 * x @ A @ x
grad = lambda x: A @ x
x0 = np.array([10.0, 1.0])


def gd(lr):
    x = x0.copy()
    while True:
        yield x.copy()
        x = x - lr * grad(x)


def momentum(lr, beta):
    x, v = x0.copy(), np.zeros(2)
    while True:
        yield x.copy()
        v = beta * v + grad(x)
        x = x - lr * v


def rmsprop(lr, rho=0.9, eps=1e-8):
    x, s = x0.copy(), np.zeros(2)
    while True:
        yield x.copy()
        g = grad(x)
        s = rho * s + (1 - rho) * g ** 2
        x = x - lr * g / (np.sqrt(s) + eps)


def adam(lr, b1=0.9, b2=0.999, eps=1e-8):
    x, m, v, t = x0.copy(), np.zeros(2), np.zeros(2), 0
    while True:
        yield x.copy()
        t += 1
        g = grad(x)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g ** 2
        mh, vh = m / (1 - b1 ** t), v / (1 - b2 ** t)
        x = x - lr * mh / (np.sqrt(vh) + eps)


def passos_ate(gerador, tol=1e-6, max_it=20000):
    """Iterações até f < tol (ou None) e o menor valor de f visto até max_it."""
    menor = np.inf
    for t, x in enumerate(gerador):
        menor = min(menor, f(x))
        if f(x) < tol:
            return t, menor
        if t >= max_it:
            return None, menor


configs = {
    "GD (η = 2/(L+μ) = 0,0198)": gd(2 / 101),
    "Momentum de Polyak (η = 0,0331; β = 0,669)": momentum(4 / 121, (9 / 11) ** 2),
    "Momentum (η = 0,0100; β = 0,9)": momentum(0.0100, 0.9),
    "Momentum (η = 0,0100; β = 0,95)": momentum(0.0100, 0.95),
    "RMSProp (η = 0,05)": rmsprop(0.05),
    "RMSProp (η = 0,005)": rmsprop(0.005),
    "Adam (η = 0,5)": adam(0.5),
}
print(f"f(x0) = {f(x0):.1f};  L = 100, μ = 1, κ = 100;  critério: f(x) < 1e-6")
kappa = 100
print(f"fator de contração previsto: GD (κ-1)/(κ+1) = {(kappa-1)/(kappa+1):.4f};  momentum ótimo (√κ-1)/(√κ+1) = {(kappa**.5-1)/(kappa**.5+1):.4f}")
for nome, g in configs.items():
    t, menor = passos_ate(g)
    if t is not None:
        print(f"{nome:34s} -> {t:5d} iterações")
    else:
        print(f"{nome:34s} -> não atingiu em 20000; menor f visto = {menor:.2e}")

# Correção de viés do Adam: primeiro passo com gradientes de escalas muito diferentes
print("\nPrimeiro passo do Adam (lr = 0,1) em cada coordenada, por escala do gradiente:")
for escala in (1e-3, 1.0, 1e3):
    g = escala
    m, v = 0.1 * g, 0.001 * g ** 2                      # estimativas sem correção, t = 1
    mh, vh = m / (1 - 0.9), v / (1 - 0.999)             # com correção
    passo_sem = 0.1 * m / (np.sqrt(v) + 1e-8)
    passo_com = 0.1 * mh / (np.sqrt(vh) + 1e-8)
    print(f"  |g| = {escala:7.0e}: sem correção {passo_sem:.4f}   com correção {passo_com:.4f}")

# Valores de f ao longo das primeiras 300 iterações (usados na figura 6.2)
historicos = {nome: [f(x) for _, x in zip(range(300), g)] for nome, g in
              {"gd": gd(2 / 101), "momentum": momentum(0.0100, 0.9), "rmsprop": rmsprop(0.05), "adam": adam(0.5)}.items()}
np.savez("/tmp/hist_otim.npz", **{k: np.array(v) for k, v in historicos.items()})
