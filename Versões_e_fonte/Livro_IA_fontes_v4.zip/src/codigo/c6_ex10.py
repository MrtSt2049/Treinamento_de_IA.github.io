import numpy as np

# Velocidade do momentum (β = 0,9) com gradiente constante e com gradiente de sinal alternado
beta, g = 0.9, 1.0
v_const = v_alt = 0.0
for t in range(1, 201):
    v_const = beta * v_const + g
    v_alt = beta * v_alt + g * (-1) ** t
print(f"gradiente constante: |v| após 200 passos = {abs(v_const):.4f}  (previsto g/(1-β) = {g/(1-beta):.4f})")
print(f"gradiente alternado: |v| após 200 passos = {abs(v_alt):.4f}  (previsto g/(1+β) = {g/(1+beta):.4f})")

# Dois primeiros passos do Adam com g1 = 2, g2 = -1
b1, b2 = 0.9, 0.999
m = v = 0.0
for t, g in enumerate([2.0, -1.0], start=1):
    m = b1 * m + (1 - b1) * g
    v = b2 * v + (1 - b2) * g ** 2
    mh, vh = m / (1 - b1 ** t), v / (1 - b2 ** t)
    print(f"t = {t}: m = {m:.5f}  v = {v:.6f}  m̂ = {mh:.5f}  v̂ = {vh:.5f}  passo/η = {mh / (np.sqrt(vh) + 1e-8):.5f}")
