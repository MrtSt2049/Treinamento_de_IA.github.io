import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

rng = np.random.default_rng(0)
X = rng.normal(size=(60, 5000))               # 5000 variáveis de ruído puro
y = rng.integers(0, 2, size=60)               # rótulos sorteados: nada a aprender

# ERRADO: escolher as 20 "melhores" variáveis usando todos os dados, e só depois validar
X_sel = SelectKBest(f_classif, k=20).fit_transform(X, y)
errado = cross_val_score(LogisticRegression(), X_sel, y, cv=5).mean()

# CERTO: a seleção faz parte do modelo e é refeita dentro de cada partição
pipeline = make_pipeline(SelectKBest(f_classif, k=20), LogisticRegression())
certo = cross_val_score(pipeline, X, y, cv=5).mean()

print(f"seleção fora da validação cruzada  : acurácia = {errado:.3f}")
print(f"seleção dentro da validação cruzada: acurácia = {certo:.3f}")
print("acurácia real de qualquer modelo nestes dados: 0.500")
