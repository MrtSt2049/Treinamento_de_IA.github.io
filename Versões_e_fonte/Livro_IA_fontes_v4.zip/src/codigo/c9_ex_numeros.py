"""Conferência numérica de exercícios do Capítulo 9."""
import numpy as np

# 9.1 atenção à mão: q = (1,1); chaves (1,0), (0,1), (-1,0); valores (2,0), (0,4), (6,6); d_k = 2
q = np.array([1.0, 1.0]); K = np.array([[1, 0], [0, 1], [-1, 0.0]]); V = np.array([[2, 0], [0, 4], [6, 6.0]])
s = K @ q / np.sqrt(2); w = np.exp(s) / np.exp(s).sum()
print("9.1  pontuações", np.round(s, 4), "pesos", np.round(w, 4), "saída", np.round(w @ V, 4))

# 9.2 e 9.11 parâmetros
mha = lambda d: 4 * d * d + 4 * d
bloco = lambda d: 12 * d * d + 13 * d
modelo = lambda V_, P, N, d: V_ * d + P * d + N * bloco(d) + 2 * d
print("9.2  MHA d=512:", mha(512), "| bloco d=512:", bloco(512))
print("9.11 V=32000, P=2048, N=24, d=1024:", modelo(32000, 2048, 24, 1024), f"= {modelo(32000, 2048, 24, 1024) / 1e6:.1f} milhões")

# 9.5 cache: N = 24, d = 2048, float16, T = 8192, lote 4
por_token = 2 * 24 * 2048 * 2
print(f"9.5  cache por token {por_token} B = {por_token / 1024:.0f} KiB; por sequência de 8192: {por_token * 8192 / 2 ** 30:.2f} GiB; lote 4: {4 * por_token * 8192 / 2 ** 30:.2f} GiB")

# 9.9 codificação posicional com d = 4
omega = np.array([1.0, 0.01])
pe = lambda p: np.array([np.sin(omega[0] * p), np.cos(omega[0] * p), np.sin(omega[1] * p), np.cos(omega[1] * p)])
print("9.9  PE(0) =", np.round(pe(0), 4), "PE(1) =", np.round(pe(1), 4), "PE(0).PE(1) =", round(float(pe(0) @ pe(1)), 4), "= sum cos(w_i) =", round(float(np.cos(omega).sum()), 4))

# 9.12 o termo quadrático iguala o linear em T = 6d
for d in (768, 4096):
    print(f"9.12 d = {d}: 4 T^2 d = 24 T d^2 em T = {6 * d}")
