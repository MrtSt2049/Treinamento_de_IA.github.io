"""Exercício 9.13: um bloco Transformer pré-LN completo, sem codificação posicional, é equivariante a permutações; com a posição somada, não é."""
import torch
from torch import nn

torch.manual_seed(0)
d, h, T = 32, 4, 9


class Bloco(nn.Module):
    def __init__(self):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.att = nn.MultiheadAttention(d, h, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, x, causal=False):
        m = torch.triu(torch.ones(T, T, dtype=torch.bool), 1) if causal else None
        z = self.ln1(x)
        x = x + self.att(z, z, z, attn_mask=m, need_weights=False)[0]
        return x + self.ffn(self.ln2(x))


b = Bloco().eval()
x = torch.randn(1, T, d)
perm = torch.randperm(T)
with torch.no_grad():
    print(f"sem máscara, sem posição : max|f(Px) - P f(x)| = {(b(x[:, perm]) - b(x)[:, perm]).abs().max().item():.1e}   (equivariante)")
    print(f"com máscara causal       : max|f(Px) - P f(x)| = {(b(x[:, perm], True) - b(x, True)[:, perm]).abs().max().item():.1e}   (a máscara depende da ordem)")
    pos = torch.randn(1, T, d)                                 # posição somada à entrada
    print(f"com posição somada       : max|f(P(x+e)) - P f(x+e)| = {(b(x[:, perm] + pos) - b(x + pos)[:, perm]).abs().max().item():.1e}   (a posição quebra a simetria: P age só em x, não em e)")
