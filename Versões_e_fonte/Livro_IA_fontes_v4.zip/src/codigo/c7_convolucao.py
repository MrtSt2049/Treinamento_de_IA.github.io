import numpy as np
import torch
import torch.nn.functional as F


def correlacao2d(x, k, stride=1, padding=0):
    """Convolução de redes neurais (na verdade, correlação cruzada) de uma imagem 2D por um filtro 2D."""
    x = np.pad(x, padding)
    kh, kw = k.shape
    h = (x.shape[0] - kh) // stride + 1
    w = (x.shape[1] - kw) // stride + 1
    saida = np.zeros((h, w))
    for i in range(h):
        for j in range(w):
            trecho = x[i * stride:i * stride + kh, j * stride:j * stride + kw]
            saida[i, j] = (trecho * k).sum()
    return saida


rng = np.random.default_rng(0)
x = rng.normal(size=(9, 9))
k = rng.normal(size=(3, 3))

# 1. Confere com a convolução do PyTorch e com a fórmula do tamanho da saída
print("tamanho da saída: (H + 2P - K)/S + 1")
for stride, padding in [(1, 0), (1, 1), (2, 0), (2, 1)]:
    mia = correlacao2d(x, k, stride, padding)
    ref = F.conv2d(torch.tensor(x)[None, None], torch.tensor(k)[None, None], stride=stride, padding=padding)[0, 0].numpy()
    formula = (9 + 2 * padding - 3) // stride + 1
    print(f"  S={stride} P={padding}: saída {mia.shape}, fórmula {formula}x{formula}, "
          f"maior diferença para o PyTorch = {np.abs(mia - ref).max():.1e}")

# 2. Um filtro de bordas (Sobel vertical) em uma imagem sintética: quadrado claro sobre fundo escuro
img = np.zeros((8, 8)); img[2:6, 2:6] = 1.0
sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=float)
mapa = correlacao2d(img, sobel_x, padding=1)
np.set_printoptions(linewidth=140)
print("\nimagem (quadrado 4x4):")
print(img.astype(int))
print("mapa de características com o filtro de Sobel vertical:")
print(mapa.astype(int))

# 3. Equivariância a translações: deslocar a entrada desloca a saída (longe das bordas)
x2 = np.zeros((12, 12)); x2[3:6, 3:6] = rng.normal(size=(3, 3))
desloc = np.roll(x2, shift=(2, 3), axis=(0, 1))
a = correlacao2d(x2, k, padding=1)
b = correlacao2d(desloc, k, padding=1)
print("\nequivariância: saída(deslocar(x)) == deslocar(saída(x)):", np.allclose(b, np.roll(a, shift=(2, 3), axis=(0, 1))))

# 4. Convolução verdadeira = correlação com o filtro girado 180 graus
conv_verdadeira = correlacao2d(x, k[::-1, ::-1])
from scipy.signal import convolve2d
print("correlação com filtro girado == convolução matemática (scipy):", np.allclose(conv_verdadeira, convolve2d(x, k, mode="valid")))
