"""Conferência numérica dos exercícios do Capítulo 10."""
import math
from collections import Counter

import numpy as np

# 10.1: BPE à mão sobre um corpus minúsculo (símbolos iniciais = caracteres; desempate: maior contagem, depois maior par)
freq = {"low": 5, "lower": 2, "newest": 6, "widest": 3}
pal = {p: tuple(p) for p in freq}
print("10.1")
for it in range(4):
    pares = Counter()
    for p, s in pal.items():
        for a, b in zip(s, s[1:]):
            pares[(a, b)] += freq[p]
    top = sorted(pares.items(), key=lambda kv: (-kv[1], [-ord(ch) for ch in "".join(kv[0])]))[:3]
    melhor = max(pares.items(), key=lambda kv: (kv[1], kv[0]))[0]
    print(f"  fusão {it + 1}: contagens principais {sorted(pares.items(), key=lambda kv: (-kv[1], kv[0]))[:4]}; escolhido {melhor}")
    for p, s in pal.items():
        i, out = 0, []
        while i < len(s):
            if i < len(s) - 1 and (s[i], s[i + 1]) == melhor:
                out.append(s[i] + s[i + 1]); i += 2
            else:
                out.append(s[i]); i += 1
        pal[p] = tuple(out)
    print("   ", {p: " ".join(s) for p, s in pal.items()})

# 10.2: fração de parâmetros da LoRA
d = k = 4096
for r in (8, 16):
    print(f"10.2  r={r}: {r * (d + k)} parâmetros = {100 * r * (d + k) / (d * k):.3f}% de {d * k}")

# 10.3: memória
P = 1.3e9
print(f"10.3  completo fp32: {16 * P / 1e9:.1f} GB; LoRA com base em 16 bits e p_t = 0,5% de P: {(2 * P + 16 * 0.005 * P) / 1e9:.2f} GB")

# 10.4: quantização de 4 bits
w = np.array([0.9, -0.3, 0.05, -1.2])
q = 7
s = np.abs(w).max() / q
hat = np.round(w / s)
print(f"10.4  s = {s:.5f}; inteiros {hat.astype(int)}; reconstrução {np.round(hat * s, 4)}; erros {np.round(np.abs(hat * s - w), 4)}; s/2 = {s / 2:.4f}")

# 10.6: gradientes da LoRA, exemplo numérico
G = np.array([[1.0, 2.0], [3.0, 4.0]])
A = np.array([[1.0, 1.0]])
B = np.array([[0.5], [-0.5]])
fator = 2.0
print("10.6  dL/dB =", (fator * G @ A.T).ravel(), "; dL/dA =", (fator * B.T @ G).ravel(), "; com B = 0: dL/dA =", (fator * np.zeros((1, 2)) @ G).ravel(), ", dL/dB =", (fator * G @ A.T).ravel())

# 10.8: LoRA em todo o GPT-2 pequeno (d = 768, 12 blocos)
mat = [(768, 2304), (768, 768), (768, 3072), (3072, 768)]
por_bloco = sum(a + b for a, b in mat)
print(f"10.8  por bloco: {por_bloco} r; total 12 blocos: {12 * por_bloco} r; r = 8: {12 * por_bloco * 8} = {100 * 12 * por_bloco * 8 / 124.4e6:.2f}% de 124,4 M")

# 10.9: perplexidade por token para bits por byte
ppl, bytes_tok = 88.6, 23174 / 9158
print(f"10.9  bits por token = {math.log2(ppl):.3f}; bytes por token = {bytes_tok:.2f}; bits por byte = {math.log2(ppl) / bytes_tok:.3f}")

# 10.11: Eckart-Young
sv = np.array([4.0, 3.0, 2.0, 1.0])
tot = (sv ** 2).sum()
for r in (1, 2, 3):
    print(f"10.11 r={r}: erro absoluto {math.sqrt((sv[r:] ** 2).sum()):.4f}; relativo {math.sqrt((sv[r:] ** 2).sum() / tot):.4f}; energia retida {100 * (sv[:r] ** 2).sum() / tot:.1f}%")

# 10.12: primeiro passo de SGD da LoRA com B = 0: Delta W = -eta (alpha/r)^2 G A^T A
eta, alpha_r = 0.1, 2.0
rng = np.random.default_rng(0)
G = rng.normal(size=(3, 4)); A = rng.normal(size=(2, 4))
Bn = -eta * alpha_r * G @ A.T
dW = alpha_r * Bn @ A
print("10.12 DeltaW == -eta (alpha/r)^2 G A^T A:", np.allclose(dW, -eta * alpha_r ** 2 * G @ A.T @ A))
Q, _ = np.linalg.qr(A.T)
A_o = Q.T                                                      # linhas ortonormais
print("      com linhas ortonormais, A^T A é projetor:", np.allclose((A_o.T @ A_o) @ (A_o.T @ A_o), A_o.T @ A_o))
