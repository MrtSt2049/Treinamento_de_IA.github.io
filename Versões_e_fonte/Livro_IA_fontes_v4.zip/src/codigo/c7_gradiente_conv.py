import numpy as np
import torch


def correlacao_valida(x, k):
    kh, kw = k.shape
    h, w = x.shape[0] - kh + 1, x.shape[1] - kw + 1
    return np.array([[(x[i:i + kh, j:j + kw] * k).sum() for j in range(w)] for i in range(h)])


rng = np.random.default_rng(0)
x = rng.normal(size=(7, 7))
k = rng.normal(size=(3, 3))
y = correlacao_valida(x, k)                       # forma 5x5
g = rng.normal(size=y.shape)                      # gradiente que chega da camada seguinte: ∂L/∂y

# ---- retropropagação da camada convolucional (Proposição 7.2) ----
grad_k = correlacao_valida(x, g)                  # ∂L/∂k = correlação da entrada com ∂L/∂y
g_cheio = np.pad(g, 2)                            # preenchimento K-1 = 2 em cada borda
grad_x = correlacao_valida(g_cheio, k[::-1, ::-1])  # ∂L/∂x = correlação de ∂L/∂y (preenchido) com o filtro girado 180°

# ---- conferência com o autograd ----
tx = torch.tensor(x, requires_grad=True)
tk = torch.tensor(k, requires_grad=True)
ty = torch.nn.functional.conv2d(tx[None, None], tk[None, None])[0, 0]
(ty * torch.tensor(g)).sum().backward()

print("formas: x", x.shape, "k", k.shape, "y", y.shape)
print(f"∂L/∂k: maior diferença para o autograd = {np.abs(grad_k - tk.grad.numpy()).max():.1e}")
print(f"∂L/∂x: maior diferença para o autograd = {np.abs(grad_x - tx.grad.numpy()).max():.1e}")
