import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

dados = load_breast_cancer()
X, y = dados.data[:, :4], (dados.target == 0).astype(int)      # positivo = maligno
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.4, random_state=0, stratify=y)
modelo = make_pipeline(StandardScaler(), LogisticRegression()).fit(X_tr, y_tr)
escore = modelo.predict_proba(X_te)[:, 1]                       # P(maligno | x)


def metricas(y, escore, limiar):
    pred = (escore >= limiar).astype(int)
    vp = int(np.sum((pred == 1) & (y == 1)))
    fp = int(np.sum((pred == 1) & (y == 0)))
    fn = int(np.sum((pred == 0) & (y == 1)))
    vn = int(np.sum((pred == 0) & (y == 0)))
    precisao = vp / (vp + fp)
    recall = vp / (vp + fn)
    return vp, fp, fn, vn, (vp + vn) / y.size, precisao, recall, 2 * precisao * recall / (precisao + recall)


print("limiar   VP   FP   FN   VN   acurácia   precisão   recall      F1")
for limiar in (0.2, 0.5, 0.8):
    vp, fp, fn, vn, acc, prec, rec, f1 = metricas(y_te, escore, limiar)
    print(f"{limiar:6.1f}  {vp:3d}  {fp:3d}  {fn:3d}  {vn:3d}   {acc:8.4f}   {prec:8.4f}   {rec:6.4f}  {f1:6.4f}")

pred = (escore >= 0.5).astype(int)
vp, fp, fn, vn, acc, prec, rec, f1 = metricas(y_te, escore, 0.5)
print("confere com sklearn:", confusion_matrix(y_te, pred).ravel().tolist() == [vn, fp, fn, vp],
      np.isclose(prec, precision_score(y_te, pred)), np.isclose(rec, recall_score(y_te, pred)),
      np.isclose(f1, f1_score(y_te, pred)))

# AUC como probabilidade de ordenar corretamente um par (positivo, negativo)
pos, neg = escore[y_te == 1], escore[y_te == 0]
auc_pares = np.mean((pos[:, None] > neg[None, :]) + 0.5 * (pos[:, None] == neg[None, :]))
print(f"AUC por pares = {auc_pares:.6f}   roc_auc_score = {roc_auc_score(y_te, escore):.6f}")
