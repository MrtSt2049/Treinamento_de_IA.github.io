import numpy as np

rng = np.random.default_rng(3)
print("   d   média do cosseno   desvio padrão   1/sqrt(d)")
for d in (2, 10, 100, 1000):
    U, V = rng.normal(size=(5000, d)), rng.normal(size=(5000, d))
    cos = np.sum(U * V, axis=1) / (np.linalg.norm(U, axis=1) * np.linalg.norm(V, axis=1))
    print(f"{d:4d}   {cos.mean():+16.4f}   {cos.std():13.4f}   {1 / np.sqrt(d):9.4f}")
