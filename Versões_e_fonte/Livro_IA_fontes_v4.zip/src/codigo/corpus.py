"""Corpus de texto: prosa em português extraída dos originais do próprio livro (Capítulos 1 a 8).

Remove código, equações, tabelas, figuras e marcações dos contêineres; devolve parágrafos de prosa.
"""
import pathlib
import re

SRC = pathlib.Path(__file__).resolve().parent.parent
ARQ = {  # capítulo -> arquivos de texto
    1: ["01a-algebra.md", "01b-calculo.md", "01c-probabilidade.md", "01d-projeto-exercicios.md"],
    2: ["02a-agentes.md", "02b-exercicios.md"],
    3: ["03-formulacao.md"], 4: ["04-modelos.md"], 5: ["05-avaliacao.md"],
    6: ["06a-neuronio.md", "06b-backprop.md", "06c-pytorch-projetos.md", "06d-exercicios.md"],
    7: ["07a-convolucao.md", "07b-arquiteturas.md", "07c-projeto-exercicios.md"],
    8: ["08a-rnn.md", "08b-lstm-gru.md", "08c-projeto-exercicios.md"],
}


def limpar(texto):
    texto = re.sub(r"```.*?```", " ", texto, flags=re.S)            # blocos de código
    texto = re.sub(r"\$\$.*?\$\$", " ", texto, flags=re.S)           # equações destacadas
    texto = re.sub(r"\$[^$\n]+\$", " ", texto)                        # equações no texto
    texto = re.sub(r"^(<<<|>>>|\+\+\+).*$", " ", texto, flags=re.M)  # inclusões
    texto = re.sub(r"<[^>]+>", " ", texto)                            # HTML
    texto = re.sub(r"^:::.*$", " ", texto, flags=re.M)                # contêineres
    texto = re.sub(r"^\|.*$", " ", texto, flags=re.M)                 # tabelas
    texto = re.sub(r"[*_`#>]", "", texto)                             # marcas de markdown
    texto = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", texto)
    paragrafos = []
    for p in re.split(r"\n\s*\n", texto):
        p = re.sub(r"\s+", " ", p).strip()
        if len(p) >= 80 and sum(c.isalpha() for c in p) / len(p) > 0.7:
            paragrafos.append(p)
    return paragrafos


def carregar(capitulos):
    """Lista de parágrafos dos capítulos pedidos (em ordem)."""
    saida = []
    for c in capitulos:
        for arq in ARQ[c]:
            f = SRC / arq
            if f.exists():
                saida += limpar(f.read_text(encoding="utf-8"))
    return saida


if __name__ == "__main__":
    for c in ARQ:
        ps = carregar([c])
        print(f"capítulo {c}: {len(ps):4d} parágrafos, {sum(map(len, ps)) / 1000:7.1f} mil caracteres")
    ps = carregar(list(ARQ))
    print(f"total: {len(ps)} parágrafos, {sum(map(len, ps)) / 1000:.1f} mil caracteres, {len(set(''.join(ps)))} caracteres distintos")
    print("exemplo:", ps[len(ps) // 2][:200])
