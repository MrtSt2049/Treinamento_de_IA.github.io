"""Custo quadrático da autoatenção e cache de chaves e valores (KV cache) na geração."""
import time
import torch
import torch.nn.functional as F
from transformers import GPT2Config, GPT2LMHeadModel

torch.manual_seed(0)
torch.set_num_threads(2)

# 1) tempo e memória da matriz de atenção em função do comprimento T (uma camada, 8 cabeças, d_k = 64)
print("   T   tempo (ms)   razão   matriz T x T (MiB, float32, 8 cabeças)")
ant = None
for T in (256, 512, 1024, 2048, 4096):
    q = k = v = torch.randn(1, 8, T, 64)
    F.scaled_dot_product_attention(q, k, v, is_causal=True)             # aquecimento
    t0 = time.perf_counter()
    for _ in range(3):
        F.scaled_dot_product_attention(q, k, v, is_causal=True)
    ms = (time.perf_counter() - t0) / 3 * 1e3
    print(f"{T:5d}  {ms:9.1f}  {'' if ant is None else f'{ms / ant:5.2f}x'}   {8 * T * T * 4 / 2 ** 20:8.1f}")
    ant = ms

# 2) a geração com e sem cache produz exatamente os mesmos tokens
cfg = GPT2Config(vocab_size=200, n_positions=512, n_embd=128, n_layer=4, n_head=4, bos_token_id=0, eos_token_id=0, pad_token_id=0)
m = GPT2LMHeadModel(cfg).eval()
prompt = torch.randint(1, 200, (1, 16))
res = {}
for cache in (True, False):
    t0 = time.perf_counter()
    with torch.no_grad():
        res[cache] = m.generate(prompt, max_new_tokens=300, do_sample=False, use_cache=cache, min_new_tokens=300)
    res[(cache, "t")] = time.perf_counter() - t0
print(f"\nmesmos tokens com e sem cache: {bool((res[True] == res[False]).all())}")
print(f"tempo para gerar 300 tokens: com cache {res[(True, 't')]:.2f} s; sem cache {res[(False, 't')]:.2f} s  (razão {res[(False, 't')] / res[(True, 't')]:.1f}x)")

# 3) contagem de produtos escalares q.k para gerar T tokens (uma cabeça, uma camada)
for T in (100, 1000, 10000):
    sem = sum(t * (t + 1) // 2 for t in range(1, T + 1))   # recalcula tudo a cada passo (com máscara causal)
    com = sum(t for t in range(1, T + 1))                                                                         # só a consulta nova contra t chaves
    print(f"T = {T:6d}: produtos q.k sem cache {sem:.3e}, com cache {com:.3e}  (razão {sem / com:8.1f}x)")

# 4) memória do cache: 2 (K e V) x camadas x T x d x bytes
for nome, (N, d) in {"minúsculo (N=4, d=128)": (4, 128), "tipo GPT-2 pequeno (N=12, d=768)": (12, 768), "N=32, d=4096": (32, 4096)}.items():
    print(f"cache por token, {nome:34s}: {2 * N * d * 2 / 1024:8.1f} KiB em float16; para T=4096: {2 * N * d * 2 * 4096 / 2 ** 20:8.1f} MiB")
