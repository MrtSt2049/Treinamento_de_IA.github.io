import numpy as np
import torch

# Rede 2-2-3: x ∈ R², camada oculta com 2 ReLU, saída com 3 logits e softmax; exemplo da classe k = 2
x = np.array([1.0, 2.0])
W1 = np.array([[0.5, -1.0], [1.5, 0.5]]); b1 = np.array([0.1, -0.2])
W2 = np.array([[1.0, -1.0, 0.5], [0.5, 2.0, -1.0]]); b2 = np.array([0.0, 0.1, -0.1])
k = 2
np.set_printoptions(precision=5, suppress=True)

# ---- passo para frente ----
z1 = x @ W1 + b1
h1 = np.maximum(0, z1)
a = h1 @ W2 + b2
p = np.exp(a - a.max()) / np.exp(a - a.max()).sum()
L = -np.log(p[k])
print("z1 =", z1, "\nh1 =", h1, "\na  =", a, "\np  =", p, f"\nL  = {L:.5f}")

# ---- passo para trás ----
y = np.eye(3)[k]
d2 = p - y                                   # ∂L/∂a
gW2, gb2 = np.outer(h1, d2), d2              # ∂L/∂W2 = h1 d2ᵀ
d1 = (W2 @ d2) * (z1 > 0)                    # ∂L/∂z1
gW1, gb1 = np.outer(x, d1), d1
print("\nδ² =", d2, "\nδ¹ =", d1)
print("∂L/∂W² =\n", gW2, "\n∂L/∂W¹ =\n", gW1)

# ---- conferência com autograd ----
t = lambda v: torch.tensor(v, dtype=torch.float64, requires_grad=True)
tW1, tb1, tW2, tb2 = t(W1), t(b1), t(W2), t(b2)
logits = torch.relu(torch.tensor(x) @ tW1 + tb1) @ tW2 + tb2
torch.nn.functional.cross_entropy(logits[None], torch.tensor([k])).backward()
dif = max(np.abs(tW1.grad.numpy() - gW1).max(), np.abs(tb1.grad.numpy() - gb1).max(),
          np.abs(tW2.grad.numpy() - gW2).max(), np.abs(tb2.grad.numpy() - gb2).max())
print(f"\nmaior diferença para o autograd do PyTorch: {dif:.1e}")
