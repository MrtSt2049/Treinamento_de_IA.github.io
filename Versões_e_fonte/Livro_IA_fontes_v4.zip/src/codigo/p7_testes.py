"""Testes automáticos do Projeto 7 (rápidos; executar depois do pré-treino)."""
import copy
import math

import numpy as np
import torch
from peft import LoraConfig, get_peft_model
from transformers import GPT2LMHeadModel

from c10_quant import quantizar
from p7_comum import BASE, BLOCO, VOCAB, blocos, contar, dados, novo_modelo, perda, treinar

d, tok, ds, ntok = dados()
ok = []


def teste(nome, cond):
    ok.append(cond)
    print(("PASSOU  " if cond else "FALHOU  ") + nome, flush=True)


# 1. divisão sem vazamento: os conjuntos de parágrafos são disjuntos e o domínio-alvo não entrou no tokenizador
conj = {k: set(v) for k, v in d.items()}
teste("conjuntos de parágrafos disjuntos (treino, validação e teste de cada domínio, e entre domínios)",
      all(not (conj[a] & conj[b]) for a in conj for b in conj if a < b))
teste(f"o tokenizador tem o vocabulário pedido ({VOCAB}); foi treinado só com o treino da origem (ver p7_comum.dados)", tok.get_vocab_size() == VOCAB)

# 2. tokenização sem perdas e sem token desconhecido (BPE em bytes)
amostra = d["alvo_te"][:50] + ["∑ 日本 ação"]
teste("decodificar(codificar(x)) == x em 51 parágrafos (inclui símbolos nunca vistos)", all(tok.decode(tok.encode(p).ids) == p for p in amostra))

# 3. formas dos dados
x = torch.tensor(ds["alvo_va"]["input_ids"])
teste(f"blocos têm forma (n, {BLOCO}) e identificadores em [0, {VOCAB})", x.shape[1] == BLOCO and int(x.max()) < VOCAB and int(x.min()) >= 0)

# 4. a perda inicial é próxima de ln V (modelo sem treino)
torch.manual_seed(0)
m0 = novo_modelo()
teste("perda inicial perto de ln V (dentro de 5%)", abs(perda(m0, ds["orig_va"]) - math.log(VOCAB)) / math.log(VOCAB) < 0.05)

# 5. LoRA: saída idêntica no início, contagem de parâmetros e base congelada
base = GPT2LMHeadModel.from_pretrained(BASE).eval()
pm = get_peft_model(copy.deepcopy(base), LoraConfig(r=4, lora_alpha=8, target_modules=["c_attn", "c_proj", "c_fc"], fan_in_fan_out=True, lora_dropout=0.0, task_type="CAUSAL_LM")).eval()
xb = x[:4]
with torch.no_grad():
    teste("LoRA com B = 0: logits idênticos aos do modelo base", torch.allclose(base(xb).logits, pm(xb).logits, atol=1e-5))
_, trein = contar(pm)
esperado = 4 * 4 * (128 + 384 + 128 + 128 + 128 + 512 + 512 + 128)          # r * soma de (d + k) por matriz, 4 blocos
teste(f"parâmetros treináveis da LoRA = r·Σ(d+k) = {esperado}", trein == esperado)
pm.train()
antes = {n: p.detach().clone() for n, p in pm.named_parameters() if "lora" not in n}
treinar(pm, ds["alvo_tr"], ds["alvo_va"], passos=5, lr=1e-2, seed=0, aquecimento=1, eval_cada=5)
teste("após treinar, a base (pesos fora dos adaptadores) permanece intacta", all(torch.equal(antes[n], p) for n, p in pm.named_parameters() if "lora" not in n))
teste("após treinar, os adaptadores B deixaram de ser nulos", any(float(p.abs().max()) > 0 for n, p in pm.named_parameters() if "lora_B" in n))
fund = copy.deepcopy(pm).merge_and_unload().eval()
pm.eval()
with torch.no_grad():
    teste("fusão (merge_and_unload) preserva os logits (erro < 1e-3)", float((fund(xb).logits - pm(xb).logits).abs().max()) < 1e-3)

# 6. quantização: cota |erro| <= s/2 e erro maior com menos bits
W = np.random.default_rng(0).normal(0, 0.05, (256, 64))
Wq8, _ = quantizar(W, 8, "tensor")
Wq4, _ = quantizar(W, 4, "tensor")
teste("quantização absmax: |erro| <= s/2 (8 bits)", np.abs(W - Wq8).max() <= np.abs(W).max() / 127 / 2 + 1e-12)
teste("menos bits, mais erro (4 bits > 8 bits)", np.linalg.norm(W - Wq4) > np.linalg.norm(W - Wq8))

print(f"\n{sum(ok)} de {len(ok)} testes passaram")
