import warnings
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

dados = load_breast_cancer()
X = StandardScaler().fit_transform(dados.data[:, [0, 1]])   # raio médio e textura média
y = (dados.target == 0).astype(float)                       # 1 = maligno
Xb = np.column_stack([np.ones(X.shape[0]), X])


def sigmoide(z):
    return 1.0 / (1.0 + np.exp(-z))


def perda(beta):
    p = np.clip(sigmoide(Xb @ beta), 1e-12, 1 - 1e-12)
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))


# Código didático: descida do gradiente na entropia cruzada
beta = np.zeros(3)
for passo in range(5000):
    gradiente = Xb.T @ (sigmoide(Xb @ beta) - y) / y.size
    beta -= 1.0 * gradiente
print("descida do gradiente:", np.round(beta, 4), f"perda = {perda(beta):.5f}")

# Código de produção: scikit-learn sem regularização
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    clf = LogisticRegression(C=np.inf, max_iter=1000).fit(X, y)
beta_sk = np.concatenate([clf.intercept_, clf.coef_[0]])
print("scikit-learn        :", np.round(beta_sk, 4), f"perda = {perda(beta_sk):.5f}")

print("odds ratios (por desvio padrão):", np.round(np.exp(beta[1:]), 2))
print(f"acurácia no treino: {np.mean((sigmoide(Xb @ beta) >= 0.5) == y):.4f}")
