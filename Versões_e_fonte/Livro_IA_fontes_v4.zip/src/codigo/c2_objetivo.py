"""Agente baseado em objetivos: planeja um caminho por busca em largura."""
from collections import deque

MAPA = ["I..#....",
        ".#.#.##.",
        ".#...#..",
        ".####.#.",
        "......#O"]          # I = início, O = objetivo, # = parede


def localizar(simbolo):
    for i, linha in enumerate(MAPA):
        if simbolo in linha:
            return i, linha.index(simbolo)


def vizinhos(estado):
    """Modelo de transição: movimentos válidos a partir de um estado."""
    i, j = estado
    for acao, (di, dj) in {"N": (-1, 0), "S": (1, 0), "L": (0, 1), "O": (0, -1)}.items():
        ni, nj = i + di, j + dj
        if 0 <= ni < len(MAPA) and 0 <= nj < len(MAPA[0]) and MAPA[ni][nj] != "#":
            yield acao, (ni, nj)


def busca_em_largura(inicio, objetivo):
    """Retorna o plano com menor número de ações, ou None se não houver."""
    fronteira = deque([inicio])
    origem = {inicio: None}                  # estado -> (estado anterior, ação)
    while fronteira:
        estado = fronteira.popleft()
        if estado == objetivo:
            plano = []
            while origem[estado] is not None:
                estado, acao = origem[estado]
                plano.append(acao)
            return plano[::-1]
        for acao, proximo in vizinhos(estado):
            if proximo not in origem:
                origem[proximo] = (estado, acao)
                fronteira.append(proximo)
    return None


if __name__ == "__main__":
    plano = busca_em_largura(localizar("I"), localizar("O"))
    print("plano:", "".join(plano))
    print("número de ações:", len(plano))
