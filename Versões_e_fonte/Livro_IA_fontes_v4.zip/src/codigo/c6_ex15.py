import numpy as np
import torch
from projeto4 import Rede, avaliar, dados, treinar

print("Sensibilidade à taxa de aprendizado do Adam (MLP 64-256-256-10, 300 exemplos, 3 sementes)")
print(f"{'η':>8s} {'perda val':>11s} {'acc. val':>10s} {'acc. teste':>11s} {'época*':>7s}")
for lr in (1e-4, 1e-3, 1e-2, 1e-1, 1.0):
    r = []
    for s in range(3):
        treino, val, teste = dados(semente=s)
        torch.manual_seed(s)
        m = Rede()
        ep = treinar(m, treino, val, lr=lr, semente=s)
        pv, av = avaliar(m, *val)
        r.append([pv, av, avaliar(m, *teste)[1], ep])
    r = np.array(r).mean(axis=0)
    print(f"{lr:8.0e} {r[0]:11.4f} {r[1]:10.4f} {r[2]:11.4f} {r[3]:7.1f}")
