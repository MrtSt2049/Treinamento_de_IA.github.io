import numpy as np

rng = np.random.default_rng(0)


def softmax(a):
    e = np.exp(a - a.max())
    return e / e.sum()


def entropia_cruzada(a, k):
    """-log softmax(a)_k via log-sum-exp (estável)."""
    m = a.max()
    return -(a[k] - m - np.log(np.exp(a - m).sum()))


a = rng.normal(size=5)
k = 2
y = np.eye(5)[k]
analitico = softmax(a) - y                       # resultado da seção 6.4

eps = 1e-6
numerico = np.zeros(5)
for i in range(5):
    d = np.zeros(5); d[i] = eps
    numerico[i] = (entropia_cruzada(a + d, k) - entropia_cruzada(a - d, k)) / (2 * eps)

np.set_printoptions(precision=8, suppress=True)
print("∂L/∂a analítico (p - y):", analitico)
print("∂L/∂a numérico         :", numerico)
print("erro relativo           : %.2e" % (np.linalg.norm(analitico - numerico) / np.linalg.norm(analitico + numerico)))

# estabilidade: log(softmax) ingênuo vs log-sum-exp para logits extremos
a = np.array([-1000.0, 0.0, 1000.0])
with np.errstate(all="ignore"):
    ingenuo = -np.log(np.exp(a[0]) / np.exp(a).sum())
print("\nlogits [-1000, 0, 1000], classe 0:")
print("  -log(softmax) ingênuo :", ingenuo)
print("  log-sum-exp estável   :", entropia_cruzada(a, 0))
