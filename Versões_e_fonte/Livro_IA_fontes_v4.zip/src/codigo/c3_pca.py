import numpy as np
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA

X = load_iris().data                           # (150, 4)
Xc = X - X.mean(axis=0)                        # centralização

# Código didático: autovetores da matriz de covariância
S = Xc.T @ Xc / (X.shape[0] - 1)
autovalores, V = np.linalg.eigh(S)
ordem = np.argsort(autovalores)[::-1]          # maior variância primeiro
autovalores, V = autovalores[ordem], V[:, ordem]
Z = Xc @ V[:, :2]                              # projeção em 2 componentes

print("variância explicada (didático):", np.round(autovalores / autovalores.sum(), 4))

# Código de produção
pca = PCA(n_components=2).fit(X)
print("variância explicada (sklearn) :", np.round(pca.explained_variance_ratio_, 4))
Z_sk = pca.transform(X)
print("mesmas projeções, a menos do sinal:", np.allclose(np.abs(Z), np.abs(Z_sk)))
print("variância das projeções:", np.round(Z.var(axis=0, ddof=1), 4), "= autovalores",
      np.round(autovalores[:2], 4))
