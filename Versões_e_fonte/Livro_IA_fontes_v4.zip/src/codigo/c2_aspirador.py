"""Mundo do aspirador com duas salas: agente reativo simples e agente baseado em modelo."""
import random

SALAS = ("A", "B")


class Ambiente:
    """Duas salas; o agente percebe apenas a sala em que está e se ela está suja."""

    def __init__(self, sujeira, posicao, custo_movimento=0.0):
        self.sujeira = dict(sujeira)          # {"A": True, "B": False}
        self.posicao = posicao
        self.custo_movimento = custo_movimento
        self.desempenho = 0.0

    def percepcao(self):
        return self.posicao, self.sujeira[self.posicao]

    def executar(self, acao):
        if acao == "Aspirar":
            self.sujeira[self.posicao] = False
        elif acao in ("Direita", "Esquerda"):
            self.posicao = "B" if acao == "Direita" else "A"
            self.desempenho -= self.custo_movimento
        # Medida de desempenho: 1 ponto por sala limpa a cada passo de tempo
        self.desempenho += sum(not suja for suja in self.sujeira.values())


def agente_reativo(percepcao):
    """Regras condição-ação sobre a percepção atual; não guarda memória."""
    posicao, suja = percepcao
    if suja:
        return "Aspirar"
    return "Direita" if posicao == "A" else "Esquerda"


class AgenteComModelo:
    """Mantém um estado interno: o que sabe sobre cada sala."""

    def __init__(self):
        self.limpa = {"A": None, "B": None}   # None = ainda não observada

    def __call__(self, percepcao):
        posicao, suja = percepcao
        self.limpa[posicao] = not suja        # atualiza o estado com o sensor
        if suja:
            self.limpa[posicao] = True        # modelo: aspirar deixa a sala limpa
            return "Aspirar"
        outra = "B" if posicao == "A" else "A"
        if self.limpa[outra]:                 # modelo: sujeira não reaparece
            return "NoOp"
        return "Direita" if posicao == "A" else "Esquerda"


def simular(criar_agente, custo_movimento, passos=20):
    """Média do desempenho nas 8 configurações iniciais possíveis."""
    total = 0.0
    for suja_a in (True, False):
        for suja_b in (True, False):
            for posicao in SALAS:
                ambiente = Ambiente({"A": suja_a, "B": suja_b}, posicao, custo_movimento)
                agente = criar_agente()
                for _ in range(passos):
                    ambiente.executar(agente(ambiente.percepcao()))
                total += ambiente.desempenho
    return total / 8


if __name__ == "__main__":
    for custo in (0.0, 1.0):
        reativo = simular(lambda: agente_reativo, custo)
        modelo = simular(AgenteComModelo, custo)
        print(f"custo por movimento = {custo}:  reativo = {reativo:6.2f}   "
              f"baseado em modelo = {modelo:6.2f}")
