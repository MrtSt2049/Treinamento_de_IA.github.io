import numpy as np
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs

X, _ = make_blobs(n_samples=600, centers=3, cluster_std=1.0, random_state=4)


def kmeans(X, k, semente=0, max_iter=100):
    """Algoritmo de Lloyd. Retorna centros, rótulos e histórico do objetivo."""
    rng = np.random.default_rng(semente)
    centros = X[rng.choice(X.shape[0], size=k, replace=False)]
    historico = []
    for _ in range(max_iter):
        # Passo 1: cada ponto vai para o centro mais próximo
        d2 = ((X[:, None, :] - centros[None, :, :]) ** 2).sum(axis=2)   # (n, k)
        rotulos = d2.argmin(axis=1)
        historico.append(d2[np.arange(X.shape[0]), rotulos].sum())
        # Passo 2: cada centro vai para a média dos seus pontos
        novos = np.array([X[rotulos == j].mean(axis=0) for j in range(k)])
        if np.allclose(novos, centros):
            break
        centros = novos
    return centros, rotulos, np.array(historico)


centros, rotulos, hist = kmeans(X, k=3)
print("objetivo por iteração:", np.round(hist, 1))
print("nunca aumenta:", bool(np.all(np.diff(hist) <= 1e-9)))

km = KMeans(n_clusters=3, n_init=10, random_state=0).fit(X)
print(f"objetivo final (didático) = {hist[-1]:.1f}   inertia_ (sklearn) = {km.inertia_:.1f}")

print("objetivo para k = 1..6:",
      [round(KMeans(n_clusters=k, n_init=10, random_state=0).fit(X).inertia_) for k in range(1, 7)])
