"""Exercício 9.14: gradiente da perda em relação às pontuações S e em relação a Q, com e sem a escala 1/sqrt(d_k)."""
import torch

torch.manual_seed(0)
T, REP = 16, 300
print("        ||dL/dS||                   ||dL/dQ||                  prob. máx. média")
print("d_k   com esc.  sem esc.  razão   com esc.  sem esc.  razão   com esc.  sem esc.")
for dk in (4, 16, 64, 256, 1024):
    res = {}
    for escala in (True, False):
        gS, gQ, pm = [], [], []
        for _ in range(REP):
            Q = torch.randn(T, dk, requires_grad=True)
            K, V = torch.randn(T, dk), torch.randn(T, 8)
            S = Q @ K.T / (dk ** 0.5 if escala else 1.0)
            S.retain_grad()
            A = torch.softmax(S, -1)
            (A @ V).pow(2).sum().backward()                     # a mesma perda arbitrária nos dois casos
            gS.append(S.grad.norm().item()); gQ.append(Q.grad.norm().item()); pm.append(A.max(-1).values.mean().item())
        res[escala] = [sum(v) / REP for v in (gS, gQ, pm)]
    (a, b), (c, d), (e, f) = zip(res[True], res[False])
    print(f"{dk:4d}  {a:7.3f}  {b:8.3f}  {a / b:5.2f}   {c:7.3f}  {d:8.3f}  {c / d:5.2f}   {e:7.3f}  {f:8.3f}")
