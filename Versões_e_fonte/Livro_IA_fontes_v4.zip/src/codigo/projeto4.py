"""Projeto 4: pipeline de treinamento em PyTorch, com Dropout, BatchNorm, weight decay e checkpoint do melhor modelo."""
import copy
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

from projeto3 import MLP          # a rede em NumPy do Projeto 3

torch.set_num_threads(2)


def dados(semente=0, n_treino=300):
    X, y = load_digits(return_X_y=True)
    X = (X / 16.0).astype(np.float32)
    Xtr, Xr, ytr, yr = train_test_split(X, y, train_size=n_treino, stratify=y, random_state=semente)
    Xva, Xte, yva, yte = train_test_split(Xr, yr, train_size=300, stratify=yr, random_state=semente)
    t = lambda a, dt: torch.tensor(a, dtype=dt)
    return [(t(A, torch.float32), t(b, torch.long)) for A, b in ((Xtr, ytr), (Xva, yva), (Xte, yte))]


class Rede(nn.Module):
    def __init__(self, ocultas=(256, 256), dropout=0.0, batchnorm=False):
        super().__init__()
        camadas, entrada = [], 64
        for h in ocultas:
            camadas.append(nn.Linear(entrada, h))
            if batchnorm:
                camadas.append(nn.BatchNorm1d(h))
            camadas.append(nn.ReLU())
            if dropout > 0:
                camadas.append(nn.Dropout(dropout))
            entrada = h
        camadas.append(nn.Linear(entrada, 10))             # logits; a softmax está dentro da perda
        self.rede = nn.Sequential(*camadas)

    def forward(self, x):
        return self.rede(x)


@torch.no_grad()
def avaliar(modelo, X, y):
    modelo.eval()                                          # desliga Dropout e usa estatísticas acumuladas do BatchNorm
    logits = modelo(X)
    return nn.functional.cross_entropy(logits, y).item(), (logits.argmax(1) == y).float().mean().item()


def treinar(modelo, treino, val, epocas=100, lr=2e-3, wd=0.0, lote=32, semente=0):
    torch.manual_seed(semente)
    carregador = DataLoader(TensorDataset(*treino), batch_size=lote, shuffle=True)
    otim = torch.optim.AdamW(modelo.parameters(), lr=lr, weight_decay=wd)
    melhor, estado, ep_melhor = float("inf"), None, 0
    for ep in range(1, epocas + 1):
        modelo.train()
        for xb, yb in carregador:
            otim.zero_grad()
            perda = nn.functional.cross_entropy(modelo(xb), yb)
            perda.backward()
            otim.step()
        perda_val, _ = avaliar(modelo, *val)
        if perda_val < melhor:                              # checkpoint: guarda o melhor estado na validação
            melhor, estado, ep_melhor = perda_val, copy.deepcopy(modelo.state_dict()), ep
    modelo.load_state_dict(estado)
    return ep_melhor


if __name__ == "__main__":
    # ---------- 1. conferência: o gradiente do PyTorch coincide com o da retropropagação em NumPy ----------
    rng = np.random.default_rng(0)
    Xs, ys = rng.normal(size=(16, 64)), rng.integers(0, 10, size=16)
    npmlp = MLP([64, 32, 10], semente=0)
    gW, gb = npmlp.gradientes(Xs, ys)
    pt = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 10)).double()
    with torch.no_grad():
        for camada, W, b in zip([pt[0], pt[2]], npmlp.W, npmlp.b):
            camada.weight.copy_(torch.tensor(W.T)); camada.bias.copy_(torch.tensor(b))
    nn.functional.cross_entropy(pt(torch.tensor(Xs)), torch.tensor(ys)).backward()
    dif = max(np.abs(pt[0].weight.grad.numpy() - gW[0].T).max(), np.abs(pt[2].weight.grad.numpy() - gW[1].T).max(),
              np.abs(pt[0].bias.grad.numpy() - gb[0]).max(), np.abs(pt[2].bias.grad.numpy() - gb[1]).max())
    print(f"1. maior diferença entre gradientes (PyTorch vs NumPy): {dif:.2e}")
    assert dif < 1e-12

    # ---------- 2. ablação em regime de poucos dados: 300 exemplos de treino ----------
    variantes = {
        "base (MLP 64-256-256-10)":      dict(),
        "+ Dropout 0,3":                 dict(dropout=0.3),
        "+ BatchNorm":                   dict(batchnorm=True),
        "+ weight decay 1e-2":           dict(wd=1e-2),
        "Dropout + BatchNorm + wd":      dict(dropout=0.3, batchnorm=True, wd=1e-2),
    }
    sementes = range(5)
    print(f"\n2. Ablação (300 exemplos de treino, 300 de validação, 1197 de teste; média ± desvio em {len(sementes)} sementes)")
    print(f"{'variante':30s} {'acc. treino':>12s} {'acc. val':>10s} {'acc. teste':>14s} {'época*':>7s}")
    for nome, cfg in variantes.items():
        r = []
        for s in sementes:
            treino, val, teste = dados(semente=s)
            torch.manual_seed(s)
            m = Rede(dropout=cfg.get("dropout", 0.0), batchnorm=cfg.get("batchnorm", False))
            ep = treinar(m, treino, val, wd=cfg.get("wd", 0.0), semente=s)
            r.append([avaliar(m, *treino)[1], avaliar(m, *val)[1], avaliar(m, *teste)[1], ep])
        r = np.array(r)
        print(f"{nome:30s} {r[:,0].mean():12.4f} {r[:,1].mean():10.4f} {r[:,2].mean():8.4f}±{r[:,2].std():.4f} {r[:,3].mean():7.1f}")
    print("* época com menor perda de validação (checkpoint)")

    # ---------- 3. erro comum: avaliar com o modelo em modo de treino ----------
    treino, val, teste = dados(semente=0)
    torch.manual_seed(0)
    m = Rede(dropout=0.5, batchnorm=True)
    treinar(m, treino, val)
    acc_eval = avaliar(m, *teste)[1]
    m.train()
    with torch.no_grad():
        acc_train_mode = (m(teste[0]).argmax(1) == teste[1]).float().mean().item()
    print(f"\n3. mesmo modelo, mesmo teste: modo eval = {acc_eval:.4f}; esquecendo model.eval() = {acc_train_mode:.4f}")
    n_par = sum(p.numel() for p in m.parameters())
    print(f"   parâmetros do modelo com Dropout 0,5 e BatchNorm: {n_par}")
