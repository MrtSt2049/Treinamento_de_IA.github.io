import torch
from torch import nn

torch.manual_seed(0)
profundidade, largura = 20, 64
X = torch.randn(256, largura)
y = torch.randint(0, 10, (256,))


def norma_gradientes(ativacao, init):
    camadas = []
    for _ in range(profundidade):
        lin = nn.Linear(largura, largura)
        init(lin.weight)
        nn.init.zeros_(lin.bias)
        camadas += [lin, ativacao()]
    rede = nn.Sequential(*camadas, nn.Linear(largura, 10))
    nn.functional.cross_entropy(rede(X), y).backward()
    lins = [m for m in rede if isinstance(m, nn.Linear)]
    return [m.weight.grad.norm().item() for m in lins]


configs = [("sigmoide, Xavier", nn.Sigmoid, nn.init.xavier_normal_),
           ("tanh, Xavier", nn.Tanh, nn.init.xavier_normal_),
           ("ReLU, Xavier", nn.ReLU, nn.init.xavier_normal_),
           ("ReLU, He", nn.ReLU, lambda w: nn.init.kaiming_normal_(w, nonlinearity="relu"))]
print(f"Norma do gradiente dos pesos (profundidade {profundidade}, largura {largura}, no passo 0)")
print(f"{'configuração':20s} {'1ª camada':>12s} {'10ª camada':>12s} {'última':>12s} {'1ª / última':>12s}")
for nome, ativ, init in configs:
    g = norma_gradientes(ativ, init)
    print(f"{nome:20s} {g[0]:12.3e} {g[9]:12.3e} {g[-1]:12.3e} {g[0] / g[-1]:12.3e}")
