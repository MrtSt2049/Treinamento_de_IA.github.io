import numpy as np

escalar = np.float64(3.5)                      # ordem 0: shape ()
vetor = np.array([1.0, 2.0, 3.0])              # ordem 1: shape (3,)
matriz = np.array([[1.0, 2.0, 3.0],
                   [4.0, 5.0, 6.0]])           # ordem 2: shape (2, 3)
tensor = np.zeros((4, 2, 3))                   # ordem 3: 4 matrizes 2x3

for nome, obj in [("escalar", escalar), ("vetor", vetor),
                  ("matriz", matriz), ("tensor", tensor)]:
    print(f"{nome:8s} ordem={np.ndim(obj)} shape={np.shape(obj)}")

# Produto matriz-vetor: (2, 3) @ (3,) -> (2,)
print("A @ x =", matriz @ vetor)

# Produto matricial: (2, 3) @ (3, 2) -> (2, 2)
print("A @ A.T =\n", matriz @ matriz.T)

# Broadcasting: o vetor (3,) é somado a cada linha da matriz (2, 3)
print("A + x =\n", matriz + vetor)

# Produto em lote: (4, 2, 3) @ (3,) -> (4, 2), uma multiplicação por matriz do lote
print("lote @ x ->", (tensor @ vetor).shape)
