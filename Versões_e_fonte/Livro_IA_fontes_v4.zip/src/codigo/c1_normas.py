import numpy as np

u = np.array([3.0, 4.0, 0.0])
v = np.array([4.0, 3.0, 0.0])

produto = u @ v                                 # produto escalar
norma_l2 = np.linalg.norm(u)                    # raiz da soma dos quadrados
norma_l1 = np.linalg.norm(u, ord=1)             # soma dos módulos
cosseno = produto / (np.linalg.norm(u) * np.linalg.norm(v))

print("u . v           =", produto)
print("||u||_2         =", norma_l2)
print("||u||_1         =", norma_l1)
print("cos(theta)      =", cosseno)
print("theta (graus)   =", round(float(np.degrees(np.arccos(cosseno))), 2))

# Desigualdade de Cauchy-Schwarz em 10.000 pares aleatórios
rng = np.random.default_rng(0)
U = rng.normal(size=(10_000, 50))
V = rng.normal(size=(10_000, 50))
lado_esq = np.abs(np.sum(U * V, axis=1))
lado_dir = np.linalg.norm(U, axis=1) * np.linalg.norm(V, axis=1)
print("Cauchy-Schwarz vale em todos os pares:", bool(np.all(lado_esq <= lado_dir)))
