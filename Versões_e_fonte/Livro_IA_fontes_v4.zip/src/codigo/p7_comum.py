"""Projeto 7: código comum (dados, tokenizador, modelo, avaliação e ajuste fino com Trainer e peft)."""
import json
import math
import os
import time
import warnings

import numpy as np
import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers
from transformers import GPT2Config, GPT2LMHeadModel, Trainer, TrainingArguments, default_data_collator

from corpus import carregar

warnings.filterwarnings("ignore")
torch.set_num_threads(2)
RAIZ = "/tmp/p7"
BASE = f"{RAIZ}/base"
BLOCO, VOCAB = 128, 1000
os.makedirs(RAIZ, exist_ok=True)


# ---------------------------------------------------------------- dados
def dividir():
    """Domínio de origem: Capítulos 1 a 5 (90% treino, 10% validação). Domínio-alvo: Capítulos 6 a 8 (60/20/20)."""
    rng = np.random.default_rng(0)
    orig, alvo = carregar([1, 2, 3, 4, 5]), carregar([6, 7, 8])
    o, a = rng.permutation(len(orig)), rng.permutation(len(alvo))
    no, na = int(0.9 * len(orig)), int(0.6 * len(alvo))
    nv = int(0.2 * len(alvo))
    return {
        "orig_tr": [orig[i] for i in o[:no]], "orig_va": [orig[i] for i in o[no:]],
        "alvo_tr": [alvo[i] for i in a[:na]], "alvo_va": [alvo[i] for i in a[na:na + nv]], "alvo_te": [alvo[i] for i in a[na + nv:]],
    }


def tokenizador(orig_tr):
    arq = f"{RAIZ}/tokenizador.json"
    if os.path.exists(arq):
        return Tokenizer.from_file(arq)
    tok = Tokenizer(models.BPE())
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    tok.train_from_iterator(orig_tr, trainers.BpeTrainer(vocab_size=VOCAB, special_tokens=["<pad>", "<eos>"], initial_alphabet=pre_tokenizers.ByteLevel.alphabet()))
    tok.save(arq)
    return tok


def blocos(paragrafos, tok):
    """Concatena os parágrafos separados por <eos> e fatia em blocos de BLOCO tokens (o resto é descartado)."""
    ids = []
    for p in paragrafos:
        ids += tok.encode(p).ids + [1]
    n = len(ids) // BLOCO
    arr = np.array(ids[:n * BLOCO]).reshape(n, BLOCO)
    return Dataset.from_dict({"input_ids": arr.tolist(), "labels": arr.tolist()}), len(ids)


def dados():
    d = dividir()
    tok = tokenizador(d["orig_tr"])
    ds, ntok = {}, {}
    for k, v in d.items():
        ds[k], ntok[k] = blocos(v, tok)
    return d, tok, ds, ntok


# ---------------------------------------------------------------- modelo e avaliação
def novo_modelo():
    cfg = GPT2Config(vocab_size=VOCAB, n_positions=BLOCO, n_embd=128, n_layer=4, n_head=4, resid_pdrop=0.1, embd_pdrop=0.1, attn_pdrop=0.1,
                     bos_token_id=1, eos_token_id=1, pad_token_id=0)
    return GPT2LMHeadModel(cfg)


@torch.no_grad()
def perda(modelo, ds, lote=32):
    """Entropia cruzada média por token (nats), em modo de avaliação."""
    modelo.eval()
    x = torch.tensor(ds["input_ids"])
    total, n = 0.0, 0
    for i in range(0, len(x), lote):
        b = x[i:i + lote]
        total += modelo(input_ids=b, labels=b).loss.item() * b.shape[0] * (BLOCO - 1)
        n += b.shape[0] * (BLOCO - 1)
    return total / n


def ppl(modelo, ds):
    return math.exp(perda(modelo, ds))


def contar(modelo):
    tot = sum(p.numel() for p in modelo.parameters())
    trein = sum(p.numel() for p in modelo.parameters() if p.requires_grad)
    return tot, trein


# ---------------------------------------------------------------- treino com Trainer
def treinar(modelo, ds_tr, ds_va, passos, lr, seed, lote=16, aquecimento=10, eval_cada=50):
    args = TrainingArguments(output_dir=f"{RAIZ}/tmp", per_device_train_batch_size=lote, per_device_eval_batch_size=32, max_steps=passos, learning_rate=lr,
                             lr_scheduler_type="cosine", warmup_steps=aquecimento, weight_decay=0.01, eval_strategy="steps", eval_steps=eval_cada,
                             logging_steps=eval_cada, save_strategy="no", report_to="none", use_cpu=True, seed=seed, data_seed=seed, disable_tqdm=True,
                             max_grad_norm=1.0)
    t = Trainer(model=modelo, args=args, train_dataset=ds_tr, eval_dataset=ds_va, data_collator=default_data_collator)
    t0 = time.time()
    t.train()
    # O Trainer desta versão divide a soma das perdas por BLOCO rótulos, e não por BLOCO-1 previsões; a razão BLOCO/(BLOCO-1) corrige o valor
    # registrado (conferido contra a função perda(), que usa as BLOCO-1 previsões).
    fator = BLOCO / (BLOCO - 1)
    curva = [(h["step"], math.exp(fator * h["eval_loss"])) for h in t.state.log_history if "eval_loss" in h]
    return curva, time.time() - t0


def ajustar(metodo, r, lr, seed, ds, passos=200, salvar=None):
    """metodo: 'completo' (todos os parâmetros), 'lora' ou 'zero' (referência sem pré-treino) (adaptadores de posto r nas camadas lineares dos blocos)."""
    if metodo == "zero":                                       # referência: sem pré-treino, pesos aleatórios treinados só no domínio-alvo
        torch.manual_seed(seed)
        modelo = novo_modelo()
    else:
        modelo = GPT2LMHeadModel.from_pretrained(BASE)
    total0 = sum(p.numel() for p in modelo.parameters())
    if metodo == "lora":
        modelo = get_peft_model(modelo, LoraConfig(r=r, lora_alpha=2 * r, target_modules=["c_attn", "c_proj", "c_fc"], fan_in_fan_out=True,
                                                    lora_dropout=0.0, task_type="CAUSAL_LM"))
    _, trein = contar(modelo)
    curva, seg = treinar(modelo, ds["alvo_tr"], ds["alvo_va"], passos, lr, seed)
    if metodo == "lora":
        modelo = modelo.merge_and_unload()
    res = {"metodo": metodo, "r": r if metodo == "lora" else None, "lr": lr, "seed": seed, "treinaveis": trein, "total": total0,
           "alvo_va": ppl(modelo, ds["alvo_va"]), "alvo_te": ppl(modelo, ds["alvo_te"]), "orig_va": ppl(modelo, ds["orig_va"]),
           "curva": curva, "segundos": seg}
    if salvar:
        modelo.save_pretrained(salvar)
    return res
