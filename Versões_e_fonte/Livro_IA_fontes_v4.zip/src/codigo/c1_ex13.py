import numpy as np


def distancias_com_lacos(X, Y):
    D = np.zeros((X.shape[0], Y.shape[0]))
    for i in range(X.shape[0]):
        for j in range(Y.shape[0]):
            D[i, j] = np.sqrt(np.sum((X[i] - Y[j]) ** 2))
    return D


def distancias_vetorizadas(X, Y):
    # ||x - y||^2 = ||x||^2 + ||y||^2 - 2 x.y, para todos os pares de uma vez
    x2 = np.sum(X ** 2, axis=1)[:, None]          # (n, 1)
    y2 = np.sum(Y ** 2, axis=1)[None, :]          # (1, m)
    D2 = x2 + y2 - 2.0 * X @ Y.T                  # (n, m) por difusão
    return np.sqrt(np.maximum(D2, 0.0))           # arredondamento pode gerar -1e-16


rng = np.random.default_rng(1)
X, Y = rng.normal(size=(300, 64)), rng.normal(size=(200, 64))
print("mesmo resultado:", np.allclose(distancias_com_lacos(X, Y), distancias_vetorizadas(X, Y)))
