"""Agente baseado em utilidade: escolhe a ação de maior utilidade esperada."""
# Cada ação leva a resultados incertos: (probabilidade, minutos de viagem)
ACOES = {
    "via expressa": [(0.80, 20), (0.20, 70)],    # rápida, com risco de congestionamento
    "avenida":      [(0.95, 32), (0.05, 40)],    # mais lenta, previsível
}


def utilidade_linear(minutos):
    return -minutos                               # indiferente ao risco


def utilidade_com_prazo(minutos, prazo=45):
    # Cada minuto além do prazo custa cinco vezes mais (aversão ao atraso)
    return -minutos - 5.0 * max(0, minutos - prazo)


def utilidade_esperada(resultados, u):
    return sum(p * u(m) for p, m in resultados)


if __name__ == "__main__":
    for nome_u, u in [("linear", utilidade_linear), ("com prazo", utilidade_com_prazo)]:
        valores = {a: utilidade_esperada(r, u) for a, r in ACOES.items()}
        melhor = max(valores, key=valores.get)
        resumo = "  ".join(f"{a}: {v:8.2f}" for a, v in valores.items())
        print(f"utilidade {nome_u:9s} -> {resumo}  => escolhe {melhor}")
