import numpy as np

z = np.array([-10.0, -2.0, 0.0, 2.0, 10.0])
sig = lambda z: 1 / (1 + np.exp(-z))
d_sig = lambda z: sig(z) * (1 - sig(z))
d_tanh = lambda z: 1 - np.tanh(z) ** 2
d_relu = lambda z: (z > 0).astype(float)
d_leaky = lambda z, a=0.01: np.where(z > 0, 1.0, a)

np.set_printoptions(precision=5, suppress=True)
print("z            ", z)
print("sigmoide     ", sig(z))
print("σ'(z)        ", d_sig(z))
print("tanh'(z)     ", d_tanh(z))
print("ReLU'(z)     ", d_relu(z))
print("Leaky'(z)    ", d_leaky(z))
print()
print("máximo de σ'(z):", d_sig(0.0), " | máximo de tanh'(z):", d_tanh(0.0))
print("Produto das derivadas da sigmoide em z=0 após L camadas (cota superior do fator do gradiente):")
for L in (1, 5, 10, 20):
    print(f"  L = {L:2d}: 0.25^L = {0.25 ** L:.3e}")

# softmax: invariância a deslocamento e estabilidade numérica
def softmax_ingenua(a):
    e = np.exp(a)
    return e / e.sum()


def softmax(a):
    e = np.exp(a - a.max())
    return e / e.sum()


a = np.array([1000.0, 1001.0, 1002.0])
with np.errstate(over="ignore", invalid="ignore"):
    print("\nsoftmax ingênua em [1000, 1001, 1002]:", softmax_ingenua(a))
print("softmax com deslocamento     :", softmax(a))
print("igual a softmax([0, 1, 2])   :", softmax(np.array([0.0, 1.0, 2.0])))
