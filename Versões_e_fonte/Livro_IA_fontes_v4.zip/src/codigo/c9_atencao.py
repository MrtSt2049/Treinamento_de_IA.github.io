"""Atenção por produto escalar escalonado: implementação, escala 1/sqrt(d_k) e equivariância a permutações."""
import numpy as np
import torch
import torch.nn.functional as F

rng = np.random.default_rng(0)


def softmax(z, eixo=-1):
    z = z - z.max(axis=eixo, keepdims=True)           # estabilidade numérica: softmax é invariante a deslocamentos
    e = np.exp(z)
    return e / e.sum(axis=eixo, keepdims=True)


def atencao(Q, K, V, mascara=None):
    dk = Q.shape[-1]
    S = Q @ K.T / np.sqrt(dk)                          # pontuações (T_q, T_k)
    if mascara is not None:
        S = np.where(mascara, S, -np.inf)
    A = softmax(S)                                     # cada linha soma 1
    return A @ V, A


# 1) confere com a implementação do PyTorch
Tq, Tk, dk, dv = 5, 7, 16, 8
Q, K, V = rng.normal(size=(Tq, dk)), rng.normal(size=(Tk, dk)), rng.normal(size=(Tk, dv))
saida, A = atencao(Q, K, V)
ref = F.scaled_dot_product_attention(*(torch.tensor(m)[None] for m in (Q, K, V)))[0].numpy()
print("formato da saída:", saida.shape, "| soma das linhas de A:", np.round(A.sum(1), 6))
print(f"diferença para F.scaled_dot_product_attention: {np.abs(saida - ref).max():.1e}")
print("cada saída é combinação convexa das linhas de V:",
      bool(np.all(saida.min(0) >= V.min(0) - 1e-12) and np.all(saida.max(0) <= V.max(0) + 1e-12)))

# 2) por que dividir por sqrt(d_k): variância do produto escalar entre vetores com entradas N(0,1)
print("\nd_k   var(q.k)   var(q.k/sqrt(d_k))")
for d in (4, 16, 64, 256, 1024):
    q, k = rng.normal(size=(200_000, d)), rng.normal(size=(200_000, d))
    s = (q * k).sum(1)
    print(f"{d:4d}  {s.var():9.2f}  {(s / np.sqrt(d)).var():9.3f}")

# 3) consequência: sem a escala, o softmax satura quando d_k é grande
print("\nsoftmax sobre 10 chaves, d_k = 256 (média de 2000 sorteios)")
print("escala        prob. máxima média   ||J||_F do softmax (média)")
for nome, esc in (("sem escala", 1.0), ("1/sqrt(d_k)", 1 / np.sqrt(256))):
    pmax, jn = [], []
    for _ in range(2000):
        q, Kk = rng.normal(size=256), rng.normal(size=(10, 256))
        p = softmax(Kk @ q * esc)
        pmax.append(p.max())
        jn.append(np.linalg.norm(np.diag(p) - np.outer(p, p)))   # jacobiano do softmax: diag(p) - p p^T
    print(f"{nome:12s}  {np.mean(pmax):18.3f}   {np.mean(jn):.4f}")

# 4) autoatenção sem codificação posicional é equivariante a permutações das posições
T, d = 6, 12
X = rng.normal(size=(T, d))
WQ, WK, WV = (rng.normal(size=(d, d)) / np.sqrt(d) for _ in range(3))
f = lambda X: atencao(X @ WQ, X @ WK, X @ WV)[0]
P = np.eye(T)[rng.permutation(T)]
print(f"\nequivariância: max|f(PX) - P f(X)| = {np.abs(f(P @ X) - P @ f(X)).max():.1e}")
