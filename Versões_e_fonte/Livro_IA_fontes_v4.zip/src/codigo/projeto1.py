"""Projeto 1: regressão linear por descida do gradiente, apenas com NumPy.

Executar:  python projeto1.py
Dependência: NumPy (testado com a versão 2.x).
"""
import numpy as np


def gerar_dados(n=200, d=3, ruido=0.5, semente=7):
    """Gera y = X w* + b* + ruído gaussiano. Retorna X (n, d), y (n,), w*, b*."""
    rng = np.random.default_rng(semente)
    X = rng.normal(size=(n, d))
    w_real = np.array([2.0, -1.0, 0.5])[:d]
    b_real = 4.0
    y = X @ w_real + b_real + ruido * rng.normal(size=n)
    return X, y, w_real, b_real


def adicionar_intercepto(X):
    """Acrescenta uma coluna de uns: o intercepto vira mais um parâmetro."""
    return np.hstack([X, np.ones((X.shape[0], 1))])


def perda(theta, X, y):
    """Erro quadrático médio: (1/n) ||X theta - y||^2."""
    residuo = X @ theta - y
    return residuo @ residuo / y.size


def gradiente(theta, X, y):
    """Gradiente analítico: (2/n) X^T (X theta - y)."""
    return 2.0 / y.size * X.T @ (X @ theta - y)


def gradiente_numerico(f, theta, h=1e-6):
    g = np.zeros_like(theta)
    for i in range(theta.size):
        e = np.zeros_like(theta)
        e[i] = h
        g[i] = (f(theta + e) - f(theta - e)) / (2 * h)
    return g


def treinar(X, y, taxa, passos):
    """Descida do gradiente em lote. Retorna parâmetros e histórico da perda."""
    theta = np.zeros(X.shape[1])
    historico = [perda(theta, X, y)]
    for _ in range(passos):
        theta = theta - taxa * gradiente(theta, X, y)
        historico.append(perda(theta, X, y))
    return theta, np.array(historico)


if __name__ == "__main__":
    X_bruto, y, w_real, b_real = gerar_dados()
    X = adicionar_intercepto(X_bruto)

    # Teste 1: gradiente analítico confere com diferenças finitas
    theta_teste = np.random.default_rng(0).normal(size=X.shape[1])
    g_a = gradiente(theta_teste, X, y)
    g_n = gradiente_numerico(lambda t: perda(t, X, y), theta_teste)
    erro_rel = np.linalg.norm(g_a - g_n) / np.linalg.norm(g_a)
    assert erro_rel < 1e-6, erro_rel
    print(f"teste 1  erro relativo do gradiente: {erro_rel:.2e}")

    # Taxa de aprendizado a partir da curvatura: Hessiana = (2/n) X^T X
    hessiana = 2.0 / y.size * X.T @ X
    L = np.linalg.eigvalsh(hessiana).max()
    theta_gd, hist = treinar(X, y, taxa=1.0 / L, passos=200)

    # Teste 2: a perda nunca aumenta com taxa 1/L
    assert np.all(np.diff(hist) <= 1e-12)
    print(f"teste 2  perda inicial {hist[0]:.4f} -> final {hist[-1]:.4f} (monótona)")

    # Teste 3: mesma solução dos mínimos quadrados resolvidos diretamente
    theta_mq, *_ = np.linalg.lstsq(X, y, rcond=None)
    assert np.allclose(theta_gd, theta_mq, atol=1e-6)
    print("teste 3  descida do gradiente = mínimos quadrados:", np.round(theta_gd, 4))
    print("         parâmetros geradores                    :", np.append(w_real, b_real))

    # Teste 4: resíduo ortogonal às colunas de X (condição de otimalidade)
    residuo = y - X @ theta_gd
    assert np.allclose(X.T @ residuo, 0.0, atol=1e-6)
    print(f"teste 4  ||X^T r|| = {np.linalg.norm(X.T @ residuo):.2e}")

    # Taxa acima de 2/L diverge
    _, hist_ruim = treinar(X, y, taxa=2.2 / L, passos=50)
    print(f"taxa 2.2/L: perda após 50 passos = {hist_ruim[-1]:.3e}")
