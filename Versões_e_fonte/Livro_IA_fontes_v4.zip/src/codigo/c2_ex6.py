"""Exercício 2.6: a sujeira reaparece. Requer c2_aspirador.py na mesma pasta."""
import random
from c2_aspirador import Ambiente, agente_reativo, AgenteComModelo


class AmbienteComSujeira(Ambiente):
    def __init__(self, *args, p_sujar=0.1, rng=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.p_sujar, self.rng = p_sujar, rng

    def executar(self, acao):
        super().executar(acao)
        for sala in self.sujeira:                       # o ambiente muda sozinho
            if self.rng.random() < self.p_sujar:
                self.sujeira[sala] = True


class AgenteQueRevisita(AgenteComModelo):
    """Modelo corrigido: o que foi visto há mais de `validade` passos volta a ser incerto."""

    def __init__(self, validade=3):
        super().__init__()
        self.validade = validade
        self.idade = {"A": 0, "B": 0}

    def __call__(self, percepcao):
        posicao, _ = percepcao
        outra = "B" if posicao == "A" else "A"
        self.idade[posicao] = 0
        self.idade[outra] += 1
        if self.idade[outra] > self.validade:
            self.limpa[outra] = None                    # informação envelhecida
        return super().__call__(percepcao)


def media(criar_agente, episodios=2000, passos=50, custo=0.2, semente=0):
    rng = random.Random(semente)
    total = 0.0
    for _ in range(episodios):
        amb = AmbienteComSujeira({"A": True, "B": True}, "A", custo, rng=rng)
        agente = criar_agente()
        for _ in range(passos):
            amb.executar(agente(amb.percepcao()))
        total += amb.desempenho
    return total / episodios


if __name__ == "__main__":
    print(f"reativo simples             : {media(lambda: agente_reativo):6.2f}")
    print(f"modelo 'sujeira não volta'  : {media(AgenteComModelo):6.2f}")
    print(f"modelo com revisita (3)     : {media(AgenteQueRevisita):6.2f}")
