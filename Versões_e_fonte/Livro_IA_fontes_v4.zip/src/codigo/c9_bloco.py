"""Bloco Transformer (pré-LN) à mão: LayerNorm, atenção, rede por posição, conexões residuais; contagem de parâmetros."""
import torch
from torch import nn
from transformers import GPT2Config, GPT2LMHeadModel

torch.manual_seed(0)


def layernorm(x, g, b, eps=1e-5):
    mu, var = x.mean(-1, keepdim=True), x.var(-1, unbiased=False, keepdim=True)
    return g * (x - mu) / torch.sqrt(var + eps) + b


# 1) LayerNorm: normaliza cada vetor (cada posição) sobre as suas d coordenadas
x = torch.randn(3, 5, 8) * 4 + 7
ln = nn.LayerNorm(8)
y = layernorm(x, ln.weight, ln.bias)
print(f"LayerNorm manual vs nn.LayerNorm: {(y - ln(x)).abs().max().item():.1e}")
print(f"média por posição após a normalização: máx |média| = {y.mean(-1).abs().max().item():.1e}; desvio-padrão = {y.std(-1, unbiased=False).mean().item():.4f}")


# 2) um bloco pré-LN: x <- x + Atenção(LN(x));  x <- x + FFN(LN(x))
class Bloco(nn.Module):
    def __init__(self, d, h, dff):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.att = nn.MultiheadAttention(d, h, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(d, dff), nn.GELU(), nn.Linear(dff, d))

    def forward(self, x):
        T = x.shape[1]
        causal = torch.triu(torch.ones(T, T, dtype=torch.bool), 1)
        z = self.ln1(x)
        x = x + self.att(z, z, z, attn_mask=causal, need_weights=False)[0]
        return x + self.ffn(self.ln2(x))


d, h = 64, 4
b = Bloco(d, h, 4 * d)
n = sum(p.numel() for p in b.parameters())
print(f"\nparâmetros de um bloco com d = {d}, d_ff = 4d: {n}   (fórmula 12 d^2 + 13 d = {12 * d * d + 13 * d})")
print("  atenção 4d^2+4d =", 4 * d * d + 4 * d, "| rede por posição 8d^2+5d =", 8 * d * d + 5 * d, "| duas LayerNorm 4d =", 4 * d)
print("formato preservado:", tuple(b(torch.randn(2, 10, d)).shape))

# 3) modelo completo: confere a fórmula de parâmetros com o GPT-2 da biblioteca (configuração minúscula, sem pesos pré-treinados)
V, P, N, d = 1000, 128, 4, 64
cfg = GPT2Config(vocab_size=V, n_positions=P, n_embd=d, n_layer=N, n_head=4, bos_token_id=0, eos_token_id=0)
m = GPT2LMHeadModel(cfg)
total = sum(p.numel() for p in m.parameters())               # a saída usa a mesma matriz da entrada (pesos amarrados)
formula = V * d + P * d + N * (12 * d * d + 13 * d) + 2 * d
print(f"\nGPT-2 minúsculo (V={V}, P={P}, N={N}, d={d}): {total} parâmetros; fórmula V d + P d + N(12 d^2 + 13 d) + 2 d = {formula}")
emb = V * d + P * d
print(f"  só as camadas de embeddings: {emb} ({100 * emb / total:.1f}% do total)")
for nome, (V2, P2, N2, d2) in {"GPT-2 pequeno (124M)": (50257, 1024, 12, 768), "GPT-2 médio": (50257, 1024, 24, 1024)}.items():
    print(f"  {nome:22s}: fórmula dá {(V2 * d2 + P2 * d2 + N2 * (12 * d2 * d2 + 13 * d2) + 2 * d2) / 1e6:7.1f} milhões de parâmetros")
