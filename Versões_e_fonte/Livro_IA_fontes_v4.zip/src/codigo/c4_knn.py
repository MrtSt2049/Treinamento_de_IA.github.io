import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)


def knn_prever(X_tr, y_tr, X_te, k):
    """Código didático: voto majoritário entre os k vizinhos mais próximos."""
    d2 = (X_te**2).sum(1)[:, None] + (X_tr**2).sum(1)[None, :] - 2 * X_te @ X_tr.T
    vizinhos = np.argsort(d2, axis=1)[:, :k]               # índices dos k mais próximos
    return (y_tr[vizinhos].mean(axis=1) > 0.5).astype(int)  # k ímpar: sem empates


pred = knn_prever(X_tr, y_tr, X_te, k=5)
sk = KNeighborsClassifier(n_neighbors=5).fit(X_tr, y_tr).predict(X_te)
print("didático = sklearn:", bool(np.all(pred == sk)), f"| acurácia sem padronizar = {np.mean(pred == y_te):.4f}")

escala = StandardScaler().fit(X_tr)                        # ajustado só no treino
Z_tr, Z_te = escala.transform(X_tr), escala.transform(X_te)
print("  k   acurácia treino   acurácia teste   (variáveis padronizadas)")
for k in (1, 5, 15, 51, 151):
    m = KNeighborsClassifier(n_neighbors=k).fit(Z_tr, y_tr)
    print(f"{k:3d}   {m.score(Z_tr, y_tr):15.4f}   {m.score(Z_te, y_te):14.4f}")
