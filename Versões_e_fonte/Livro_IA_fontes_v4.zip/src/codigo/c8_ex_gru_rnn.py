"""Exercício 8.9: uma GRU com z ≈ 0 e r ≈ 1 reproduz uma RNN simples."""
import torch
from torch import nn

torch.manual_seed(0)
F, H = 4, 6
rnn, gru = nn.RNN(F, H, batch_first=True), nn.GRU(F, H, batch_first=True)
with torch.no_grad():
    for p in gru.parameters():
        p.zero_()
    # ordem dos blocos na GRU do PyTorch: (r, z, n)
    gru.weight_ih_l0[2 * H:] = rnn.weight_ih_l0        # candidato n usa os pesos da RNN
    gru.weight_hh_l0[2 * H:] = rnn.weight_hh_l0
    gru.bias_ih_l0[2 * H:] = rnn.bias_ih_l0
    gru.bias_hh_l0[2 * H:] = rnn.bias_hh_l0
    gru.bias_ih_l0[:H] = 40.0                          # r = sigmoid(40) ≈ 1
    gru.bias_ih_l0[H:2 * H] = -40.0                    # z = sigmoid(-40) ≈ 0
x = torch.randn(3, 50, F)
a, b = rnn(x)[0], gru(x)[0]
print("maior diferença entre a RNN e a GRU com z ≈ 0, r ≈ 1 (50 passos):", f"{(a - b).abs().max().item():.2e}")
