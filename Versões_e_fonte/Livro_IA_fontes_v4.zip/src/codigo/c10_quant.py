"""Quantização uniforme simétrica (absmax) de pesos: erro, efeito de valores atípicos e custo em bits por peso.

Funções reutilizadas pelo Projeto 7 (quantização do modelo pré-treinado)."""
import numpy as np


def quantizar(W, bits, modo="tensor", bloco=64):
    """Devolve (W quantizada e desquantizada, bits efetivos por peso). Escala por tensor, por canal (coluna) ou por bloco ao longo do eixo 0."""
    q = 2 ** (bits - 1) - 1                                   # 127 para 8 bits, 7 para 4 bits
    n, m = W.shape
    if modo == "tensor":
        s = np.abs(W).max() / q
        n_escalas = 1
        Wq = np.round(W / s).clip(-q, q) * s
    elif modo == "canal":
        s = np.abs(W).max(axis=0, keepdims=True) / q
        n_escalas = m
        Wq = np.round(W / s).clip(-q, q) * s
    else:
        B = W.reshape(n // bloco, bloco, m)
        s = np.abs(B).max(axis=1, keepdims=True) / q
        n_escalas = (n // bloco) * m
        Wq = (np.round(B / s).clip(-q, q) * s).reshape(n, m)
    return Wq, bits + 32 * n_escalas / W.size                 # escalas guardadas em 32 bits


def erro_rel(W, Wq):
    return np.linalg.norm(W - Wq) / np.linalg.norm(W)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    n, m = 512, 128
    W = rng.normal(0, 0.05, (n, m))
    print(f"matriz {n}x{m} com pesos N(0, 0,05^2)")
    print(f"{'bits':>4} {'escala':>8} {'bits/peso':>10} {'erro relativo':>14} {'max |erro|':>11} {'cota s/2':>9}")
    for bits in (8, 4):
        for modo in ("tensor", "canal", "bloco"):
            Wq, bpp = quantizar(W, bits, modo)
            s_max = np.abs(W).max() / (2 ** (bits - 1) - 1)
            print(f"{bits:4d} {modo:>8} {bpp:10.2f} {erro_rel(W, Wq):14.4f} {np.abs(W - Wq).max():11.5f} {s_max / 2:9.5f}")

    print("\nmesma matriz com UM valor atípico de 60 desvios-padrão (3,0):")
    W2 = W.copy()
    W2[17, 5] = 3.0
    for bits in (8, 4):
        for modo in ("tensor", "canal", "bloco"):
            Wq, bpp = quantizar(W2, bits, modo)
            resto = np.ones_like(W2, bool); resto[17, 5] = False       # erro nos demais 65 535 pesos
            e_resto = np.linalg.norm((W2 - Wq)[resto]) / np.linalg.norm(W2[resto])
            print(f"{bits:4d} {modo:>8} {bpp:10.2f}  erro relativo total {erro_rel(W2, Wq):.4f}   erro relativo nos demais pesos {e_resto:.4f}")

    # cota teórica: com 8 bits e sem recorte, |erro| <= s/2 em todo peso
    Wq, _ = quantizar(W2, 8, "tensor")
    s = np.abs(W2).max() / 127
    print(f"\ncota |erro| <= s/2 respeitada (8 bits, por tensor, com atípico): {np.abs(W2 - Wq).max() <= s / 2 + 1e-12}; s/2 = {s / 2:.5f}")
