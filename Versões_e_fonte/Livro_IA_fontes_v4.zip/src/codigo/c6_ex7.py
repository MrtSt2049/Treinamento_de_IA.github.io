import torch

# Rede 1-1-1: h = tanh(w1 x + b1), saída = w2 h + b2, perda = 1/2 (saída - y)^2
x, y = 1.0, 1.0
t = lambda v: torch.tensor(v, dtype=torch.float64, requires_grad=True)
w1, b1, w2, b2 = t(0.5), t(0.0), t(-1.0), t(0.5)
h = torch.tanh(w1 * x + b1)
saida = w2 * h + b2
perda = 0.5 * (saida - y) ** 2
perda.backward()
print(f"h = {h.item():.6f}   saída = {saida.item():.6f}   perda = {perda.item():.6f}")
print(f"dL/dw2 = {w2.grad.item():.6f}   dL/db2 = {b2.grad.item():.6f}")
print(f"dL/dw1 = {w1.grad.item():.6f}   dL/db1 = {b1.grad.item():.6f}")
