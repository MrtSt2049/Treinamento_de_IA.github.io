import numpy as np

rng = np.random.default_rng(0)
H, T = 32, 60


def ortogonal(n):
    q, _ = np.linalg.qr(rng.normal(size=(n, n)))
    return q


def norma_jacobiano(W, ativ, k_max, x_escala=0.5):
    """‖∂h_T/∂h_{T-k}‖ (norma espectral) para k = 1..k_max, para h_t = φ(W h_{t-1} + U x_t)."""
    U = rng.normal(size=(H, H)) / np.sqrt(H)
    h = np.zeros(H)
    d_lista = []
    for t in range(T):
        z = W @ h + U @ (x_escala * rng.normal(size=H))
        h = np.tanh(z) if ativ == "tanh" else z
        d_lista.append(np.diag(1 - h ** 2) if ativ == "tanh" else np.eye(H))   # φ'(z) (tanh' = 1 - tanh²)
    J, normas = np.eye(H), []
    for k in range(1, k_max + 1):
        J = J @ (d_lista[T - k] @ W)        # ∂h_{T-k+1}/∂h_{T-k} = D_{T-k+1} W; acumula o produto
        normas.append(np.linalg.norm(J, 2))
    return np.array(normas)


print("Norma espectral de ∂h_T/∂h_{T-k}, com W = ρ·(matriz ortogonal), H = 32")
print(f"{'':26s}" + "".join(f"{'k = ' + str(k):>11s}" for k in (1, 5, 10, 20, 40, 60)))
for ativ in ("identidade", "tanh"):
    for rho in (0.5, 0.9, 1.0, 1.1, 1.5):
        n = norma_jacobiano(rho * ortogonal(H), "tanh" if ativ == "tanh" else "id", 60)
        print(f"{ativ + ', ρ = ' + str(rho):26s}" + "".join(f"{n[k - 1]:11.2e}" for k in (1, 5, 10, 20, 40, 60)))

# Recorte de gradiente (gradient clipping): g <- g · min(1, c/‖g‖)
g = rng.normal(size=1000) * 50
c = 5.0
g_cortado = g * min(1.0, c / np.linalg.norm(g))
print(f"\nrecorte: ‖g‖ = {np.linalg.norm(g):.1f} -> {np.linalg.norm(g_cortado):.1f}; direção preservada (cosseno = "
      f"{g @ g_cortado / np.linalg.norm(g) / np.linalg.norm(g_cortado):.4f})")
