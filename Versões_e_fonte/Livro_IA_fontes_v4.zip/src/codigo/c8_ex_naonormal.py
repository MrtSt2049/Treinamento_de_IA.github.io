"""Exercício 8.12: raio espectral pequeno não impede crescimento transitório (matriz não normal)."""
import numpy as np

W = np.array([[0.5, 2.0], [0.0, 0.5]])
rho = max(abs(np.linalg.eigvals(W)))
print(f"raio espectral ρ(W) = {rho:.2f}; norma espectral ‖W‖₂ = {np.linalg.norm(W, 2):.3f}")
Wk, normas = np.eye(2), []
for k in range(1, 41):
    Wk = Wk @ W
    normas.append(np.linalg.norm(Wk, 2))
pico = int(np.argmax(normas)) + 1
print(f"‖W^k‖₂ máximo = {max(normas):.3f} em k = {pico};  k=1: {normas[0]:.3f}  k=5: {normas[4]:.3f}  k=10: {normas[9]:.4f}  k=40: {normas[39]:.2e}")
print(f"ρ^k em k=10: {rho ** 10:.2e}; (γσ)^k = ‖W‖₂^k em k=10: {np.linalg.norm(W, 2) ** 10:.2e}")
