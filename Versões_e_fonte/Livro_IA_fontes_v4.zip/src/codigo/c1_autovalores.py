import numpy as np

A = np.array([[2.0, 1.0],
              [1.0, 2.0]])

# eigh é a rotina indicada para matrizes simétricas: autovalores reais e ordenados
autovalores, Q = np.linalg.eigh(A)
print("autovalores:", autovalores)
print("autovetores (colunas de Q):\n", np.round(Q, 4))

# Verificações: A q = lambda q, Q ortogonal, A = Q diag(lambda) Q^T
print("A q = lambda q   :", np.allclose(A @ Q, Q * autovalores))
print("Q^T Q = I        :", np.allclose(Q.T @ Q, np.eye(2)))
print("A = Q L Q^T      :", np.allclose(Q @ np.diag(autovalores) @ Q.T, A))
print("det = produto    :", np.isclose(np.linalg.det(A), np.prod(autovalores)))
print("traço = soma     :", np.isclose(np.trace(A), np.sum(autovalores)))


def iteracao_de_potencia(A, passos=50, semente=0):
    """Aproxima o autovalor dominante multiplicando repetidamente por A."""
    x = np.random.default_rng(semente).normal(size=A.shape[0])
    for _ in range(passos):
        x = A @ x
        x = x / np.linalg.norm(x)          # evita overflow e fixa a escala
    return x @ A @ x, x                    # quociente de Rayleigh, autovetor


lam, x = iteracao_de_potencia(A)
print("iteração de potência:", round(float(lam), 6), np.round(np.abs(x), 4))
