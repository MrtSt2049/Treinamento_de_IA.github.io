import numpy as np

rng = np.random.default_rng(1)
sigma, n, repeticoes = 0.3, 25, 2000
x = np.linspace(0, 1, n)                           # pontos de treino fixos
x_teste = x                                       # teste: novas respostas nos mesmos pontos


def f(x):
    return np.sin(2 * np.pi * x)


print("grau   viés^2   variância   viés^2+var+sigma^2   erro de teste   erro de treino")
for grau in (1, 3, 5, 9, 13, 17):
    previsoes = np.empty((repeticoes, x_teste.size))
    erro_treino = erro_teste = 0.0
    for r in range(repeticoes):                       # novas respostas ruidosas a cada repetição
        y = f(x) + sigma * rng.normal(size=n)
        coef = np.polynomial.polynomial.polyfit(x, y, grau)
        previsoes[r] = np.polynomial.polynomial.polyval(x_teste, coef)
        erro_treino += np.mean((y - np.polynomial.polynomial.polyval(x, coef)) ** 2)
        y_novo = f(x_teste) + sigma * rng.normal(size=x_teste.size)
        erro_teste += np.mean((y_novo - previsoes[r]) ** 2)
    vies2 = np.mean((previsoes.mean(axis=0) - f(x_teste)) ** 2)
    variancia = np.mean(previsoes.var(axis=0))
    print(f"{grau:4d}   {vies2:6.4f}   {variancia:9.4f}   {vies2 + variancia + sigma**2:18.4f}"
          f"   {erro_teste / repeticoes:13.4f}   {erro_treino / repeticoes:14.4f}")
