"""Tokenizadores de subpalavras com a biblioteca `tokenizers` (BPE em bytes e WordPiece) e a interface do `transformers`."""
import numpy as np
from tokenizers import Tokenizer, decoders, models, normalizers, pre_tokenizers, trainers
from transformers import PreTrainedTokenizerFast

from corpus import carregar

ps = carregar(list(range(1, 9)))
ordem = np.random.default_rng(0).permutation(len(ps))
nv = len(ps) // 10
val = [ps[i] for i in ordem[:nv]]
tr = [ps[i] for i in ordem[nv:]]
nbytes = sum(len(p.encode()) for p in val)

# --- BPE em nível de bytes (estilo GPT-2) ---
bpe = Tokenizer(models.BPE())
bpe.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
bpe.decoder = decoders.ByteLevel()
bpe.train_from_iterator(tr, trainers.BpeTrainer(vocab_size=1000, special_tokens=["<pad>", "<eos>"], initial_alphabet=pre_tokenizers.ByteLevel.alphabet()))

# --- WordPiece (estilo BERT), sem remover acentos ---
wp = Tokenizer(models.WordPiece(unk_token="[UNK]"))
wp.normalizer = normalizers.BertNormalizer(lowercase=True, strip_accents=False)
wp.pre_tokenizer = pre_tokenizers.BertPreTokenizer()
wp.decoder = decoders.WordPiece()
wp.train_from_iterator(tr, trainers.WordPieceTrainer(vocab_size=1000, special_tokens=["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"]))

print(f"vocabulário: BPE {bpe.get_vocab_size()}, WordPiece {wp.get_vocab_size()}")
for nome, t in (("BPE (bytes)", bpe), ("WordPiece", wp)):
    n = sum(len(t.encode(p).ids) for p in val)
    desc = sum(t.encode(p).tokens.count("[UNK]") for p in val)
    print(f"{nome:12s}: {1000 * n / nbytes:6.1f} tokens por 1000 bytes na validação; tokens [UNK]: {desc}")

frase = "A regularização reduz o superajuste dos hiperparâmetros."
raro = "hiperparametrização e ∑ 日本"
for nome, t in (("BPE (bytes)", bpe), ("WordPiece", wp)):
    print(f"\n{nome}\n  frase: {t.encode(frase).tokens}\n  rara : {t.encode(raro).tokens}")
    ids = t.encode(frase).ids
    print("  ids  :", ids[:10], "...")
    print("  decodificação:", repr(t.decode(ids)))

# --- interface do transformers: lote com preenchimento, truncamento e máscara de atenção ---
tok = PreTrainedTokenizerFast(tokenizer_object=wp, pad_token="[PAD]", unk_token="[UNK]", cls_token="[CLS]", sep_token="[SEP]", mask_token="[MASK]")
lote = tok(["O gradiente desce.", "A regularização reduz o superajuste dos hiperparâmetros do modelo."], padding=True, truncation=True, max_length=12, return_tensors="pt")
print("\nchaves do lote:", list(lote.keys()))
print("input_ids:\n", lote["input_ids"])
print("attention_mask:\n", lote["attention_mask"])
print("tokens da 2ª sequência (truncada em 12):", tok.convert_ids_to_tokens(lote["input_ids"][1]))
