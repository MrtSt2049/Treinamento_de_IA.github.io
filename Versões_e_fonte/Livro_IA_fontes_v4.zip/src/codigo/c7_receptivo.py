import numpy as np
import torch
from torch import nn


def campo_receptivo(camadas):
    """r_l = r_{l-1} + (k_l - 1) j_{l-1};  j_l = j_{l-1} s_l  (j = salto entre posições vizinhas, em pixels de entrada)."""
    r, j = 1, 1
    for k, s in camadas:
        r += (k - 1) * j
        j *= s
    return r


# (tamanho do filtro, passo) de cada camada que altera o campo receptivo
arq = [(3, 1), (3, 1), (2, 2), (3, 1), (3, 1), (2, 2), (3, 1)]
print("campo receptivo teórico após cada camada:", [campo_receptivo(arq[:i + 1]) for i in range(len(arq))])

# Medida empírica: onde o gradiente da saída central em relação à entrada é não nulo
torch.manual_seed(0)
rede = nn.Sequential(nn.Conv2d(1, 4, 3, padding=1), nn.Conv2d(4, 4, 3, padding=1), nn.MaxPool2d(2),
                     nn.Conv2d(4, 4, 3, padding=1), nn.Conv2d(4, 4, 3, padding=1), nn.MaxPool2d(2),
                     nn.Conv2d(4, 4, 3, padding=1))
# Sem ReLU. O max pooling roteia o gradiente apenas ao máximo de cada janela; em geral o suporte medido
# é um subconjunto do campo receptivo teórico, e aqui coincide com ele.
x = torch.randn(1, 1, 40, 40, requires_grad=True)
saida = rede(x)
print("formato da saída:", tuple(saida.shape))
centro = saida.shape[-1] // 2
saida[0, :, centro, centro].sum().backward()
g = x.grad[0, 0].abs().numpy()
linhas, colunas = np.where(g > 0)
print(f"suporte do gradiente na entrada: {linhas.max() - linhas.min() + 1} x {colunas.max() - colunas.min() + 1} pixels")
