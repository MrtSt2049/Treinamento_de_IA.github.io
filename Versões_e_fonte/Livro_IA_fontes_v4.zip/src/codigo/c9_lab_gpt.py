"""Laboratório do Capítulo 9: Transformer decodificador vs GRU, modelos de linguagem de caracteres treinados do zero
sobre a prosa do próprio livro (Capítulos 1 a 8). Métrica: bits por caractere (bpc) em parágrafos de validação."""
import math
import sys
import time
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from corpus import carregar

torch.set_num_threads(2)
CTX, LOTE = 128, 32


class Bloco(nn.Module):
    def __init__(self, d, h, p):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.qkv, self.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
        self.ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))
        self.h, self.p = h, p

    def forward(self, x):
        N, T, d = x.shape
        q, k, v = self.qkv(self.ln1(x)).view(N, T, 3, self.h, d // self.h).permute(2, 0, 3, 1, 4)
        z = F.scaled_dot_product_attention(q, k, v, is_causal=True, dropout_p=self.p if self.training else 0.0)
        x = x + F.dropout(self.proj(z.transpose(1, 2).reshape(N, T, d)), self.p, self.training)
        return x + F.dropout(self.ffn(self.ln2(x)), self.p, self.training)


class MiniGPT(nn.Module):
    def __init__(self, V, d=128, N=4, h=4, p=0.1):
        super().__init__()
        self.tok, self.pos = nn.Embedding(V, d), nn.Embedding(CTX, d)
        self.blocos = nn.ModuleList(Bloco(d, h, p) for _ in range(N))
        self.ln = nn.LayerNorm(d)
        self.p = p
        for mod in self.modules():                            # inicialização no estilo GPT-2: N(0, 0,02^2)
            if isinstance(mod, (nn.Linear, nn.Embedding)):
                nn.init.normal_(mod.weight, std=0.02)
                if getattr(mod, "bias", None) is not None:
                    nn.init.zeros_(mod.bias)

    def forward(self, x):
        z = F.dropout(self.tok(x) + self.pos(torch.arange(x.shape[1])), self.p, self.training)
        for b in self.blocos:
            z = b(z)
        return self.ln(z) @ self.tok.weight.T                # pesos amarrados entre entrada e saída


class GRULM(nn.Module):
    def __init__(self, V, e=64, H=256, p=0.1):
        super().__init__()
        self.emb = nn.Embedding(V, e)
        self.rnn = nn.GRU(e, H, num_layers=2, batch_first=True, dropout=p)
        self.cab = nn.Linear(H, V)

    def forward(self, x):
        return self.cab(self.rnn(self.emb(x))[0])


def lotes(dados, gen):
    ix = torch.randint(0, len(dados) - CTX - 1, (LOTE,), generator=gen)
    return torch.stack([dados[i:i + CTX] for i in ix]), torch.stack([dados[i + 1:i + CTX + 1] for i in ix])


@torch.no_grad()
def bpc(m, dados):
    m.eval()
    n = (len(dados) - 1) // CTX
    X = dados[:n * CTX].view(n, CTX)
    Y = dados[1:n * CTX + 1].view(n, CTX)
    perda = sum(F.cross_entropy(m(X[i:i + 64]).reshape(-1, m.tok.num_embeddings if hasattr(m, "tok") else m.cab.out_features), Y[i:i + 64].reshape(-1), reduction="sum").item()
                for i in range(0, n, 64))
    return perda / (n * CTX) / math.log(2)


if __name__ == "__main__":
    tipo, passos = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 0
    ps = carregar(list(range(1, 9)))
    rng = np.random.default_rng(0)
    ordem = rng.permutation(len(ps))
    nv = len(ps) // 10
    val_ps, tr_ps = [ps[i] for i in ordem[:nv]], [ps[i] for i in ordem[nv:]]
    alfabeto = sorted(set("".join(ps)) | {"\n"})
    idx = {c: i for i, c in enumerate(alfabeto)}
    cod = lambda L: torch.tensor([idx[c] for c in "\n".join(L) + "\n"])
    tr, va = cod(tr_ps), cod(val_ps)
    V = len(alfabeto)
    print(f"{len(tr_ps)} parágrafos de treino ({len(tr)} caracteres), {len(val_ps)} de validação ({len(va)} caracteres), V = {V}")

    if tipo == "base":                                          # referências: frequência de caracteres e bigramas com suavização
        uni = np.bincount(tr.numpy(), minlength=V) + 1.0
        uni /= uni.sum()
        print(f"unigramas:  {-(np.log2(uni[va.numpy()])).mean():.3f} bpc")
        big = np.ones((V, V))
        np.add.at(big, (tr[:-1].numpy(), tr[1:].numpy()), 1)
        big /= big.sum(1, keepdims=True)
        print(f"bigramas:   {-(np.log2(big[va[:-1].numpy(), va[1:].numpy()])).mean():.3f} bpc")
        sys.exit()

    torch.manual_seed(0)
    m = MiniGPT(V) if tipo == "gpt" else GRULM(V)
    lr = 1e-3 if tipo == "gpt" else 3e-3
    otim = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.01)
    print(f"{tipo}: {sum(p.numel() for p in m.parameters())} parâmetros, {passos} passos de {LOTE}x{CTX} caracteres")
    gen = torch.Generator().manual_seed(0)
    t0, melhor = time.time(), (9e9, None)
    for passo in range(1, passos + 1):
        f = min(1.0, passo / 50) * 0.5 * (1 + math.cos(math.pi * passo / passos))            # aquecimento + cosseno
        for g in otim.param_groups:
            g["lr"] = lr * f
        m.train()
        x, y = lotes(tr, gen)
        perda = F.cross_entropy(m(x).reshape(-1, V), y.reshape(-1))
        otim.zero_grad(); perda.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        otim.step()
        if passo % 100 == 0 or passo == passos:
            v = bpc(m, va)
            if v < melhor[0]:
                melhor = (v, passo)
            print(f"passo {passo:5d}  treino {perda.item() / math.log(2):.3f} bpc  validação {v:.3f} bpc  ({time.time() - t0:5.0f} s)", flush=True)
    print(f"melhor validação: {melhor[0]:.3f} bpc no passo {melhor[1]}")
    if tipo == "gpt":                                           # amostra com temperatura 0,8 (qualidade baixa esperada)
        m.eval()
        x = torch.tensor([[idx[c] for c in "O gradiente "]])
        with torch.no_grad():
            for _ in range(200):
                p = F.softmax(m(x[:, -CTX:])[0, -1] / 0.8, -1)
                x = torch.cat([x, torch.multinomial(p, 1, generator=gen)[None]], 1)
        print("amostra:", "".join(alfabeto[i] for i in x[0]).replace("\n", " ⏎ "))
