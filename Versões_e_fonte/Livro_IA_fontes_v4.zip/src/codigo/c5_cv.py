import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold, LeaveOneOut, cross_val_score

X, y = load_diabetes(return_X_y=True)
n = y.size


def kfold_didatico(X, y, k, semente=0):
    """k-fold para regressão linear; devolve a média do EQM nas k partes."""
    indices = np.random.default_rng(semente).permutation(y.size)
    partes = np.array_split(indices, k)
    erros = []
    for i in range(k):
        val = partes[i]
        tr = np.concatenate([partes[j] for j in range(k) if j != i])
        modelo = LinearRegression().fit(X[tr], y[tr])       # ajusta sem a parte i
        erros.append(np.mean((y[val] - modelo.predict(X[val])) ** 2))
    return np.mean(erros), np.std(erros)


for k in (5, 10):
    media, desvio = kfold_didatico(X, y, k)
    sk = -cross_val_score(LinearRegression(), X, y, scoring="neg_mean_squared_error",
                          cv=KFold(k, shuffle=True, random_state=0))
    print(f"k = {k:2d}: didático = {media:7.1f} (desvio entre partes {desvio:5.1f})   sklearn = {sk.mean():7.1f}")

# LOOCV: n ajustes ...
loo = -cross_val_score(LinearRegression(), X, y, scoring="neg_mean_squared_error", cv=LeaveOneOut())
# ... ou um único ajuste, com a fórmula das alavancagens
Xb = np.column_stack([np.ones(n), X])
H = Xb @ np.linalg.solve(Xb.T @ Xb, Xb.T)                    # matriz chapéu
residuo = y - H @ y
atalho = np.mean((residuo / (1 - np.diag(H))) ** 2)
print(f"LOOCV com {n} ajustes = {loo.mean():.3f}   fórmula com 1 ajuste = {atalho:.3f}")
print(f"EQM de treino = {np.mean(residuo**2):.1f} (otimista)")
