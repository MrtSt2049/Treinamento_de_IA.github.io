import numpy as np

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
y = np.array([0, 1, 1, 0])

# Rede 2-2-1 com ReLU e pesos escolhidos à mão:  h1 = ReLU(x1 + x2),  h2 = ReLU(x1 + x2 - 1),  saída = h1 - 2 h2
W1 = np.array([[1.0, 1.0], [1.0, 1.0]]); b1 = np.array([0.0, -1.0])
W2 = np.array([1.0, -2.0]); b2 = 0.0

H = np.maximum(0, X @ W1 + b1)
saida = H @ W2 + b2
print("entradas        :", X.tolist())
print("camada oculta H :", H.tolist())
print("saída da rede   :", saida.tolist())
print("alvo            :", y.tolist())
assert np.allclose(saida, y)
print("A rede 2-2-1 com ReLU reproduz o XOR exatamente.")

# Sem a não linearidade a composição colapsa em uma única transformação afim
W_colapso = W1 @ W2
b_colapso = b1 @ W2 + b2
print("\nsem ReLU: saída =", (X @ W_colapso + b_colapso).tolist(), " (afim em x; não pode separar o XOR)")
