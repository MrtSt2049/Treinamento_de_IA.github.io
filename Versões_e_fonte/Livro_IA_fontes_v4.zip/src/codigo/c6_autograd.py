import torch

# 1. tensores e autograd: y = sum(w * x)^2, gradiente em relação a w
x = torch.tensor([1.0, 2.0, 3.0])
w = torch.tensor([0.5, -1.0, 2.0], requires_grad=True)
y = (w @ x) ** 2
y.backward()
print("y =", y.item(), "| dy/dw (autograd) =", w.grad.tolist())
print("dy/dw (à mão: 2 (w·x) x)        =", (2 * (w @ x) * x).tolist())

# 2. o gradiente acumula: é preciso zerá-lo a cada passo
y2 = (w @ x) ** 2
y2.backward()
print("após segundo backward sem zerar  =", w.grad.tolist(), " (o dobro)")
w.grad.zero_()

# 3. grafo computacional: grad_fn registra a operação que produziu cada tensor
z = torch.relu(w) * 3
print("z.grad_fn =", type(z.grad_fn).__name__)

# 4. torch.no_grad desativa o registro (inferência / validação)
with torch.no_grad():
    t = w * 2
print("dentro de no_grad: t.requires_grad =", t.requires_grad)

# 5. detach separa um tensor do grafo
print("w.detach().requires_grad =", w.detach().requires_grad)

# 6. mesma regressão da seção 4.2 em três linhas, com nn.Module
torch.manual_seed(0)
X = torch.randn(200, 3)
beta = torch.tensor([2.0, -1.0, 0.5])
yv = X @ beta + 0.1 * torch.randn(200)
modelo = torch.nn.Linear(3, 1)
otimizador = torch.optim.SGD(modelo.parameters(), lr=0.1)
for _ in range(200):
    otimizador.zero_grad()
    perda = torch.nn.functional.mse_loss(modelo(X).squeeze(), yv)
    perda.backward()
    otimizador.step()
print("pesos aprendidos:", [round(v, 3) for v in modelo.weight.squeeze().tolist()], "| verdadeiros:", beta.tolist())
print("número de parâmetros:", sum(p.numel() for p in modelo.parameters()))
