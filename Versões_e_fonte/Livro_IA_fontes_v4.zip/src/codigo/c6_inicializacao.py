import numpy as np

rng = np.random.default_rng(0)
n, largura, L = 1000, 500, 20
X = rng.normal(size=(n, largura))


def propagar(init, ativ):
    h, desvios = X, []
    for _ in range(L):
        W = init(largura) * rng.normal(size=(largura, largura))
        h = ativ(h @ W)
        desvios.append(h.std())
    return desvios


ingenua = lambda m: 0.01
xavier = lambda m: np.sqrt(1.0 / m)
he = lambda m: np.sqrt(2.0 / m)
tanh = np.tanh
relu = lambda z: np.maximum(0, z)

print(f"Desvio-padrão das ativações após L camadas (largura {largura}, entrada com desvio 1)")
print(f"{'configuração':28s} {'L=1':>10s} {'L=5':>10s} {'L=10':>10s} {'L=20':>10s}")
for nome, init, ativ in [("tanh,  N(0, 0,01²)", ingenua, tanh), ("tanh,  Xavier", xavier, tanh),
                         ("ReLU,  Xavier", xavier, relu), ("ReLU,  He", he, relu)]:
    d = propagar(init, ativ)
    print(f"{nome:28s} {d[0]:10.3e} {d[4]:10.3e} {d[9]:10.3e} {d[19]:10.3e}")
