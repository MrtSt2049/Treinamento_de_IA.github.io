import numpy as np


def treinar_perceptron(X, y, epocas=50):
    """Regra do perceptron: w <- w + (y - y_hat) x. Devolve pesos, viés e época de convergência."""
    w, b = np.zeros(X.shape[1]), 0.0
    for epoca in range(1, epocas + 1):
        erros = 0
        for xi, yi in zip(X, y):
            y_hat = int(w @ xi + b > 0)
            if y_hat != yi:
                w += (yi - y_hat) * xi
                b += (yi - y_hat)
                erros += 1
        if erros == 0:
            return w, b, epoca
    return w, b, None


X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
for nome, y in [("AND", [0, 0, 0, 1]), ("OR ", [0, 1, 1, 1]), ("XOR", [0, 1, 1, 0])]:
    w, b, conv = treinar_perceptron(X, np.array(y))
    pred = (X @ w + b > 0).astype(int)
    acertos = int((pred == y).sum())
    status = f"convergiu na época {conv}" if conv else "não convergiu em 50 épocas"
    print(f"{nome}: w = {w}, b = {b:+.0f}, acertos = {acertos}/4, {status}")
