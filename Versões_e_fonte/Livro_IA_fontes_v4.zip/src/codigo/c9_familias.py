"""As três famílias de Transformers (codificador, decodificador, codificador-decodificador), sem pesos pré-treinados."""
import torch
from transformers import BertConfig, BertForMaskedLM, GPT2Config, GPT2LMHeadModel, T5Config, T5ForConditionalGeneration

torch.manual_seed(0)
V, T = 100, 8
ids = torch.randint(5, V, (1, T))
ids2 = ids.clone()
ids2[0, 5:] = torch.randint(5, V, (3,))                     # muda só os instantes 5, 6 e 7


def efeito(logits1, logits2):
    return (logits1[0, :5] - logits2[0, :5]).abs().max().item()


# Codificador (BERT): atenção bidirecional; as saídas em t < 5 DEPENDEM de t >= 5
bert = BertForMaskedLM(BertConfig(vocab_size=V, hidden_size=32, num_hidden_layers=2, num_attention_heads=4, intermediate_size=128, max_position_embeddings=32, initializer_range=0.3)).eval()
with torch.no_grad():
    a, b = bert(ids).logits, bert(ids2).logits
print(f"BERT : logits {tuple(a.shape)}; mudar o futuro altera t<5 em {efeito(a, b):.3f}  (bidirecional)")

# Decodificador (GPT-2): máscara causal; as saídas em t < 5 NÃO dependem de t >= 5
gpt = GPT2LMHeadModel(GPT2Config(vocab_size=V, n_positions=32, n_embd=32, n_layer=2, n_head=4, bos_token_id=0, eos_token_id=0, initializer_range=0.3)).eval()
with torch.no_grad():
    a, b = gpt(ids).logits, gpt(ids2).logits
print(f"GPT-2: logits {tuple(a.shape)}; mudar o futuro altera t<5 em {efeito(a, b):.1e}  (causal)")

# Codificador-decodificador (T5): o decodificador consulta a saída do codificador por atenção cruzada
t5 = T5ForConditionalGeneration(T5Config(vocab_size=V, d_model=32, d_kv=8, d_ff=128, num_layers=2, num_heads=4,
                                         decoder_start_token_id=0, pad_token_id=0, eos_token_id=1)).eval()
alvo = torch.randint(5, V, (1, 5))
with torch.no_grad():
    out = t5(input_ids=ids, labels=alvo)
    # trocar a ENTRADA do codificador muda a saída do decodificador (atenção cruzada)...
    out2 = t5(input_ids=torch.randint(5, V, (1, T)), labels=alvo)
    # ... mas, dentro do decodificador, a máscara é causal: mudar alvo futuro não altera as saídas anteriores
    alvo2 = alvo.clone(); alvo2[0, 3:] = torch.randint(5, V, (2,))
    out3 = t5(input_ids=ids, labels=alvo2)
print(f"T5   : logits {tuple(out.logits.shape)}; entrada do codificador diferente muda as saídas em {(out.logits - out2.logits).abs().max().item():.3f}; "
      f"alvo futuro diferente altera t<3 em {(out.logits[0, :3] - out3.logits[0, :3]).abs().max().item():.1e}")

for nome, m in (("BERT", bert), ("GPT-2", gpt), ("T5", t5)):
    print(f"{nome:6s} {sum(p.numel() for p in m.parameters()):8d} parâmetros")

# perda de modelagem de linguagem mascarada (BERT): só as posições mascaradas contam (rótulo -100 é ignorado)
rot = torch.full_like(ids, -100)
mask_pos = torch.tensor([2, 6])
rot[0, mask_pos] = ids[0, mask_pos]
entrada = ids.clone(); entrada[0, mask_pos] = 4             # 4 faz o papel do símbolo [MASK] neste exemplo
with torch.no_grad():
    print(f"\nperda MLM do BERT sem treino: {bert(entrada, labels=rot).loss.item():.3f}   (ln V = {torch.log(torch.tensor(float(V))).item():.3f})")
    # perda de modelo causal: o rótulo é a própria entrada, deslocada internamente por uma posição
    print(f"perda causal do GPT-2 sem treino: {gpt(ids, labels=ids).loss.item():.3f}")
