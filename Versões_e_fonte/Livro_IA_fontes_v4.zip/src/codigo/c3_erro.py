import numpy as np

rng = np.random.default_rng(0)
sigma = 0.3                                    # desvio padrão do ruído


def f(x):                                      # função verdadeira (desconhecida na prática)
    return np.sin(2 * np.pi * x)


def amostra(n):
    x = rng.uniform(0, 1, n)
    return x, f(x) + sigma * rng.normal(size=n)


x_tr, y_tr = amostra(50)
x_te, y_te = amostra(200_000)                  # teste grande: estima o erro esperado

print(f"erro irredutível Var(eps)      = {sigma**2:.4f}")
print(f"EQM usando a própria f         = {np.mean((y_te - f(x_te))**2):.4f}")
for grau in (1, 3, 5):
    coef = np.polyfit(x_tr, y_tr, grau)        # mínimos quadrados polinomial
    f_hat = np.polyval(coef, x_te)
    redutivel = np.mean((f(x_te) - f_hat)**2)
    total = np.mean((y_te - f_hat)**2)
    print(f"grau {grau}: redutível = {redutivel:.4f}   total = {total:.4f}   "
          f"redutível + irredutível = {redutivel + sigma**2:.4f}")
