"""Atenção multi-cabeça implementada à mão e comparada com torch.nn.MultiheadAttention; máscara causal."""
import torch
from torch import nn

torch.manual_seed(0)
N, T, d, h = 2, 6, 16, 4                                  # lote, instantes, dimensão do modelo, cabeças
dk = d // h

mha = nn.MultiheadAttention(d, h, batch_first=True)
x = torch.randn(N, T, d)
Wq, Wk, Wv = mha.in_proj_weight.chunk(3, dim=0)           # cada (d, d): as h cabeças empilhadas
bq, bk, bv = mha.in_proj_bias.chunk(3)
Wo, bo = mha.out_proj.weight, mha.out_proj.bias


def multicabeca(x, causal):
    N, T, _ = x.shape
    # projeções e separação em cabeças: (N, T, d) -> (N, h, T, dk)
    sep = lambda z: z.view(N, T, h, dk).transpose(1, 2)
    Q, K, V = sep(x @ Wq.T + bq), sep(x @ Wk.T + bk), sep(x @ Wv.T + bv)
    S = Q @ K.transpose(-1, -2) / dk ** 0.5                # (N, h, T, T)
    if causal:
        S = S.masked_fill(torch.triu(torch.ones(T, T, dtype=torch.bool), 1), float("-inf"))
    A = torch.softmax(S, -1)
    Z = (A @ V).transpose(1, 2).reshape(N, T, d)           # concatena as cabeças
    return Z @ Wo.T + bo, A


for causal in (False, True):
    mascara = torch.triu(torch.ones(T, T, dtype=torch.bool), 1) if causal else None
    ref, _ = mha(x, x, x, attn_mask=mascara, need_weights=False)
    meu, A = multicabeca(x, causal)
    print(f"causal={causal!s:5s}  diferença para nn.MultiheadAttention: {(meu - ref).abs().max().item():.1e}")

print("\nformato dos pesos de atenção (N, h, T, T):", tuple(A.shape))
print("pesos acima da diagonal com máscara causal (devem ser 0):", A[0, 0].triu(1).abs().max().item())
print("linha 3 da cabeça 0 (só as posições 0..3 recebem peso):", [round(v, 3) for v in A[0, 0, 3].tolist()])

n_param = sum(p.numel() for p in mha.parameters())
print(f"\nparâmetros: {n_param}  (fórmula 4d^2 + 4d = {4 * d * d + 4 * d}); independe de h e de T")
for hh in (1, 2, 4, 8, 16):
    print(f"  h = {hh:2d}: {sum(p.numel() for p in nn.MultiheadAttention(d, hh).parameters())} parâmetros")

# a máscara causal torna a saída em t independente das entradas futuras
x2 = x.clone()
x2[:, 4:] = torch.randn(N, T - 4, d)                       # altera só os instantes 4 e 5
a, _ = multicabeca(x, True)
b, _ = multicabeca(x2, True)
print(f"\nmáscara causal: saídas em t<4 mudam em {(a[:, :4] - b[:, :4]).abs().max().item():.1e}; em t>=4 mudam em {(a[:, 4:] - b[:, 4:]).abs().max().item():.2f}")
a, _ = multicabeca(x, False)
b, _ = multicabeca(x2, False)
print(f"sem máscara  : saídas em t<4 mudam em {(a[:, :4] - b[:, :4]).abs().max().item():.2f}")
