"""Projeto 3: rede neural densa em NumPy, com retropropagação, verificação numérica do gradiente e Adam."""
import time
import numpy as np
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


class MLP:
    """Perceptron multicamadas: [Linear -> ReLU] * (L-1) -> Linear -> Softmax, perda = entropia cruzada média."""

    def __init__(self, tamanhos, semente=0):
        rng = np.random.default_rng(semente)
        # Inicialização de He (seção 6.7): variância 2/entrada
        self.W = [rng.normal(0, np.sqrt(2.0 / m), size=(m, n)) for m, n in zip(tamanhos[:-1], tamanhos[1:])]
        self.b = [np.zeros(n) for n in tamanhos[1:]]

    # ---------- propagação para frente ----------
    def frente(self, X):
        """Devolve as probabilidades e o cache (entradas de cada camada e pré-ativações)."""
        entradas, pre = [], []
        h = X
        for l, (W, b) in enumerate(zip(self.W, self.b)):
            entradas.append(h)
            z = h @ W + b
            pre.append(z)
            h = np.maximum(0, z) if l < len(self.W) - 1 else z
        a = h - h.max(axis=1, keepdims=True)           # softmax estável
        p = np.exp(a) / np.exp(a).sum(axis=1, keepdims=True)
        return p, (entradas, pre)

    def perda(self, X, y, lam=0.0):
        p, _ = self.frente(X)
        L = -np.log(p[np.arange(len(y)), y]).mean()
        return L + 0.5 * lam * sum((W ** 2).sum() for W in self.W)

    # ---------- retropropagação ----------
    def gradientes(self, X, y, lam=0.0):
        p, (entradas, pre) = self.frente(X)
        n = len(y)
        delta = p.copy()
        delta[np.arange(n), y] -= 1                    # ∂L/∂a = p - y  (seção 6.4)
        delta /= n
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        for l in reversed(range(len(self.W))):
            gW[l] = entradas[l].T @ delta + lam * self.W[l]
            gb[l] = delta.sum(axis=0)
            if l > 0:
                delta = (delta @ self.W[l].T) * (pre[l - 1] > 0)   # regra da cadeia + derivada da ReLU
        return gW, gb

    def prever(self, X):
        return self.frente(X)[0].argmax(axis=1)


def verificar_gradiente(rede, X, y, eps=1e-6, amostras=20, semente=1):
    """Compara o gradiente analítico com diferenças centrais em parâmetros sorteados."""
    rng = np.random.default_rng(semente)
    gW, gb = rede.gradientes(X, y)
    pior = 0.0
    for params, grads in ((rede.W, gW), (rede.b, gb)):
        for l in range(len(params)):
            for _ in range(amostras):
                idx = tuple(rng.integers(0, s) for s in params[l].shape)
                original = params[l][idx]
                params[l][idx] = original + eps; mais = rede.perda(X, y)
                params[l][idx] = original - eps; menos = rede.perda(X, y)
                params[l][idx] = original
                num, ana = (mais - menos) / (2 * eps), grads[l][idx]
                pior = max(pior, abs(num - ana) / max(1e-12, abs(num) + abs(ana)))
    return pior


class Adam:
    def __init__(self, params, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.params, self.lr, self.b1, self.b2, self.eps, self.t = params, lr, b1, b2, eps, 0
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]

    def passo(self, grads):
        self.t += 1
        for p, g, m, v in zip(self.params, grads, self.m, self.v):
            m *= self.b1; m += (1 - self.b1) * g
            v *= self.b2; v += (1 - self.b2) * g ** 2
            p -= self.lr * (m / (1 - self.b1 ** self.t)) / (np.sqrt(v / (1 - self.b2 ** self.t)) + self.eps)


def treinar(rede, Xtr, ytr, Xva, yva, epocas=60, lote=64, lr=3e-3, lam=1e-4, semente=0):
    rng = np.random.default_rng(semente)
    otim = Adam(rede.W + rede.b, lr=lr)               # listas concatenadas: atualização in-place
    historico = []
    for ep in range(1, epocas + 1):
        ordem = rng.permutation(len(ytr))
        for i in range(0, len(ytr), lote):
            idx = ordem[i:i + lote]
            gW, gb = rede.gradientes(Xtr[idx], ytr[idx], lam)
            otim.passo(gW + gb)
        historico.append((ep, rede.perda(Xtr, ytr), rede.perda(Xva, yva), (rede.prever(Xva) == yva).mean()))
    return historico


if __name__ == "__main__":
    X, y = load_digits(return_X_y=True)
    X = X / 16.0                                       # pixels em [0, 1]
    Xtr, Xtmp, ytr, ytmp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
    Xva, Xte, yva, yte = train_test_split(Xtmp, ytmp, test_size=0.5, stratify=ytmp, random_state=1)
    print(f"treino {Xtr.shape}, validação {Xva.shape}, teste {Xte.shape}")

    # ---- Teste 1: perda inicial ≈ ln 10 (rede sem informação) ----
    rede = MLP([64, 64, 10], semente=0)
    L0 = rede.perda(Xtr, ytr)
    print(f"\nTeste 1  perda inicial = {L0:.4f}  (ln 10 = {np.log(10):.4f})")
    assert abs(L0 - np.log(10)) < 0.5

    # ---- Teste 2: verificação numérica do gradiente ----
    erro = verificar_gradiente(rede, Xtr[:32], ytr[:32])
    print(f"Teste 2  maior erro relativo do gradiente = {erro:.2e}")
    assert erro < 1e-6

    # ---- Teste 3: a rede deve decorar 16 exemplos (capacidade e correção do laço) ----
    pequena = MLP([64, 64, 10], semente=0)
    treinar(pequena, Xtr[:16], ytr[:16], Xva, yva, epocas=300, lote=16, lr=1e-2, lam=0.0)
    acc16 = (pequena.prever(Xtr[:16]) == ytr[:16]).mean()
    print(f"Teste 3  acurácia ao decorar 16 exemplos = {acc16:.2f}")
    assert acc16 == 1.0

    # ---- Treinamento completo ----
    t0 = time.perf_counter()
    rede = MLP([64, 64, 10], semente=0)
    hist = treinar(rede, Xtr, ytr, Xva, yva, epocas=60)
    dt = time.perf_counter() - t0
    print(f"\nTreino ({dt:.1f} s):  época | perda treino | perda val | acurácia val")
    for ep, ltr, lva, acc in hist:
        if ep in (1, 2, 5, 10, 20, 40, 60):
            print(f"  {ep:3d} | {ltr:12.4f} | {lva:9.4f} | {acc:11.4f}")
    acc_te = (rede.prever(Xte) == yte).mean()
    print(f"\nacurácia no teste (rede 64-64-10, NumPy) = {acc_te:.4f}")
    assert acc_te > 0.95

    base = LogisticRegression(max_iter=2000).fit(Xtr, ytr)
    print(f"acurácia no teste (regressão logística)    = {base.score(Xte, yte):.4f}")
    n_par = sum(W.size for W in rede.W) + sum(b.size for b in rede.b)
    print(f"parâmetros da rede = {n_par}")
    np.save("/tmp/p3_hist.npy", np.array(hist))
