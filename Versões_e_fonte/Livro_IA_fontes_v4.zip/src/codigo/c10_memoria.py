"""Memória (em GB) de pesos, gradientes e estados do otimizador no treino com AdamW, sem contar as ativações.

Cenários (bytes por parâmetro):
  completo, fp32           : pesos 4 + gradientes 4 + AdamW (m, v) 8                 = 16 P
  LoRA, base fp32          : base congelada 4 P + adaptadores (4 + 4 + 8) p_t         = 4 P + 16 p_t
  LoRA, base em 16 bits    : 2 P + 16 p_t
  LoRA, base em 4 bits     : 0,5 P (+ constantes de quantização, ignoradas) + 16 p_t   (esquema do QLoRA, adaptadores em fp32)
"""
GB = 1e9


def mem(P, pt):
    return {"completo fp32": 16 * P / GB, "LoRA, base fp32": (4 * P + 16 * pt) / GB, "LoRA, base 16 bits": (2 * P + 16 * pt) / GB,
            "LoRA, base 4 bits": (0.5 * P + 16 * pt) / GB}


casos = [("GPT-2 pequeno (P = 124,4 M; LoRA r = 8 em todas as lineares, p_t = 1 179 648)", 124.4e6, 1_179_648),
         ("modelo hipotético de 7 bilhões (p_t = 0,5% de P, hipótese ilustrativa)", 7e9, 0.005 * 7e9)]
for nome, P, pt in casos:
    print(nome)
    for k, v in mem(P, pt).items():
        print(f"   {k:20s} {v:8.2f} GB")
