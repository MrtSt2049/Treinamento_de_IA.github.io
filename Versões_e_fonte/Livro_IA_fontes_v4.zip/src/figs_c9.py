"""Figuras do Capítulo 9 (SVG)."""
import re
from figs_c6 import painel, curva, legenda, salvar, fmt  # noqa: F401

SETA = '<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker></defs>'


def caixa(x, y, w, h, texto, cls="cx", fonte=13):
    return f'<rect class="{cls}" x="{x}" y="{y}" width="{w}" height="{h}" rx="8"/><text x="{x + w / 2}" y="{y + h / 2 + 5}" font-size="{fonte}" text-anchor="middle">{texto}</text>'


def seta(x1, y1, x2, y2, cls="seta"):
    return f'<line class="{cls}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}"/>'


def rotulo(x, y, t, fonte=12, cls="t2", anc="middle"):
    return f'<text x="{x}" y="{y}" font-size="{fonte}" text-anchor="{anc}" class="{cls}">{t}</text>'


# ---------- Figura 9.1: fluxo da atenção ----------
c = [SETA]
c += [caixa(10, 40, 70, 44, "Q", "cxa"), caixa(10, 120, 70, 44, "Kᵀ", "cxa")]
c += [rotulo(45, 100, "T<tspan font-size='9' dy='3'>q</tspan><tspan dy='-3'>×d</tspan><tspan font-size='9' dy='3'>k</tspan>", 11),
      rotulo(45, 180, "d<tspan font-size='9' dy='3'>k</tspan><tspan dy='-3'>×T</tspan><tspan font-size='9' dy='3'>k</tspan>", 11)]
c += ['<circle cx="130" cy="102" r="16" class="cxm"/><text x="130" y="108" font-size="16" text-anchor="middle">×</text>',
      seta(80, 62, 114, 96), seta(80, 142, 114, 108), seta(146, 102, 186, 102)]
c += [caixa(186, 76, 80, 52, "S = QKᵀ/√d<tspan font-size='9' dy='3'>k</tspan>", "cx", 11)]
c += [seta(266, 102, 306, 102), caixa(306, 76, 90, 52, "softmax<tspan font-size='9' dy='-9'> </tspan>", "cxg", 12)]
c += [rotulo(351, 146, "por linha", 11)]
c += [seta(396, 102, 436, 102), caixa(436, 76, 60, 52, "A", "cxg", 14)]
c += [rotulo(466, 146, "T<tspan font-size='9' dy='3'>q</tspan><tspan dy='-3'>×T</tspan><tspan font-size='9' dy='3'>k</tspan>", 11)]
c += [caixa(436, 176, 60, 40, "V", "cxa")]
c += ['<circle cx="548" cy="102" r="16" class="cxm"/><text x="548" y="108" font-size="16" text-anchor="middle">×</text>',
      seta(496, 102, 532, 102), seta(496, 196, 548, 120), seta(564, 102, 600, 102)]
c += [caixa(600, 76, 36, 52, "Z", "cx", 14)]
c += [rotulo(320, 244, "cada linha de Z é uma combinação convexa das linhas de V (pesos = linha de A)", 12)]
salvar("fig_c9_atencao.svg", 648, 262, "Fluxo da atenção por produto escalar escalonado: pontuações, softmax por linha e combinação dos valores", c)

# ---------- Figura 9.2: bloco pré-LN e pilha do decodificador ----------
c = [SETA]
x0 = 120
c.append(rotulo(x0, 14, "Bloco pré-LN", 13, "", "middle"))
ys = {"x": 330, "ln1": 288, "mha": 238, "add1": 190, "ln2": 150, "ffn": 100, "add2": 56}
c.append(f'<line class="lm" x1="{x0}" y1="350" x2="{x0}" y2="34" style="stroke-width:2.5" marker-end="url(#pt-seta)"/>')
c.append(rotulo(x0 - 14, 346, "x", 13, "", "end"))
for nome, y, txt, cls in (("ln1", 276, "LN", "cx"), ("mha", 228, "MHA causal", "cxa"), ("ln2", 124, "LN", "cx"), ("ffn", 76, "FFN", "cxg")):
    c.append(caixa(x0 + 40, y, 90, 30, txt, cls))
for ysoma in (190, 40):
    c.append(f'<circle cx="{x0}" cy="{ysoma}" r="13" class="cxm"/><text x="{x0}" y="{ysoma + 6}" font-size="16" text-anchor="middle">+</text>')
c += [f'<polyline class="seta" points="{x0},306 {x0 + 85},306 {x0 + 85},308 {x0 + 85},306"/>']
# ramos: do fluxo para LN -> subcamada -> soma
c += [f'<polyline class="seta" points="{x0},300 {x0 + 85},300 {x0 + 85},306"/>']
c = [e for e in c if "points" not in e]                           # redesenha os ramos explicitamente
for ln_y, sub_y, soma_y in ((276, 228, 190), (124, 76, 40)):
    c.append(f'<line class="ln" x1="{x0}" y1="{ln_y + 40}" x2="{x0 + 85}" y2="{ln_y + 40}"/>')
    c.append(seta(x0 + 85, ln_y + 40, x0 + 85, ln_y + 31))
    c.append(seta(x0 + 85, ln_y, x0 + 85, sub_y + 31))
    c.append(f'<line class="ln" x1="{x0 + 85}" y1="{sub_y}" x2="{x0 + 85}" y2="{soma_y}"/>')
    c.append(seta(x0 + 85, soma_y, x0 + 14, soma_y))
c.append(rotulo(x0 + 85, 366, "o fluxo residual passa intacto", 11))
# pilha
xp = 420
c.append(rotulo(xp, 14, "Modelo decodificador", 13, "", "middle"))
pilha = [(330, "tokens (ids)", "cx"), (284, "embedding + posição", "cxa"), (214, "N × bloco", "cxm"), (160, "LN final", "cx"), (114, "linear (d → V)", "cxa"), (68, "softmax", "cxg")]
for y, t, cls in pilha:
    h = 52 if "bloco" in t else 32
    c.append(caixa(xp - 80, y - (0 if h == 32 else 10), 160, h, t, cls))
for a, b in ((330, 316), (284, 266), (214, 192), (160, 146), (114, 100)):
    c.append(seta(xp, a, xp, b))
c.append(seta(xp, 68, xp, 46))
c.append(rotulo(xp, 38, "p(x<tspan font-size='9' dy='3'>t</tspan><tspan dy='-3'>|x</tspan><tspan font-size='9' dy='3'>&lt;t</tspan><tspan dy='-3'>)</tspan>", 12))
salvar("fig_c9_bloco.svg", 560, 380, "Bloco Transformer pré-LN e pilha de um modelo decodificador", c)

# ---------- Figura 9.3: máscaras das três famílias ----------
c = []
n, lado = 8, 22
def painel_mascara(x0, titulo, regra, sub):
    out = [f'<text x="{x0 + n * lado / 2}" y="20" font-size="13" text-anchor="middle">{titulo}</text>']
    for i in range(n):
        for j in range(n):
            ok = regra(i, j)
            out.append(f'<rect x="{x0 + j * lado}" y="{32 + i * lado}" width="{lado - 1}" height="{lado - 1}" rx="2" class="{"pa" if ok else "fraco"}" style="{"" if ok else "fill:none;stroke:var(--linha)"}"/>')
    out.append(f'<text x="{x0 + n * lado / 2}" y="{32 + n * lado + 20}" font-size="11" text-anchor="middle" class="t2">{sub}</text>')
    return out
c += painel_mascara(20, "Codificador (BERT)", lambda i, j: True, "todas as posições")
c += painel_mascara(240, "Decodificador (GPT)", lambda i, j: j <= i, "só o passado (causal)")
c += painel_mascara(460, "Atenção cruzada (T5, BART)", lambda i, j: True, "linhas: decodificador; colunas: codificador")
salvar("fig_c9_familias.svg", 660, 250, "Máscaras de atenção do codificador, do decodificador e da atenção cruzada", c)
print("ok")

# ---------- Figura 9.4: curvas de validação do laboratório (Transformer vs GRU) ----------
def le_lab(arq):
    pts = []
    for lin in open(arq):
        m = re.match(r"^passo\s+(\d+)\s+treino ([0-9.]+) bpc\s+validação ([0-9.]+) bpc", lin)
        if m:
            pts.append((int(m.group(1)), float(m.group(2)), float(m.group(3))))
    return pts


G, R = le_lab("codigo/c9_lab_gpt.out"), le_lab("codigo/c9_lab_gru.out")
c = []
s, X, Y = painel(70, 20, 520, 250, 0, 1500, 1.5, 4.5, [0, 300, 600, 900, 1200, 1500], [1.5, 2, 2.5, 3, 3.5, 4, 4.5], "passo de treino", "bits por caractere (validação)")
c += s
for nome, y, cls in (("bigramas (3,454)", 3.454, "lr"), ("unigramas (4,497)", 4.497, "lr")):
    c.append(f'<line class="fraco" x1="70" y1="{fmt(Y(y))}" x2="590" y2="{fmt(Y(y))}" style="stroke:var(--rubi);stroke-dasharray:2 4"/>')
    c.append(f'<text x="588" y="{fmt(Y(y) - 5)}" font-size="11" text-anchor="end" class="t2">{nome}</text>')
c.append(curva(X, Y, [p[0] for p in G], [p[2] for p in G], "lv"))
c.append(curva(X, Y, [p[0] for p in R], [p[2] for p in R], "la"))
c.append(curva(X, Y, [p[0] for p in G], [p[1] for p in G], "lv", "3 3"))
c.append(curva(X, Y, [p[0] for p in R], [p[1] for p in R], "la", "3 3"))
c += legenda([("lv", "Transformer: validação", None), ("la", "GRU: validação", None)], 40, 318, 200)
c += legenda([("lv", "Transformer: treino (1 lote)", "3 3"), ("la", "GRU: treino (1 lote)", "3 3")], 40, 340, 250)
salvar("fig_c9_lab.svg", 640, 360, "Bits por caractere na validação e no treino ao longo de 1500 passos, para um Transformer decodificador e uma GRU, com as referências de unigramas e bigramas", c)
print("fig_c9_lab ok")
