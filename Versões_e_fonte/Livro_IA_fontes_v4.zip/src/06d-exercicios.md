## 6.12 Exercícios

### Nível I: consolidação

**6.1** Quantos parâmetros tem um MLP $784\text{-}128\text{-}64\text{-}10$ (com vieses)?

**6.2** Calcule $\sigma(0)$, $\sigma'(0)$, $\tanh'(0)$ e $\operatorname{ReLU}'(2)$.

**6.3** Para os logits $\mathbf{a}=(0,\ln2,\ln4)$, calcule a softmax, a perda de entropia cruzada se a classe correta é a de índice $2$ (a terceira) e o gradiente da perda em relação a $\mathbf{a}$.

**6.4** Os dados de um problema são linearmente separáveis com margem $\gamma=0{,}5$ e todos os vetores têm norma no máximo $R=5$. Qual é a cota para o número de erros do perceptron?

**6.5** Indique a ativação da camada de saída e a perda adequadas para: (a) prever o preço de um imóvel; (b) classificar e-mails como spam ou não; (c) reconhecer um dígito manuscrito; (d) atribuir a uma foto qualquer subconjunto de $K$ etiquetas (uma foto pode ter várias).

### Nível II: desenvolvimento

**6.6** Para um único neurônio sigmoide com perda de entropia cruzada binária, deduza o gradiente em relação a $\mathbf{w}$ e $b$ e mostre que, na média sobre $n$ exemplos, ele é $\frac1n\mathbf{X}^\top(\boldsymbol\sigma-\mathbf{y})$. Compare com a seção 4.5.

**6.7** Considere a rede $1\text{-}1\text{-}1$ dada por $h=\tanh(w_1x+b_1)$, saída $\hat y=w_2h+b_2$, perda $\mathcal{L}=\frac12(\hat y-y)^2$, com $x=1$, $y=1$, $w_1=0{,}5$, $b_1=0$, $w_2=-1$, $b_2=0{,}5$. Calcule à mão a perda e as quatro derivadas, e confira com o autograd.

**6.8** Mostre que, se todos os pesos de uma camada oculta são inicializados com o **mesmo valor** (por exemplo, zero), os neurônios dessa camada permanecem idênticos durante todo o treinamento. Por que isso é um problema?

**6.9** Seja $h$ a ativação de um neurônio e $\tilde h=m\,h/(1-p)$ com $m\sim\text{Bernoulli}(1-p)$ (Dropout invertido). Calcule $\mathbb{E}[\tilde h]$ e $\operatorname{Var}(\tilde h)$.

**6.10** Calcule o desvio-padrão dos pesos de uma camada $256\to256$ segundo (a) LeCun ($\sigma_w^2=1/n_\text{ent}$), (b) Xavier ($\sigma_w^2=2/(n_\text{ent}+n_\text{saí})$), (c) He. Por que a ReLU pede o fator $2$ a mais?

**6.11** No *momentum* com $\beta=0{,}9$ e $\mathbf{g}$ de módulo constante $g$, determine o módulo da velocidade em regime permanente (a) quando o sinal do gradiente é constante e (b) quando o sinal alterna a cada passo. Interprete a razão.

**6.12** No Adam com $\beta_1=0{,}9$ e $\beta_2=0{,}999$, calcule $\hat m_t$, $\hat v_t$ e a razão $\hat m_t/\bigl(\sqrt{\hat v_t}+\epsilon\bigr)$ para $t=1$ e $t=2$, com gradientes $g_1=2$ e $g_2=-1$ (ignore $\epsilon$ no $t=2$).

### Nível III: avançado

**6.13** Mostre que a perda de entropia cruzada, vista como função dos logits $\mathbf{a}$, é **convexa**. (Dica: calcule a Hessiana usando o Teorema 6.7 e a Proposição 6.5.) Isso quer dizer que a perda da rede é convexa nos pesos?

**6.14** Reproduza o experimento da dissipação do gradiente: construa MLPs de profundidade $20$ e largura $64$ com ativação sigmoide, tanh e ReLU, com inicializações de Xavier e de He, e meça a norma do gradiente dos pesos em cada camada antes do primeiro passo de otimização. Compare a primeira, a décima e a última camada e interprete.

**6.15** Mostre que uma função $f:\mathbb{R}\to\mathbb{R}$ calculada por uma rede com uma camada oculta de $m$ neurônios ReLU é linear por partes com no máximo $m+1$ trechos, e construa uma rede com dois neurônios que calcule $|x|$. Relacione com o Teorema 6.4.

**6.16** Meça a sensibilidade do treinamento do Projeto 4 (rede base) à taxa de aprendizado do Adam, com $\eta\in\{10^{-4},10^{-3},10^{-2},10^{-1},1\}$ e $3$ sementes. Descreva as regiões de subajuste por lentidão, de bom funcionamento e de divergência.

## 6.13 Soluções comentadas

::: solucao 6.1
$(784+1)\cdot128+(128+1)\cdot64+(64+1)\cdot10=100\,480+8\,256+650=109\,386$ parâmetros. A primeira camada responde por mais de 90% deles.
:::

::: solucao 6.2
$\sigma(0)=0{,}5$; $\sigma'(0)=\sigma(0)(1-\sigma(0))=0{,}25$ (o máximo da derivada); $\tanh'(0)=1-\tanh^2(0)=1$; $\operatorname{ReLU}'(2)=1$.
:::

::: solucao 6.3
Os exponenciais são $(1,2,4)$, com soma $7$, de modo que $\operatorname{softmax}(\mathbf{a})=(1/7,\,2/7,\,4/7)\approx(0{,}143;\,0{,}286;\,0{,}571)$. A perda é $-\ln(4/7)=\ln(7/4)\approx0{,}560$. O gradiente é $\mathbf{p}-\mathbf{y}=(1/7,\,2/7,\,4/7-1)=(1/7,\,2/7,\,-3/7)\approx(0{,}143;\,0{,}286;\,-0{,}429)$: aumentar o logit da classe correta reduz a perda, e aumentar os demais a eleva.
:::

::: solucao 6.4
Pelo Teorema 6.1, no máximo $(R/\gamma)^2=(5/0{,}5)^2=100$ erros. A cota independe do número de exemplos.
:::

::: solucao 6.5
(a) Regressão: saída linear (identidade) e MSE. (b) Classificação binária: sigmoide e entropia cruzada binária (`BCEWithLogitsLoss`). (c) Dez classes mutuamente exclusivas: softmax e entropia cruzada categórica. (d) Rótulos múltiplos independentes: **uma sigmoide por etiqueta** e entropia cruzada binária em cada uma, somadas. A softmax seria errada aqui, porque obrigaria as probabilidades a somar $1$, impondo exclusividade que não existe.
:::

::: solucao 6.6
Seja $z=\mathbf{w}^\top\mathbf{x}+b$ e $p=\sigma(z)$. Pelo Teorema 6.7, $\partial\mathcal{L}/\partial z=p-y$. Como $\partial z/\partial\mathbf{w}=\mathbf{x}$ e $\partial z/\partial b=1$, a regra da cadeia dá $\nabla_{\mathbf{w}}\mathcal{L}=(p-y)\,\mathbf{x}$ e $\partial\mathcal{L}/\partial b=p-y$. Na média sobre $n$ exemplos, empilhados em $\mathbf{X}\in\mathbb{R}^{n\times d}$, $\nabla_{\mathbf{w}}\hat{\mathcal{R}}=\frac1n\sum_i(p_i-y_i)\mathbf{x}_i=\frac1n\mathbf{X}^\top(\boldsymbol\sigma-\mathbf{y})$. É exatamente o gradiente da regressão logística da seção 4.5, confirmando que um neurônio sigmoide treinado com entropia cruzada **é** a regressão logística.
:::

::: solucao 6.7
Passo para frente: $z_1=0{,}5$, $h=\tanh(0{,}5)=0{,}462117$, $\hat y=-0{,}462117+0{,}5=0{,}037883$, $\mathcal{L}=\frac12(0{,}037883-1)^2=0{,}462835$.

Passo para trás: $\partial\mathcal{L}/\partial\hat y=\hat y-y=-0{,}962117$. Então $\partial\mathcal{L}/\partial w_2=h\,(\hat y-y)=-0{,}444611$ e $\partial\mathcal{L}/\partial b_2=-0{,}962117$. O erro na camada oculta é $\delta_1=w_2(\hat y-y)\,(1-h^2)=(-1)(-0{,}962117)(0{,}786448)=0{,}756655$, e $\partial\mathcal{L}/\partial w_1=x\,\delta_1=0{,}756655$, $\partial\mathcal{L}/\partial b_1=0{,}756655$.

>>> codigo/c6_ex7.out

O autograd reproduz os cinco números (`c6_ex7.py`).
:::

::: solucao 6.8
Suponha que todos os pesos que chegam à camada oculta valham $c$ e que os pesos que saem dela também valham $c'$ (iguais entre si). Então os neurônios têm a mesma pré-ativação e a mesma saída. Pelo Teorema 6.8, $\delta^{(1)}_j=\varphi'(z_j)\sum_kW^{(2)}_{jk}\delta^{(2)}_k$ é o mesmo para todo $j$, e os gradientes dos pesos que chegam a cada neurônio, $\mathbf{x}\,\delta^{(1)}_j$, também são os mesmos. A atualização altera todos igualmente, e a simetria se mantém **para sempre**, por indução. A camada se comporta como um único neurônio replicado: toda a largura é desperdiçada. A inicialização aleatória (seção 6.7) quebra a simetria. Com pesos iniciais **zero** e ReLU o problema é pior: $z=0$ e a derivada convencionada em $0$ é zero, de modo que nada aprende na camada oculta.
:::

::: solucao 6.9
Como $\mathbb{E}[m]=1-p$, $\mathbb{E}[\tilde h]=(1-p)h/(1-p)=h$: o Dropout invertido não altera a média, e por isso a inferência pode usar a rede inteira sem reescalar. Para a variância, $\mathbb{E}[\tilde h^2]=\mathbb{E}[m^2]\,h^2/(1-p)^2=(1-p)\,h^2/(1-p)^2=h^2/(1-p)$, e $\operatorname{Var}(\tilde h)=h^2/(1-p)-h^2=h^2\,\dfrac{p}{1-p}$. Com $p=0{,}5$, a variância é $h^2$; com $p=0{,}9$, é $9h^2$. Quanto maior $p$, mais ruído é injetado.
:::

::: solucao 6.10
(a) LeCun: $\sigma_w=\sqrt{1/256}=0{,}0625$. (b) Xavier: $\sigma_w=\sqrt{2/(256+256)}=0{,}0625$ (iguais aqui, porque entrada e saída têm a mesma largura). (c) He: $\sigma_w=\sqrt{2/256}\approx0{,}0884$. A ReLU zera, em média, metade das pré-ativações (as negativas), de modo que o segundo momento de $h$ é a **metade** da variância de $z$: $\mathbb{E}[h^2]=\frac12\operatorname{Var}(z)$. Para que a variância se conserve de camada em camada, $n\sigma_w^2\cdot\frac12=1$, ou seja, $\sigma_w^2=2/n$. O experimento da seção 6.7 mostra o efeito: com Xavier e ReLU, o sinal decai a $7\times10^{-4}$ em $20$ camadas; com He, mantém-se em $0{,}8$ a $1$.
:::

::: solucao 6.11
(a) Com gradiente constante, $v=\beta v+g$ converge para $v=g/(1-\beta)=10g$. (b) Com sinal alternado, $v_t=\beta v_{t-1}+(-1)^tg$; a solução em regime permanente é uma sequência de módulo $g/(1+\beta)\approx0{,}526g$. A execução confirma:

>>> codigo/c6_ex10.out

A razão é cerca de $19$: o *momentum* **amplifica** direções em que o gradiente é consistente e **amortece** as em que ele oscila. É o mecanismo pelo qual acelera o avanço no fundo de um vale estreito (direção de baixa curvatura, sinal constante) e reduz a oscilação nas paredes (direção de alta curvatura, sinal alternado).
:::

::: solucao 6.12
$t=1$: $m_1=0{,}1\cdot2=0{,}2$, $v_1=0{,}001\cdot4=0{,}004$. Correções: $\hat m_1=0{,}2/0{,}1=2$, $\hat v_1=0{,}004/0{,}001=4$. Razão: $2/\sqrt4=1$, isto é, passo $=\eta$.

$t=2$: $m_2=0{,}9\cdot0{,}2+0{,}1\cdot(-1)=0{,}08$, $v_2=0{,}999\cdot0{,}004+0{,}001\cdot1=0{,}004996$. Correções: $\hat m_2=0{,}08/(1-0{,}81)=0{,}42105$, $\hat v_2=0{,}004996/(1-0{,}999^2)=2{,}49925$. Razão: $0{,}42105/\sqrt{2{,}49925}=0{,}2663$. O sinal oposto do segundo gradiente reduz muito o passo: o *momentum* "lembra" do primeiro gradiente. O programa confirma (última parte da saída do exercício anterior): passo/$\eta$ igual a $1{,}00000$ e $0{,}26634$.
:::

::: solucao 6.13
Pelo Teorema 6.7, $\nabla_{\mathbf{a}}\mathcal{L}=\mathbf{p}-\mathbf{y}$, com $\mathbf{y}$ constante. A Hessiana é então o jacobiano da softmax (Proposição 6.5): $\mathbf{H}=\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^\top$. Para qualquer $\mathbf{u}$, $\mathbf{u}^\top\mathbf{H}\mathbf{u}=\sum_kp_ku_k^2-\bigl(\sum_kp_ku_k\bigr)^2=\operatorname{Var}_{k\sim\mathbf{p}}(u_k)\ge0$. A Hessiana é semidefinida positiva, e $\mathcal{L}$ é convexa em $\mathbf{a}$. **Isso não implica convexidade nos pesos**: os logits são funções não lineares dos pesos (composição com ReLU etc.), e a composição de uma função convexa com uma não linear não é convexa em geral. Por isso a perda de uma rede tem muitos mínimos locais e pontos de sela. Em um modelo sem camadas ocultas (a regressão logística multinomial), os logits são lineares nos pesos, e a perda é de fato convexa.
:::

::: solucao 6.14
Resultado do programa:

>>> codigo/c6_ex13.out

- **Sigmoide.** O gradiente na primeira camada é $8\times10^{-14}$, contra $0{,}53$ na última: razão de $10^{-13}$. A dissipação previsível pela cota $4^{-L}$ (seção 6.3) aparece com toda a força, e as primeiras camadas praticamente não aprenderiam.
- **Tanh com Xavier.** Os gradientes são de mesma ordem em todas as camadas (razão $0{,}59$): tanh, centrada em zero e com derivada $1$ na origem, combina bem com a inicialização de Xavier.
- **ReLU com Xavier.** A razão primeira/última é próxima de $1$, mas **todos** os valores são pequenos, da ordem de $10^{-4}$: o que se dissipou foi o sinal no passo para frente (a variância cai à metade por camada), e os gradientes dos pesos são proporcionais às ativações. A razão entre camadas não basta; é preciso olhar também o valor absoluto.
- **ReLU com He.** Os gradientes são de ordem $0{,}15$ a $0{,}70$ em todas as camadas, com a primeira cerca de cinco vezes menor que a última ($0{,}22$), uma atenuação moderada.

A leitura combinada: não basta mudar a ativação para ReLU; é preciso **combinar** ativação e inicialização. Esse conjunto de números é uma fotografia no passo $0$, com uma única semente; durante o treinamento, os gradientes evoluem.
:::

::: solucao 6.15
Cada neurônio $c_j\operatorname{ReLU}(w_jx+b_j)$ é linear por partes, com uma única quebra em $x=-b_j/w_j$ (se $w_j\ne0$). A soma de $m$ funções lineares por partes, cada uma com no máximo uma quebra, é linear por partes com no máximo $m$ quebras, ou seja, no máximo $m+1$ trechos. Para $|x|$ bastam dois neurônios: $|x|=\operatorname{ReLU}(x)+\operatorname{ReLU}(-x)$, com $w_1=1,\ w_2=-1,\ b_1=b_2=0,\ c_1=c_2=1$. Relação com o Teorema 6.4: para aproximar uma função contínua qualquer por uma função linear por partes com erro menor que $\varepsilon$, o número de trechos (portanto de neurônios $m$) pode ter de crescer muito quando $\varepsilon\to0$; o teorema afirma que $m$ finito basta, sem dizer quão grande.
:::

::: solucao 6.16
Resultado do programa:

>>> codigo/c6_ex15.out

- **$\eta=10^{-4}$:** o treinamento é lento. A "época de menor perda de validação" é a última (100): a rede não terminou de convergir, e a perda de validação ($0{,}218$) é maior que a das melhores taxas.
- **$\eta=10^{-3}$ e $10^{-2}$:** boa região. $10^{-3}$ tem a menor perda de validação ($0{,}153$) e a maior acurácia de teste ($0{,}948$); $10^{-2}$ é um pouco pior ($0{,}183$ e $0{,}944$).
- **$\eta=10^{-1}$:** o treinamento é instável: a acurácia cai a $0{,}67$, com perda de validação $0{,}88$.
- **$\eta=1$:** diverge, com acurácia de $0{,}10$, o acaso entre $10$ classes, e perda de validação $8{,}1$.

O padrão em forma de "U" invertido para a acurácia é típico: existe uma faixa de uma a duas ordens de grandeza em que o resultado é bom, e fora dela o desempenho cai rapidamente. A faixa é estreita em relação ao intervalo em que a taxa poderia estar a priori, e é por isso que a taxa de aprendizado é o hiperparâmetro mais importante. Três sementes dão uma ideia da tendência, mas não permitem afirmar qual entre $10^{-3}$ e $10^{-2}$ é melhor.
:::

## 6.14 Referências e leituras

**O que estudar primeiro.** Goodfellow, Bengio e Courville (2016): capítulos 6 (redes *feedforward* profundas), 7 (regularização) e 8 (otimização). Para a prática, os tutoriais oficiais do PyTorch ("Learn the Basics" e "Introduction to PyTorch").

### Livros didáticos fundamentais

- GOODFELLOW, I.; BENGIO, Y.; COURVILLE, A. *Deep Learning*. Cambridge: MIT Press, 2016. Capítulos 6 a 8. Texto completo em deeplearningbook.org.
- HASTIE, T.; TIBSHIRANI, R.; FRIEDMAN, J. *The Elements of Statistical Learning*. 2. ed. New York: Springer, 2009. Capítulo 11 (redes neurais).
- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Capítulo 10 (aprendizado profundo).

### Artigos originais

- BAYDIN, A. G.; PEARLMUTTER, B. A.; RADUL, A. A.; SISKIND, J. M. Automatic differentiation in machine learning: a survey. *Journal of Machine Learning Research*, v. 18, n. 153, p. 1–43, 2018.
- CYBENKO, G. Approximation by superpositions of a sigmoidal function. *Mathematics of Control, Signals and Systems*, v. 2, n. 4, p. 303–314, 1989.
- GLOROT, X.; BENGIO, Y. Understanding the difficulty of training deep feedforward neural networks. In: *Proceedings of the 13th International Conference on Artificial Intelligence and Statistics (AISTATS)*, 2010. p. 249–256.
- HE, K.; ZHANG, X.; REN, S.; SUN, J. Delving deep into rectifiers: surpassing human-level performance on ImageNet classification. In: *Proceedings of the IEEE International Conference on Computer Vision (ICCV)*, 2015. p. 1026–1034.
- HORNIK, K.; STINCHCOMBE, M.; WHITE, H. Multilayer feedforward networks are universal approximators. *Neural Networks*, v. 2, n. 5, p. 359–366, 1989.
- IOFFE, S.; SZEGEDY, C. Batch normalization: accelerating deep network training by reducing internal covariate shift. In: *Proceedings of the 32nd International Conference on Machine Learning (ICML)*, 2015. p. 448–456.
- KINGMA, D. P.; BA, J. Adam: a method for stochastic optimization. In: *3rd International Conference on Learning Representations (ICLR)*, 2015. arXiv:1412.6980.
- LESHNO, M.; LIN, V. Y.; PINKUS, A.; SCHOCKEN, S. Multilayer feedforward networks with a nonpolynomial activation function can approximate any function. *Neural Networks*, v. 6, n. 6, p. 861–867, 1993.
- LOSHCHILOV, I.; HUTTER, F. Decoupled weight decay regularization. In: *7th International Conference on Learning Representations (ICLR)*, 2019.
- MAAS, A. L.; HANNUN, A. Y.; NG, A. Y. Rectifier nonlinearities improve neural network acoustic models. In: *ICML Workshop on Deep Learning for Audio, Speech and Language Processing*, 2013.
- MINSKY, M.; PAPERT, S. *Perceptrons*. Cambridge: MIT Press, 1969.
- NAIR, V.; HINTON, G. E. Rectified linear units improve restricted Boltzmann machines. In: *Proceedings of the 27th International Conference on Machine Learning (ICML)*, 2010. p. 807–814.
- NOVIKOFF, A. B. J. On convergence proofs on perceptrons. In: *Proceedings of the Symposium on the Mathematical Theory of Automata*, v. 12, 1962. p. 615–622.
- PASZKE, A. et al. PyTorch: an imperative style, high-performance deep learning library. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 32, 2019.
- POLYAK, B. T. Some methods of speeding up the convergence of iteration methods. *USSR Computational Mathematics and Mathematical Physics*, v. 4, n. 5, p. 1–17, 1964.
- ROSENBLATT, F. The perceptron: a probabilistic model for information storage and organization in the brain. *Psychological Review*, v. 65, n. 6, p. 386–408, 1958.
- RUMELHART, D. E.; HINTON, G. E.; WILLIAMS, R. J. Learning representations by back-propagating errors. *Nature*, v. 323, p. 533–536, 1986.
- SANTURKAR, S.; TSIPRAS, D.; ILYAS, A.; MĄDRY, A. How does batch normalization help optimization? In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 31, 2018.
- SRIVASTAVA, N.; HINTON, G.; KRIZHEVSKY, A.; SUTSKEVER, I.; SALAKHUTDINOV, R. Dropout: a simple way to prevent neural networks from overfitting. *Journal of Machine Learning Research*, v. 15, n. 56, p. 1929–1958, 2014.
- TIELEMAN, T.; HINTON, G. Lecture 6.5, RMSProp. *COURSERA: Neural Networks for Machine Learning*, 2012.
- WILSON, A. C.; ROELOFS, R.; STERN, M.; SREBRO, N.; RECHT, B. The marginal value of adaptive gradient methods in machine learning. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017.

### Documentação técnica

- PyTorch, tutoriais e documentação: pytorch.org/tutorials e pytorch.org/docs. Em particular os módulos `torch.autograd`, `torch.nn` e `torch.optim`. Versão 2.15 nas execuções deste livro. Repositório dos tutoriais: github.com/pytorch/tutorials.

