## 1.12 Variáveis aleatórias e distribuições

### Motivação

Dados reais contêm ruído. Dois imóveis idênticos nas variáveis medidas são vendidos por preços diferentes; a mesma pergunta admite várias respostas corretas. Um modelo que ignore a incerteza não tem como dizer quanto confia em uma previsão nem o que significa "errar pouco, em média". A probabilidade fornece a linguagem para as duas coisas, e fornece também a origem das funções de perda usadas em todo o livro.

### Probabilidade

Um experimento aleatório tem um conjunto $\Omega$ de resultados possíveis, o **espaço amostral**. Um **evento** é um subconjunto de $\Omega$. Uma **medida de probabilidade** $P$ associa a cada evento um número, respeitando os axiomas de Kolmogorov:

1. $P(A)\ge 0$ para todo evento $A$;
2. $P(\Omega) = 1$;
3. se $A_1, A_2, \dots$ são eventos dois a dois disjuntos, $P(A_1\cup A_2\cup\cdots) = \sum_i P(A_i)$.

Deles decorrem as regras usuais, como $P(A^c) = 1-P(A)$ e $P(A\cup B) = P(A)+P(B)-P(A\cap B)$.

::: nota Duas interpretações
Os axiomas dizem como probabilidades se comportam, e não o que significam. Na interpretação **frequentista**, $P(A)$ é a frequência relativa de $A$ em repetições do experimento. Na interpretação **bayesiana**, $P(A)$ quantifica um grau de crença, atualizado diante de evidências. As duas usam a mesma matemática e convivem em aprendizado de máquina; a diferença aparece na forma de tratar os parâmetros de um modelo (fixos e desconhecidos, ou incertos e descritos por uma distribuição).
:::

### Variáveis aleatórias

::: definicao 1.17 · Variável aleatória
Uma **variável aleatória** é uma função $X:\Omega\to\mathbb{R}$ que associa um número a cada resultado do experimento. É **discreta** quando assume valores em um conjunto finito ou enumerável, e **contínua** quando assume valores em um intervalo e tem densidade.
:::

Uma variável discreta é descrita por sua **função de massa de probabilidade**, $p(x) = P(X = x)$, com $p(x)\ge0$ e $\sum_x p(x) = 1$.

Uma variável contínua é descrita por sua **função densidade de probabilidade**, $p(x)\ge0$, com $\int_{-\infty}^{\infty}p(x)\,dx = 1$. Probabilidades são áreas sob a densidade:

$$
P(a\le X\le b) = \int_a^b p(x)\,dx .
$$

::: erro Ler densidade como probabilidade
Para uma variável contínua, $P(X = x) = 0$ em qualquer ponto, e $p(x)$ **não** é uma probabilidade: é uma probabilidade por unidade de comprimento, e pode ser maior que 1. A densidade de uma Gaussiana com desvio padrão $0{,}1$ vale cerca de $3{,}99$ no centro. Apenas integrais da densidade são probabilidades.
:::

### Distribuição de Bernoulli

::: definicao 1.18 · Distribuição de Bernoulli
Uma variável $X$ tem distribuição de **Bernoulli** com parâmetro $p\in[0,1]$, e escreve-se $X\sim\operatorname{Bernoulli}(p)$, se assume o valor 1 com probabilidade $p$ e o valor 0 com probabilidade $1-p$. De forma compacta:

$$
P(X = x) = p^x(1-p)^{1-x}, \qquad x\in\{0,1\}.
$$
:::

A Bernoulli modela qualquer resultado binário: um e-mail é spam ou não, um cliente cancela ou não, um pixel pertence ao objeto ou ao fundo. A forma compacta parece um artifício, mas tem função: tomando o logaritmo, obtém-se $x\log p + (1-x)\log(1-p)$, expressão que é o núcleo da entropia cruzada binária dos Capítulos 4 e 6.

A generalização para $K$ resultados é a distribuição **categórica**, com probabilidades $p_1,\dots,p_K$ que somam 1. A saída de um modelo de linguagem, a cada passo, é uma distribuição categórica sobre o vocabulário (Capítulo 11).

### Distribuição Gaussiana

::: definicao 1.19 · Distribuição Gaussiana
Uma variável contínua $X$ tem distribuição **Gaussiana** (ou normal) de média $\mu$ e variância $\sigma^2>0$, e escreve-se $X\sim\mathcal{N}(\mu,\sigma^2)$, se sua densidade é

$$
p(x) = \frac{1}{\sqrt{2\pi\sigma^2}}\exp\!\Bigl(-\frac{(x-\mu)^2}{2\sigma^2}\Bigr).
$$
:::

Cada parte da fórmula tem uma função. O expoente é o quadrado da distância de $x$ até $\mu$, medida em unidades de $\sigma$; a densidade decai rapidamente com essa distância. O fator $1/\sqrt{2\pi\sigma^2}$ existe apenas para que a área total seja 1. O parâmetro $\mu$ desloca a curva; $\sigma$ a alarga. Cerca de 68% da probabilidade fica a até um desvio padrão da média, 95% a até dois e 99,7% a até três.

Três razões explicam a presença constante da Gaussiana.

- **Teorema Central do Limite.** A soma de muitas variáveis independentes, de mesma distribuição e variância finita, devidamente padronizada, tem distribuição aproximadamente Gaussiana. Ruídos que resultam de muitas pequenas causas independentes tendem a ser bem descritos por ela.
- **Tratabilidade.** Somas e transformações lineares de Gaussianas são Gaussianas, e quase toda conta tem forma fechada.
- **Hipótese mínima.** Entre as distribuições com média e variância dadas, a Gaussiana é a de maior entropia: é a escolha que menos acrescenta suposições.

::: atencao Gaussiana é hipótese, e não fato
Dizer que o ruído é Gaussiano é uma **hipótese estatística** conveniente. Dados com valores extremos frequentes (rendas, tempos de resposta, retornos financeiros) violam essa hipótese, e os métodos que dela dependem herdam a fragilidade.
:::

### Gaussiana multivariada

Para um vetor aleatório $\mathbf{x}\in\mathbb{R}^d$, a Gaussiana tem como parâmetros um vetor de médias $\boldsymbol\mu\in\mathbb{R}^d$ e uma matriz de covariância $\boldsymbol\Sigma\in\mathbb{R}^{d\times d}$, simétrica e definida positiva (a covariância é definida na seção 1.14):

$$
p(\mathbf{x}) = \frac{1}{\sqrt{(2\pi)^d\det\boldsymbol\Sigma}}\exp\!\Bigl(-\tfrac12(\mathbf{x}-\boldsymbol\mu)^\top\boldsymbol\Sigma^{-1}(\mathbf{x}-\boldsymbol\mu)\Bigr).
$$

A expressão reúne quase toda a álgebra linear do capítulo. O expoente é uma forma quadrática. As curvas de nível da densidade são elipses cujos eixos são os autovetores de $\boldsymbol\Sigma$, com comprimentos proporcionais às raízes dos autovalores. O determinante aparece como fator de volume, no papel que $\sigma^2$ tinha no caso escalar.

## 1.13 Probabilidade condicional e Teorema de Bayes

### Motivação

Aprender com dados é rever o que se sabe à luz de uma observação. A probabilidade condicional formaliza "o que se sabe depois de observar", e o Teorema de Bayes diz como fazer a revisão.

::: definicao 1.20 · Probabilidade condicional
Para eventos $A$ e $B$, com $P(B)>0$, a **probabilidade condicional** de $A$ dado $B$ é

$$
P(A\mid B) = \frac{P(A\cap B)}{P(B)}.
$$
:::

Condicionar em $B$ é restringir o universo aos resultados em que $B$ ocorreu e renormalizar. Rearranjando a definição, obtém-se a **regra do produto**:

$$
P(A\cap B) = P(A\mid B)\,P(B) = P(B\mid A)\,P(A).
$$

Aplicada repetidamente, ela fornece a **regra da cadeia da probabilidade**:

$$
P(A_1\cap A_2\cap\dots\cap A_n) = P(A_1)\,P(A_2\mid A_1)\,P(A_3\mid A_1\cap A_2)\cdots P(A_n\mid A_1\cap\dots\cap A_{n-1}).
$$

Essa é uma **identidade matemática**, válida sem hipótese alguma.

::: aplicacao Regra da cadeia e modelos de linguagem
A probabilidade de uma frase com tokens $w_1,\dots,w_T$ fatora-se, pela regra da cadeia, em $\prod_{t=1}^{T}P(w_t\mid w_1,\dots,w_{t-1})$. Um modelo de linguagem autoregressivo (Capítulos 9 e 11) é um estimador de cada um desses fatores: dada a sequência anterior, ele produz a distribuição do próximo token. A fatoração é exata; o que se aproxima é cada fator.
:::

::: definicao 1.21 · Independência
Os eventos $A$ e $B$ são **independentes** se $P(A\cap B) = P(A)\,P(B)$. Quando $P(B)>0$, isso equivale a $P(A\mid B) = P(A)$: saber que $B$ ocorreu não altera a probabilidade de $A$.
:::

### Probabilidade total

Se os eventos $B_1,\dots,B_k$ são disjuntos e cobrem $\Omega$ (formam uma partição), então, para qualquer evento $A$,

$$
P(A) = \sum_{i=1}^k P(A\mid B_i)\,P(B_i).
$$

A fórmula decompõe $A$ nos pedaços $A\cap B_i$, que são disjuntos, e aplica a regra do produto a cada um.

::: teorema 1.8 · Teorema de Bayes
Para eventos $A$ e $B$ com $P(A)>0$ e $P(B)>0$,

$$
P(A\mid B) = \frac{P(B\mid A)\,P(A)}{P(B)}.
$$
:::

::: demonstracao
Pela regra do produto, $P(A\mid B)\,P(B) = P(A\cap B) = P(B\mid A)\,P(A)$. Dividindo por $P(B)$, obtém-se o resultado.
:::

A demonstração tem uma linha. A importância está na leitura. Quando $A$ é uma hipótese $H$ e $B$ são dados observados $D$, cada termo ganha um nome:

$$
\underbrace{P(H\mid D)}_{\text{posterior}} = \frac{\overbrace{P(D\mid H)}^{\text{verossimilhança}}\;\overbrace{P(H)}^{\text{priori}}}{\underbrace{P(D)}_{\text{evidência}}}.
$$

A **priori** é a crença antes dos dados. A **verossimilhança** diz quão compatíveis os dados são com a hipótese. A **posterior** é a crença revista. A **evidência** é uma constante de normalização, calculada pela probabilidade total.

::: exemplo 1.7 · Teste diagnóstico
Uma doença atinge 1% de uma população. Um teste tem sensibilidade de 95% (probabilidade de resultado positivo em quem tem a doença) e especificidade de 90% (probabilidade de resultado negativo em quem não tem). Uma pessoa recebe resultado positivo. Qual é a probabilidade de que tenha a doença?

Sejam $D$ o evento "tem a doença" e $T$ o evento "teste positivo". Os dados são $P(D) = 0{,}01$, $P(T\mid D) = 0{,}95$ e $P(T\mid D^c) = 1 - 0{,}90 = 0{,}10$.

Pela probabilidade total:

$$
P(T) = 0{,}95\times0{,}01 + 0{,}10\times0{,}99 = 0{,}0095 + 0{,}0990 = 0{,}1085 .
$$

Pelo Teorema de Bayes:

$$
P(D\mid T) = \frac{0{,}95\times 0{,}01}{0{,}1085}\approx 0{,}0876 .
$$

Mesmo com resultado positivo, a probabilidade de doença é inferior a 9%. Em 10 000 pessoas, 100 têm a doença e 95 delas testam positivo; das 9 900 saudáveis, 990 também testam positivo. Os verdadeiros positivos são 95 em 1 085.
:::

::: erro Inverter a condicional
Confundir $P(T\mid D) = 0{,}95$ com $P(D\mid T)\approx 0{,}09$ é o engano conhecido como negligência da taxa-base. Ele reaparece no Capítulo 5 com outros nomes: sensibilidade é o *recall*, e $P(D\mid T)$ é a *precisão* de um classificador. Um classificador com excelente recall pode ter precisão muito baixa quando a classe positiva é rara.
:::

### De Bayes às funções de perda

Seja um modelo com parâmetros $\boldsymbol\theta$ e dados observados $\mathcal{D}$. A **Estimação por Máxima Verossimilhança** (*Maximum Likelihood Estimation*, MLE) escolhe os parâmetros que tornam os dados observados mais prováveis:

$$
\hat{\boldsymbol\theta}_{\text{MLE}} = \arg\max_{\boldsymbol\theta}\; p(\mathcal{D}\mid\boldsymbol\theta).
$$

Supondo exemplos independentes, a verossimilhança é um produto, e seu logaritmo é uma soma. Como o logaritmo é crescente, maximizar a verossimilhança equivale a minimizar o negativo da log-verossimilhança:

$$
\hat{\boldsymbol\theta}_{\text{MLE}} = \arg\min_{\boldsymbol\theta}\;\Bigl(-\sum_{i=1}^n\log p(y_i\mid\mathbf{x}_i,\boldsymbol\theta)\Bigr).
$$

Essa expressão é a ponte entre probabilidade e otimização: **escolher um modelo probabilístico para os dados determina a função de perda**. A proposição a seguir mostra o primeiro caso; os Capítulos 4 e 6 mostram os demais.

::: proposicao 1.9 · Ruído Gaussiano leva ao erro quadrático
Suponha $y_i = f(\mathbf{x}_i;\boldsymbol\theta)+\varepsilon_i$, com ruídos $\varepsilon_i\sim\mathcal{N}(0,\sigma^2)$ independentes e $\sigma^2$ fixo. Então o estimador de máxima verossimilhança de $\boldsymbol\theta$ é o minimizador do erro quadrático médio.
:::

::: demonstracao
Sob a hipótese, $y_i\mid\mathbf{x}_i\sim\mathcal{N}\bigl(f(\mathbf{x}_i;\boldsymbol\theta),\sigma^2\bigr)$. Pela Definição 1.19,

$$
-\sum_{i=1}^n\log p(y_i\mid\mathbf{x}_i,\boldsymbol\theta) = \frac{n}{2}\log(2\pi\sigma^2)+\frac{1}{2\sigma^2}\sum_{i=1}^n\bigl(y_i-f(\mathbf{x}_i;\boldsymbol\theta)\bigr)^2 .
$$

O primeiro termo não depende de $\boldsymbol\theta$, e o fator $1/2\sigma^2$ é uma constante positiva. Minimizar a expressão em $\boldsymbol\theta$ é, portanto, minimizar a soma dos quadrados dos resíduos, que difere do erro quadrático médio pelo fator constante $1/n$.
:::

O resultado esclarece o estatuto do erro quadrático médio: ele é a perda **correta** sob a hipótese de ruído Gaussiano de variância constante, e uma escolha discutível quando essa hipótese falha, por exemplo na presença de valores extremos. De modo análogo, supor resposta Bernoulli conduz à entropia cruzada binária (Exercício 1.16).

Quando se dispõe de uma distribuição a priori $p(\boldsymbol\theta)$, pode-se maximizar a posterior, o que acrescenta o termo $-\log p(\boldsymbol\theta)$ à perda. Uma priori Gaussiana sobre os parâmetros produz exatamente a penalidade $\ell_2$ da regressão Ridge, e uma priori de Laplace produz a penalidade $\ell_1$ do Lasso (Capítulo 5). Regularização e crença a priori são duas descrições do mesmo termo.

## 1.14 Esperança, variância e covariância

### Esperança

::: definicao 1.22 · Esperança
A **esperança** (ou valor esperado) de uma variável aleatória $X$ é

$$
\mathbb{E}[X] = \sum_x x\,p(x)\quad\text{(caso discreto)},\qquad \mathbb{E}[X] = \int_{-\infty}^{\infty}x\,p(x)\,dx\quad\text{(caso contínuo)},
$$

quando a soma ou a integral converge absolutamente. Para uma função $g$, $\mathbb{E}[g(X)] = \sum_x g(x)\,p(x)$, com a integral correspondente no caso contínuo.
:::

A esperança é a média dos valores possíveis, ponderada pelas probabilidades: o centro de massa da distribuição. Pela Lei dos Grandes Números, a média de muitas amostras independentes aproxima-se de $\mathbb{E}[X]$. É o que justifica estimar esperanças por médias amostrais, procedimento conhecido como método de Monte Carlo.

A propriedade mais usada é a **linearidade**: para quaisquer variáveis $X$ e $Y$ e constantes $a$, $b$, $c$,

$$
\mathbb{E}[aX+bY+c] = a\,\mathbb{E}[X]+b\,\mathbb{E}[Y]+c .
$$

A linearidade **não exige independência**. Já a regra $\mathbb{E}[XY] = \mathbb{E}[X]\,\mathbb{E}[Y]$ vale quando $X$ e $Y$ são independentes, e em geral falha sem essa hipótese.

### Variância

::: definicao 1.23 · Variância e desvio padrão
A **variância** de $X$, com $\mu = \mathbb{E}[X]$, é

$$
\operatorname{Var}(X) = \mathbb{E}\bigl[(X-\mu)^2\bigr].
$$

O **desvio padrão** é $\sigma = \sqrt{\operatorname{Var}(X)}$, e tem a mesma unidade de $X$.
:::

A variância é o quadrado da distância típica entre $X$ e sua média. Uma fórmula equivalente facilita as contas.

::: proposicao 1.10 · Fórmula da variância
$\operatorname{Var}(X) = \mathbb{E}[X^2]-\bigl(\mathbb{E}[X]\bigr)^2$. Além disso, $\operatorname{Var}(aX+b) = a^2\operatorname{Var}(X)$.
:::

::: demonstracao
Expandindo o quadrado e usando a linearidade, com $\mu$ constante: $\mathbb{E}[(X-\mu)^2] = \mathbb{E}[X^2]-2\mu\,\mathbb{E}[X]+\mu^2 = \mathbb{E}[X^2]-\mu^2$. Para a segunda afirmação, $\mathbb{E}[aX+b] = a\mu+b$, logo $\operatorname{Var}(aX+b) = \mathbb{E}[(aX-a\mu)^2] = a^2\,\mathbb{E}[(X-\mu)^2]$.
:::

::: exemplo 1.8 · Esperança e variância de Bernoulli e da Gaussiana
Para $X\sim\operatorname{Bernoulli}(p)$: $\mathbb{E}[X] = 1\cdot p+0\cdot(1-p) = p$. Como $X^2 = X$ (os valores são 0 e 1), $\mathbb{E}[X^2] = p$, e portanto $\operatorname{Var}(X) = p-p^2 = p(1-p)$. A variância é máxima em $p = 0{,}5$, o caso de maior incerteza, e nula em $p = 0$ ou $p = 1$.

Para $X\sim\mathcal{N}(\mu,\sigma^2)$, os parâmetros são exatamente a média e a variância: $\mathbb{E}[X] = \mu$ e $\operatorname{Var}(X) = \sigma^2$.
:::

### Covariância e correlação

::: definicao 1.24 · Covariância e correlação
A **covariância** entre $X$ e $Y$, com médias $\mu_X$ e $\mu_Y$, é

$$
\operatorname{Cov}(X,Y) = \mathbb{E}\bigl[(X-\mu_X)(Y-\mu_Y)\bigr] = \mathbb{E}[XY]-\mu_X\mu_Y .
$$

A **correlação** é a covariância normalizada pelos desvios padrão:

$$
\rho_{XY} = \frac{\operatorname{Cov}(X,Y)}{\sigma_X\,\sigma_Y}\in[-1,1].
$$
:::

A covariância é positiva quando valores de $X$ acima da média tendem a acompanhar valores de $Y$ acima da média, e negativa quando tendem a acompanhar valores abaixo. A correlação elimina a dependência das unidades. O fato de $\rho$ ficar entre $-1$ e $1$ é, mais uma vez, a desigualdade de Cauchy–Schwarz: a covariância comporta-se como um produto escalar entre variáveis centradas, o desvio padrão como uma norma, e a correlação como o cosseno do ângulo entre elas.

A variância da soma de duas variáveis é

$$
\operatorname{Var}(X+Y) = \operatorname{Var}(X)+\operatorname{Var}(Y)+2\operatorname{Cov}(X,Y),
$$

e reduz-se à soma das variâncias quando a covariância é nula.

::: erro Covariância nula não é independência
Independência implica covariância zero, mas a recíproca é falsa. Se $X\sim\mathcal{N}(0,1)$ e $Y = X^2$, então $Y$ é completamente determinada por $X$ e, ainda assim, $\operatorname{Cov}(X,Y) = \mathbb{E}[X^3]-\mathbb{E}[X]\,\mathbb{E}[X^2] = 0$. A covariância detecta apenas relações **lineares**. E, quando detecta uma relação, não informa a causa: correlação não estabelece causalidade.
:::

### Matriz de covariância

::: definicao 1.25 · Matriz de covariância
Para um vetor aleatório $\mathbf{x}\in\mathbb{R}^d$ com média $\boldsymbol\mu = \mathbb{E}[\mathbf{x}]$, a **matriz de covariância** é

$$
\boldsymbol\Sigma = \mathbb{E}\bigl[(\mathbf{x}-\boldsymbol\mu)(\mathbf{x}-\boldsymbol\mu)^\top\bigr]\in\mathbb{R}^{d\times d},\qquad \Sigma_{ij} = \operatorname{Cov}(x_i,x_j).
$$
:::

A diagonal contém as variâncias de cada componente; fora dela, as covariâncias entre pares.

::: proposicao 1.11 · Propriedades da matriz de covariância
A matriz $\boldsymbol\Sigma$ é simétrica e semidefinida positiva. Para $\mathbf{A}\in\mathbb{R}^{m\times d}$ e $\mathbf{b}\in\mathbb{R}^m$ constantes, o vetor $\mathbf{y} = \mathbf{A}\mathbf{x}+\mathbf{b}$ tem média $\mathbf{A}\boldsymbol\mu+\mathbf{b}$ e covariância $\mathbf{A}\boldsymbol\Sigma\mathbf{A}^\top$.
:::

::: demonstracao
A simetria vem de $\operatorname{Cov}(x_i,x_j) = \operatorname{Cov}(x_j,x_i)$. Para a segunda parte, a linearidade da esperança dá $\mathbb{E}[\mathbf{y}] = \mathbf{A}\boldsymbol\mu+\mathbf{b}$, e então $\mathbf{y}-\mathbb{E}[\mathbf{y}] = \mathbf{A}(\mathbf{x}-\boldsymbol\mu)$. Logo a covariância de $\mathbf{y}$ é $\mathbb{E}[\mathbf{A}(\mathbf{x}-\boldsymbol\mu)(\mathbf{x}-\boldsymbol\mu)^\top\mathbf{A}^\top] = \mathbf{A}\boldsymbol\Sigma\mathbf{A}^\top$. Tomando $\mathbf{A} = \mathbf{v}^\top$, para um vetor $\mathbf{v}$ qualquer, a variável escalar $\mathbf{v}^\top\mathbf{x}$ tem variância $\mathbf{v}^\top\boldsymbol\Sigma\mathbf{v}$. Como variâncias não são negativas, $\mathbf{v}^\top\boldsymbol\Sigma\mathbf{v}\ge0$ para todo $\mathbf{v}$.
:::

A proposição liga as três partes do capítulo. A forma quadrática $\mathbf{v}^\top\boldsymbol\Sigma\mathbf{v}$ é a variância dos dados projetados na direção $\mathbf{v}$. Pelo teorema espectral, a direção unitária de maior variância é o autovetor de $\boldsymbol\Sigma$ com maior autovalor. Essa é a ideia da Análise de Componentes Principais, apresentada no Capítulo 3.

Na prática, $\boldsymbol\mu$ e $\boldsymbol\Sigma$ são desconhecidas e estimadas a partir de uma matriz de dados $\mathbf{X}\in\mathbb{R}^{n\times d}$. Com $\bar{\mathbf{x}}$ a média das linhas e $\mathbf{X}_c$ a matriz com a média subtraída de cada linha, a covariância amostral é

$$
\hat{\boldsymbol\Sigma} = \frac{1}{n-1}\,\mathbf{X}_c^\top\mathbf{X}_c .
$$

O divisor $n-1$, em vez de $n$, torna o estimador não viesado, isto é, sua esperança é exatamente $\boldsymbol\Sigma$. A noção de viés de um estimador será central no Capítulo 5.

### Implementação

<<< codigo/c1_prob.py

>>> codigo/c1_prob.out

O programa confere, por simulação, três resultados do texto. O bloco 1 reproduz o Exemplo 1.7: a frequência de doentes entre os que testaram positivo, em um milhão de pessoas simuladas, coincide com o valor do Teorema de Bayes. O bloco 2 confere as médias e variâncias do Exemplo 1.8. O bloco 3 usa a Proposição 1.11 no sentido inverso: para gerar amostras com covariância $\boldsymbol\Sigma$ a partir de ruído padrão $\mathbf{z}\sim\mathcal{N}(\mathbf{0},\mathbf{I})$, basta uma matriz $\mathbf{L}$ com $\mathbf{L}\mathbf{L}^\top = \boldsymbol\Sigma$, pois a covariância de $\mathbf{L}\mathbf{z}$ é $\mathbf{L}\mathbf{I}\mathbf{L}^\top$. A fatoração de Cholesky fornece essa matriz.

As pequenas diferenças entre valores simulados e teóricos são erro de Monte Carlo, que decresce na proporção de $1/\sqrt{n}$: para ganhar um algarismo decimal de precisão, é preciso multiplicar o número de amostras por 100.

## 1.15 Dos fundamentos aos algoritmos modernos

A tabela reúne os conceitos do capítulo e indica onde cada um volta a ser usado. Ela serve como mapa de revisão: ao chegar a um capítulo posterior, releia as seções correspondentes.

| Conceito | Onde reaparece | Papel |
|---|---|---|
| Vetores, matrizes, tensores | Todos os capítulos | Representação de dados, parâmetros e ativações |
| Produto matricial | 6, 7, 9 | Camadas lineares; composição de transformações |
| Produto escalar | 6, 9, 12 | Neurônio; pontuação de atenção; similaridade entre *embeddings* |
| Normas $\ell_1$ e $\ell_2$ | 4, 5, 12 | Funções de perda; regularização Lasso e Ridge; distâncias |
| Posto | 3, 10 | Redução de dimensionalidade; LoRA |
| Autovalores e autovetores | 3, 5, 6, 8 | Componentes principais; condicionamento; gradientes que explodem ou se dissipam |
| Condicionamento | 4, 5, 6 | Estabilidade dos mínimos quadrados; normalização de entradas e de camadas |
| Gradiente e regra da cadeia | 4, 6 a 10 | Treinamento de todos os modelos; backpropagation |
| Hessiana e convexidade | 4, 6 | Garantias da regressão; dificuldades de redes profundas |
| Descida do gradiente | 4, 6 a 10 | SGD, Momentum, RMSProp, Adam |
| Bernoulli e categórica | 4, 6, 11 | Classificação; entropia cruzada; amostragem de tokens |
| Gaussiana | 3, 4, 6 | Modelo de ruído; inicialização de pesos |
| Probabilidade condicional e regra da cadeia | 9, 11 | Modelagem autoregressiva de linguagem |
| Teorema de Bayes | 3, 5, 15 | Classificador de Bayes; precisão e recall; avaliação |
| Esperança e variância | 3, 5 | Risco esperado; decomposição viés-variância |
| Covariância | 3, 6 | Componentes principais; normalização |

Um exemplo de como as peças se encaixam. No Capítulo 8, uma rede recorrente aplica a mesma matriz $\mathbf{W}$ a cada passo de tempo; pela regra da cadeia, o gradiente em relação a estados distantes contém um produto de muitas Jacobianas que envolvem $\mathbf{W}$. Pela análise da iteração de potência da seção 1.6, esse produto cresce ou decai conforme os valores singulares das Jacobianas sejam maiores ou menores que 1. A explosão e a dissipação de gradientes, que motivaram as LSTMs e depois os Transformers, são um fenômeno de autovalores.
