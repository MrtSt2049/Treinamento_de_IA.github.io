## 1.16 Projeto 1: fundamentos matemáticos computacionais

::: projeto Regressão linear por descida do gradiente, apenas com NumPy
O projeto reúne as três partes do capítulo em um programa: operações matriciais, gradiente analítico conferido numericamente e otimização, sobre dados gerados com ruído Gaussiano.
:::

### Objetivo

Implementar, sem bibliotecas de aprendizado de máquina, o ajuste de um modelo linear por descida do gradiente, e demonstrar por testes automáticos que a implementação está correta.

### Problema

Dados $n$ exemplos $(\mathbf{x}_i,y_i)$, com $\mathbf{x}_i\in\mathbb{R}^d$, encontrar pesos $\mathbf{w}\in\mathbb{R}^d$ e intercepto $b$ que minimizem o erro quadrático médio das previsões $\hat y_i = \mathbf{w}^\top\mathbf{x}_i+b$.

### Requisitos

- Usar apenas NumPy.
- Não usar laços sobre exemplos: todas as operações devem ser matriciais.
- Conferir o gradiente analítico por diferenças finitas.
- Escolher a taxa de aprendizado a partir da curvatura, e não por tentativa.
- Comparar o resultado com a solução direta de mínimos quadrados.

### Arquitetura

<figure>
<svg class="fig" viewBox="0 0 720 120" role="img" aria-label="Fluxo do projeto: gerar dados, montar matriz com intercepto, calcular perda e gradiente, conferir gradiente, treinar, validar contra mínimos quadrados">
<defs><marker id="seta1" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pt"/></marker></defs>
<g font-size="12" font-weight="700" text-anchor="middle">
<rect class="cx" x="2" y="30" width="104" height="56" rx="6"/><text x="54" y="55">gerar_dados</text><text x="54" y="72" class="t2" font-weight="400">X, y</text>
<rect class="cx" x="124" y="30" width="110" height="56" rx="6"/><text x="179" y="55">intercepto</text><text x="179" y="72" class="t2" font-weight="400">coluna de uns</text>
<rect class="cx" x="252" y="30" width="110" height="56" rx="6"/><text x="307" y="55">perda, gradiente</text><text x="307" y="72" class="t2" font-weight="400">forma matricial</text>
<rect class="cxa" x="380" y="30" width="104" height="56" rx="6"/><text x="432" y="55">teste 1</text><text x="432" y="72" class="t2" font-weight="400">grad. numérico</text>
<rect class="cx" x="502" y="30" width="90" height="56" rx="6"/><text x="547" y="55">treinar</text><text x="547" y="72" class="t2" font-weight="400">η = 1/L</text>
<rect class="cxa" x="610" y="30" width="108" height="56" rx="6"/><text x="664" y="55">testes 2 a 4</text><text x="664" y="72" class="t2" font-weight="400">validação</text>
</g>
<g class="ln" marker-end="url(#seta1)"><path d="M106 58H122"/><path d="M234 58H250"/><path d="M362 58H378"/><path d="M484 58H500"/><path d="M592 58H608"/></g>
</svg>
<figcaption><b>Figura 1.3.</b> Etapas do Projeto 1. Em azul, as etapas de verificação.</figcaption>
</figure>

### Fundamentos teóricos

**Intercepto como parâmetro.** Acrescentando uma coluna de uns a $\mathbf{X}$, o modelo $\mathbf{w}^\top\mathbf{x}+b$ torna-se $\tilde{\mathbf{X}}\boldsymbol\theta$, com $\boldsymbol\theta = (\mathbf{w}, b)$. Daqui em diante, $\mathbf{X}$ denota a matriz já aumentada.

**Perda e gradiente.** Pelo Exemplo 1.5, $\mathcal{L}(\boldsymbol\theta) = \tfrac1n\lVert\mathbf{X}\boldsymbol\theta-\mathbf{y}\rVert_2^2$ e $\nabla\mathcal{L}(\boldsymbol\theta) = \tfrac2n\mathbf{X}^\top(\mathbf{X}\boldsymbol\theta-\mathbf{y})$.

**Taxa de aprendizado.** A Hessiana é $\tfrac2n\mathbf{X}^\top\mathbf{X}$ (Exemplo 1.6). Pelo Teorema 1.7, qualquer taxa abaixo de $2/L$ converge, em que $L$ é o maior autovalor da Hessiana. Adota-se $\eta = 1/L$, com a qual a perda diminui a cada passo.

**Condição de otimalidade.** No mínimo, $\nabla\mathcal{L} = \mathbf{0}$, isto é, $\mathbf{X}^\top(\mathbf{y}-\mathbf{X}\boldsymbol\theta) = \mathbf{0}$: o vetor de resíduos é ortogonal a todas as colunas de $\mathbf{X}$. Essa propriedade, que será interpretada geometricamente no Capítulo 4, fornece um teste independente do algoritmo.

### Implementação

<<< codigo/projeto1.py

### Testes e resultados

>>> codigo/projeto1.out

Leitura dos resultados:

- **Teste 1.** O erro relativo entre o gradiente analítico e o numérico é da ordem de $10^{-10}$. Valores abaixo de $10^{-6}$ indicam implementação correta; valores próximos de 1 indicam erro de sinal ou de fator.
- **Teste 2.** A perda decresce monotonicamente, como previsto para $\eta = 1/L$, e estabiliza em cerca de $0{,}25$. Esse valor é a variância do ruído usado na geração ($0{,}5^2$): nenhum modelo pode ficar sistematicamente abaixo dele. Trata-se de uma primeira aparição do **erro irredutível** do Capítulo 3.
- **Teste 3.** A descida do gradiente e a solução direta coincidem. Os parâmetros estimados ficam próximos dos geradores, mas não são iguais a eles: com 200 exemplos ruidosos, o estimador tem variância.
- **Teste 4.** O resíduo é ortogonal às colunas de $\mathbf{X}$ até a precisão da máquina.
- **Divergência.** Com $\eta = 2{,}2/L$, acima do limite do Teorema 1.7, a perda explode.

### Limitações

- O gradiente usa todos os exemplos a cada passo; com milhões de exemplos, isso é inviável.
- O cálculo de $L$ exige os autovalores de $\mathbf{X}^\top\mathbf{X}$, o que só é possível em problemas pequenos e quadráticos.
- Os dados são sintéticos e obedecem exatamente às hipóteses do modelo. Dados reais não obedecem.
- Não há separação entre treino e teste: o projeto verifica a otimização, e não a generalização.

### Melhorias possíveis

1. Padronizar as colunas de $\mathbf{X}$ e medir o efeito sobre o número de condição e sobre o número de passos.
2. Implementar a versão estocástica, com lotes de 16 exemplos, e comparar as curvas de perda.
3. Acrescentar a penalidade $\lambda\lVert\mathbf{w}\rVert_2^2$ (Exercício 1.10) e observar o encolhimento dos pesos.
4. Substituir o número fixo de passos por um critério de parada baseado na norma do gradiente.

## 1.17 Resumo do capítulo

::: resumo Ideias centrais
- **Dados e parâmetros são arranjos.** A forma de cada arranjo deve ser conhecida e conferida em toda operação.
- **Matrizes são funções lineares**, e o produto matricial é a composição dessas funções.
- **O produto escalar mede alinhamento**; as normas medem tamanho. A desigualdade de Cauchy–Schwarz sustenta o cosseno, a correlação e a direção de maior descida.
- **Autovalores revelam as direções em que uma matriz apenas estica.** Para matrizes simétricas, eles são reais e os autovetores são ortogonais.
- **Resolver sistemas é diferente de inverter matrizes**, e o número de condição diz quanta precisão será perdida.
- **O gradiente aponta a subida mais íngreme; a Hessiana descreve a curvatura.** A descida do gradiente converge em funções quadráticas se e somente se $\eta<2/L$, com velocidade ditada pelo número de condição.
- **O Teorema de Bayes atualiza crenças com dados.** Escolher um modelo probabilístico para os dados determina a função de perda: ruído Gaussiano leva ao erro quadrático.
- **Esperança é linear sempre; variâncias somam-se apenas quando a covariância é nula.** A matriz de covariância é simétrica e semidefinida positiva.
:::

## 1.18 Exercícios

### Nível I: consolidação

**1.1** Sejam $\mathbf{A}\in\mathbb{R}^{3\times4}$, $\mathbf{B}\in\mathbb{R}^{4\times2}$ e $\mathbf{x}\in\mathbb{R}^4$. Para cada expressão, diga se está definida e qual é a forma do resultado: (a) $\mathbf{A}\mathbf{B}$; (b) $\mathbf{B}\mathbf{A}$; (c) $\mathbf{A}\mathbf{x}$; (d) $\mathbf{A}^\top\mathbf{A}$; (e) $\mathbf{x}^\top\mathbf{x}$; (f) $\mathbf{x}\mathbf{x}^\top$.

**1.2** Para $\mathbf{u} = (1,2,2)^\top$ e $\mathbf{v} = (2,0,-1)^\top$, calcule $\mathbf{u}^\top\mathbf{v}$, $\lVert\mathbf{u}\rVert_2$, $\lVert\mathbf{u}\rVert_1$, $\lVert\mathbf{v}\rVert_2$ e o ângulo entre os vetores.

**1.3** Calcule o determinante de $\begin{bmatrix}1&2\\3&4\end{bmatrix}$ e de $\begin{bmatrix}1&2\\2&4\end{bmatrix}$. Qual delas é invertível? Interprete geometricamente.

**1.4** Encontre os autovalores e autovetores de $\begin{bmatrix}4&1\\1&4\end{bmatrix}$. A matriz é definida positiva?

**1.5** Para $f(x_1,x_2) = x_1^2+3x_1x_2+5x_2^2$, calcule o gradiente e a Hessiana. Classifique o ponto crítico.

**1.6** Em uma caixa de entrada, 20% das mensagens são spam. A palavra "promoção" aparece em 40% das mensagens de spam e em 5% das demais. Qual é a probabilidade de uma mensagem que contém "promoção" ser spam?

### Nível II: desenvolvimento

**1.7** Mostre que, para vetores de norma 1, $\lVert\mathbf{u}-\mathbf{v}\rVert_2^2 = 2-2\cos\theta$. Conclua que, nesse caso, ordenar vizinhos por distância euclidiana crescente ou por cosseno decrescente produz a mesma lista.

**1.8** Prove que $\lVert\mathbf{x}\rVert_2\le\lVert\mathbf{x}\rVert_1\le\sqrt n\,\lVert\mathbf{x}\rVert_2$ para todo $\mathbf{x}\in\mathbb{R}^n$. Dê exemplos em que cada igualdade é atingida.

**1.9** Prove, a partir das definições, que $(\mathbf{A}\mathbf{B})^\top = \mathbf{B}^\top\mathbf{A}^\top$.

**1.10** Para $\lambda>0$, considere $f(\mathbf{x}) = \lVert\mathbf{A}\mathbf{x}-\mathbf{b}\rVert_2^2+\lambda\lVert\mathbf{x}\rVert_2^2$. (a) Calcule o gradiente. (b) Mostre que o minimizador satisfaz $(\mathbf{A}^\top\mathbf{A}+\lambda\mathbf{I})\mathbf{x} = \mathbf{A}^\top\mathbf{b}$. (c) Mostre que essa matriz é sempre invertível. (d) O que acontece com o número de condição quando $\lambda$ cresce?

**1.11** Para $f(x_1,x_2) = x_1^2+10x_2^2$, a partir de $\mathbf{x}_0 = (10,1)^\top$ e com $\eta = 0{,}05$, calcule à mão dois passos da descida do gradiente. Determine o intervalo de taxas que convergem, a melhor taxa constante e o fator de contração correspondente.

**1.12** Prove que $\operatorname{Var}(X+Y) = \operatorname{Var}(X)+\operatorname{Var}(Y)+2\operatorname{Cov}(X,Y)$.

**1.13** (Computacional) Escreva uma função que receba $\mathbf{X}\in\mathbb{R}^{n\times d}$ e $\mathbf{Y}\in\mathbb{R}^{m\times d}$ e devolva a matriz $n\times m$ das distâncias euclidianas entre todas as linhas de $\mathbf{X}$ e todas as linhas de $\mathbf{Y}$, sem laços em Python. Confira contra uma versão com laços.

**1.14** Seja $X$ o resultado de um dado honesto. Calcule $\mathbb{E}[X]$ e $\operatorname{Var}(X)$. Calcule a esperança e a variância da soma de dois dados independentes.

### Nível III: avançado

**1.15** (Experimento) Gere matrizes simétricas definidas positivas $2\times2$ com números de condição $\kappa\in\{1, 10, 100, 1000\}$. Para cada uma, meça quantos passos da descida do gradiente, com a melhor taxa constante, são necessários para reduzir o erro por um fator $10^{6}$. Compare com a previsão do Teorema 1.7 e explique a relação aproximadamente linear entre passos e $\kappa$.

**1.16** (Derivação) Suponha respostas binárias $y_i\in\{0,1\}$ com $y_i\mid\mathbf{x}_i\sim\operatorname{Bernoulli}(\hat y_i)$, em que $\hat y_i\in(0,1)$ é a saída do modelo. Derive a função de perda correspondente à máxima verossimilhança. Mostre que ela penaliza fortemente previsões confiantes e erradas.

**1.17** (Análise crítica) Estime por simulação a distribuição do cosseno entre dois vetores Gaussianos independentes em $\mathbb{R}^d$, para $d\in\{2,10,100,1000\}$. O que acontece com a média e com o desvio padrão? Discuta a consequência para a interpretação de similaridades entre *embeddings* de alta dimensão.

**1.18** (Pesquisa) O método de Newton usa a Hessiana para escolher o passo: $\mathbf{x}_{k+1} = \mathbf{x}_k-\mathbf{H}^{-1}\nabla f$. (a) Mostre que ele minimiza uma função quadrática definida positiva em um único passo. (b) Estime o custo de memória e de tempo por passo para um modelo com $10^8$ parâmetros. (c) Consulte Nocedal e Wright (2006) e descreva, em uma página, a ideia dos métodos quase-Newton de memória limitada.

## 1.19 Soluções comentadas

::: solucao 1.1
(a) Definida, $3\times2$. (b) Não definida: $(4\times2)(3\times4)$, pois $2\ne3$. (c) Definida, vetor de $\mathbb{R}^3$. (d) Definida, $4\times4$. (e) Definida, escalar: é $\lVert\mathbf{x}\rVert_2^2$. (f) Definida, $4\times4$: matriz de posto 1, chamada produto externo.
:::

::: solucao 1.2
$\mathbf{u}^\top\mathbf{v} = 2+0-2 = 0$; $\lVert\mathbf{u}\rVert_2 = \sqrt{1+4+4} = 3$; $\lVert\mathbf{u}\rVert_1 = 5$; $\lVert\mathbf{v}\rVert_2 = \sqrt5$. Como o produto escalar é zero, os vetores são ortogonais: o ângulo é de $90°$.
:::

::: solucao 1.3
Os determinantes são $1\cdot4-2\cdot3 = -2$ e $1\cdot4-2\cdot2 = 0$. A primeira matriz é invertível: dobra áreas e inverte a orientação. A segunda não é: sua segunda coluna é o dobro da primeira, e o plano é achatado sobre a reta gerada por $(1,2)^\top$.
:::

::: solucao 1.4
$\det(\mathbf{A}-\lambda\mathbf{I}) = (4-\lambda)^2-1 = 0$ dá $\lambda = 3$ e $\lambda = 5$. Autovetores: $(1,-1)^\top/\sqrt2$ para $\lambda=3$ e $(1,1)^\top/\sqrt2$ para $\lambda=5$. Conferência: traço $8 = 3+5$; determinante $15 = 3\cdot5$. Ambos os autovalores são positivos, logo a matriz é definida positiva.
:::

::: solucao 1.5
$\nabla f = (2x_1+3x_2,\ 3x_1+10x_2)^\top$ e $\mathbf{H} = \begin{bmatrix}2&3\\3&10\end{bmatrix}$. O gradiente só se anula na origem, pois o sistema tem determinante $11\neq0$. Os autovalores da Hessiana têm produto $11>0$ e soma $12>0$, portanto são ambos positivos. A Hessiana é definida positiva, e a origem é mínimo estrito. Como a Hessiana é constante, a função é convexa, e o mínimo é global.
:::

::: solucao 1.6
Com $S$ = spam e $W$ = contém a palavra: $P(W) = 0{,}40\times0{,}20+0{,}05\times0{,}80 = 0{,}08+0{,}04 = 0{,}12$. Então $P(S\mid W) = 0{,}08/0{,}12 = 2/3\approx0{,}667$. A palavra eleva a probabilidade de spam de 20% para cerca de 67%, o que está longe de uma certeza.
:::

::: solucao 1.7
$\lVert\mathbf{u}-\mathbf{v}\rVert_2^2 = (\mathbf{u}-\mathbf{v})^\top(\mathbf{u}-\mathbf{v}) = \lVert\mathbf{u}\rVert_2^2+\lVert\mathbf{v}\rVert_2^2-2\,\mathbf{u}^\top\mathbf{v} = 2-2\cos\theta$, pois as normas valem 1 e, nesse caso, $\mathbf{u}^\top\mathbf{v} = \cos\theta$. A distância é função decrescente do cosseno; logo, as duas ordenações coincidem. É por isso que muitos bancos vetoriais normalizam os vetores na ingestão e usam o produto escalar, mais barato, como medida única.
:::

::: solucao 1.8
*Primeira desigualdade.* $\lVert\mathbf{x}\rVert_1^2 = \bigl(\sum_i\lvert x_i\rvert\bigr)^2 = \sum_i x_i^2+\sum_{i\ne j}\lvert x_i\rvert\lvert x_j\rvert\ge\sum_i x_i^2 = \lVert\mathbf{x}\rVert_2^2$. Igualdade quando no máximo uma componente é não nula, por exemplo $\mathbf{x} = \mathbf{e}_1$.

*Segunda desigualdade.* Aplicando Cauchy–Schwarz ao vetor $\mathbf{a}$ com componentes $\lvert x_i\rvert$ e ao vetor de uns: $\lVert\mathbf{x}\rVert_1 = \mathbf{a}^\top\mathbf{1}\le\lVert\mathbf{a}\rVert_2\lVert\mathbf{1}\rVert_2 = \sqrt n\,\lVert\mathbf{x}\rVert_2$. Igualdade quando todas as componentes têm o mesmo módulo, por exemplo $\mathbf{x} = \mathbf{1}$.
:::

::: solucao 1.9
Seja $\mathbf{A}\in\mathbb{R}^{m\times n}$ e $\mathbf{B}\in\mathbb{R}^{n\times p}$. Pela definição de transposta e de produto: $[(\mathbf{A}\mathbf{B})^\top]_{ij} = (\mathbf{A}\mathbf{B})_{ji} = \sum_k A_{jk}B_{ki} = \sum_k(\mathbf{B}^\top)_{ik}(\mathbf{A}^\top)_{kj} = (\mathbf{B}^\top\mathbf{A}^\top)_{ij}$. As formas confirmam a inversão da ordem: $\mathbf{B}^\top\mathbf{A}^\top$ é $(p\times n)(n\times m)$, enquanto $\mathbf{A}^\top\mathbf{B}^\top$ nem sempre está definida.
:::

::: solucao 1.10
(a) Pelas identidades da seção 1.9, $\nabla f(\mathbf{x}) = 2\mathbf{A}^\top(\mathbf{A}\mathbf{x}-\mathbf{b})+2\lambda\mathbf{x}$.

(b) Igualando a zero e reorganizando: $(\mathbf{A}^\top\mathbf{A}+\lambda\mathbf{I})\mathbf{x} = \mathbf{A}^\top\mathbf{b}$.

(c) Para $\mathbf{v}\neq\mathbf{0}$: $\mathbf{v}^\top(\mathbf{A}^\top\mathbf{A}+\lambda\mathbf{I})\mathbf{v} = \lVert\mathbf{A}\mathbf{v}\rVert_2^2+\lambda\lVert\mathbf{v}\rVert_2^2>0$. A matriz é definida positiva, portanto invertível, mesmo quando $\mathbf{A}^\top\mathbf{A}$ não é. A Hessiana de $f$ é o dobro dessa matriz, de modo que $f$ é estritamente convexa e o minimizador é único.

(d) Os autovalores de $\mathbf{A}^\top\mathbf{A}+\lambda\mathbf{I}$ são $\mu_i+\lambda$, em que $\mu_i\ge0$ são os autovalores de $\mathbf{A}^\top\mathbf{A}$. O número de condição $(\mu_{\max}+\lambda)/(\mu_{\min}+\lambda)$ decresce com $\lambda$ e tende a 1. A regularização $\ell_2$ melhora o condicionamento, além de encolher os parâmetros. Esse é o problema Ridge do Capítulo 5.
:::

::: solucao 1.11
$\nabla f = (2x_1, 20x_2)^\top$. Primeiro passo: $\mathbf{x}_1 = (10,1)-0{,}05\,(20,20) = (9,0)$. Segundo passo: $\mathbf{x}_2 = (9,0)-0{,}05\,(18,0) = (8{,}1;\,0)$.

A Hessiana é $\operatorname{diag}(2,20)$, com $L = 20$ e $\kappa = 10$. Convergem as taxas $0<\eta<0{,}1$. A melhor taxa constante é $2/(2+20)\approx0{,}0909$, com fator $\rho = 9/11\approx0{,}818$.

Com $\eta = 0{,}05 = 1/L$, os fatores por componente são $1-0{,}05\cdot2 = 0{,}9$ e $1-0{,}05\cdot20 = 0$: a direção mais curva é resolvida em um passo, e a mais plana avança apenas 10% por passo. O exemplo mostra, em miniatura, por que o mau condicionamento torna a descida lenta.
:::

::: solucao 1.12
Com $\mu_X$ e $\mu_Y$ as médias, a linearidade dá $\mathbb{E}[X+Y] = \mu_X+\mu_Y$. Então $\operatorname{Var}(X+Y) = \mathbb{E}\bigl[\bigl((X-\mu_X)+(Y-\mu_Y)\bigr)^2\bigr] = \mathbb{E}[(X-\mu_X)^2]+\mathbb{E}[(Y-\mu_Y)^2]+2\,\mathbb{E}[(X-\mu_X)(Y-\mu_Y)]$, que é a expressão pedida.
:::

::: solucao 1.13
A identidade $\lVert\mathbf{x}-\mathbf{y}\rVert^2 = \lVert\mathbf{x}\rVert^2+\lVert\mathbf{y}\rVert^2-2\,\mathbf{x}^\top\mathbf{y}$ permite calcular todos os pares com um único produto matricial.

<<< codigo/c1_ex13.py

>>> codigo/c1_ex13.out

O `np.maximum(D2, 0.0)` trata o cancelamento da seção 1.7: para pontos quase idênticos, a soma pode resultar em um número negativo minúsculo, cuja raiz seria `nan`. Essa mesma identidade é usada por bibliotecas de busca vetorial (Capítulo 12).
:::

::: solucao 1.14
$\mathbb{E}[X] = (1+2+\dots+6)/6 = 3{,}5$. $\mathbb{E}[X^2] = 91/6$. $\operatorname{Var}(X) = 91/6-49/4 = 35/12\approx2{,}917$. Para a soma de dois dados independentes: esperança $7$ (linearidade) e variância $35/6\approx5{,}833$ (covariância nula).
:::

::: solucao 1.15 (orientação)
Com a melhor taxa, o erro contrai por $\rho = (\kappa-1)/(\kappa+1)$ a cada passo. O número de passos para um fator $10^{-6}$ é $k\approx\ln(10^6)/(-\ln\rho)$. Para $\kappa$ grande, $-\ln\rho\approx2/\kappa$, de modo que $k\approx6{,}9\,\kappa$: cerca de 69 passos para $\kappa=10$, 690 para $\kappa = 100$ e 6 900 para $\kappa=1000$. Para $\kappa = 1$, um passo basta. O experimento deve reproduzir esses números de perto quando o ponto inicial tem componentes nas duas direções principais. Para gerar as matrizes, use $\mathbf{Q}\operatorname{diag}(1,\kappa)\mathbf{Q}^\top$ com $\mathbf{Q}$ uma rotação.
:::

::: solucao 1.16
A verossimilhança de um exemplo é $\hat y_i^{\,y_i}(1-\hat y_i)^{1-y_i}$ (Definição 1.18). O negativo da log-verossimilhança de $n$ exemplos independentes, dividido por $n$, é

$$
\mathcal{L} = -\frac1n\sum_{i=1}^n\bigl[y_i\log\hat y_i+(1-y_i)\log(1-\hat y_i)\bigr],
$$

a **entropia cruzada binária**. Para um exemplo com $y_i = 1$, a contribuição é $-\log\hat y_i$: vale $0{,}01$ para $\hat y_i = 0{,}99$, vale $0{,}69$ para $\hat y_i = 0{,}5$ e cresce sem limite quando $\hat y_i\to0$. Uma previsão confiante e errada custa muito mais do que uma previsão hesitante, e por isso implementações limitam $\hat y_i$ a um intervalo como $[10^{-7}, 1-10^{-7}]$ ou trabalham diretamente com os *logits* (Capítulo 6).
:::

::: solucao 1.17 (orientação)
<<< codigo/c1_ex17.py

>>> codigo/c1_ex17.out

A média é zero em qualquer dimensão, e o desvio padrão é próximo de $1/\sqrt d$. Em dimensão alta, dois vetores aleatórios são quase ortogonais. Consequências: (i) um cosseno de $0{,}3$ entre vetores de dimensão 1000 está a cerca de dez desvios padrão do que o acaso produziria, embora pareça baixo em escala absoluta; (ii) limiares de similaridade não são transferíveis entre modelos de dimensões diferentes. Uma ressalva importante: *embeddings* reais não são isotrópicos como vetores Gaussianos, e costumam concentrar-se em um cone do espaço, o que desloca os cossenos típicos para valores positivos. A calibração de limiares deve ser empírica, com dados do próprio domínio.
:::

::: solucao 1.18 (orientação)
(a) Para $f = \tfrac12\mathbf{x}^\top\mathbf{A}\mathbf{x}-\mathbf{b}^\top\mathbf{x}$: $\mathbf{x}_1 = \mathbf{x}_0-\mathbf{A}^{-1}(\mathbf{A}\mathbf{x}_0-\mathbf{b}) = \mathbf{A}^{-1}\mathbf{b} = \mathbf{x}^\star$, para qualquer $\mathbf{x}_0$. O método de Newton corrige exatamente o mau condicionamento. (b) A Hessiana tem $10^{16}$ elementos, cerca de $8\times10^{16}$ bytes em `float64`, ou 80 petabytes; a resolução do sistema custaria da ordem de $10^{24}$ operações. (c) A resposta deve cobrir: aproximação da inversa da Hessiana construída a partir de diferenças de gradientes sucessivos; armazenamento de apenas alguns pares de vetores (L-BFGS); e as dificuldades com gradientes estocásticos, que explicam a predominância de métodos de primeira ordem adaptativos em aprendizado profundo.
:::

## 1.20 Referências e leituras

**O que estudar primeiro.** Para quem precisa reforçar a base: Deisenroth, Faisal e Ong (2020), capítulos 2 a 6, na ordem. Para revisão rápida voltada a aprendizado profundo: Goodfellow, Bengio e Courville (2016), capítulos 2 a 4.

### Livros didáticos fundamentais

- DEISENROTH, M. P.; FAISAL, A. A.; ONG, C. S. *Mathematics for Machine Learning*. Cambridge: Cambridge University Press, 2020. Disponível em: mml-book.github.io.
- GOODFELLOW, I.; BENGIO, Y.; COURVILLE, A. *Deep Learning*. Cambridge, MA: MIT Press, 2016. Capítulos 2 (álgebra linear), 3 (probabilidade) e 4 (computação numérica). Disponível em: www.deeplearningbook.org.
- STRANG, G. *Introduction to Linear Algebra*. 5. ed. Wellesley: Wellesley-Cambridge Press, 2016.

### Referências complementares

- BLITZSTEIN, J. K.; HWANG, J. *Introduction to Probability*. 2. ed. Boca Raton: CRC Press, 2019.
- BOYD, S.; VANDENBERGHE, L. *Convex Optimization*. Cambridge: Cambridge University Press, 2004.
- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. Disponível em: www.statlearning.com.
- NOCEDAL, J.; WRIGHT, S. J. *Numerical Optimization*. 2. ed. New York: Springer, 2006.
- TREFETHEN, L. N.; BAU, D. *Numerical Linear Algebra*. Philadelphia: SIAM, 1997.
- WASSERMAN, L. *All of Statistics: A Concise Course in Statistical Inference*. New York: Springer, 2004.

### Artigo científico

- HARRIS, C. R. et al. Array programming with NumPy. *Nature*, v. 585, p. 357–362, 2020.

### Documentação técnica

- NumPy: guia do usuário e referência de `numpy.linalg` e `numpy.random`. numpy.org/doc.
- SciPy: referência de `scipy.linalg`. docs.scipy.org.
