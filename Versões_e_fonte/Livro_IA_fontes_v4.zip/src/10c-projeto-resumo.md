## 10.10 Projeto 7: pré-treino em miniatura, ajuste fino completo contra LoRA, quantização

::: projeto Do tokenizador ao ajuste fino, de ponta a ponta
O projeto percorre, em escala que cabe em uma CPU, todas as etapas do capítulo: treina um **tokenizador**, **pré-treina** um GPT-2 minúsculo em um domínio, **ajusta** o modelo a outro domínio de duas maneiras (completo e LoRA), mede o **esquecimento**, **quantiza** os pesos e examina o **espectro** das atualizações. Como o acesso ao *Hub* está bloqueado, não há modelo pré-treinado externo: o "pré-treino" é feito aqui, em miniatura.
:::

### Objetivo

Responder a cinco perguntas com experimentos controlados: (1) o pré-treino ajuda o ajuste a um domínio novo? (2) Como o ajuste completo e a LoRA se comparam, com o mesmo número de passos, no domínio-alvo **e** no de origem? (3) A taxa de aprendizado muda essa comparação? (4) Quanta perda de qualidade a quantização de pesos em poucos bits causa? (5) A atualização do ajuste completo tem, de fato, posto baixo (a hipótese da LoRA)?

### Problema

**Domínios.** O texto são os parágrafos de prosa deste livro. O **domínio de origem** é o dos Capítulos 1 a 5 (matemática, agentes, aprendizado estatístico); o **domínio-alvo**, o dos Capítulos 6 a 8 (redes neurais, convolucionais e recorrentes). O vocabulário e o estilo se sobrepõem, mas o conteúdo difere. A origem é dividida em $90\%$ para treino e $10\%$ para validação; o alvo, em $60\%$ para treino, $20\%$ para **validação** (escolha de hiperparâmetros) e $20\%$ para **teste** (relatado uma vez, no final), todos por parágrafos sorteados com semente fixa e **sem sobreposição**.

**Modelo.** Um GPT-2 minúsculo (`GPT2LMHeadModel`): $4$ blocos, $d=128$, $4$ cabeças, contexto de $128$ tokens, vocabulário de $1\,000$, *dropout* $0{,}1$, $937\,728$ parâmetros. O texto é cortado em **blocos** de $128$ tokens (parágrafos separados por um token de fim de texto).

### Requisitos

- Tokenizador BPE em bytes de vocabulário $1\,000$ treinado **somente** com o treino da origem.
- Pré-treino de $600$ passos (lotes de $16$ blocos) sobre a origem, AdamW com $10^{-3}$, cosseno com aquecimento.
- Ajuste ao alvo por $200$ passos, em quatro configurações: **sem pré-treino** (referência: pesos aleatórios treinados só no alvo), **ajuste completo** e **LoRA** com $r\in\{1,4,16\}$ em todas as matrizes lineares dos blocos ($\alpha=2r$, sem *dropout*).
- **Taxa de aprendizado escolhida pela perplexidade de validação no alvo**, para o ajuste completo e para a LoRA, em uma varredura com a semente $0$; depois, $3$ sementes por configuração.
- Métricas: perplexidade por token no **alvo** (validação e teste) e na **origem** (validação, para medir o esquecimento).
- Quantização simétrica absmax dos pesos dos blocos em $8$, $4$, $3$ e $2$ bits, com escala por tensor, por canal e por bloco de $64$; análise espectral de $\Delta\mathbf{W}$.
- Testes automáticos (sem vazamento, tokenização sem perdas, LoRA, quantização).

### Arquitetura

| Etapa | Programa | O que faz |
|---|---|---|
| Dados e tokenizador | `p7_comum.dados` | Divide os parágrafos, treina o BPE na origem, gera blocos de $128$ tokens (`datasets.Dataset`). |
| Pré-treino | `projeto7.py pretreino` | Treina o GPT-2 minúsculo com o `Trainer` e grava o modelo. |
| Varredura | `projeto7.py varredura` e `varredura2` | Para cada método, testa taxas de aprendizado (semente $0$). |
| Ajuste final | `projeto7.py final` | $3$ sementes $\times$ $5$ configurações com as taxas escolhidas. |
| Quantização | `projeto7.py quant` | Quantiza e desquantiza os pesos dos blocos e mede a perplexidade. |
| Espectro | `projeto7.py svd` | SVD de $\Delta\mathbf{W}=\mathbf{W}_{\text{ajustado}}-\mathbf{W}_{\text{base}}$ por matriz. |

### Fundamentos teóricos

- **Seção 10.3 e Proposição 10.2:** o BPE em bytes é sem perdas e sem token desconhecido; o tokenizador é congelado depois de treinado.
- **Proposição 10.1:** vocabulário maior, sequências mais curtas, tabela de embeddings maior.
- **Proposições 10.3 a 10.6:** memória do treino, parâmetros e posto da LoRA, gradientes, fusão sem custo.
- **Proposição 10.7 (Eckart-Young):** a energia retida pelos $r$ primeiros valores singulares de $\Delta\mathbf{W}$ mede o que uma atualização de posto $r$ poderia capturar.
- **Proposição 10.8:** a quantização absmax erra no máximo $s/2$ por peso, e $s$ é proporcional ao maior valor do grupo.
- **Perplexidade:** $\operatorname{PPL}=\exp(\mathcal{L})$, com $\mathcal{L}$ a entropia cruzada média em nats por token. Como **todos** os modelos do projeto usam o **mesmo** tokenizador e o mesmo texto de avaliação, a perplexidade por token é comparável entre eles (Exercício 10.9 explica por que não o seria entre tokenizadores distintos).

### Implementação

Primeiro, o módulo comum: dados, tokenizador, modelo, avaliação, o laço de treino com o `Trainer` e o ajuste (completo, LoRA ou "do zero"). Em seguida, o programa de experimentos.

<<< codigo/p7_comum.py

<<< codigo/projeto7.py

::: nota Um detalhe de versão que mudaria os números
A função `perda` calcula a perda média sobre as $127$ **previsões** de cada bloco de $128$ tokens. O `Trainer` da versão usada (`transformers` 5.22.2) registrou uma perda de validação **menor por um fator de $127/128$**, porque divide a soma das perdas pelo número de rótulos (128) e não pelo de previsões (127). A discrepância foi detectada comparando o valor do `Trainer` ($55{,}3$) com o da função `perda` ($57{,}1$) sobre o mesmo modelo, e a razão dos logaritmos é exatamente $128/127$. Por isso `treinar` corrige as curvas por esse fator, e todos os números finais da tabela vêm da função `perda`, que é a definição do texto. O pré-treino foi **refeito** depois da correção.
:::

### Testes e resultados

#### Dados e pré-treino

<<< codigo/p7_testes.py

>>> codigo/p7_testes.out

Todos os $12$ testes passam. Em particular, a LoRA com $\mathbf{B}=\mathbf{0}$ reproduz os *logits* do modelo base, treina exatamente $r\sum(d+k)=32\,768$ parâmetros para $r=4$, deixa a base **intacta** durante o treino e preserva os *logits* depois da fusão (Proposições 10.4 a 10.6, agora sobre um modelo real da biblioteca).

>>> codigo/p7_pretreino.out

- **O tokenizador comprime menos o alvo:** $2{,}86$ bytes por token na origem, $2{,}66$ no alvo de validação e $2{,}53$ no de teste. É o efeito esperado de um vocabulário aprendido em outro domínio (seção 10.2), embora pequeno aqui.
- **A perda inicial** é $\ln V$: a perplexidade de um modelo sem treino é cerca de $1\,024$ para $V=1\,000$, ou seja, o modelo é quase uniforme.
- **O pré-treino** leva a perplexidade de validação na origem de $1\,024$ a $57{,}1$ em $600$ passos ($103$ s, uma CPU de $2$ núcleos); no alvo, o modelo **sem ajuste** chega a $83{,}8$ (validação) e $88{,}6$ (teste). A distância entre $57{,}1$ e $83{,}8$ é o custo da mudança de domínio.

#### Varredura da taxa de aprendizado

>>> codigo/p7_varredura.out

>>> codigo/p7_varredura2.out

Na primeira varredura, o melhor valor de cada método estava no **extremo** da grade ($10^{-3}$ para o ajuste completo e $10^{-2}$ para a LoRA), o que não permite saber se há um melhor ainda além. Por isso a grade foi **estendida** (`varredura2`): o ajuste completo piora em $3\times10^{-3}$ ($56{,}3$) e $10^{-2}$ ($94{,}3$, divergindo), e a LoRA praticamente empata em $3\times10^{-2}$ ($61{,}96$ contra $61{,}79$) e diverge em $10^{-1}$ ($348{,}5$). Os ótimos, $10^{-3}$ e $10^{-2}$, são então **internos** à grade estendida. A LoRA tolera e **precisa** de taxas de aprendizado uma ordem de grandeza maiores, o que é conhecido na prática. A taxa $10^{-2}$, escolhida para $r=4$, foi usada **sem novo ajuste** para $r=1$ e $r=16$.

#### Ajuste final, com três sementes

>>> codigo/p7_final.out

>>> codigo/p7_resumo.out

| Método | Treináveis | Alvo (teste) | Alvo (validação) | Origem (validação) |
|---|---|---|---|---|
| Sem ajuste (pré-treinado) | $0$ | $88{,}6$ | $83{,}8$ | $57{,}1$ |
| Sem pré-treino | $937\,728$ ($100\%$) | $85{,}75\pm0{,}22$ | $86{,}36\pm0{,}97$ | $153{,}8\pm2{,}0$ |
| Ajuste completo | $937\,728$ ($100\%$) | **$51{,}08\pm0{,}09$** | $49{,}25\pm0{,}07$ | $83{,}30\pm0{,}10$ |
| LoRA $r=1$ | $8\,192$ ($0{,}9\%$) | $70{,}96\pm0{,}14$ | $68{,}40\pm0{,}34$ | $62{,}41\pm0{,}25$ |
| LoRA $r=4$ | $32\,768$ ($3{,}5\%$) | $62{,}80\pm0{,}05$ | $61{,}54\pm0{,}22$ | $66{,}84\pm0{,}15$ |
| LoRA $r=16$ | $131\,072$ ($14{,}0\%$) | $58{,}49\pm0{,}08$ | $57{,}41\pm0{,}31$ | $71{,}56\pm0{,}18$ |

(Média $\pm$ desvio-padrão amostral de $3$ sementes; o modelo sem ajuste é uma única avaliação.)

<figure>
+++ fig_c10_compromisso.svg
<figcaption><b>Figura 10.2.</b> O compromisso entre aprender o alvo (eixo vertical) e preservar a origem (eixo horizontal; menor é melhor nos dois eixos, então o canto inferior esquerdo é o ideal). Pontos de validação da semente $0$ ao variar a taxa de aprendizado (rótulos) no ajuste completo e na LoRA $r=4$; triângulos: LoRA $r=1$ e $r=16$ (média de $3$ sementes). O ajuste completo com $10^{-2}$ ($94{,}3$; $269{,}4$) está fora do gráfico.</figcaption>
</figure>

**Leitura dos resultados.**

1. **O pré-treino ajuda muito.** Em $200$ passos, partindo de pesos aleatórios, o modelo chega a $85{,}8$ no teste do alvo, praticamente o que o modelo pré-treinado **sem nenhum ajuste** já faz ($88{,}6$); com ajuste completo, $51{,}1$, uma queda de $42\%$ da perplexidade. Ressalva: o modelo pré-treinado também recebeu $600$ passos a mais de cálculo no outro domínio, de modo que a comparação é a **do mesmo orçamento de ajuste**, não a do mesmo orçamento total.
2. **O ajuste completo é o melhor no alvo e o que mais esquece.** $51{,}1$ no teste do alvo, mas a perplexidade na origem sobe de $57{,}1$ para $83{,}3$ ($+46\%$): o esquecimento catastrófico da seção 10.7, medido.
3. **A LoRA fica no meio, e o posto controla o ponto.** Com $r=1,4,16$ ($0{,}9\%$, $3{,}5\%$ e $14\%$ dos parâmetros), o alvo vai de $71{,}0$ a $62{,}8$ e $58{,}5$ (de $-20\%$ a $-34\%$ em relação ao modelo sem ajuste), e a origem sobe de $57{,}1$ para $62{,}4$, $66{,}8$ e $71{,}6$. Mais capacidade, mais aprendizado do alvo e mais esquecimento. Os desvios entre as sementes são minúsculos ($\le0{,}35$) diante dessas diferenças, mas as sementes só mudam a **ordem dos dados** e a inicialização de $\mathbf{A}$.
4. **A LoRA não esquece menos "de graça".** A Figura 10.2 mostra o ajuste completo com **taxa menor** ocupando posições tão boas quanto as da LoRA, ou melhores. Com $3\times10^{-4}$, o ajuste completo chega a $51{,}5$ no alvo e $67{,}3$ na origem, **melhor nos dois eixos** que a LoRA $r=16$ ($57{,}4$ e $71{,}6$, validação). Com $10^{-4}$, chega a $58{,}2$ e $61{,}2$: no alvo, quase o mesmo que a LoRA $r=16$ ($57{,}4$), e $10$ pontos melhor na origem. Com $3\times10^{-5}$, $67{,}1$ e $57{,}8$, melhor nos dois eixos que a LoRA $r=4$ com $3\times10^{-4}$ ($74{,}0$ e $58{,}6$). O que decide o esquecimento, neste experimento, é **o quanto os pesos se movem** (taxa, passos, capacidade), e não a parametrização em si. Isso não contradiz relatos de que a LoRA aprende menos e esquece menos que o ajuste completo (por exemplo, Biderman e colegas, 2024, que não foram reproduzidos aqui): mostra que, **em escala minúscula**, a conclusão depende de se comparar um ponto ou **toda a curva** do compromisso.
5. **A vantagem da LoRA é de memória e de armazenamento, não de qualidade.** Para um modelo de $0{,}9$ milhão de parâmetros, a economia é irrelevante, e a LoRA $r=16$ já treina $14\%$ dos pesos. A fração só fica pequena (algo como $1\%$ ou menos) em modelos com $d$ grande (Exemplo 10.2 e programa `c10_memoria.py`).

#### Quantização

>>> codigo/p7_quant.out

<figure>
+++ fig_c10_quant.svg
<figcaption><b>Figura 10.3.</b> Perplexidade do modelo pré-treinado (origem, validação) depois de quantizar e desquantizar as matrizes dos blocos, em função do custo em bits por peso, com três granularidades de escala (eixo vertical em escala logarítmica).</figcaption>
</figure>

- **$8$ bits é, na prática, sem perda:** perplexidade $57{,}06$ a $57{,}07$ contra $57{,}07$, em qualquer granularidade, com erro relativo de pesos de $0{,}6\%$ a $1{,}1\%$.
- **$4$ bits custa pouco:** $+1{,}1\%$ por tensor, $+0{,}3\%$ por canal e $+0{,}2\%$ por bloco, ou seja, **a granularidade fina compensa**, como a Proposição 10.8 prevê, por apenas $0{,}2$ a $0{,}5$ bit por peso a mais. Com $4$ bits, a memória dos pesos quantizados cai a $1/8$ da de $32$ bits.
- **$3$ bits** custa de $1{,}6\%$ a $5{,}6\%$; **$2$ bits** (apenas os níveis $-s,0,+s$) **quebra o modelo por tensor** (perplexidade $638$, $+1\,018\%$), e ainda degrada muito com escala por canal ($+48\%$) e por bloco ($+20\%$).
- **O que isto não mostra.** A quantização é **simulada** (os pesos são quantizados e desquantizados em ponto flutuante; não há *kernels* de inteiros, e a velocidade não foi medida). Só as matrizes dos blocos foram quantizadas; embeddings, normalizações e vieses ficaram em precisão simples, e os bits por peso se referem às matrizes quantizadas. As ativações não foram quantizadas, e é nelas que, segundo Dettmers e colegas (2022, LLM.int8), valores atípicos dificultam a quantização de modelos grandes. Um modelo de $0{,}9$ milhão de parâmetros não permite extrapolar para modelos de bilhões.

#### O espectro das atualizações

>>> codigo/p7_svd.out

<figure>
+++ fig_c10_svd.svg
<figcaption><b>Figura 10.4.</b> Fração da energia $\sum_{i\le r}\sigma_i^2/\sum_i\sigma_i^2$ de $\Delta\mathbf{W}$ retida pelos $r$ primeiros valores singulares, média das $16$ matrizes dos blocos, para o ajuste completo e para a LoRA $r=16$ (semente $0$), e para uma matriz gaussiana aleatória do mesmo formato (controle).</figcaption>
</figure>

- **No ajuste completo, a atualização não tem posto baixo.** Com $r=16$ de $128$, só $55{,}8\%$ da energia fica retida, e com $r=4$, $21{,}1\%$. É **mais concentrada que o ruído** (o controle aleatório retém $27{,}8\%$ e $8{,}0\%$), mas está longe de um espectro que decaia depressa. Pela Proposição 10.7, uma LoRA de posto $16$ não poderia reproduzir esse $\Delta\mathbf{W}$: o erro relativo mínimo seria da ordem de $\sqrt{1-0{,}558}\approx0{,}66$.
- **A atualização do ajuste completo foi grande:** em média, $\lVert\Delta\mathbf{W}\rVert_F/\lVert\mathbf{W}\rVert_F=0{,}49$, isto é, quase metade da norma dos pesos, com a taxa $10^{-3}$. A hipótese de posto baixo da LoRA foi formulada para **grandes modelos pré-treinados com atualizações pequenas**; um modelo de $d=128$ treinado por $600$ passos e depois deslocado por $200$ a outro domínio, com taxa alta, é um regime diferente.
- **A atualização da LoRA** (fundida) tem posto $\le16$, e, nas matrizes de $128$ de largura, retém $100\%$ da energia em $r=16$ por construção; a norma relativa média dela, $1{,}26$, é **maior** que a do ajuste completo, consequência da taxa $10^{-2}$ e do fator $\alpha/r=2$.

### Limitações

- **Escala.** Um modelo de $0{,}9$ milhão de parâmetros, um texto de $\approx 10^{5}$ tokens e $200$ passos de ajuste. Os resultados descrevem esse regime. **Não** se extrapolam para modelos de bilhões de parâmetros, onde a hipótese de posto baixo, o esquecimento e a quantização se comportam de modo diferente.
- **Um modelo pré-treinado, um par de domínios, uma divisão.** As três sementes variam a ordem dos dados e a inicialização de $\mathbf{A}$, **não** o pré-treino nem a divisão dos parágrafos; os desvios-padrão minúsculos não medem a incerteza real.
- **A varredura usou uma semente e uma grade grossa** (fatores de $3$), com $r=4$ para a LoRA, e outros hiperparâmetros (fator $\alpha$, módulos adaptados, *dropout*, passos) não foram ajustados. A conclusão sobre o esquecimento (item 4) depende disso e **deveria ser reconfirmada** com várias sementes por ponto.
- **Sem modelo pré-treinado real.** O acesso ao Hub estava bloqueado. Todos os procedimentos acima funcionam sobre modelos baixados do Hub, mas **isso não foi executado aqui**.
- **QLoRA e `bitsandbytes` não foram executados** (exigem GPU); a quantização foi simulada à mão.

### Melhorias possíveis

- Repetir o experimento com um modelo pré-treinado real, de algumas centenas de milhões de parâmetros (código da seção 10.6, **não executado aqui**), e verificar se o esquecimento da LoRA e o espectro de $\Delta\mathbf{W}$ mudam de regime.
- Varrer, por método, mais taxas e mais sementes, e ajustar também $\alpha$, o conjunto de matrizes e o número de passos; comparar com o **mesmo orçamento de cálculo**.
- Medir o esquecimento com **replay** (misturar uma fração de dados da origem ao ajuste) e com regularização em direção aos pesos originais.
- Quantizar também as ativações e medir a velocidade com *kernels* reais de inteiros.

## 10.11 Resumo do capítulo

::: resumo Capítulo 10
- **Pipeline.** Texto $\to$ normalização $\to$ pré-tokenização $\to$ subpalavras $\to$ identificadores $\to$ lotes com preenchimento e máscara $\to$ modelo $\to$ perda. O tokenizador é parte do modelo e deve ser treinado só com dados de treino.
- **Subpalavras.** Equilibram vocabulário e comprimento de sequência (Proposição 10.1): para o mesmo texto, vocabulários maiores dão sequências mais curtas, e o custo da atenção cai com o **quadrado** do comprimento.
- **BPE em bytes** é sem perdas e sem token desconhecido (Proposição 10.2); com $800$ fusões, $1\,000$ bytes viram $349$ tokens, com retornos decrescentes. **WordPiece** codifica por maior prefixo e tem `[UNK]`; **Unigram** escolhe a segmentação de maior probabilidade.
- **Hugging Face.** `tokenizers`, `datasets`, `transformers` (com `Trainer`) e `peft` compõem o fluxo. O acesso ao Hub estava bloqueado: nenhum modelo externo foi usado, e o código que depende dele está rotulado como **não executado**.
- **Memória do treino.** $16$ bytes por parâmetro com AdamW em precisão simples (Proposição 10.3); congelar a base e guardá-la em menos bits reduz o custo.
- **LoRA.** $\mathbf{W}=\mathbf{W}_0+\frac{\alpha}{r}\mathbf{B}\mathbf{A}$, com $r(d+k)$ parâmetros, posto $\le r$, $\mathbf{B}=\mathbf{0}$ no início (Proposições 10.4 e 10.5), e fusão sem custo na inferência (Proposição 10.6). A hipótese de posto baixo é empírica (Proposição 10.7 mede o que se perde).
- **Quantização** absmax: erro $\le s/2$ por peso; um atípico no grupo degrada todos os outros; escalas por canal ou por bloco confinam o dano (Proposição 10.8).
- **Projeto 7.** Neste modelo minúsculo, o pré-treino ajudou muito ($85{,}8\to51{,}1$); o ajuste completo foi o melhor no alvo e o que mais esqueceu ($57{,}1\to83{,}3$ na origem); a LoRA ficou no meio e seu posto controlou o compromisso; **a LoRA não esqueceu menos de graça** (um ajuste completo com taxa menor foi tão bom ou melhor nos dois eixos); a atualização do ajuste completo **não** tinha posto baixo; $8$ bits foi sem perda, $4$ bits custou $0{,}2\%$ a $1{,}1\%$, e $2$ bits quebrou o modelo por tensor.
:::

**Ponte para o Capítulo 11.** Até aqui, o modelo de linguagem foi tratado como uma função que dá a probabilidade do próximo token. O Capítulo 11 usa essa função **para gerar** texto: parâmetros de amostragem (temperatura, top-$p$, top-$k$), a confiabilidade das respostas (alucinações, calibração) e a imposição de saídas estruturadas (JSON, Pydantic). É o primeiro passo da engenharia de aplicações com modelos de linguagem.
