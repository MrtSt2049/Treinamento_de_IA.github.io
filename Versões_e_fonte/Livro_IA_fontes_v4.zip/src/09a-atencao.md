<div class="objetivos">

Objetivos do capítulo

- Explicar por que a recorrência limita o paralelismo, o comprimento do caminho entre posições e o tamanho do contexto, e comparar o custo de uma camada recorrente com o de uma camada de autoatenção.
- Definir a atenção por produto escalar escalonado, $\operatorname{Attention}(\mathbf{Q},\mathbf{K},\mathbf{V})=\operatorname{softmax}(\mathbf{Q}\mathbf{K}^{\top}/\sqrt{d_k})\mathbf{V}$, **deduzir** o fator $1/\sqrt{d_k}$ e demonstrar as propriedades que o tornam estável.
- Construir a autoatenção, a atenção multi-cabeça, as máscaras (causal e de preenchimento) e a codificação posicional, demonstrando a equivariância a permutações e a propriedade de rotação das posições senoidais.
- Montar o bloco Transformer (atenção, rede por posição, conexões residuais e normalização de camada), contar seus parâmetros e conferir a fórmula com a biblioteca.
- Distinguir as famílias de codificador (BERT), decodificador (GPT) e codificador-decodificador (T5, BART) por suas máscaras, objetivos de treino e usos.
- Explicar o custo quadrático da atenção e o cache de chaves e valores, e comparar, em um laboratório, um Transformer decodificador com uma GRU treinados do zero.

**Pré-requisitos:** Capítulo 1 (álgebra linear, probabilidade), Capítulo 6 (retropropagação, PyTorch), Capítulo 7 (conexões residuais, Teorema 7.5) e Capítulo 8 (recorrência e atenção em sequência-para-sequência).

</div>

## 9.1 Por que abandonar a recorrência

O Capítulo 8 terminou com três limitações das redes recorrentes. Elas se repetem aqui porque motivam cada decisão de projeto do Transformer.

1. **Gargalo de estado.** Tudo o que a rede sabe sobre o passado cabe em $\mathbf{h}_t\in\mathbb{R}^H$. Um tradutor recorrente que codifica uma frase inteira em um único vetor perde informação quanto maior for a frase.
2. **Caminho longo entre posições.** A influência da posição $s$ sobre a posição $t$ atravessa $t-s$ passos de recorrência, e o gradiente é multiplicado por $t-s$ jacobianos (Teorema 8.3). Mesmo com portas, isso exigiu inicializações cuidadosas (seção 8.4).
3. **Cálculo sequencial.** $\mathbf{h}_t$ só pode ser calculado depois de $\mathbf{h}_{t-1}$. Em um acelerador com milhares de unidades de cálculo, uma sequência de $T$ passos usa o hardware com paralelismo $O(1)$ no tempo, e o treino fica lento justamente nos textos longos.

A ideia que resolve as três é permitir que **toda posição consulte diretamente todas as outras**, em uma única operação de matriz. Bahdanau, Cho e Bengio (2015) introduziram a atenção como um complemento da recorrência na tradução; Vaswani e colegas (2017) mostraram, no artigo *Attention is all you need*, que a recorrência podia ser **removida**, e que a arquitetura resultante, o **Transformer**, treinava mais rápido e traduzia melhor. A tabela compara o custo por camada, para sequências de comprimento $T$ e dimensão $d$.

| Tipo de camada | Operações por camada | Passos sequenciais | Comprimento do caminho máximo |
|---|---|---|---|
| Recorrente | $O(T\,d^2)$ | $O(T)$ | $O(T)$ |
| Autoatenção | $O(T^2\,d)$ | $O(1)$ | $O(1)$ |
| Convolucional (núcleo $k$) | $O(k\,T\,d^2)$ | $O(1)$ | $O(\log_k T)$ (com dilatação) |

A autoatenção troca **profundidade no tempo** por **largura**: o número de passos sequenciais cai de $T$ para $1$, e o caminho entre duas posições quaisquer passa a ter comprimento $1$. O preço é o termo $T^2$, que domina quando a sequência é longa (seção 9.8).

## 9.2 Atenção como consulta suave

### Uma busca em dicionário, feita de modo diferenciável

Em um dicionário comum, uma **consulta** (*query*) procura uma **chave** (*key*) igual a ela e devolve o **valor** (*value*) associado. A atenção faz essa busca de modo **suave**: compara a consulta com **todas** as chaves, transforma as comparações em pesos que somam $1$ e devolve a **média ponderada** dos valores.

::: definicao 9.1 · Atenção por produto escalar escalonado
Sejam $\mathbf{Q}\in\mathbb{R}^{T_q\times d_k}$ (uma consulta por linha), $\mathbf{K}\in\mathbb{R}^{T_k\times d_k}$ (uma chave por linha) e $\mathbf{V}\in\mathbb{R}^{T_k\times d_v}$ (um valor por linha). A **atenção** é
$$\operatorname{Attention}(\mathbf{Q},\mathbf{K},\mathbf{V})=\mathbf{A}\mathbf{V},\qquad \mathbf{A}=\operatorname{softmax}\!\Bigl(\frac{\mathbf{Q}\mathbf{K}^{\top}}{\sqrt{d_k}}\Bigr)\in\mathbb{R}^{T_q\times T_k},$$
com a softmax aplicada a **cada linha**. A matriz $\mathbf{S}=\mathbf{Q}\mathbf{K}^{\top}/\sqrt{d_k}$ contém as **pontuações**, e $\mathbf{A}$, os **pesos de atenção**: $A_{ij}$ é quanto a consulta $i$ presta atenção na chave $j$.
:::

::: exemplo 9.1 · Uma consulta, três chaves
Seja $d_k=2$, a consulta $\mathbf{q}=(1,0)$, as chaves $\mathbf{k}_1=(1,0)$, $\mathbf{k}_2=(0,1)$, $\mathbf{k}_3=(1,1)$ e os valores $\mathbf{v}_1=(1,0)$, $\mathbf{v}_2=(0,2)$, $\mathbf{v}_3=(3,3)$. Os produtos escalares são $(1,0,1)$, e, divididos por $\sqrt2$, as pontuações valem $(0{,}707;\,0;\,0{,}707)$. A softmax dá os pesos $(0{,}401;\,0{,}198;\,0{,}401)$, e a saída é
$$0{,}401\,(1,0)+0{,}198\,(0,2)+0{,}401\,(3,3)=(1{,}604;\ 1{,}599).$$
A consulta é igualmente parecida com $\mathbf{k}_1$ e $\mathbf{k}_3$ (ambas têm o produto escalar $1$), e por isso recebem o mesmo peso; $\mathbf{k}_2$, ortogonal, recebe menos. Sem a escala $1/\sqrt{d_k}$, os pesos seriam $(0{,}422;\,0{,}155;\,0{,}422)$, mais concentrados.
:::

### Propriedades básicas

::: proposicao 9.1 · A saída é uma combinação convexa dos valores
Cada linha $\mathbf{a}_i$ de $\mathbf{A}$ tem entradas não negativas que somam $1$, e a saída $i$ é $\sum_jA_{ij}\mathbf{v}_j$. Logo, cada saída pertence ao **fecho convexo** dos valores, e, em particular, cada coordenada da saída fica entre o mínimo e o máximo da mesma coordenada nos valores. A softmax é **invariante a deslocamentos** ($\operatorname{softmax}(\mathbf{z}+c\mathbf{1})=\operatorname{softmax}(\mathbf{z})$), o que permite subtrair $\max_j z_j$ antes de exponenciar sem alterar o resultado e sem risco de estouro numérico.
:::

::: demonstracao
$A_{ij}=e^{S_{ij}}/\sum_le^{S_{il}}>0$ e $\sum_jA_{ij}=1$ por construção; uma média ponderada com pesos não negativos que somam $1$ é uma combinação convexa. Para o deslocamento, $e^{z_j+c}/\sum_le^{z_l+c}=e^{c}e^{z_j}/(e^{c}\sum_le^{z_l})$.
:::

### Por que dividir por $\sqrt{d_k}$

O fator $1/\sqrt{d_k}$ não é decorativo. Ele mantém a escala das pontuações **independente** de $d_k$.

::: proposicao 9.2 · Variância do produto escalar
Sejam $\mathbf{q},\mathbf{k}\in\mathbb{R}^{d_k}$ com componentes **independentes**, de média $0$ e variância $1$. Então $\mathbb{E}[\mathbf{q}^{\top}\mathbf{k}]=0$ e $\operatorname{Var}(\mathbf{q}^{\top}\mathbf{k})=d_k$. Portanto, $\mathbf{q}^{\top}\mathbf{k}/\sqrt{d_k}$ tem média $0$ e variância $1$.
:::

::: demonstracao
$\mathbf{q}^{\top}\mathbf{k}=\sum_{i=1}^{d_k}q_ik_i$. Cada produto $q_ik_i$ tem média $\mathbb{E}[q_i]\mathbb{E}[k_i]=0$ e variância $\mathbb{E}[q_i^2]\mathbb{E}[k_i^2]=1$ (independência). Os $d_k$ produtos são independentes, logo as variâncias somam $d_k$. Dividir por $\sqrt{d_k}$ divide a variância por $d_k$.
:::

Sem a escala, quando $d_k$ é grande, as pontuações têm desvio-padrão $\sqrt{d_k}$ e a softmax **satura**: quase toda a massa vai para a maior pontuação. Isso é um problema de aprendizado, e não apenas de aparência, pelo resultado a seguir.

::: proposicao 9.3 · O jacobiano da softmax e a saturação
Seja $\mathbf{p}=\operatorname{softmax}(\mathbf{z})$. Então $\partial\mathbf{p}/\partial\mathbf{z}=\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^{\top}$. Se $\mathbf{p}$ tende a um vetor $\mathbf{e}_j$ da base canônica (um peso próximo de $1$ e os demais próximos de $0$), o jacobiano tende à matriz nula: **o gradiente em relação às pontuações desaparece**.
:::

::: demonstracao
$p_i=e^{z_i}/\sum_le^{z_l}$. Para $i=j$, $\partial p_i/\partial z_i=p_i-p_i^2=p_i(1-p_i)$; para $i\ne j$, $\partial p_i/\partial z_j=-p_ip_j$. Em forma matricial, $\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^{\top}$. Se $\mathbf{p}\to\mathbf{e}_j$, então $\operatorname{diag}(\mathbf{p})\to\mathbf{e}_j\mathbf{e}_j^{\top}$ e $\mathbf{p}\mathbf{p}^{\top}\to\mathbf{e}_j\mathbf{e}_j^{\top}$, e a diferença tende a zero.
:::

O programa a seguir confere a implementação com a do PyTorch, mede a Proposição 9.2 e mostra a saturação.

<<< codigo/c9_atencao.py

>>> codigo/c9_atencao.out

A variância de $\mathbf{q}^{\top}\mathbf{k}$ acompanha $d_k$ ($255{,}5$ para $d_k=256$, $1\,028{,}6$ para $1\,024$), e a versão escalonada fica em $1$. Com $d_k=256$ e $10$ chaves, a probabilidade máxima média sobe de $0{,}32$ (com a escala) para $0{,}93$ (sem a escala), e a norma do jacobiano da softmax cai de $0{,}35$ para $0{,}09$, cerca de quatro vezes: com a atenção quase em "tudo ou nada", a saída fica pouco sensível a variações nas pontuações. O Exercício 9.14 mede o efeito sobre os gradientes de uma perda arbitrária, com um resultado mais sutil do que "o gradiente some".

::: intuicao Atenção como regressão por núcleo
Se todas as chaves têm a mesma norma, $\mathbf{q}^{\top}\mathbf{k}_j=\tfrac12(\lVert\mathbf{q}\rVert^2+\lVert\mathbf{k}_j\rVert^2-\lVert\mathbf{q}-\mathbf{k}_j\rVert^2)$, e os termos que não dependem de $j$ saem da softmax. A atenção passa a ser $\sum_jw_j\mathbf{v}_j$ com $w_j\propto\exp(-\lVert\mathbf{q}-\mathbf{k}_j\rVert^2/(2\sqrt{d_k}))$: uma **média ponderada pela proximidade** entre a consulta e as chaves, a regressão por núcleo de Nadaraya e Watson com um núcleo gaussiano. A rede aprende o que significa "perto" ao aprender as projeções que geram $\mathbf{q}$ e $\mathbf{k}$.
:::

<figure>
+++ fig_c9_atencao.svg
<figcaption><b>Figura 9.1.</b> Fluxo da atenção. As consultas $\mathbf{Q}$ e as chaves $\mathbf{K}$ geram a matriz de pontuações $\mathbf{Q}\mathbf{K}^{\top}/\sqrt{d_k}$; a softmax por linha a transforma nos pesos $\mathbf{A}$, que combinam as linhas de $\mathbf{V}$.</figcaption>
</figure>

## 9.3 Autoatenção, máscaras e atenção cruzada

Na **autoatenção** (*self-attention*), as consultas, as chaves e os valores vêm da **mesma** sequência $\mathbf{X}\in\mathbb{R}^{T\times d}$, por projeções lineares **aprendidas**.

::: definicao 9.2 · Autoatenção e atenção cruzada
Com $\mathbf{W}_Q,\mathbf{W}_K\in\mathbb{R}^{d\times d_k}$ e $\mathbf{W}_V\in\mathbb{R}^{d\times d_v}$, a **autoatenção** sobre $\mathbf{X}$ é
$$\operatorname{SA}(\mathbf{X})=\operatorname{Attention}(\mathbf{X}\mathbf{W}_Q,\ \mathbf{X}\mathbf{W}_K,\ \mathbf{X}\mathbf{W}_V).$$
Na **atenção cruzada** (*cross-attention*), as consultas vêm de uma sequência $\mathbf{Y}$ e as chaves e os valores, de outra, $\mathbf{X}$: $\operatorname{Attention}(\mathbf{Y}\mathbf{W}_Q,\mathbf{X}\mathbf{W}_K,\mathbf{X}\mathbf{W}_V)$. É assim que um decodificador consulta o resultado de um codificador.
:::

As três projeções fazem papéis distintos para a mesma posição: $\mathbf{q}_i$ é **o que a posição $i$ procura**, $\mathbf{k}_j$ é **como a posição $j$ se anuncia** e $\mathbf{v}_j$ é **o que a posição $j$ entrega** a quem lhe prestar atenção. Separar chave e valor permite que o critério de relevância seja diferente da informação transmitida.

### A autoatenção não conhece a ordem

::: teorema 9.4 · Equivariância a permutações
Seja $\mathbf{P}$ uma matriz de permutação $T\times T$. Então $\operatorname{SA}(\mathbf{P}\mathbf{X})=\mathbf{P}\operatorname{SA}(\mathbf{X})$: embaralhar as posições da entrada embaralha, do mesmo modo, as posições da saída, e nada mais muda.
:::

::: demonstracao
As projeções agem linha a linha: $\mathbf{P}\mathbf{X}\mathbf{W}=\mathbf{P}(\mathbf{X}\mathbf{W})$. Assim, $\mathbf{Q}'=\mathbf{P}\mathbf{Q}$, $\mathbf{K}'=\mathbf{P}\mathbf{K}$, $\mathbf{V}'=\mathbf{P}\mathbf{V}$, e $\mathbf{S}'=\mathbf{P}\mathbf{Q}\mathbf{K}^{\top}\mathbf{P}^{\top}/\sqrt{d_k}=\mathbf{P}\mathbf{S}\mathbf{P}^{\top}$. A softmax por linha comuta com permutações de colunas, e permutar as linhas apenas troca a ordem das linhas: $\mathbf{A}'=\mathbf{P}\mathbf{A}\mathbf{P}^{\top}$. Logo, a saída é $\mathbf{A}'\mathbf{V}'=\mathbf{P}\mathbf{A}\mathbf{P}^{\top}\mathbf{P}\mathbf{V}=\mathbf{P}\mathbf{A}\mathbf{V}$, pois $\mathbf{P}^{\top}\mathbf{P}=\mathbf{I}$.
:::

O último item do programa anterior confere o teorema: a diferença é de $9\times10^{-16}$. A consequência é grave para a linguagem: "o cão mordeu o homem" e "o homem mordeu o cão" seriam indistinguíveis para a camada. É preciso **injetar a posição** nas entradas (seção 9.5).

### Máscaras

A matriz de pontuações pode ser modificada **antes** da softmax somando $-\infty$ às entradas proibidas, o que zera o peso correspondente ($e^{-\infty}=0$).

- **Máscara de preenchimento:** posições de *padding* recebem $-\infty$ nas colunas, para que ninguém lhes preste atenção (ver o análogo para recorrência, seção 8.5).
- **Máscara causal:** $S_{ij}=-\infty$ para $j>i$, de modo que a posição $i$ só enxerga as posições $1,\dots,i$. É o que permite treinar modelos de linguagem **em paralelo** sem que a posição $i$ "espie" o token que deve prever.

::: proposicao 9.5 · A máscara causal isola o futuro
Em uma pilha de camadas de autoatenção com máscara causal, a saída na posição $t$ **não depende** das entradas nas posições $t'>t$.
:::

::: demonstracao
Em uma camada, a saída $i$ é $\sum_{j\le i}A_{ij}\mathbf{v}_j$, com $\mathbf{v}_j$ e os pesos $A_{ij}$ funções apenas das posições $j\le i$ (as pontuações $S_{ij}$, $j>i$, são removidas pela máscara e a softmax é renormalizada só sobre $j\le i$). As operações por posição (projeções, rede por posição, normalização) também não misturam posições. Por indução nas camadas, se as entradas de uma camada na posição $i$ dependem só de $x_{\le i}$, as saídas dessa camada na posição $i$ dependem só de $x_{\le i}$.
:::

O programa da seção 9.4 verifica a proposição: ao trocar as entradas dos instantes $4$ e $5$, as saídas em $t<4$ mudam em exatamente $0$ com a máscara causal e em $0{,}43$ sem ela.

### Custo

Calcular $\mathbf{Q}\mathbf{K}^{\top}$ custa $O(T^2d_k)$ operações e **materializa** uma matriz $T\times T$ por cabeça. Dobrar o comprimento quadruplica ambos. É esse termo que limita o comprimento de contexto e é o alvo de muitas otimizações (seção 9.8).

## 9.4 Atenção multi-cabeça

Uma única atenção produz **um** conjunto de pesos por posição, isto é, uma única "maneira" de relacionar as posições. A **atenção multi-cabeça** executa várias em paralelo, cada uma com suas projeções, e concatena os resultados.

::: definicao 9.3 · Atenção multi-cabeça
Com $h$ cabeças, $d_k=d_v=d/h$, e projeções $\mathbf{W}_Q^{(i)},\mathbf{W}_K^{(i)},\mathbf{W}_V^{(i)}\in\mathbb{R}^{d\times d/h}$ para cada cabeça $i=1,\dots,h$,
$$\operatorname{MHA}(\mathbf{X})=\bigl[\operatorname{head}_1\ \cdots\ \operatorname{head}_h\bigr]\mathbf{W}_O,\qquad \operatorname{head}_i=\operatorname{Attention}\bigl(\mathbf{X}\mathbf{W}_Q^{(i)},\mathbf{X}\mathbf{W}_K^{(i)},\mathbf{X}\mathbf{W}_V^{(i)}\bigr),$$
com $[\cdots]$ a concatenação ao longo das colunas e $\mathbf{W}_O\in\mathbb{R}^{d\times d}$ a projeção de saída.
:::

Na implementação, as $h$ matrizes $\mathbf{W}_Q^{(i)}$ são empilhadas em uma só $\mathbf{W}_Q\in\mathbb{R}^{d\times d}$, a projeção é feita **de uma vez**, e o resultado é remodelado de $(N,T,d)$ para $(N,h,T,d/h)$. Assim, todas as cabeças são calculadas em um único produto de matrizes em lote.

::: proposicao 9.6 · Parâmetros da atenção multi-cabeça
A camada MHA com $d_k=d_v=d/h$ tem $4d^2$ pesos (as quatro matrizes $\mathbf{W}_Q,\mathbf{W}_K,\mathbf{W}_V,\mathbf{W}_O$, todas $d\times d$) e $4d$ vieses, ou seja, $4d^2+4d$ parâmetros, **independentemente** de $h$ e de $T$. O custo de cálculo da matriz de pontuações é $O(T^2d)$, também independente de $h$.
:::

::: demonstracao
Cada uma das quatro matrizes tem $d\times d$ entradas, pois $h\cdot(d/h)=d$ colunas. Há um vetor de viés de tamanho $d$ para cada. As $h$ matrizes de pontuações $T\times T$ custam $h\cdot T^2\cdot(d/h)=T^2d$.
:::

O programa abaixo implementa a atenção multi-cabeça à mão, confere com `nn.MultiheadAttention` com e sem máscara causal, confirma a Proposição 9.6 e verifica a Proposição 9.5.

<<< codigo/c9_multicabeca.py

>>> codigo/c9_multicabeca.out

::: nota Por que várias cabeças
Com $h$ cabeças, o modelo pode, em uma mesma camada, relacionar uma palavra com o seu sujeito em uma cabeça e com a palavra anterior em outra. Isso é uma **motivação**, e não um teorema: Vaswani e colegas observaram experimentalmente que $h$ moderado (8, nos seus modelos base) melhora a qualidade, e estudos posteriores mostram que muitas cabeças podem ser removidas após o treino com pouca perda. A divisão de $d$ por $h$ mantém o custo total constante.
:::
