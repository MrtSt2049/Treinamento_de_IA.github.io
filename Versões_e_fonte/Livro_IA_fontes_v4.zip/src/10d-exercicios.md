## 10.12 Exercícios

### Nível I: consolidação

**10.1** Execute **à mão** três fusões do BPE (Definição 10.1), com símbolos iniciais iguais aos caracteres, sobre o corpus de frequências `low` ($5$), `lower` ($2$), `newest` ($6$), `widest` ($3$). Em caso de empate, escolha o par maior na ordem lexicográfica. Escreva a segmentação de cada palavra depois de cada fusão.

**10.2** Quantos parâmetros a LoRA treina em uma matriz $4\,096\times4\,096$ com $r=8$ e com $r=16$? Que fração de $16\,777\,216$ isso representa?

**10.3** Pela Proposição 10.3, estime a memória (sem ativações) do ajuste completo, em precisão simples, de um modelo de $1{,}3$ bilhão de parâmetros. Compare com a LoRA, com a base em $16$ bits e $0{,}5\%$ de parâmetros treináveis.

**10.4** Quantize em $4$ bits, com escala absmax por tensor, os pesos $\mathbf{w}=(0{,}9;\,-0{,}3;\,0{,}05;\,-1{,}2)$. Dê a escala, os inteiros, a reconstrução e o maior erro, e confira a cota da Proposição 10.8.

**10.5** Um lote tem duas sequências, de $3$ e de $5$ tokens, preenchidas com o identificador $0$ até $5$. Escreva a `attention_mask` e diga que fração das posições do lote é preenchimento. Por que omitir a máscara é um erro?

### Nível II: desenvolvimento

**10.6** Com $\mathbf{G}=\bigl(\begin{smallmatrix}1&2\\3&4\end{smallmatrix}\bigr)$, $\mathbf{A}=(1\ \ 1)$, $\mathbf{B}=\bigl(\begin{smallmatrix}0{,}5\\-0{,}5\end{smallmatrix}\bigr)$ e $\alpha/r=2$, calcule $\partial\mathcal{L}/\partial\mathbf{A}$ e $\partial\mathcal{L}/\partial\mathbf{B}$ pela Proposição 10.5. Refaça com $\mathbf{B}=\mathbf{0}$.

**10.7** Com escala em $16$ bits, qual tamanho de bloco $g$ faz a quantização em $4$ bits custar $4{,}5$ bits por peso? Qual é o custo com $g=128$?

**10.8** Deduza o número de parâmetros treináveis da LoRA aplicada às quatro matrizes lineares de cada bloco do GPT-2 pequeno ($d=768$; as matrizes são $768\times2\,304$, $768\times768$, $768\times3\,072$ e $3\,072\times768$), com $12$ blocos, em função de $r$. Confira que $r=8$ dá $0{,}95\%$ de $124{,}4$ milhões.

**10.9** Um modelo tem perplexidade $88{,}6$ **por token** em um texto com $2{,}53$ bytes por token. Calcule os bits por byte. Por que essa é a medida correta para comparar dois tokenizadores?

**10.10** Dado o vocabulário WordPiece $\{$`un`, `##able`, `##a`, `##b`, `##le`, `u`, `##n`, `##d`$\}$, aplique a regra de maior prefixo (seção 10.4) às palavras `unable` e `unabled`. O que acontece com `unwise`, se `w`, `i`, `s` e `e` não estão no vocabulário?

### Nível III: avançado

**10.11** Uma matriz $\Delta\mathbf{W}$ tem valores singulares $(4,3,2,1)$. Pela Proposição 10.7, calcule o erro absoluto e o relativo da melhor aproximação de posto $1$, $2$ e $3$, e a energia retida.

**10.12** Mostre que, com $\mathbf{B}=\mathbf{0}$, um passo de gradiente descendente com taxa $\eta$ sobre $(\mathbf{A},\mathbf{B})$ muda a matriz efetiva por $\Delta\mathbf{W}=-\eta\,(\alpha/r)^2\,\mathbf{G}\mathbf{A}^{\top}\mathbf{A}$. Se as linhas de $\mathbf{A}$ são ortonormais, o que $\mathbf{A}^{\top}\mathbf{A}$ representa, e como interpretar o passo?

**10.13** Interprete os resultados do Projeto 7 (seção 10.10): (a) compare o ajuste completo e a LoRA em perplexidade no domínio-alvo **e** no domínio de origem; (b) o que a varredura de taxas de aprendizado mostra; (c) o que eles **não** permitem concluir.

**10.14** (Projeto) O Projeto 7 compara os métodos com **o mesmo número de passos**. Proponha um desenho experimental que compare com o **mesmo orçamento de cálculo** ou o mesmo número de parâmetros treináveis, e diga que resultado mudaria a conclusão do capítulo.

**10.15** (Programação) Implemente a quantização por bloco com $g=32$ e $g=128$ sobre os pesos do modelo pré-treinado do Projeto 7 e compare a perplexidade e os bits por peso com a tabela da seção 10.10.

## 10.13 Soluções comentadas

::: solucao 10.1
Contagens dos pares (programa `c10_ex_numeros.py`): $(e,s)$ e $(s,t)$ têm $9$ (em `newest`, $6$; em `widest`, $3$), $(w,e)$ tem $8$, $(l,o)$ e $(o,w)$ têm $7$. Há **empate** entre $(e,s)$ e $(s,t)$; pela regra, escolhe-se $(s,t)$. 

- **Fusão 1** $(s,t)\to st$: `low` = `l o w`; `lower` = `l o w e r`; `newest` = `n e w e st`; `widest` = `w i d e st`.
- **Fusão 2** $(e,st)\to est$ (contagem $9$): `newest` = `n e w est`; `widest` = `w i d est`.
- **Fusão 3**: empate entre $(l,o)$ e $(o,w)$ com $7$; escolhe-se $(o,w)\to ow$: `low` = `l ow`; `lower` = `l ow e r`.

A quarta fusão seria $(l,ow)\to low$ (contagem $7$). Observe que o empate **muda** o vocabulário: o resultado do BPE depende da regra de desempate, e por isso as implementações a fixam.
:::

::: solucao 10.2
$r(d+k)=r\cdot8\,192$: $65\,536$ para $r=8$ ($0{,}391\%$ de $16\,777\,216$) e $131\,072$ para $r=16$ ($0{,}781\%$).
:::

::: solucao 10.3
Completo: $16\times1{,}3\times10^{9}=20{,}8$ GB. LoRA com base em $16$ bits (2 bytes) e $p_t=0{,}005P$: $2P+16p_t=2{,}6+0{,}104=2{,}70$ GB, cerca de $7{,}7$ vezes menos. Nenhum dos valores conta as ativações.
:::

::: solucao 10.4
$q=7$, $s=1{,}2/7=0{,}1714$. Os quocientes $w_i/s$ são $5{,}25;\ -1{,}75;\ 0{,}29;\ -7$, que arredondam para $5,\ -2,\ 0,\ -7$. A reconstrução é $(0{,}857;\ -0{,}343;\ 0;\ -1{,}2)$ e os erros, $(0{,}043;\ 0{,}043;\ 0{,}050;\ 0)$. O maior erro, $0{,}050$, é menor que $s/2=0{,}0857$, como a Proposição 10.8 garante. Note que o peso $0{,}05$, o menor, foi **zerado**: pesos pequenos perto de um atípico grande são os que mais sofrem.
:::

::: solucao 10.5
`input_ids` com preenchimento $0$ nas duas últimas posições da primeira linha e `attention_mask` $\begin{pmatrix}1&1&1&0&0\\1&1&1&1&1\end{pmatrix}$. Há $2$ posições de preenchimento em $10$, isto é, $20\%$. Sem a máscara, a atenção da sequência curta consultaria as posições de preenchimento como se fossem tokens reais (e, em um codificador, o preenchimento entraria nas médias), de modo que o resultado dependeria de **quanto** preenchimento o lote tem, e não só do texto.
:::

::: solucao 10.6
Com $\mathbf{G}\mathbf{A}^{\top}=(3,\,7)^{\top}$ e $\mathbf{B}^{\top}\mathbf{G}=(-1,\,-1)$: $\partial\mathcal{L}/\partial\mathbf{B}=2\,(3,7)^{\top}=(6,14)^{\top}$ e $\partial\mathcal{L}/\partial\mathbf{A}=2\,(-1,-1)=(-2,-2)$. Com $\mathbf{B}=\mathbf{0}$: $\partial\mathcal{L}/\partial\mathbf{A}=(0,0)$ e $\partial\mathcal{L}/\partial\mathbf{B}=(6,14)^{\top}$, inalterado, pois não depende de $\mathbf{B}$. O programa `c10_ex_numeros.py` confirma.
:::

::: solucao 10.7
$16/g=0{,}5$ dá $g=32$. Com $g=128$, o custo é $4+16/128=4{,}125$ bits por peso. Blocos menores toleram melhor os atípicos (seção 10.9) e custam mais bits.
:::

::: solucao 10.8
Por bloco, $r\,[(768+2\,304)+(768+768)+(768+3\,072)+(3\,072+768)]=r\,(3\,072+1\,536+3\,840+3\,840)=12\,288\,r$. Em $12$ blocos, $147\,456\,r$; com $r=8$, $1\,179\,648=0{,}95\%$ de $124{,}4\times10^{6}$, valor que a biblioteca `peft` também reporta (seção 10.8).
:::

::: solucao 10.9
Bits por token: $\log_2 88{,}6=6{,}469$. Bits por byte: $6{,}469/2{,}53=2{,}557$. A perplexidade por token depende de **quantos bytes** cada token cobre; um tokenizador com tokens longos tem perplexidade por token maior sem ser pior. O bit por byte (como o bpc do laboratório do Capítulo 9) é a medida da **informação por unidade de texto**, comparável entre tokenizadores, desde que o texto avaliado seja o mesmo.
:::

::: solucao 10.10
`unable`: o maior prefixo no vocabulário é `un` (`una` e `unab` não estão); o resto, `able`, vira `##able`, que existe: `un ##able`. `unabled`: `un`, depois `##able`, depois `##d`: `un ##able ##d`. `unwise`: `un` e, em seguida, nenhuma continuação começando em `w` existe (`##w` ausente), e **nem um único caractere** do resto é encontrado: a palavra inteira vira `[UNK]`, e a informação de `un` se perde. É a diferença para o BPE em bytes (Proposição 10.2(b)).
:::

::: solucao 10.11
Energia total $16+9+4+1=30$. Posto $1$: erro $\sqrt{9+4+1}=\sqrt{14}=3{,}742$ (relativo $0{,}683$; energia retida $53{,}3\%$). Posto $2$: $\sqrt{5}=2{,}236$ ($0{,}408$; $83{,}3\%$). Posto $3$: $\sqrt1=1$ ($0{,}183$; $96{,}7\%$). Programa: `c10_ex_numeros.py`.
:::

::: solucao 10.12
Com $\mathbf{B}=\mathbf{0}$, a Proposição 10.5 dá $\partial\mathcal{L}/\partial\mathbf{B}=(\alpha/r)\mathbf{G}\mathbf{A}^{\top}$ e $\partial\mathcal{L}/\partial\mathbf{A}=\mathbf{0}$. Um passo muda $\mathbf{B}$ para $-\eta(\alpha/r)\mathbf{G}\mathbf{A}^{\top}$, e a matriz efetiva, por $\Delta\mathbf{W}=(\alpha/r)\,\mathbf{B}\mathbf{A}=-\eta(\alpha/r)^2\,\mathbf{G}\mathbf{A}^{\top}\mathbf{A}$ ($\mathbf{A}$ não mudou). Se as linhas de $\mathbf{A}$ são ortonormais, $\mathbf{A}^{\top}\mathbf{A}$ é o **projetor ortogonal** sobre o espaço gerado por essas linhas: o passo é o gradiente **completo** $\mathbf{G}$ projetado em um subespaço de dimensão $r$ do espaço de entrada, e a LoRA é, no primeiro passo, um gradiente descendente restrito a esse subespaço, com taxa efetiva $\eta(\alpha/r)^2$. O programa confere numericamente ambos os fatos.
:::

::: solucao 10.13
(a) No alvo (teste), o ajuste completo chega a $51{,}1$ e a LoRA a $71{,}0$, $62{,}8$ e $58{,}5$ para $r=1,4,16$; na origem (validação), a perplexidade sobe de $57{,}1$ para $83{,}3$ no ajuste completo e para $62{,}4$, $66{,}8$ e $71{,}6$ na LoRA. Mais capacidade aprende mais o alvo e esquece mais. (b) A varredura mostra que cada método tem uma taxa ótima **interna** (ajuste completo em $10^{-3}$, LoRA em $10^{-2}$ a $3\times10^{-2}$), que a LoRA exige taxas maiores, que as duas divergem com taxas altas demais, e, pela Figura 10.2, que o **esquecimento** acompanha a taxa: no ajuste completo, taxas menores esquecem menos e aprendem menos. Com isso, um ajuste completo com taxa menor ocupa posições tão boas quanto a LoRA ou melhores. (c) Eles **não** permitem concluir: que a LoRA seja pior que o ajuste completo em geral (modelo de $0{,}9$ milhão de parâmetros, $200$ passos, um par de domínios); que o ajuste completo "esqueça mais" por natureza (esquece mais **com a taxa ótima para o alvo**); nem que a hipótese de posto baixo seja falsa (a Figura 10.4 vale para esse modelo e esse regime). Também não há incerteza real nos desvios-padrão: as sementes não variam o pré-treino nem a divisão dos dados.
:::

::: solucao 10.14
Um desenho possível: para cada método, **varrer** taxa e número de passos em uma grade e comparar as **curvas de Pareto** (perplexidade no alvo contra perplexidade na origem), com **várias sementes por ponto**, **inclusive** do pré-treino e da divisão, e contabilizar o custo em operações (a LoRA economiza memória, mas o passo para frente e para trás passa pela base inteira, então o custo de cálculo é da mesma ordem). Para igualar parâmetros treináveis, comparar a LoRA com um ajuste completo que adapte **somente** um subconjunto de matrizes (ou camadas) de mesmo tamanho. Mudaria a conclusão do capítulo (de que a LoRA não esquece menos "de graça") se, ao longo de toda a curva e com várias sementes, a curva da LoRA ficasse **sistematicamente abaixo e à esquerda** da do ajuste completo; ou, ao contrário, a reforçaria se as curvas se sobrepusessem.
:::

::: solucao 10.15
O programa `c10_ex_bloco.py` executa o experimento:

>>> codigo/c10_ex_bloco.out

Com $4$ bits, reduzir o bloco de $128$ para $32$ baixa o erro relativo dos pesos de $0{,}120$ para $0{,}098$ e a perplexidade de $+0{,}3\%$ para $-0{,}0\%$ (indistinguível do fp32), ao custo de $4{,}25$ para $5{,}00$ bits por peso (escala de $32$ bits). Com $3$ bits, de $+1{,}9\%$ ($3{,}25$ bits por peso) a $+1{,}2\%$ ($4{,}00$). Note a comparação **a custo igual**: $3$ bits com $g=32$ ($4{,}00$ bits por peso, $+1{,}2\%$) é **pior** que $4$ bits com $g=128$ ($4{,}25$, $+0{,}3\%$) e com $g=64$ ($4{,}50$, $+0{,}2\%$): neste modelo, gastar bits no valor vale mais que gastar bits em escalas.
:::

## 10.14 Referências e leituras

### Livros didáticos

- JURAFSKY, D.; MARTIN, J. H. *Speech and Language Processing*. 3. ed. (rascunho), Stanford. Capítulos sobre tokenização, modelos de linguagem e *transformers*. Texto completo no site dos autores.
- ZHANG, A.; LIPTON, Z. C.; LI, M.; SMOLA, A. J. *Dive into Deep Learning*. Cambridge: Cambridge University Press, 2023. Capítulos sobre pré-treinamento e aplicações em linguagem natural. Texto completo em d2l.ai.

### Artigos originais

- AGHAJANYAN, A.; ZETTLEMOYER, L.; GUPTA, S. Intrinsic dimensionality explains the effectiveness of language model fine-tuning. In: *Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2021.
- BIDERMAN, D. et al. LoRA learns less and forgets less. *Transactions on Machine Learning Research*, 2024.
- DETTMERS, T. et al. LLM.int8(): 8-bit matrix multiplication for transformers at scale. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 35, 2022.
- DETTMERS, T.; PAGNONI, A.; HOLTZMAN, A.; ZETTLEMOYER, L. QLoRA: efficient finetuning of quantized LLMs. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 36, 2023.
- ECKART, C.; YOUNG, G. The approximation of one matrix by another of lower rank. *Psychometrika*, v. 1, n. 3, p. 211–218, 1936.
- GAGE, P. A new algorithm for data compression. *The C Users Journal*, v. 12, n. 2, 1994.
- HOULSBY, N. et al. Parameter-efficient transfer learning for NLP. In: *Proceedings of the 36th International Conference on Machine Learning (ICML)*, 2019.
- HU, E. J. et al. LoRA: low-rank adaptation of large language models. In: *10th International Conference on Learning Representations (ICLR)*, 2022.
- KUDO, T. Subword regularization: improving neural network translation models with multiple subword candidates. In: *Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2018.
- KUDO, T.; RICHARDSON, J. SentencePiece: a simple and language independent subword tokenizer and detokenizer for neural text processing. In: *Proceedings of the 2018 Conference on Empirical Methods in Natural Language Processing: System Demonstrations*, 2018.
- LESTER, B.; AL-RFOU, R.; CONSTANT, N. The power of scale for parameter-efficient prompt tuning. In: *Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2021.
- LI, X. L.; LIANG, P. Prefix-tuning: optimizing continuous prompts for generation. In: *Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2021.
- RAJBHANDARI, S. et al. ZeRO: memory optimizations toward training trillion parameter models. In: *International Conference for High Performance Computing, Networking, Storage and Analysis (SC)*, 2020.
- RADFORD, A. et al. Language models are unsupervised multitask learners. OpenAI, 2019.
- SCHUSTER, M.; NAKAJIMA, K. Japanese and Korean voice search. In: *IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP)*, 2012.
- SENNRICH, R.; HADDOW, B.; BIRCH, A. Neural machine translation of rare words with subword units. In: *Proceedings of the 54th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2016.
- WOLF, T. et al. Transformers: state-of-the-art natural language processing. In: *Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing: System Demonstrations*, 2020.

### Documentação técnica

- Hugging Face: documentação das bibliotecas `transformers` (classes `Trainer`, `TrainingArguments`, `GPT2LMHeadModel`), `tokenizers`, `datasets` e `peft` (`LoraConfig`, `get_peft_model`, `merge_and_unload`), em huggingface.co/docs. Versões nas execuções deste livro: `transformers` 5.22.2, `tokenizers` 0.23.3, `datasets` 5.2.0, `peft` 0.21.3, `accelerate` 1.15.0.

::: nota Sobre as referências
As referências deste capítulo foram citadas **de memória**, sem consulta às páginas originais (o ambiente de produção não tem acesso aos sites dos periódicos e repositórios). Autores, títulos e locais de publicação são os que o autor conhece com confiança, mas páginas, volumes e URLs foram omitidos de propósito quando não verificáveis. Antes de citar em um trabalho formal, confira cada referência na fonte.
:::
