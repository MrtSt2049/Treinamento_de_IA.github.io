## 10.6 O ecossistema Hugging Face

A **Hugging Face** mantém um conjunto de bibliotecas de código aberto que se tornou a interface comum para modelos de linguagem. Três delas formam o núcleo deste capítulo, e as três estão instaladas no ambiente do livro.

| Biblioteca | Papel | O que usamos aqui |
|---|---|---|
| `tokenizers` | Tokenizadores rápidos (núcleo em Rust): normalização, pré-tokenização, modelo de subpalavras, treinamento do vocabulário. | `Tokenizer`, `BpeTrainer`, `WordPieceTrainer` |
| `datasets` | Conjuntos de dados em colunas, apoiados em arquivos Arrow mapeados em memória, com `map`, `filter`, divisão e embaralhamento. | `Dataset.from_dict` |
| `transformers` | Arquiteturas (`GPT2LMHeadModel`, `BertModel`, ...), configurações, o `Trainer` e a ponte com o tokenizador. | `GPT2Config`, `GPT2LMHeadModel`, `Trainer`, `TrainingArguments` |
| `peft` | Métodos de adaptação eficiente em parâmetros (LoRA e outros) sobre modelos do `transformers`. | `LoraConfig`, `get_peft_model` |

**Configuração, modelo e persistência.** Todo modelo é construído a partir de uma **configuração** (`GPT2Config`: tamanho do vocabulário, comprimento do contexto, dimensão, número de blocos e de cabeças, taxas de *dropout*). `GPT2LMHeadModel(config)` cria o modelo com pesos aleatórios, e `modelo.save_pretrained(pasta)` e `GPT2LMHeadModel.from_pretrained(pasta)` gravam e leem a configuração e os pesos. Os mesmos nomes valem para qualquer arquitetura da biblioteca, e as classes `AutoTokenizer` e `AutoModelForCausalLM` escolhem a classe certa a partir do nome de um modelo no *Hub*.

**Perda de modelo de linguagem.** Ao receber `labels` iguais a `input_ids`, o modelo calcula a entropia cruzada entre os *logits* da posição $t$ e o token $t+1$: o deslocamento por uma posição é feito **dentro** do modelo (nos comprimentos, uma sequência de $T$ tokens contribui com $T-1$ previsões). É o objetivo autoregressivo do Capítulo 9, e é por isso que o código do projeto pode passar os mesmos dados como entrada e como rótulo.

::: atencao Código que depende do Hugging Face Hub
Neste ambiente de produção do livro, o acesso ao *Hub* (o repositório de modelos e dados) está **bloqueado**, e por isso **nenhum modelo pré-treinado da internet foi usado ou executado**. O trecho abaixo é o uso típico e **não foi executado aqui**; está correto em sua forma, mas depende de rede e de baixar centenas de megabytes de pesos.

```python
# NÃO EXECUTADO neste livro (requer acesso ao Hugging Face Hub)
from transformers import AutoTokenizer, AutoModelForCausalLM

tok = AutoTokenizer.from_pretrained("gpt2")             # baixa vocabulário e fusões
modelo = AutoModelForCausalLM.from_pretrained("gpt2")   # baixa pesos pré-treinados
ids = tok("A atenção permite", return_tensors="pt")
saida = modelo.generate(**ids, max_new_tokens=20, do_sample=True, temperature=0.8)
print(tok.decode(saida[0]))
```

Para que o experimento do capítulo seja **inteiramente reproduzível**, o Projeto 7 faz, em miniatura, o que o fluxo acima automatiza: treina um tokenizador, **pré-treina** um GPT-2 minúsculo sobre um domínio e só então o ajusta a outro.
:::

**O `Trainer`.** Escrever o laço de treino à mão (como no Capítulo 6) é instrutivo, mas repetitivo: *loop* de épocas, lotes, otimizador, agendador da taxa de aprendizado, recorte de gradiente, avaliação periódica, registro. O `Trainer` encapsula tudo isso. O que o aluno controla fica em `TrainingArguments`:

| Argumento | Função |
|---|---|
| `max_steps`, `per_device_train_batch_size` | Orçamento de treino e tamanho do lote. |
| `learning_rate`, `lr_scheduler_type`, `warmup_steps`, `weight_decay` | Taxa de aprendizado, agendador (aqui, cosseno com aquecimento) e regularização do AdamW. |
| `max_grad_norm` | Recorte da norma do gradiente (seção 8.3). |
| `eval_strategy`, `eval_steps` | Quando avaliar sobre o conjunto de validação. |
| `seed`, `data_seed` | Sementes da inicialização de partes aleatórias e da ordem dos dados. |
| `use_cpu`, `report_to`, `save_strategy` | Dispositivo, sistema de registro externo e gravação de pontos de verificação. |

Ao final de `trainer.train()`, `trainer.state.log_history` guarda, em uma lista de dicionários, a perda de treino e a de validação nos passos de registro; é de lá que as curvas do projeto são extraídas.

## 10.7 Ajuste fino completo e o custo de memória

Um modelo pré-treinado sobre muito texto já "sabe" muito sobre a língua. O **ajuste fino** (*fine-tuning*) continua o treinamento, com uma taxa de aprendizado pequena, em dados de um domínio ou de uma tarefa específica. É o mesmo princípio da transferência de aprendizado com redes convolucionais da seção 7.7: reutilizar uma representação aprendida em vez de começar de pesos aleatórios. No **ajuste fino completo**, todos os $P$ parâmetros são atualizados.

Dois problemas aparecem. O primeiro é o **esquecimento catastrófico**: ao se adaptar ao domínio novo, o modelo pode perder desempenho no domínio de origem. O projeto mede isso. O segundo é o **custo de memória**.

::: proposicao 10.3 · Memória do treino com AdamW
Considere um modelo com $P$ parâmetros treinado em precisão simples (4 bytes por número) com AdamW. Sem contar as **ativações**, a memória necessária é $16P$ bytes: $4P$ para os pesos, $4P$ para os gradientes e $8P$ para os dois momentos do otimizador ($\mathbf{m}$ e $\mathbf{v}$, cada um com $P$ números). Se apenas $p_t\ll P$ parâmetros são treinados e os demais ficam **congelados**, o custo cai para $4P+16p_t$, pois gradientes e estados do otimizador existem somente para os $p_t$ parâmetros treináveis.
:::

::: demonstracao
O AdamW (seção 6.6) mantém, para **cada** parâmetro treinável, uma estimativa de primeiro momento e uma de segundo momento, ambas do tamanho do parâmetro; o gradiente também tem o tamanho do parâmetro. Cada número ocupa $4$ bytes: $4+4+4+4=16$ bytes por parâmetro treinável. Um parâmetro congelado só precisa de seu valor (4 bytes), sem gradiente nem momentos.
:::

Em precisão mista (pesos e gradientes em 16 bits e uma cópia em 32 bits dos pesos e dos momentos), a contabilidade usual (Rajbhandari et al., 2020) também resulta em cerca de $16$ bytes por parâmetro; o que muda é a velocidade, não a ordem de grandeza.

O programa abaixo aplica a Proposição 10.3, e suas variantes com a base congelada em menos bits, a dois tamanhos de modelo.

<<< codigo/c10_memoria.py

>>> codigo/c10_memoria.out

Para o GPT-2 pequeno, o ajuste completo precisa de cerca de $2$ GB só para pesos, gradientes e momentos. Para um modelo de $7$ bilhões de parâmetros, são $112$ GB, mais do que cabe em uma GPU comum. O segundo caso é **hipotético** (a fração de $0{,}5\%$ de parâmetros treináveis é uma suposição ilustrativa) e as ativações, que dependem do tamanho do lote e do contexto, **não** estão contadas. O ponto da tabela é a **estrutura** do custo: congelar a base elimina $12$ bytes por parâmetro congelado, e guardar a base em poucos bits reduz os $4$ bytes restantes. É o que as duas seções seguintes exploram.

## 10.8 Adaptação de baixo posto (LoRA)

A **LoRA** (*Low-Rank Adaptation*, Hu et al., 2022) parte de uma observação empírica e de uma hipótese. A observação é a do custo acima. A hipótese, motivada pelo trabalho de Aghajanyan, Zettlemoyer e Gupta (2021) sobre a **dimensão intrínseca** do ajuste fino, é que a **atualização** dos pesos em uma adaptação tem **posto baixo**: não é preciso uma matriz $\Delta\mathbf{W}$ arbitrária $d\times k$, uma de posto $r\ll\min(d,k)$ basta. É uma hipótese, e não um teorema; o Projeto 7 a testa.

::: definicao 10.3 · LoRA
Seja $\mathbf{W}_0\in\mathbb{R}^{d\times k}$ uma matriz de pesos pré-treinada, **congelada**. A LoRA a substitui por
$$\mathbf{W}=\mathbf{W}_0+\frac{\alpha}{r}\,\mathbf{B}\mathbf{A},\qquad \mathbf{B}\in\mathbb{R}^{d\times r},\ \mathbf{A}\in\mathbb{R}^{r\times k},\ r\ll\min(d,k),$$
e **somente $\mathbf{A}$ e $\mathbf{B}$ são treinados**. A inicialização é $\mathbf{B}=\mathbf{0}$ e $\mathbf{A}$ com entradas aleatórias pequenas, de modo que $\mathbf{W}=\mathbf{W}_0$ no início do ajuste. O hiperparâmetro $\alpha$ fixa a escala da atualização; o fator $\alpha/r$ a mantém comparável quando se varia $r$.
:::

No código do projeto, usa-se $\alpha=2r$, de modo que o fator vale $2$ para todos os postos. (Convenção: o `peft` guarda as matrizes de pesos como $(\text{saída},\text{entrada})$; o GPT-2 usa uma camada `Conv1D` com a orientação oposta, e por isso a configuração leva `fan_in_fan_out=True`.)

::: proposicao 10.4 · Número de parâmetros e posto da atualização
(a) A LoRA treina $r(d+k)$ parâmetros por matriz adaptada, a fração $r(d+k)/(dk)$ do total da matriz. (b) O posto de $\Delta\mathbf{W}=\frac{\alpha}{r}\mathbf{B}\mathbf{A}$ é no máximo $r$.
:::

::: demonstracao
(a) $\mathbf{B}$ tem $dr$ entradas e $\mathbf{A}$ tem $rk$. (b) $\operatorname{posto}(\mathbf{B}\mathbf{A})\le\min(\operatorname{posto}\mathbf{B},\operatorname{posto}\mathbf{A})\le r$. Multiplicar por um escalar não muda o posto.
:::

::: exemplo 10.2 · Os números de uma camada
Para uma camada com $d=64$ saídas e $k=48$ entradas, a matriz tem $dk=3\,072$ pesos (a camada completa, com os $64$ vieses, tem $3\,136$ parâmetros). Com $r=4$, a LoRA treina $4(64+48)=448$ parâmetros, **$14{,}6\%$** de $dk$. Em uma matriz grande, a fração é muito menor: para $d=k=4\,096$ e $r=8$, são $8\cdot8\,192=65\,536$ parâmetros, isto é, $0{,}39\%$ dos $16\,777\,216$ da matriz.
:::

::: proposicao 10.5 · Gradientes da LoRA
Seja $\mathbf{G}=\partial\mathcal{L}/\partial\mathbf{W}\in\mathbb{R}^{d\times k}$ o gradiente da perda em relação à matriz **efetiva** $\mathbf{W}$ (o mesmo que o ajuste completo calcularia). Então
$$\frac{\partial\mathcal{L}}{\partial\mathbf{B}}=\frac{\alpha}{r}\,\mathbf{G}\mathbf{A}^{\top},\qquad \frac{\partial\mathcal{L}}{\partial\mathbf{A}}=\frac{\alpha}{r}\,\mathbf{B}^{\top}\mathbf{G}.$$
Em particular, com $\mathbf{B}=\mathbf{0}$ no início, $\partial\mathcal{L}/\partial\mathbf{A}=\mathbf{0}$ (somente $\mathbf{B}$ se move no primeiro passo), enquanto $\partial\mathcal{L}/\partial\mathbf{B}$ é em geral diferente de zero.
:::

::: demonstracao
Com $\mathbf{W}=\mathbf{W}_0+\frac{\alpha}{r}\mathbf{B}\mathbf{A}$, a diferencial da perda é $d\mathcal{L}=\langle\mathbf{G},d\mathbf{W}\rangle=\frac{\alpha}{r}\langle\mathbf{G},d\mathbf{B}\,\mathbf{A}+\mathbf{B}\,d\mathbf{A}\rangle$, em que $\langle\cdot,\cdot\rangle$ é o produto escalar de Frobenius. Como $\langle\mathbf{G},d\mathbf{B}\,\mathbf{A}\rangle=\langle\mathbf{G}\mathbf{A}^{\top},d\mathbf{B}\rangle$ e $\langle\mathbf{G},\mathbf{B}\,d\mathbf{A}\rangle=\langle\mathbf{B}^{\top}\mathbf{G},d\mathbf{A}\rangle$, lê-se cada gradiente como o coeficiente da diferencial correspondente.
:::

A assimetria da inicialização é **necessária**: se $\mathbf{A}$ e $\mathbf{B}$ fossem ambas nulas, os dois gradientes seriam nulos e nada se moveria. Com $\mathbf{B}=\mathbf{0}$ e $\mathbf{A}\neq\mathbf{0}$, o primeiro passo move apenas $\mathbf{B}$, e depois disso $\mathbf{A}$ também recebe gradiente.

::: proposicao 10.6 · A fusão não tem custo na inferência
Depois do ajuste, $\mathbf{W}'=\mathbf{W}_0+\frac{\alpha}{r}\mathbf{B}\mathbf{A}$ é uma matriz $d\times k$ comum, e a camada com $\mathbf{W}'$ produz **exatamente** a mesma saída que a camada com o adaptador. Logo, o modelo adaptado tem o mesmo custo de inferência que o original; e vários adaptadores (de $r(d+k)$ números cada) podem ser guardados e trocados sobre **uma** base compartilhada.
:::

::: demonstracao
$(\mathbf{W}_0+\frac{\alpha}{r}\mathbf{B}\mathbf{A})\mathbf{x}=\mathbf{W}_0\mathbf{x}+\frac{\alpha}{r}\mathbf{B}(\mathbf{A}\mathbf{x})$, por distributividade; a diferença numérica entre as duas formas é erro de arredondamento.
:::

::: proposicao 10.7 · A melhor aproximação de posto $r$ (Eckart-Young)
Seja $\mathbf{M}\in\mathbb{R}^{d\times k}$ com decomposição em valores singulares $\mathbf{M}=\sum_i\sigma_i\mathbf{u}_i\mathbf{v}_i^{\top}$, $\sigma_1\ge\sigma_2\ge\cdots$. Entre todas as matrizes de posto no máximo $r$, a que minimiza $\|\mathbf{M}-\mathbf{N}\|_F$ é a **truncada** $\mathbf{M}_r=\sum_{i\le r}\sigma_i\mathbf{u}_i\mathbf{v}_i^{\top}$, e o erro vale
$$\|\mathbf{M}-\mathbf{M}_r\|_F=\sqrt{\textstyle\sum_{i>r}\sigma_i^2}.$$
:::

A Proposição 10.7 (Eckart e Young, 1936) é enunciada sem demonstração, como no Capítulo 1. Ela diz **o que se perde** quando a atualização de um ajuste completo é aproximada por uma de posto $r$: o que sobra é a energia dos valores singulares descartados. Se $\Delta\mathbf{W}$ tem espectro decrescente rápido, um posto baixo basta; se o espectro é plano, não. O programa de verificação (próxima saída) e o Projeto 7 medem os dois casos.

<<< codigo/c10_lora_manual.py

>>> codigo/c10_lora_manual.out

Leitura dos resultados.

- **Equivalência no início e parâmetros.** A camada com adaptador reproduz **exatamente** a saída da camada base quando $\mathbf{B}=\mathbf{0}$, e treina $448$ parâmetros, $14{,}6\%$ dos $3\,072$ pesos da matriz.
- **Gradientes (Proposição 10.5).** No início, $\|\partial\mathcal{L}/\partial\mathbf{B}\|=123{,}9$ e $\|\partial\mathcal{L}/\partial\mathbf{A}\|=0$, como previsto.
- **Posto (Proposição 10.4).** Depois de treinar, o posto numérico de $\Delta\mathbf{W}$ é $4$, o limite $r$: os quatro valores singulares positivos são $2{,}80$, $2{,}37$, $2{,}06$ e $1{,}79$, e os demais são nulos.
- **Fusão (Proposição 10.6).** A diferença máxima entre a saída com adaptador e a saída com a matriz fundida é $7\times10^{-7}$, erro de arredondamento.
- **Eckart-Young (Proposição 10.7).** Para uma matriz $256\times256$ com valores singulares $\propto1/i$, o posto $r=4$ retém $86{,}8\%$ da energia e deixa erro relativo de $0{,}364$; com $r=64$, são $99{,}3\%$ e $0{,}084$. Um espectro decrescente **lento** exige posto alto para uma boa aproximação; é o contraexemplo que lembra que a hipótese da LoRA pode falhar.
- **Biblioteca `peft`.** Com `LoraConfig` e `get_peft_model`, em um modelo minúsculo, a biblioteca reproduz as contagens da teoria (treináveis $8\,192$ de $144\,384$), a igualdade de saída no início, e `merge_and_unload()` devolve o modelo com os pesos fundidos, sem módulos LoRA restantes. Para o GPT-2 pequeno ($124{,}4$ milhões de parâmetros), $r=8$ em todas as matrizes lineares dos blocos treina $1\,179\,648$ parâmetros, $0{,}95\%$ do total.

**Outros métodos de adaptação eficiente (PEFT).** A LoRA é a mais usada, mas não a única. *Adapters* (Houlsby et al., 2019) inserem pequenas redes de gargalo entre as camadas do Transformer; *prefix-tuning* (Li e Liang, 2021) e *prompt tuning* (Lester et al., 2021) treinam vetores contínuos acrescentados à entrada ou às chaves e valores de cada camada, mantendo todo o modelo congelado. Diferentemente da LoRA, os adapters aumentam a profundidade e, portanto, a latência, e os métodos de prefixo consomem parte do comprimento do contexto. Nenhum deles é executado neste livro.

## 10.9 Quantização de pesos

Um peso em precisão simples ocupa $32$ bits. A **quantização** o representa por um inteiro de poucos bits e uma **escala**, reduzindo a memória e a largura de banda, o que acelera a inferência, ao custo de um erro de arredondamento.

::: definicao 10.4 · Quantização uniforme simétrica (absmax)
Para $b$ bits, seja $q=2^{b-1}-1$ (por exemplo, $127$ para $8$ bits e $7$ para $4$ bits). Dado um grupo de pesos $\mathbf{w}$, define-se a **escala** $s=\max_i|w_i|/q$, os inteiros $\hat w_i=\operatorname{round}(w_i/s)\in\{-q,\dots,q\}$ e a **reconstrução** $\tilde w_i=s\,\hat w_i$. O grupo pode ser o **tensor inteiro** (uma escala), cada **canal de saída** (uma escala por coluna) ou **blocos** de tamanho fixo (por exemplo, $64$ pesos consecutivos), cada um com sua escala.
:::

::: proposicao 10.8 · Cota do erro e o efeito dos atípicos
Com a escala absmax, nenhum peso é recortado, e $|\tilde w_i-w_i|\le s/2$ para todo $i$. Como $s=\max_j|w_j|/q$ do **grupo**, um único valor atípico grande no grupo **aumenta o erro de todos os outros pesos do grupo**. O custo de memória é $b$ bits por peso mais $32/g$ bits por peso para as escalas (em precisão simples), com $g$ o tamanho do grupo.
:::

::: demonstracao
O arredondamento ao inteiro mais próximo erra no máximo $1/2$, e $w_i/s$ está em $[-q,q]$ por definição de $s$; logo, $|w_i/s-\hat w_i|\le1/2$, e multiplicando por $s$ obtém-se a cota. A cota depende de $s$, que é proporcional ao maior valor do grupo. Quanto às escalas, cada grupo de $g$ pesos guarda uma escala de $32$ bits, isto é, $32/g$ bits por peso.
:::

Uma consequência é que **grupos menores** (por canal, por bloco) toleram melhor os atípicos, ao custo de mais escalas. O programa abaixo verifica a cota e mede o efeito de **um único** atípico em uma matriz gaussiana.

<<< codigo/c10_quant.py

>>> codigo/c10_quant.out

Leitura dos resultados.

- **Sem atípicos**, $8$ bits dão erro relativo de cerca de $1\%$ (por tensor) e $4$ bits de cerca de $20\%$; a cota $s/2$ é atingida (`max |erro|` $=s/2$ no limite). Escalas por canal ou por bloco **reduzem** o erro (de $0{,}195$ a $0{,}108$ em 4 bits), porque cada escala se adapta à amplitude local, ao custo de $0{,}06$ a $0{,}5$ bit por peso.
- **Com um único atípico** de $60$ desvios-padrão, a escala por tensor se estraga: com $8$ bits, o erro relativo sobe de $0{,}011$ para $0{,}13$ (12 vezes maior); com $4$ bits, **todos os outros pesos arredondam para zero** (erro relativo de $0{,}9999$ sobre os demais). Escalas por canal ou por bloco confinam o dano ao grupo do atípico: em $4$ bits, o erro nos demais pesos fica em $0{,}16$ (por canal) e $0{,}11$ (por bloco).

**QLoRA.** A quantização e a LoRA se combinam. No **QLoRA** (Dettmers et al., 2023), a base congelada é guardada em $4$ bits, com um tipo de dado projetado para pesos com distribuição aproximadamente normal (*NormalFloat*, NF4), constantes de quantização elas próprias quantizadas (*double quantization*) e otimizadores paginados; os adaptadores LoRA, em precisão maior, são o que se treina, e o gradiente flui pela base desquantizada durante o cálculo. É o que explica a última linha do programa de memória: base em $4$ bits mais adaptadores permite ajustar modelos grandes em uma única GPU. **Isso não é executado aqui**: o QLoRA depende da biblioteca `bitsandbytes`, que exige GPU, e o ambiente do livro só tem CPU. A seção 10.10 faz, no lugar, a quantização **pós-treino** de pesos de um modelo, **implementada à mão** com a Definição 10.4, e mede a perda de qualidade.
