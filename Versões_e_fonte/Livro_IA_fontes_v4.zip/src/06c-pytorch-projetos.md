## 6.8 PyTorch

Implementar a retropropagação à mão, como no Projeto 3, ensina o mecanismo, mas não escala: cada nova camada exigiria deduzir e programar seu gradiente. O **PyTorch** (Paszke et al., 2019) automatiza isso e oferece os demais componentes de um treinamento. Esta seção apresenta as peças em quatro grupos; a documentação e os tutoriais oficiais (pytorch.org/tutorials) são a referência detalhada. Todas as execuções deste livro usam a versão 2.15, em CPU.

### Tensores

Um **tensor** do PyTorch é um arranjo multidimensional como o `ndarray` do NumPy (Capítulo 1), com três atributos adicionais: o **tipo** (`dtype`, geralmente `float32` em redes), o **dispositivo** em que reside (CPU ou GPU) e a marca `requires_grad`, que indica se as operações sobre ele devem ser registradas para a diferenciação. As operações têm os mesmos nomes e semântica do NumPy (`@`, `sum`, `mean`, difusão), e `torch.from_numpy` converte sem copiar a memória.

### Autograd

O mecanismo de diferenciação automática (seção 6.5) é o **autograd**. Toda operação sobre tensores com `requires_grad=True` registra um nó no grafo; a chamada `perda.backward()` percorre o grafo em ordem inversa e **acumula** em `parâmetro.grad` a derivada da perda. O grafo é construído dinamicamente, à medida que o código executa (*define-by-run*), o que permite usar `if` e laços do Python na definição do modelo. O programa abaixo mostra os comportamentos essenciais.

<<< codigo/c6_autograd.py

>>> codigo/c6_autograd.out

Cada ponto da saída corresponde a um erro frequente de iniciantes.

1. O gradiente do autograd coincide com a fórmula analítica $2(\mathbf{w}^\top\mathbf{x})\,\mathbf{x}$.
2. **O gradiente se acumula**: um segundo `backward()` soma ao anterior (o resultado dobra). Por isso o laço de treino chama `zero_grad()` a cada passo.
3. `z.grad_fn` guarda a operação que produziu o tensor (aqui, uma multiplicação) e é o que permite o passo para trás.
4. Dentro de `torch.no_grad()` nada é registrado: é o modo para validação e inferência, que economiza memória e tempo.
5. `detach()` separa um tensor do grafo, para parar a propagação do gradiente.
6. Com `nn.Linear` e `torch.optim.SGD`, o ajuste de uma regressão linear recupera os coeficientes verdadeiros, como na seção 4.3, em poucas linhas. O módulo tem 4 parâmetros: 3 pesos e 1 viés.

### Módulos, perdas e otimizadores

Um modelo é uma subclasse de `torch.nn.Module`. Os atributos que são camadas (`nn.Linear`, `nn.BatchNorm1d`, ...) têm seus parâmetros registrados automaticamente e aparecem em `modelo.parameters()`; o método `forward` define o cálculo. `nn.Sequential` encadeia camadas simples. Dois cuidados com as convenções:

- `nn.Linear(n_ent, n_saí)` guarda a matriz de pesos com formato $(n_\text{saí},n_\text{ent})$ e calcula $\mathbf{x}\mathbf{W}^\top+\mathbf{b}$, o **transposto** da convenção deste capítulo ($\mathbf{W}\in\mathbb{R}^{n_\text{ent}\times n_\text{saí}}$). O Projeto 4 faz essa transposição ao copiar os pesos do Projeto 3.
- `nn.CrossEntropyLoss` e `F.cross_entropy` aplicam softmax e entropia cruzada **juntas**, em forma estável (seção 6.4). Recebem **logits** e rótulos inteiros (`torch.long`). Aplicar `softmax` antes da perda é erro comum, pois a softmax seria feita duas vezes. Para classificação binária ou rótulos múltiplos independentes, usa-se `BCEWithLogitsLoss`.

Os otimizadores de `torch.optim` (`SGD` com `momentum`, `RMSprop`, `Adam`, `AdamW`) implementam as regras da seção 6.6. O ciclo de treinamento tem sempre a mesma forma:

1. `modelo.train()`;
2. para cada minilote: `otimizador.zero_grad()`, cálculo da perda, `perda.backward()`, `otimizador.step()`;
3. ao fim da época: `modelo.eval()` e, dentro de `torch.no_grad()`, avaliação em validação.

`DataLoader` e `TensorDataset` fornecem os minilotes, com `shuffle=True` para reordenar a cada época.

::: erro Os erros mais caros de um laço de treino
- **Esquecer `model.eval()` na avaliação.** Dropout continua desligando neurônios e o BatchNorm usa as estatísticas do lote. A degradação é silenciosa; o Projeto 4 mede seu tamanho.
- **Esquecer `zero_grad()`.** Os gradientes de passos anteriores se somam aos novos.
- **Aplicar softmax antes da `CrossEntropyLoss`.** A rede ainda treina, mas pior, e a perda deixa de ter a interpretação da seção 6.4.
- **Rótulos com tipo errado.** A perda de entropia cruzada espera índices de classe do tipo `long`, não `float`.
- **Avaliar sem `no_grad()`.** O resultado está correto, mas o grafo é construído e a memória cresce.
- **Vazamento pelo conjunto de teste.** Decidir época de parada ou hiperparâmetros olhando o teste invalida a estimativa (seção 5.4). O Projeto 4 usa a validação para isso.
:::

### Reprodutibilidade

Resultados de redes dependem da inicialização, da ordem dos minilotes e do Dropout, todos aleatórios. Para repetir um experimento, fixam-se as sementes com `torch.manual_seed`. Mesmo assim, operações em GPU podem ser não determinísticas, e versões diferentes da biblioteca podem alterar os números. Por isso este livro relata o desempenho como média e desvio-padrão em várias sementes sempre que a conclusão depende de diferenças pequenas.

## 6.9 Projeto 3: rede neural em NumPy

::: projeto Retropropagação do zero
O projeto implementa um perceptron multicamadas completo, sem bibliotecas de aprendizado de máquina, e o submete a testes que provam que a implementação está correta antes de qualquer conclusão sobre desempenho.
:::

### Objetivo

Implementar, em NumPy, a propagação para frente, a retropropagação e o otimizador Adam; verificar o gradiente numericamente; treinar a rede e compará-la com a regressão logística do Capítulo 4.

### Problema

Classificar imagens de dígitos manuscritos do conjunto `digits` do scikit-learn: 1797 imagens de $8\times8$ pixels (64 variáveis em escala de cinza, 0 a 16), 10 classes. Os pixels são divididos por 16 para ficar em $[0,1]$. O conjunto acompanha a biblioteca e dispensa acesso à rede.

### Requisitos

- Classe `MLP` com camadas densas, ReLU nas ocultas, softmax e entropia cruzada na saída, inicialização de He.
- Gradiente calculado pelo Teorema 6.8, **sem** uso de autograd.
- Verificação numérica do gradiente com erro relativo abaixo de $10^{-6}$.
- Teste de sanidade da perda inicial ($\approx\ln10$) e teste de capacidade (decorar 16 exemplos).
- Otimizador Adam implementado manualmente, minilotes embaralhados, penalidade $\ell_2$.
- Divisão estratificada em treino (60%), validação (20%) e teste (20%); o teste é usado uma única vez.

### Arquitetura

Rede $64\text{-}64\text{-}10$: entrada de 64 pixels, uma camada oculta de 64 neurônios com ReLU, saída com 10 logits. O número de parâmetros, pela fórmula da seção 6.2, é $(64+1)\cdot64+(64+1)\cdot10=4\,810$.

| Componente | Escolha | Justificativa |
|---|---|---|
| Ativação oculta | ReLU | gradiente não satura (seção 6.3) |
| Inicialização | He, $\sigma_w^2=2/n_\text{ent}$ | conserva a escala do sinal (seção 6.7) |
| Perda | entropia cruzada + $\frac\lambda2\lVert\mathbf{W}\rVert^2$, $\lambda=10^{-4}$ | MLE categórica (Teorema 6.6) |
| Otimizador | Adam, $\eta=3\times10^{-3}$, lote 64, 60 épocas | seção 6.6 |

### Fundamentos teóricos

Os componentes do projeto vêm das seções anteriores: a propagação para frente é a Definição 6.3; o gradiente do passo para trás é o Teorema 6.8 com $\boldsymbol\delta^{(L)}=\mathbf{p}-\mathbf{y}$ (Teorema 6.7); a verificação numérica é a diferença central da seção 6.5; o Adam é a Definição 6.8. A perda é a média no lote, e por isso $\boldsymbol\Delta^{(L)}$ é dividido por $B$. A penalidade $\ell_2$ não é aplicada aos vieses, e seu gradiente é $\lambda\mathbf{W}$.

### Implementação

<<< codigo/projeto3.py

### Testes e resultados

>>> codigo/projeto3.out

**Teste 1: perda inicial.** Com uma rede sem informação, o valor esperado é $\ln10=2{,}303$. O resultado, $2{,}467$, é próximo, mas não igual: com pesos aleatórios, os logits iniciais não são exatamente zero e a rede tem preferências aleatórias por algumas classes. O teste serve para detectar erros grosseiros (uma perda inicial de $50$ ou de $0{,}1$ indicaria problema de escala ou de rótulos), e a tolerância usada foi $0{,}5$.

**Teste 2: gradiente.** O maior erro relativo entre o gradiente analítico e a diferença central em 20 parâmetros sorteados por camada (pesos e vieses) foi $1{,}6\times10^{-7}$, abaixo do limite de $10^{-6}$. A retropropagação está correta nas duas camadas. No Projeto 4, a mesma conferência é feita contra o autograd do PyTorch.

**Teste 3: capacidade.** A rede memoriza $16$ exemplos com acurácia $1{,}00$, o que mostra que o laço de treino e o otimizador funcionam: se uma rede não consegue decorar um lote minúsculo, há erro de implementação.

**Treinamento.** A perda de treino cai de $1{,}61$ na primeira época para $0{,}010$ na sexagésima. A de validação cai de $1{,}63$ a $0{,}058$ e segue caindo, de modo que não houve sinal de superajuste que exigisse parar antes (Figura 6.4). A diferença entre as duas curvas ao fim (a validação é cerca de seis vezes a de treino) é a lacuna de generalização da seção 5.1. A acurácia de validação chega a $0{,}989$.

<figure>
+++ fig_c6_p3.svg
<figcaption><b>Figura 6.4.</b> Perda de treino (violeta) e de validação (azul) por época, na rede em NumPy. Valores da saída acima.</figcaption>
</figure>

**Resultado no teste.** A rede atinge $0{,}9806$ de acurácia nas $360$ imagens de teste (353 acertos), contra $0{,}9611$ da regressão logística (346 acertos). A diferença de dois pontos percentuais favorece a rede, mas o erro-padrão de uma acurácia estimada com $360$ exemplos é da ordem de $0{,}7$ ponto percentual: é um indício, não uma prova de superioridade. O tempo de treino (cerca de $0{,}2$ s) depende da máquina.

### Limitações

- Um único sorteio de divisão e de inicialização. Com poucas imagens de teste, a comparação com a regressão logística tem incerteza do mesmo tamanho da diferença observada.
- Imagens de $8\times8$ são um problema muito fácil; as conclusões não se transferem automaticamente a dados maiores.
- Os hiperparâmetros ($\eta$, largura, $\lambda$, épocas) foram escolhidos uma vez, sem busca; o desempenho de validação não foi usado para ajustá-los.
- A implementação em NumPy é didática: sem GPU, sem agrupamento eficiente de operações e sem tratamento de casos extremos de precisão.
- A verificação do gradiente amostra 20 parâmetros por camada; ela não prova a correção em todos.

### Melhorias possíveis

1. Repetir com várias sementes e relatar média e desvio.
2. Adicionar *momentum* e agendamento da taxa de aprendizado.
3. Acrescentar Dropout e BatchNorm, calculando seus gradientes à mão (exercício difícil e instrutivo).
4. Procurar $\eta$, largura e $\lambda$ por validação cruzada (Capítulo 5).
5. Verificar o gradiente em **todos** os parâmetros de uma rede pequena.

## 6.10 Projeto 4: treinamento em PyTorch

::: projeto Pipeline de aprendizado profundo com PyTorch
O projeto reimplementa o treinamento com PyTorch, valida o autograd contra o Projeto 3 e mede o efeito de Dropout, BatchNorm e *weight decay* em um regime de poucos dados.
:::

### Objetivo

Construir um laço de treino/validação completo com `nn.Module`, `DataLoader`, `AdamW` e *checkpoint* do melhor modelo, e estudar, por uma ablação com várias sementes, quais técnicas de regularização ajudam a generalizar.

### Problema

O mesmo conjunto `digits`, agora em um regime de **poucos dados**, em que a regularização importa: $300$ imagens de treino, $300$ de validação e as $1\,197$ restantes de teste. O sorteio da divisão e a inicialização da rede mudam a cada uma das $5$ sementes.

### Requisitos

- Rede `Rede(ocultas, dropout, batchnorm)` como `nn.Module`.
- Validação do gradiente: o PyTorch deve reproduzir o gradiente do Projeto 3 para os mesmos pesos.
- Laço de treino com `train()`/`eval()`, `zero_grad()` e `no_grad()` nos lugares corretos.
- Seleção da época pela **menor perda de validação** (*checkpoint*), sem usar o teste.
- Ablação: base, Dropout, BatchNorm, *weight decay* e a combinação, em 5 sementes.
- Medida do efeito de esquecer `model.eval()`.

### Arquitetura

Rede $64\text{-}256\text{-}256\text{-}10$ com ReLU. A ablação acrescenta, conforme a variante: Dropout $p=0{,}3$ após cada ReLU; `BatchNorm1d` antes de cada ReLU; *weight decay* $\lambda=10^{-2}$ no AdamW. Otimizador AdamW com $\eta=2\times10^{-3}$, lote de $32$, $100$ épocas. A rede base tem $85\,002$ parâmetros, muito mais do que as $300$ amostras de treino.

### Fundamentos teóricos

Dropout, BatchNorm e *weight decay* são descritos na seção 6.7; a seleção da época por validação é a parada antecipada; o comportamento distinto de `train()` e `eval()` decorre do fato de que Dropout e BatchNorm têm um comportamento aleatório (ou dependente do lote) no treinamento e determinístico na avaliação.

### Implementação

<<< codigo/projeto4.py

### Testes e resultados

>>> codigo/projeto4.out

**1. Conferência do gradiente.** Com os mesmos pesos, o gradiente do PyTorch e o da retropropagação manual do Projeto 3 diferem por $5{,}6\times10^{-17}$, ou seja, por arredondamento. A implementação manual está validada por uma fonte independente, e o autograd, por um cálculo explícito.

**2. Ablação.** Todas as variantes alcançam acurácia de treino próxima de $1$: com $85$ mil parâmetros e $300$ exemplos, todas as redes decoram o treino, e a diferença está na generalização.

- O **BatchNorm** elevou a acurácia média de teste de $0{,}947$ para $0{,}962$ (cerca de $1{,}5$ ponto percentual) e reduziu o desvio entre sementes. É a melhoria mais visível do experimento. Como o desvio entre sementes é de $0{,}6$ a $1{,}1$ ponto percentual e há apenas cinco sementes, o resultado é compatível com um efeito real, mas não o estabelece.
- O **Dropout** não alterou a acurácia de teste ($0{,}9475$ contra $0{,}9469$), mas **deslocou o ponto de menor perda de validação** de cerca da época $22$ para a época $43$: a rede passa a precisar de mais épocas para chegar a seu melhor estado, como esperado de uma técnica que dificulta o superajuste. Aqui isso não se converteu em melhor acurácia final.
- O ***weight decay*** a $10^{-2}$ não teve efeito perceptível ($0{,}9462$), em linha com a observação da seção 6.7: com $\eta=2\times10^{-3}$, o encolhimento por passo no AdamW é de apenas $2\times10^{-5}$. Um valor muito maior seria necessário para influenciar o resultado; com um único valor testado, nada se pode concluir sobre a técnica em si.
- A **combinação** não superou o BatchNorm isolado.

Os resultados não confirmam a ideia de que "mais regularização é sempre melhor": no regime deste experimento, uma técnica ajudou, uma deslocou o treinamento sem melhorar o resultado e uma foi inócua. A resposta depende do problema, e deve ser medida com validação.

**3. O custo de esquecer `eval()`.** O mesmo modelo, com Dropout $0{,}5$ e BatchNorm, avaliado no mesmo conjunto de teste, acerta $0{,}9574$ em modo de avaliação e $0{,}9240$ no modo de treino, uma queda de $3{,}3$ pontos percentuais sem nenhum aviso. O modelo tem $86\,026$ parâmetros.

### Limitações

- Apenas $5$ sementes, e um único valor de cada hiperparâmetro de regularização: as conclusões sobre cada técnica valem só para estes valores.
- A mesma divisão de dados foi usada em todas as variantes de uma semente, o que torna a comparação pareada, mas a incerteza das diferenças não foi calculada.
- O conjunto de teste foi usado para relatar todas as variantes; como nenhuma decisão foi tomada com base nele, não há vazamento, mas escolher a "melhor variante" pelo teste invalidaria a estimativa.
- Imagens de $8\times8$ e um problema fácil; a hierarquia entre as técnicas pode mudar em outros problemas.
- A execução em CPU limitou o tamanho dos experimentos.

### Melhorias possíveis

1. Aumentar o número de sementes e testar a diferença pareada entre variantes.
2. Varrer $\lambda$ (por exemplo, de $10^{-3}$ a $10^{0}$) e $p$ do Dropout.
3. Acrescentar agendamento da taxa de aprendizado e aquecimento.
4. Registrar curvas por época (TensorBoard) em vez de apenas o ponto final.
5. Repetir com um conjunto maior, em GPU, e com `torch.compile` para medir ganhos de velocidade.

## 6.11 Resumo do capítulo

::: resumo Ideias centrais
- Um **neurônio** é $\varphi(\mathbf{w}^\top\mathbf{x}+b)$. Com ativação sigmoide, é a regressão logística. O **perceptron** converge em, no máximo, $(R/\gamma)^2$ erros se os dados são linearmente separáveis, e **não resolve o XOR**.
- Um **MLP** compõe camadas afins e não lineares; **sem não linearidade** a composição colapsa em uma única função afim. O teorema da **aproximação universal** garante a existência de uma boa rede, não sua aprendizagem nem sua generalização.
- **Sigmoide e tanh saturam**; a **ReLU** preserva o gradiente no lado positivo, mas pode "morrer". A **softmax** é invariante a deslocamento, o que permite a implementação estável.
- As perdas são **verossimilhanças negativas**: MSE (gaussiana), entropia cruzada (Bernoulli, categórica). O gradiente da entropia cruzada em relação aos logits é $\mathbf{p}-\mathbf{y}$, o que a torna preferível ao MSE em classificação.
- A **retropropagação** é a regra da cadeia com reaproveitamento: $\boldsymbol\delta^{(l)}=(\mathbf{W}^{(l+1)}\boldsymbol\delta^{(l+1)})\odot\varphi'(\mathbf{z}^{(l)})$ e $\partial\mathcal{L}/\partial\mathbf{W}^{(l)}=\mathbf{h}^{(l-1)}\boldsymbol\delta^{(l)\top}$. Custa cerca de três avaliações da rede e guarda as ativações. É verificada com diferenças finitas.
- **SGD** usa um gradiente não viesado de minilote. **Momentum** ataca o mal condicionamento (de $\kappa$ para $\sqrt\kappa$ em quadráticas). **RMSProp** e **Adam** adaptam o passo por parâmetro; o Adam corrige o viés das médias móveis. Nenhum é universalmente melhor.
- A **inicialização** de Xavier/He conserva a escala do sinal. **Dropout**, **BatchNorm**, **weight decay** (AdamW) e **parada antecipada** regularizam, e Dropout e BatchNorm exigem `train()` e `eval()` corretos.
- No **PyTorch**, `autograd` automatiza a retropropagação; o laço de treino tem a forma `zero_grad`, perda, `backward`, `step`.
:::

**Para o próximo capítulo.** As redes densas tratam as entradas como vetores sem estrutura: embaralhar os pixels de uma imagem, de modo fixo, não muda o que a rede consegue aprender. Para uma imagem de $1000\times1000$ pixels e uma camada de $1000$ neurônios, seriam $10^9$ pesos só na primeira camada. O Capítulo 7 apresenta a convolução, que usa a estrutura de grade das imagens para reduzir drasticamente os parâmetros e para detectar um padrão em qualquer posição.

