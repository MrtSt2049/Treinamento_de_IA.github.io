<div class="objetivos">

Objetivos do capítulo

- Definir o neurônio artificial, mostrar que ele generaliza a regressão logística e demonstrar o teorema de convergência do perceptron e a impossibilidade de resolver o XOR com um único neurônio.
- Explicar por que as não linearidades são indispensáveis e enunciar o que o teorema da aproximação universal garante e o que não garante.
- Comparar as funções de ativação sigmoide, tanh, ReLU, Leaky ReLU e softmax, com suas derivadas e problemas de saturação.
- Derivar as perdas MSE, entropia cruzada binária e categórica a partir da máxima verossimilhança e demonstrar que o gradiente da entropia cruzada em relação aos logits é $\mathbf{p}-\mathbf{y}$.
- Deduzir e implementar o algoritmo de retropropagação a partir da regra da cadeia.
- Comparar SGD, *momentum*, RMSProp e Adam, e justificar inicialização, Dropout, Batch Normalization e *weight decay*.
- Construir e treinar redes em NumPy e em PyTorch, com testes de correção do gradiente.

**Pré-requisitos:** Capítulos 1, 4 e 5. Em particular: gradiente e descida do gradiente (1.9 a 1.11), regressão logística (4.5), erro de generalização e regularização (Capítulo 5).

</div>

## 6.1 Do neurônio ao perceptron

O Capítulo 4 terminou com um modelo, a regressão logística, que calcula uma combinação linear das variáveis e a comprime em uma probabilidade. Esse modelo é um **neurônio artificial**. O nome vem de uma analogia biológica antiga e imprecisa: o que importa aqui é apenas a estrutura matemática, e a analogia pode ser esquecida.

::: definicao 6.1 · Neurônio artificial
Um **neurônio** com $n$ entradas é a função $\hat y = \varphi(\mathbf{w}^\top\mathbf{x}+b)$, em que $\mathbf{w}\in\mathbb{R}^n$ são os **pesos**, $b\in\mathbb{R}$ é o **viés** (*bias*) e $\varphi:\mathbb{R}\to\mathbb{R}$ é a **função de ativação**. A grandeza $z=\mathbf{w}^\top\mathbf{x}+b$ é a **pré-ativação**.
:::

A escolha de $\varphi$ define modelos já conhecidos. Com $\varphi$ igual à identidade, obtém-se a regressão linear do Capítulo 4. Com $\varphi=\sigma$, a sigmoide, obtém-se a regressão logística da seção 4.5, e o treinamento por máxima verossimilhança é exatamente o que se fará adiante. Com $\varphi$ igual a um degrau, obtém-se o modelo original de Rosenblatt.

### O perceptron

O **perceptron** (Rosenblatt, 1958) é o neurônio com ativação em degrau, $\hat y = \mathbb{1}[\mathbf{w}^\top\mathbf{x}+b>0]$, treinado por uma regra simples: examine os exemplos um a um e, a cada erro, corrija os pesos na direção do exemplo.

::: definicao 6.2 · Regra de aprendizado do perceptron
Para cada exemplo $(\mathbf{x}_i,y_i)$, com $y_i\in\{0,1\}$ e previsão $\hat y_i$, atualize
$$
\mathbf{w}\leftarrow\mathbf{w}+(y_i-\hat y_i)\,\mathbf{x}_i,\qquad b\leftarrow b+(y_i-\hat y_i).
$$
Quando a previsão está correta, $y_i-\hat y_i=0$ e nada muda. Em um erro, o termo vale $+1$ (exemplo positivo classificado como negativo: $\mathbf{w}$ se aproxima de $\mathbf{x}_i$) ou $-1$ (o inverso: $\mathbf{w}$ se afasta de $\mathbf{x}_i$).
:::

::: teorema 6.1 · Convergência do perceptron (Novikoff, 1962)
Suponha que existam $\mathbf{w}^\star$ com $\lVert\mathbf{w}^\star\rVert=1$ e $\gamma>0$ tais que, com os rótulos reescritos como $s_i = 2y_i-1\in\{-1,+1\}$ e o viés absorvido em $\mathbf{x}$ (isto é, $\mathbf{x}\leftarrow(\mathbf{x},1)$), valha $s_i\,\mathbf{w}^{\star\top}\mathbf{x}_i\ge\gamma$ para todo $i$ (separabilidade linear com margem $\gamma$). Se $\lVert\mathbf{x}_i\rVert\le R$ para todo $i$, o algoritmo do perceptron, partindo de $\mathbf{w}=\mathbf{0}$, comete **no máximo $(R/\gamma)^2$ erros** e, portanto, converge em um número finito de passos.
:::

::: demonstracao
Em um erro, a atualização é $\mathbf{w}\leftarrow\mathbf{w}+s_i\mathbf{x}_i$. Seja $\mathbf{w}_k$ o vetor após $k$ erros ($\mathbf{w}_0=\mathbf{0}$).

*Limite inferior.* $\mathbf{w}_{k}^\top\mathbf{w}^\star = \mathbf{w}_{k-1}^\top\mathbf{w}^\star+s_i\mathbf{x}_i^\top\mathbf{w}^\star\ge \mathbf{w}_{k-1}^\top\mathbf{w}^\star+\gamma$. Por indução, $\mathbf{w}_k^\top\mathbf{w}^\star\ge k\gamma$, e pela desigualdade de Cauchy–Schwarz, $\lVert\mathbf{w}_k\rVert\ge k\gamma$.

*Limite superior.* $\lVert\mathbf{w}_k\rVert^2=\lVert\mathbf{w}_{k-1}\rVert^2+2s_i\mathbf{w}_{k-1}^\top\mathbf{x}_i+\lVert\mathbf{x}_i\rVert^2$. Houve erro, de modo que $s_i\mathbf{w}_{k-1}^\top\mathbf{x}_i\le0$, e então $\lVert\mathbf{w}_k\rVert^2\le\lVert\mathbf{w}_{k-1}\rVert^2+R^2$. Logo $\lVert\mathbf{w}_k\rVert^2\le kR^2$.

Combinando, $k^2\gamma^2\le\lVert\mathbf{w}_k\rVert^2\le kR^2$, isto é, $k\le R^2/\gamma^2$.
:::

O limite não depende do número de exemplos nem da dimensão, apenas da geometria: quanto maior a margem relativa ao tamanho dos dados, menos erros. A noção de margem reaparece nas máquinas de vetores de suporte, tema que este livro não desenvolve (ver as leituras ao final do capítulo).

### O que um neurônio não consegue

O teorema vale só com separabilidade linear. O exemplo clássico em que ela falha é o **XOR** (ou exclusivo): quatro pontos, $(0,0)\mapsto0$, $(0,1)\mapsto1$, $(1,0)\mapsto1$, $(1,1)\mapsto0$.

::: proposicao 6.2 · O XOR não é linearmente separável
Nenhum $(\mathbf{w},b)$ classifica corretamente os quatro pontos do XOR com $\hat y=\mathbb{1}[w_1x_1+w_2x_2+b>0]$.
:::

::: demonstracao
Suponha que existam. As quatro classificações exigem $b\le0$ (ponto $(0,0)$), $w_2+b>0$, $w_1+b>0$ e $w_1+w_2+b\le0$. Somando as duas desigualdades do meio, $w_1+w_2+2b>0$. Subtraindo a quarta, $b>0$, o que contradiz $b\le0$.
:::

Geometricamente, os dois pontos da classe 1 estão em cantos opostos do quadrado, e nenhuma reta deixa de separar um deles do centro. O programa abaixo executa a regra do perceptron nas funções AND, OR e XOR.

<<< codigo/c6_perceptron.py

>>> codigo/c6_perceptron.out

AND e OR, linearmente separáveis, convergem em poucas épocas, como o Teorema 6.1 prevê. No XOR o algoritmo não termina: os pesos oscilam indefinidamente e, ao final de 50 épocas, apenas 2 dos 4 pontos estão corretos. Esta limitação, analisada por Minsky e Papert (1969), contribuiu para reduzir por anos o interesse pelo tema. A saída, como se verá, é empilhar neurônios.

## 6.2 Perceptrons multicamadas

### Camadas e composição

Em vez de um neurônio, tome vários em paralelo, cada um com seus próprios pesos, e use suas saídas como entradas de outros neurônios.

::: definicao 6.3 · Perceptron multicamadas (MLP)
Um **perceptron multicamadas** (MLP, *multilayer perceptron*) ou **rede neural densa** (*feedforward*) com $L$ camadas é a composição
$$
\mathbf{h}^{(0)}=\mathbf{x},\qquad
\mathbf{z}^{(l)}=\mathbf{W}^{(l)\top}\mathbf{h}^{(l-1)}+\mathbf{b}^{(l)},\qquad
\mathbf{h}^{(l)}=\varphi^{(l)}\bigl(\mathbf{z}^{(l)}\bigr),\qquad l=1,\dots,L,
$$
em que $\mathbf{W}^{(l)}\in\mathbb{R}^{n_{l-1}\times n_l}$ e $\mathbf{b}^{(l)}\in\mathbb{R}^{n_l}$ são os parâmetros da camada $l$, e $\varphi^{(l)}$ é aplicada componente a componente. As camadas $1,\dots,L-1$ são **ocultas**; a camada $L$ é a **saída**. A **largura** da camada $l$ é $n_l$ e a **profundidade** é $L$. O conjunto de todos os parâmetros é denotado $\boldsymbol\theta$.
:::

Cada camada transforma uma **representação** em outra. A camada oculta aprende, com os dados, novas variáveis (as saídas $\mathbf{h}^{(l)}$) sobre as quais a camada seguinte atua. Esta é a diferença decisiva em relação aos modelos do Módulo II, em que quem analisa os dados deve fornecer as variáveis relevantes.

O número de parâmetros de uma rede é
$$
\sum_{l=1}^{L}\bigl(n_{l-1}+1\bigr)\,n_l .
$$
Uma rede $64\text{-}64\text{-}10$ (64 entradas, uma camada oculta de 64 neurônios, 10 saídas) tem $(64+1)\cdot64+(64+1)\cdot10=4\,810$ parâmetros, número que o Projeto 3 confirmará.

### A necessidade de não linearidades

::: proposicao 6.3 · Sem não linearidade, a profundidade não acrescenta nada
Se todas as ativações são a identidade, um MLP com $L$ camadas equivale a **uma única** transformação afim de $\mathbf{x}$.
:::

::: demonstracao
Para duas camadas, $\mathbf{h}^{(2)}=\mathbf{W}^{(2)\top}(\mathbf{W}^{(1)\top}\mathbf{x}+\mathbf{b}^{(1)})+\mathbf{b}^{(2)}=(\mathbf{W}^{(1)}\mathbf{W}^{(2)})^\top\mathbf{x}+\bigl(\mathbf{W}^{(2)\top}\mathbf{b}^{(1)}+\mathbf{b}^{(2)}\bigr)$, que é afim. O caso geral segue por indução, pois a composição de funções afins é afim.
:::

Uma rede linear de cem camadas tem o poder de uma regressão linear. A não linearidade $\varphi$ é o que torna a composição mais expressiva do que cada parte. O exemplo seguinte resolve o XOR com uma rede $2\text{-}2\text{-}1$ cujos pesos foram escolhidos à mão.

<<< codigo/c6_xor_mlp.py

>>> codigo/c6_xor_mlp.out

A camada oculta transforma os quatro pontos em $(0,0)$, $(1,0)$, $(1,0)$ e $(2,1)$. Nessa nova representação os dois pontos da classe 1 coincidem em $(1,0)$, e uma reta separa o par: a camada de saída calcula $h_1-2h_2$. O problema não linear virou linear na representação aprendida. Sem a ReLU, a mesma rede colapsa em uma função afim, $2-x_1-x_2$, com as saídas $2,1,1,0$ da última linha: pela Proposição 6.3, ela não pode separar o XOR.

### Aproximação universal

Quão expressivas são as redes com não linearidade? A resposta clássica é um resultado de existência.

::: teorema 6.4 · Aproximação universal (Cybenko, 1989; Hornik, Stinchcombe e White, 1989)
Seja $\varphi$ contínua, limitada e não constante (por exemplo, a sigmoide). Para toda função contínua $f$ em um conjunto compacto $K\subset\mathbb{R}^n$ e todo $\varepsilon>0$, existem $m$, pesos $\mathbf{w}_j\in\mathbb{R}^n$ e escalares $b_j,c_j\in\mathbb{R}$ tais que
$$
\Bigl|\,f(\mathbf{x})-\sum_{j=1}^{m}c_j\,\varphi\bigl(\mathbf{w}_j^\top\mathbf{x}+b_j\bigr)\Bigr|<\varepsilon\qquad\text{para todo }\mathbf{x}\in K.
$$
Resultados análogos valem para a ReLU (Leshno et al., 1993).
:::

A demonstração usa análise funcional e não será reproduzida aqui; a ideia é que combinações de sigmoides deslocadas e escaladas formam "degraus suaves" a partir dos quais qualquer função contínua pode ser montada, como uma soma de pequenos degraus aproxima uma curva.

::: atencao O que o teorema não diz
O teorema garante que **existe** uma rede de **uma** camada oculta que aproxima $f$. Ele **não** diz:

- **quantos neurônios** são necessários: $m$ pode crescer exponencialmente com a dimensão $n$;
- que a descida do gradiente **encontrará** esses pesos: é um resultado de existência, não de aprendizado;
- que a rede **generalizará**: com dados finitos e ruído, aproximar $f$ não é o mesmo que minimizar o erro de teste (Capítulo 5).

A razão para usar redes **profundas** em vez de uma camada larga é prática e parcialmente teórica: certas funções exigem muito menos neurônios quando compostas em várias camadas. Mas a vantagem prática da profundidade vem sobretudo de a composição de camadas simples ser uma família de modelos bem adaptada aos dados naturais (imagens, texto), como os Capítulos 7 a 9 mostrarão.
:::

## 6.3 Funções de ativação

A escolha da ativação afeta a expressividade, mas principalmente o comportamento dos gradientes no treinamento. Este é o critério dominante.

::: definicao 6.4 · Principais ativações
$$
\begin{aligned}
\text{sigmoide:}\quad & \sigma(z)=\frac{1}{1+e^{-z}}, & \sigma'(z)&=\sigma(z)\bigl(1-\sigma(z)\bigr)\\
\text{tangente hiperbólica:}\quad & \tanh(z)=\frac{e^{z}-e^{-z}}{e^{z}+e^{-z}}, & \tanh'(z)&=1-\tanh^2(z)\\
\text{ReLU:}\quad & \operatorname{ReLU}(z)=\max(0,z), & \operatorname{ReLU}'(z)&=\mathbb{1}[z>0]\\
\text{Leaky ReLU:}\quad & \max(\alpha z,\,z),\ \ 0<\alpha<1, & \text{derivada}&=1\text{ se }z>0\text{, senão }\alpha
\end{aligned}
$$
A ReLU não é diferenciável em $z=0$; por convenção adota-se derivada $0$ (ou qualquer valor em $[0,1]$) nesse ponto, que tem probabilidade zero de ocorrer com pesos contínuos.
:::

<figure>
+++ fig_c6_ativ.svg
<figcaption><b>Figura 6.1.</b> Ativações (esquerda) e suas derivadas (direita). A sigmoide e a tanh saturam: a derivada tende a zero para $|z|$ grande. A ReLU não satura no lado positivo, e a Leaky ReLU também não é nula no negativo.</figcaption>
</figure>

### Saturação e dissipação do gradiente

Para $|z|$ grande, a sigmoide e a tanh são quase constantes, e a derivada é quase nula. Um neurônio **saturado** deixa de aprender, porque o gradiente que o atravessa é multiplicado por $\varphi'(z)\approx0$. O problema se agrava com a profundidade. Como a retropropagação (seção 6.5) multiplica uma derivada de ativação por camada, e $\sigma'\le1/4$, a parte do fator de atenuação do gradiente que se deve às ativações é, no máximo, $4^{-L}$.

<<< codigo/c6_ativacoes.py

>>> codigo/c6_ativacoes.out

A saída mostra o fenômeno com números: em $z=\pm10$, $\sigma'\approx5\times10^{-5}$, e vinte camadas com a derivada máxima já limitam o fator a $9\times10^{-13}$. Isso é a **dissipação do gradiente** (*vanishing gradient*), que dificultou o treinamento de redes profundas até a adoção da ReLU. A tanh é preferível à sigmoide nas camadas ocultas por ser centrada em zero e ter derivada máxima 1, mas satura do mesmo modo.

A ReLU tem derivada exatamente $1$ no lado positivo, de modo que o gradiente passa sem atenuação por neurônios ativos (Nair e Hinton, 2010). Seu custo é o problema dos **neurônios mortos**: um neurônio cuja pré-ativação é negativa para todos os exemplos tem gradiente zero e nunca se recupera. A Leaky ReLU (Maas et al., 2013) mantém uma pequena inclinação $\alpha$ no lado negativo exatamente para evitar isso. Em Transformers (Capítulo 9) aparecem variantes suaves, como a GELU, mas a lógica é a mesma.

### Softmax

Para classificação em $K$ classes, a camada de saída produz $K$ números reais, os **logits** $\mathbf{a}\in\mathbb{R}^K$, que a softmax converte em uma distribuição de probabilidade.

::: definicao 6.5 · Softmax
$$
\operatorname{softmax}(\mathbf{a})_k=\frac{e^{a_k}}{\sum_{j=1}^{K}e^{a_j}},\qquad k=1,\dots,K.
$$
:::

::: proposicao 6.5 · Propriedades da softmax
1. As componentes são positivas e somam $1$.
2. **Invariância a deslocamento:** $\operatorname{softmax}(\mathbf{a}+c\mathbf{1})=\operatorname{softmax}(\mathbf{a})$ para todo $c\in\mathbb{R}$.
3. Com $K=2$, equivale à sigmoide: $\operatorname{softmax}(a_1,a_2)_1=\sigma(a_1-a_2)$.
4. O jacobiano é $\dfrac{\partial p_k}{\partial a_j}=p_k(\delta_{kj}-p_j)$, isto é, $\operatorname{diag}(\mathbf{p})-\mathbf{p}\mathbf{p}^\top$.
:::

::: demonstracao
(1) é imediata. (2): o fator $e^{c}$ aparece no numerador e em todos os termos do denominador e se cancela. (3): $e^{a_1}/(e^{a_1}+e^{a_2})=1/(1+e^{-(a_1-a_2)})$. (4): para $k=j$, $\partial p_k/\partial a_k=\bigl(e^{a_k}S-e^{2a_k}\bigr)/S^2=p_k(1-p_k)$, com $S=\sum_je^{a_j}$; para $k\ne j$, $\partial p_k/\partial a_j=-e^{a_k}e^{a_j}/S^2=-p_kp_j$.
:::

A propriedade (2) não é só elegante: é a base da implementação estável. Calcular $e^{a_k}$ diretamente transborda para logits grandes. Subtraindo $\max_k a_k$ antes de exponenciar, o maior expoente vira zero e nada transborda, sem alterar o resultado. O mesmo programa mostra: com logits $[1000,1001,1002]$, a versão ingênua devolve `nan`, e a versão deslocada devolve as mesmas probabilidades que $[0,1,2]$.

::: nota Qual ativação na saída?
A ativação da última camada é determinada pela tarefa, não por conveniência de treinamento: **identidade** para regressão (resposta em $\mathbb{R}$); **sigmoide** para classificação binária (saída em $(0,1)$); **softmax** para classificação com $K>2$ classes mutuamente exclusivas. Nas camadas ocultas, a ReLU (ou variante) é o ponto de partida habitual.
:::

## 6.4 Funções de custo

O treinamento escolhe $\boldsymbol\theta$ minimizando uma **função de custo** (*loss*), que mede a discrepância entre a saída da rede e o alvo. No Capítulo 3, a perda era uma escolha do analista; aqui ela tem uma justificativa probabilística: é a **verossimilhança negativa** de um modelo de ruído.

::: teorema 6.6 · Perdas como máxima verossimilhança
Seja $f_{\boldsymbol\theta}(\mathbf{x})$ a saída da rede. Maximizar a verossimilhança dos dados independentes $\{(\mathbf{x}_i,y_i)\}$ equivale a minimizar a perda média abaixo, em cada modelo para $y\mid\mathbf{x}$:

| Modelo para $y\mid\mathbf{x}$ | Perda (média nos $n$ exemplos) |
|---|---|
| $\mathcal{N}\bigl(f_{\boldsymbol\theta}(\mathbf{x}),\sigma^2\bigr)$, $\sigma$ fixo | **MSE:** $\dfrac1n\sum_i\bigl(y_i-f_{\boldsymbol\theta}(\mathbf{x}_i)\bigr)^2$ |
| Bernoulli com $P(y=1\mid\mathbf{x})=f_{\boldsymbol\theta}(\mathbf{x})$ | **Entropia cruzada binária:** $-\dfrac1n\sum_i\bigl[y_i\ln f_i+(1-y_i)\ln(1-f_i)\bigr]$ |
| Categórica com $P(y=k\mid\mathbf{x})=f_{\boldsymbol\theta}(\mathbf{x})_k$ | **Entropia cruzada categórica:** $-\dfrac1n\sum_i\ln f_{\boldsymbol\theta}(\mathbf{x}_i)_{y_i}$ |
:::

::: demonstracao
A log-verossimilhança de dados independentes é a soma das log-densidades. No caso gaussiano, $\ln p(y_i\mid\mathbf{x}_i)=-\frac{1}{2\sigma^2}(y_i-f_i)^2-\ln(\sigma\sqrt{2\pi})$; maximizar a soma equivale a minimizar $\sum(y_i-f_i)^2$, pois o segundo termo não depende de $\boldsymbol\theta$ (é o argumento da seção 1.13). No caso de Bernoulli, $p(y_i\mid\mathbf{x}_i)=f_i^{y_i}(1-f_i)^{1-y_i}$, e o logaritmo negativo é o termo da tabela. No caso categórico, $p(y_i\mid\mathbf{x}_i)=f_{i,y_i}$, e o logaritmo negativo é o termo da tabela.
:::

A entropia cruzada recebe esse nome por ser a entropia cruzada entre a distribuição empírica dos rótulos (que atribui probabilidade $1$ à classe correta) e a distribuição prevista pela rede. Para uma rede sem informação, que atribui probabilidade $1/K$ a cada classe, a perda vale $\ln K$: $0{,}693$ com duas classes, $2{,}303$ com dez. Este número serve de **teste de sanidade**: a perda inicial de uma rede bem inicializada deve estar próxima dele (o Projeto 3 usa esse teste).

### O gradiente da entropia cruzada

O resultado que mais simplifica o treinamento é o seguinte.

::: teorema 6.7 · Gradiente da entropia cruzada em relação aos logits
Seja $\mathbf{p}=\operatorname{softmax}(\mathbf{a})$ e $\mathcal{L}=-\ln p_k$, em que $k$ é a classe correta, com $\mathbf{y}=\mathbf{e}_k$ (vetor *one-hot*). Então
$$
\frac{\partial\mathcal{L}}{\partial\mathbf{a}}=\mathbf{p}-\mathbf{y}.
$$
O mesmo vale para a sigmoide com entropia cruzada binária: $\partial\mathcal{L}/\partial a=\sigma(a)-y$.
:::

::: demonstracao
$\mathcal{L}=-a_k+\ln\sum_je^{a_j}$. Então $\partial\mathcal{L}/\partial a_m=-\delta_{km}+e^{a_m}/\sum_je^{a_j}=p_m-y_m$. No caso binário, $\mathcal{L}=-y\ln\sigma(a)-(1-y)\ln(1-\sigma(a))$, e, usando $\sigma'=\sigma(1-\sigma)$, $\partial\mathcal{L}/\partial a=-y(1-\sigma)+(1-y)\sigma=\sigma-y$.
:::

O gradiente é o **erro de previsão**: probabilidade prevista menos probabilidade alvo. Ele é limitado em módulo e é grande exatamente quando a rede erra muito. O programa confere o resultado numericamente com diferenças finitas, e também mostra a forma estável da perda.

<<< codigo/c6_softmax_ce.py

>>> codigo/c6_softmax_ce.out

O gradiente analítico e o numérico concordam em todas as casas exibidas (erro relativo de $7\times10^{-11}$). A segunda parte mostra por que as bibliotecas implementam softmax e entropia cruzada **juntas**: com logits $[-1000,0,1000]$, calcular $\ln(\operatorname{softmax})$ passo a passo dá infinito, enquanto a forma $-a_k+\max_j a_j+\ln\sum_je^{a_j-\max a}$ ("log-soma-exp") dá o valor correto, $2000$. Por isso o `CrossEntropyLoss` do PyTorch **recebe logits**, não probabilidades.

### Por que não MSE para classificação

Seria possível treinar um classificador com MSE sobre a saída da sigmoide. Mas o gradiente em relação ao logit passa a ter o fator $\sigma'(a)$:
$$
\frac{\partial}{\partial a}\tfrac12\bigl(\sigma(a)-y\bigr)^2=\bigl(\sigma(a)-y\bigr)\,\sigma(a)\bigl(1-\sigma(a)\bigr).
$$
Quando a rede está **muito errada**, a sigmoide está saturada e esse fator se anula: a rede erra e quase não aprende.

<<< codigo/c6_perdas.py

>>> codigo/c6_perdas.out

Com a classe real $y=1$ e logit $a=-10$ (a rede tem certeza de que é a classe $0$), o gradiente da entropia cruzada tem módulo próximo de $1$, e o do MSE é $4{,}5\times10^{-5}$, mais de vinte mil vezes menor. A entropia cruzada, ao cancelar o fator $\sigma'$, mantém o sinal de aprendizado onde ele é mais necessário. É por isso, e não por convenção, que classificação usa entropia cruzada.

