## 7.5 Arquiteturas convolucionais

Uma CNN típica alterna **blocos** de convoluções (com ReLU, às vezes com BatchNorm) e *pooling*, reduzindo a resolução e aumentando o número de canais, e termina em uma ou mais camadas densas que produzem as classes. A ideia é construir uma **hierarquia de representações**: as primeiras camadas detectam bordas, as seguintes combinam bordas em texturas e partes, e as últimas combinam partes em objetos.

### LeNet-5 (1998)

A LeNet-5 (LeCun et al., 1998), criada para reconhecer dígitos manuscritos em cheques, tem a forma que se tornou o modelo das CNNs: duas convoluções com *pooling* e três camadas densas. O programa da seção 7.1 reproduz uma versão simplificada e mostra o formato do tensor em cada etapa: de $1\times32\times32$ a $6\times28\times28$ (seis filtros $5\times5$), $6\times14\times14$ após o *pooling*, $16\times10\times10$, $16\times5\times5$, e então $400\to120\to84\to10$. O total é de $61\,706$ parâmetros, dos quais $48\,120$ estão na primeira camada densa: o bloco convolucional é pequeno, e a maior parte dos parâmetros está na parte densa. (O artigo original usa conexões parciais entre mapas e tem cerca de $60$ mil parâmetros; a versão do programa é a variante moderna, com conexão completa.)

### AlexNet (2012)

A AlexNet (Krizhevsky et al., 2012) venceu a competição ImageNet de 2012 por uma margem grande: segundo o artigo, erro dos cinco melhores palpites de $15{,}3\%$, contra $26{,}2\%$ do segundo colocado. É considerada o marco do aprendizado profundo moderno em visão. Combinou, em uma rede com cerca de $60$ milhões de parâmetros, ingredientes que se tornaram padrão: **ReLU** no lugar de sigmoide e tanh (treino mais rápido), **Dropout** nas camadas densas, **aumento de dados** e treinamento em **GPUs**. O sucesso se deveu menos a uma ideia nova do que à combinação de uma arquitetura profunda, de uma base grande (cerca de $1{,}2$ milhão de imagens) e de poder computacional.

### VGG (2014): filtros pequenos e profundidade

A VGG (Simonyan e Zisserman, 2015) mostrou que é preferível empilhar filtros pequenos $3\times3$ a usar filtros grandes. A razão é contabilizada abaixo.

::: exemplo 7.1 · Duas convoluções $3\times3$ contra uma $5\times5$
Duas camadas $3\times3$ seguidas têm campo receptivo $3+2=5$ (Proposição 7.3), o mesmo de uma única camada $5\times5$. Com $C$ canais na entrada e na saída (e ignorando os vieses), a pilha tem $2\cdot9C^2=18C^2$ parâmetros e a camada única, $25C^2$: a pilha usa $72\%$ dos parâmetros. Além disso, a pilha tem uma ReLU intermediária e, portanto, é uma função mais expressiva. Três camadas $3\times3$ têm campo $7$ com $27C^2$ parâmetros, contra $49C^2$ de uma $7\times7$ ($55\%$).
:::

A VGG usa blocos de duas a quatro convoluções $3\times3$ seguidos de *max pooling*, com $16$ ou $19$ camadas treináveis. É simples e eficaz, mas tem muitos parâmetros (a maior parte nas camadas densas finais) e é computacionalmente pesada.

### ResNet (2016): conexões residuais

Ao aumentar a profundidade de uma CNN, esperava-se melhora; observou-se, porém, que redes mais profundas tinham **erro de treinamento maior** do que as mais rasas. Não era superajuste (que reduziria o erro de treino): era dificuldade de **otimização**, o **problema da degradação**. A solução da ResNet (He et al., 2016) é simples.

::: definicao 7.4 · Bloco residual
Um **bloco residual** calcula
$$
\mathbf{y}=\operatorname{ReLU}\bigl(\mathbf{x}+F(\mathbf{x})\bigr),
$$
em que $F$ é uma pequena subrede (por exemplo, convolução, BatchNorm, ReLU, convolução, BatchNorm). A parcela $\mathbf{x}$ é a **conexão de atalho** (*skip connection*), que leva a entrada, sem alteração, à saída. Quando as dimensões diferem, o atalho usa uma convolução $1\times1$ para ajustá-las.
:::

<figure>
+++ fig_c7_residual.svg
<figcaption><b>Figura 7.3.</b> Bloco residual. A rede aprende o <i>resíduo</i> $F(\mathbf{x})$ que se soma à entrada, em vez de aprender a transformação completa.</figcaption>
</figure>

Duas intuições. Primeiro, o bloco facilita **aprender a identidade**: basta que $F\approx0$, o que se obtém com pesos pequenos. Uma rede mais profunda pode, portanto, reproduzir pelo menos o que uma mais rasa faz. Segundo, e mais importante para o treinamento, o atalho abre um **caminho direto para o gradiente**.

::: teorema 7.5 · O gradiente atravessa blocos residuais
Considere $L$ blocos residuais sucessivos $\mathbf{x}_{i}=\mathbf{x}_{i-1}+F_i(\mathbf{x}_{i-1})$ (ignorando a ReLU final para simplificar). Seja $\mathbf{J}_i=\partial F_i/\partial\mathbf{x}_{i-1}$. Então
$$
\frac{\partial\mathbf{x}_L}{\partial\mathbf{x}_0}=\prod_{i=L}^{1}\bigl(\mathbf{I}+\mathbf{J}_i\bigr)=\mathbf{I}+\sum_{i}\mathbf{J}_i+\sum_{i<j}\mathbf{J}_j\mathbf{J}_i+\cdots
$$
O desenvolvimento contém o termo $\mathbf{I}$, **independente da profundidade e dos pesos**: o gradiente que chega à entrada inclui sempre uma cópia do gradiente da saída. Em uma rede sem atalhos, $\partial\mathbf{x}_L/\partial\mathbf{x}_0=\prod_i\mathbf{J}_i$, que não tem esse termo.
:::

::: demonstracao
Pela regra da cadeia, $\partial\mathbf{x}_i/\partial\mathbf{x}_{i-1}=\mathbf{I}+\mathbf{J}_i$, e o jacobiano da composição é o produto dos jacobianos, na ordem. O desenvolvimento do produto de $L$ somas é a soma de todos os produtos que escolhem, em cada fator, $\mathbf{I}$ ou $\mathbf{J}_i$; o termo em que se escolhe $\mathbf{I}$ em todos os fatores é $\mathbf{I}$.
:::

Esta é a mesma estrutura de produto de matrizes da dissipação do gradiente (seção 6.5), com uma diferença: o produto de $\mathbf{J}_i$ pode decair exponencialmente, mas o de $(\mathbf{I}+\mathbf{J}_i)$ tem a identidade como parcela. O programa mede o efeito em uma rede com $30$ camadas convolucionais, com e sem atalhos, na inicialização padrão do PyTorch.

<<< codigo/c7_residual.py

>>> codigo/c7_residual.out

Sem atalhos, a razão entre o gradiente do primeiro e o do último dos $15$ blocos é de $1{,}5\times10^{-11}$: o primeiro bloco praticamente não recebe sinal de aprendizado. Com atalhos, as normas são de mesma ordem em todos os blocos (razão $0{,}18$). É um instantâneo em uma inicialização, não uma curva de treinamento; ele mostra o mecanismo, não o desempenho final. A ResNet, com conexões residuais e BatchNorm, permitiu treinar redes com mais de cem camadas e venceu a competição ImageNet de 2015.

### A estrutura da ResNet-18

O programa abaixo cria a ResNet-18 do `torchvision` **com pesos aleatórios** (os pesos pré-treinados exigem download, que não foi possível neste ambiente) e inspeciona sua estrutura: o formato do tensor após cada estágio, a contagem de parâmetros e a adaptação para uma nova tarefa.

<<< codigo/c7_resnet18.py

>>> codigo/c7_resnet18.out

A rede começa com uma convolução $7\times7$ de *stride* $2$ e um *max pooling* (a resolução cai de $224$ para $56$), e tem quatro estágios de blocos residuais, cada um dobrando o número de canais ($64,128,256,512$) e reduzindo a resolução à metade ($56,28,14,7$). O último estágio concentra $8{,}4$ dos $11{,}7$ milhões de parâmetros, o que é típico: as camadas profundas têm mais canais e, por isso, mais pesos. Depois de um *pooling* global médio que reduz $512\times7\times7$ a $512$ valores, a camada final classifica. Ao trocar a camada final por uma de $10$ classes e congelar o resto, o número de parâmetros treináveis cai de $11{,}2$ milhões para $5\,130$ ($512\cdot10+10$).

## 7.6 Aumento de dados

Redes com milhões de parâmetros superajustam facilmente. O **aumento de dados** (*data augmentation*) é uma regularização que injeta conhecimento do domínio: aplica-se aos exemplos de treino **transformações que não alteram o rótulo**, de modo que cada época vê versões ligeiramente diferentes de cada imagem. Em imagens, as transformações usuais são deslocamentos e recortes aleatórios, espelhamento horizontal, rotações pequenas, mudanças de brilho, contraste e cor, e ruído. Três cuidados.

- **A transformação deve preservar o rótulo.** O espelhamento horizontal é inofensivo para fotos de gatos, mas inadequado para dígitos (um $2$ espelhado não é um $2$) e para texto.
- **Aplica-se apenas ao treino.** As imagens de validação e de teste são usadas como estão; caso contrário a estimativa de erro perde o sentido.
- **Cada transformação codifica uma invariância desejada.** O aumento por deslocamentos ensina a rede a ser invariante a deslocamentos; é o recurso que o Projeto 5 usa para obter a invariância que o *pooling* sozinho não dá. A biblioteca `torchvision.transforms` oferece as transformações mais comuns.

Em termos estatísticos (seção 5.2), o aumento de dados atua sobretudo reduzindo a variância do estimador, **desde que** as transformações realmente preservem o rótulo. Se não preservam, introduzem viés: é o custo de usar uma transformação inadequada. Como todo viés indutivo, ele tem um preço, que o Projeto 5 também mede.

## 7.7 Transferência de aprendizado

Treinar uma CNN grande do zero exige muitos dados rotulados e muito poder computacional. A **transferência de aprendizado** (*transfer learning*) reaproveita o que uma rede aprendeu em uma **tarefa de origem**, com muitos dados, para uma **tarefa alvo**, com poucos.

### Por que as características se transferem

Em CNNs treinadas em fotografias, as primeiras camadas aprendem filtros de bordas e de cores, que são úteis em praticamente qualquer imagem natural; as camadas finais são específicas das classes de origem. Yosinski et al. (2014) quantificaram esse gradiente de generalidade: as camadas iniciais transferem-se bem, e as finais, tanto menos quanto mais distantes forem as tarefas. Daí as duas estratégias usuais.

::: definicao 7.5 · Extração de características e ajuste fino
**Extração de características** (*feature extraction*): congela-se o corpo da rede pré-treinada (os pesos não mudam) e treina-se apenas uma **nova cabeça** de classificação sobre as características que ele produz. **Ajuste fino** (*fine-tuning*): inicializa-se toda a rede com os pesos pré-treinados, troca-se a cabeça e treina-se **tudo** (ou as camadas finais), com taxa de aprendizado pequena, para não destruir o que foi aprendido.
:::

Orientações usuais: com **poucos** dados alvo e tarefa semelhante, extração de características (poucos parâmetros livres, baixo risco de superajuste); com **mais** dados, ajuste fino. Há cuidados práticos: ao congelar camadas com BatchNorm, deve-se colocá-las em modo `eval()` (senão as estatísticas acumuladas continuam mudando); as imagens devem receber o **mesmo pré-processamento** usado no pré-treino (redimensionamento e normalização por média e desvio por canal, como no programa da seção anterior); e a taxa de aprendizado do ajuste fino é, em geral, menor que a do treino do zero.

O trecho a seguir é a receita usual com a ResNet-18. **Não foi executado neste ambiente**, porque `weights=ResNet18_Weights.DEFAULT` baixa os pesos da internet; a estrutura do modelo, o ajuste da cabeça e o pré-processamento foram verificados com o programa anterior, com pesos aleatórios.

```python
import torch
from torch import nn
from torchvision.models import ResNet18_Weights, resnet18

pesos = ResNet18_Weights.DEFAULT
modelo = resnet18(weights=pesos)               # baixa os pesos pré-treinados (exige internet)
preprocessar = pesos.transforms()              # redimensiona para 256, recorta 224 e normaliza

# --- extração de características: congela o corpo e treina só a nova cabeça ---
for p in modelo.parameters():
    p.requires_grad_(False)
modelo.fc = nn.Linear(modelo.fc.in_features, 10)     # nova cabeça, treinável por padrão
modelo.eval()                                         # BatchNorm do corpo em modo de avaliação
modelo.fc.train()
otimizador = torch.optim.AdamW(modelo.fc.parameters(), lr=1e-3)

# --- ajuste fino: descongela tudo e usa taxa menor (e BatchNorm em modo de treino) ---
for p in modelo.parameters():
    p.requires_grad_(True)
modelo.train()
otimizador = torch.optim.AdamW(modelo.parameters(), lr=1e-4)
```

Duas ressalvas sobre este material. Primeiro, o benefício da transferência depende da **semelhança entre as tarefas** e do **tamanho** do conjunto alvo; quando as tarefas são muito diferentes, a transferência pode não ajudar e até prejudicar (*transferência negativa*). Segundo, é uma hipótese a ser **testada**, e não um resultado garantido: o Projeto 5 mostra um caso em que ela, medida com cuidado, não traz ganho sobre o treino do zero.

