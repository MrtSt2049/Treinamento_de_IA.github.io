<div class="objetivos">

Objetivos do capítulo

- Representar dados e parâmetros como vetores, matrizes e tensores, e operar com eles conferindo dimensões.
- Usar produto escalar, normas, determinantes e autovalores com suas interpretações geométricas.
- Calcular gradientes e Hessianas e explicar por que a descida do gradiente funciona, e quando falha.
- Manipular variáveis aleatórias, probabilidade condicional, esperança, variância e covariância.
- Implementar tudo isso em NumPy e reconhecer onde cada ferramenta reaparece nos capítulos seguintes.

**Pré-requisitos:** matemática de ensino médio e noções básicas de Python.

</div>

## 1.1 Por que começar pela matemática

Considere um problema concreto: prever o preço de um imóvel a partir da área, do número de quartos e da idade da construção. Qualquer solução por aprendizado de máquina terá quatro ingredientes.

1. **Uma representação dos dados.** Cada imóvel vira uma lista de números; o conjunto de imóveis vira uma tabela de números.
2. **Um modelo.** Uma função que recebe os números de um imóvel e devolve um preço, e que depende de parâmetros ajustáveis.
3. **Um critério.** Um número que mede quanto o modelo erra nos dados conhecidos.
4. **Um procedimento de ajuste.** Uma forma de alterar os parâmetros para reduzir o erro.

Cada ingrediente pertence a uma área da matemática. A representação e o modelo são objetos da **álgebra linear**. O procedimento de ajuste é um problema de **cálculo e otimização**. O critério, e a pergunta mais importante de todas (o modelo funcionará em imóveis que nunca viu?), pertencem à **probabilidade e à estatística**.

Essa divisão não vale só para imóveis. Um modelo de linguagem com bilhões de parâmetros tem exatamente os mesmos quatro ingredientes. O que muda é o tamanho das matrizes e a forma da função. Por isso este capítulo é o mais longo do módulo: tudo o que vem depois é construído com as peças apresentadas aqui.

O capítulo tem três partes. As seções 1.2 a 1.7 tratam de álgebra linear; as seções 1.8 a 1.11, de cálculo e otimização; as seções 1.12 a 1.14, de probabilidade. A seção 1.15 liga cada conceito aos algoritmos modernos, e o Projeto 1 reúne as três partes em um programa.

## 1.2 Escalares, vetores, matrizes e tensores

### Motivação

Computadores processam números. Uma imagem, uma frase ou o histórico de um cliente só podem entrar em um modelo depois de convertidos em arranjos numéricos. Os quatro objetos desta seção são os formatos desses arranjos, organizados pelo número de índices necessários para localizar um elemento.

::: definicao 1.1 · Escalar, vetor, matriz e tensor
Um **escalar** é um único número real, $a \in \mathbb{R}$.

Um **vetor** é uma lista ordenada de $n$ números reais, $\mathbf{x} \in \mathbb{R}^n$. Seus elementos são localizados por um índice: $x_i$, com $i = 1, \dots, n$. Por convenção, vetores são colunas:

$$
\mathbf{x} = \begin{bmatrix} x_1 \\ x_2 \\ \vdots \\ x_n \end{bmatrix}.
$$

Uma **matriz** é um arranjo retangular com $m$ linhas e $n$ colunas, $\mathbf{A} \in \mathbb{R}^{m \times n}$. Seus elementos são localizados por dois índices: $A_{ij}$ é o elemento da linha $i$ e da coluna $j$.

Um **tensor**, no uso corrente em aprendizado de máquina, é um arranjo cujos elementos são localizados por $k$ índices. O número $k$ é a **ordem** do tensor (em NumPy e PyTorch, o número de eixos, `ndim`). Escalares, vetores e matrizes são tensores de ordem 0, 1 e 2.
:::

A lista de tamanhos de cada eixo é a **forma** (*shape*) do arranjo. Um lote de 32 imagens coloridas de $224 \times 224$ pixels é um tensor de ordem 4 e forma $(32, 3, 224, 224)$ na convenção do PyTorch: lote, canais, altura e largura.

::: atencao Dois sentidos de "tensor" e de "dimensão"
Em matemática e física, tensor é um objeto multilinear definido por como suas componentes se transformam em mudanças de base. Em aprendizado de máquina, a palavra significa apenas arranjo multidimensional. Este livro usa o segundo sentido.

A palavra dimensão também é ambígua. Um vetor de $\mathbb{R}^{768}$ tem dimensão 768 como elemento de um espaço vetorial, mas é um arranjo de ordem 1. Para evitar confusão, o livro diz **ordem** para o número de eixos e **dimensão** para o tamanho de um eixo ou de um espaço.
:::

### Interpretações de um vetor

Um mesmo vetor admite três leituras, e a habilidade de alternar entre elas é o que torna a álgebra linear útil.

- **Como dado:** uma linha de uma tabela. O imóvel com 120 m², 3 quartos e 15 anos é $\mathbf{x} = (120, 3, 15)^\top$.
- **Como ponto:** uma posição em um espaço com $n$ eixos. Imóveis parecidos são pontos próximos.
- **Como seta:** um deslocamento com direção e comprimento. A diferença $\mathbf{x} - \mathbf{y}$ é o deslocamento que leva de $\mathbf{y}$ a $\mathbf{x}$.

A leitura geométrica continua válida quando $n$ é grande demais para desenhar. Os *embeddings* do Capítulo 12 são pontos em espaços com centenas ou milhares de dimensões, e a noção de proximidade entre eles é a mesma do plano.

### Implementação

<<< codigo/c1_tensores.py

>>> codigo/c1_tensores.out

Três observações sobre o programa. Primeiro, o NumPy não distingue vetor-linha de vetor-coluna em arranjos de ordem 1: a forma `(3,)` tem um único eixo. Segundo, o operador `@` é o produto matricial, definido na próxima seção; o operador `*` multiplica elemento a elemento. Terceiro, a soma `matriz + vetor` entre formas diferentes funciona por **difusão** (*broadcasting*): o NumPy alinha as formas pela direita e repete o arranjo menor ao longo dos eixos que faltam. A difusão é uma convenção de implementação, e não uma operação da álgebra linear; a expressão matemática correspondente seria $\mathbf{A} + \mathbf{1}\mathbf{x}^\top$, em que $\mathbf{1}$ é um vetor de uns.

::: erro Confiar na difusão sem conferir a forma
Somar um arranjo de forma `(n,)` a outro de forma `(n, 1)` não produz erro: produz uma matriz `(n, n)`. Esse é um dos defeitos mais comuns em código de aprendizado de máquina, porque o programa continua rodando e a perda simplesmente não diminui como deveria. Confira `shape` depois de cada operação até que o hábito se instale.
:::

## 1.3 Operações matriciais

### Soma, multiplicação por escalar e transposição

Matrizes de mesma forma somam-se elemento a elemento, $(\mathbf{A}+\mathbf{B})_{ij} = A_{ij} + B_{ij}$, e a multiplicação por um escalar atua em cada elemento, $(\alpha \mathbf{A})_{ij} = \alpha A_{ij}$. A **transposta** troca linhas por colunas: $(\mathbf{A}^\top)_{ij} = A_{ji}$. Se $\mathbf{A} \in \mathbb{R}^{m\times n}$, então $\mathbf{A}^\top \in \mathbb{R}^{n \times m}$. Uma matriz quadrada é **simétrica** quando $\mathbf{A}^\top = \mathbf{A}$.

### Produto matriz-vetor: duas leituras

::: definicao 1.2 · Produto matriz-vetor
Para $\mathbf{A} \in \mathbb{R}^{m \times n}$ e $\mathbf{x} \in \mathbb{R}^n$, o produto $\mathbf{A}\mathbf{x} \in \mathbb{R}^m$ tem componentes

$$
(\mathbf{A}\mathbf{x})_i = \sum_{j=1}^{n} A_{ij}\, x_j, \qquad i = 1, \dots, m.
$$
:::

A fórmula admite duas leituras equivalentes.

**Leitura por linhas.** A componente $i$ do resultado combina a linha $i$ de $\mathbf{A}$ com $\mathbf{x}$. Se as linhas de $\mathbf{A}$ são os pesos de $m$ neurônios, $\mathbf{A}\mathbf{x}$ calcula as $m$ somas ponderadas de uma só vez.

**Leitura por colunas.** Chamando de $\mathbf{a}_1, \dots, \mathbf{a}_n$ as colunas de $\mathbf{A}$,

$$
\mathbf{A}\mathbf{x} = x_1 \mathbf{a}_1 + x_2 \mathbf{a}_2 + \dots + x_n \mathbf{a}_n .
$$

O resultado é uma **combinação linear** das colunas, com os elementos de $\mathbf{x}$ como coeficientes. O conjunto de todos os vetores que podem ser escritos assim é o **espaço coluna** de $\mathbf{A}$. Essa leitura será decisiva no Capítulo 4: ajustar uma regressão linear é encontrar a combinação das colunas de $\mathbf{X}$ mais próxima de $\mathbf{y}$.

Uma matriz é, portanto, uma **função**: a aplicação $\mathbf{x} \mapsto \mathbf{A}\mathbf{x}$ leva vetores de $\mathbb{R}^n$ a vetores de $\mathbb{R}^m$. Essa função é **linear**, isto é, satisfaz $\mathbf{A}(\alpha\mathbf{x} + \beta\mathbf{y}) = \alpha \mathbf{A}\mathbf{x} + \beta \mathbf{A}\mathbf{y}$. Vale também a recíproca: toda função linear entre esses espaços é dada por uma matriz.

### Produto matricial

::: definicao 1.3 · Produto matricial
Para $\mathbf{A} \in \mathbb{R}^{m \times n}$ e $\mathbf{B} \in \mathbb{R}^{n \times p}$, o produto $\mathbf{C} = \mathbf{A}\mathbf{B} \in \mathbb{R}^{m \times p}$ é definido por

$$
C_{ij} = \sum_{k=1}^{n} A_{ik}\, B_{kj}.
$$

O produto só existe quando o número de colunas de $\mathbf{A}$ é igual ao número de linhas de $\mathbf{B}$.
:::

A definição parece arbitrária, mas ela é a única que faz o produto de matrizes corresponder à **composição** das funções lineares: aplicar $\mathbf{B}$ e depois $\mathbf{A}$ a um vetor equivale a aplicar $\mathbf{A}\mathbf{B}$, pois $\mathbf{A}(\mathbf{B}\mathbf{x}) = (\mathbf{A}\mathbf{B})\mathbf{x}$.

A regra das formas é um verificador de erros gratuito. Escreva as formas lado a lado: $(m \times n)(n \times p) \to (m \times p)$. Os números internos devem coincidir e desaparecem; os externos permanecem.

::: exemplo 1.1 · Produto matricial com conferência de formas
Sejam

$$
\mathbf{A} = \begin{bmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \end{bmatrix} \in \mathbb{R}^{2\times 3},
\qquad
\mathbf{A}^\top = \begin{bmatrix} 1 & 4 \\ 2 & 5 \\ 3 & 6 \end{bmatrix} \in \mathbb{R}^{3\times 2}.
$$

O produto $\mathbf{A}\mathbf{A}^\top$ tem forma $(2\times 3)(3 \times 2) \to (2 \times 2)$:

$$
\mathbf{A}\mathbf{A}^\top =
\begin{bmatrix}
1\cdot1 + 2\cdot 2 + 3 \cdot 3 & 1\cdot 4 + 2\cdot 5 + 3\cdot 6\\
4\cdot1 + 5\cdot 2 + 6 \cdot 3 & 4\cdot 4 + 5\cdot 5 + 6\cdot 6
\end{bmatrix}
=
\begin{bmatrix} 14 & 32 \\ 32 & 77 \end{bmatrix}.
$$

O resultado coincide com a saída do programa da seção 1.2 e é simétrico. Isso não é coincidência: $(\mathbf{A}\mathbf{A}^\top)^\top = \mathbf{A}\mathbf{A}^\top$ para qualquer $\mathbf{A}$. Já $\mathbf{A}^\top\mathbf{A}$ tem forma $3 \times 3$: os dois produtos existem e nem sequer têm o mesmo tamanho.
:::

### Propriedades

Para matrizes de formas compatíveis:

- **Associatividade:** $(\mathbf{A}\mathbf{B})\mathbf{C} = \mathbf{A}(\mathbf{B}\mathbf{C})$.
- **Distributividade:** $\mathbf{A}(\mathbf{B}+\mathbf{C}) = \mathbf{A}\mathbf{B} + \mathbf{A}\mathbf{C}$.
- **Transposta do produto:** $(\mathbf{A}\mathbf{B})^\top = \mathbf{B}^\top \mathbf{A}^\top$, com a ordem invertida.
- **Não comutatividade:** em geral, $\mathbf{A}\mathbf{B} \neq \mathbf{B}\mathbf{A}$.

A não comutatividade tem leitura geométrica direta: girar e depois esticar um objeto ao longo de um eixo produz resultado diferente de esticar e depois girar.

### Identidade e inversa

A **matriz identidade** $\mathbf{I}_n$ tem uns na diagonal e zeros fora dela; ela representa a função que não altera o vetor: $\mathbf{I}\mathbf{x} = \mathbf{x}$.

::: definicao 1.4 · Matriz inversa
Uma matriz quadrada $\mathbf{A} \in \mathbb{R}^{n \times n}$ é **invertível** se existe $\mathbf{A}^{-1}$ tal que $\mathbf{A}^{-1}\mathbf{A} = \mathbf{A}\mathbf{A}^{-1} = \mathbf{I}_n$. Quando existe, a inversa é única.
:::

A inversa desfaz a transformação. Se $\mathbf{A}\mathbf{x} = \mathbf{b}$ e $\mathbf{A}$ é invertível, então $\mathbf{x} = \mathbf{A}^{-1}\mathbf{b}$. Nem toda matriz quadrada é invertível: se a transformação achata o espaço (por exemplo, leva o plano inteiro sobre uma reta), informação é perdida e não há como voltar. As seções 1.5 e 1.6 fornecem dois testes para isso.

Uma matriz $\mathbf{Q}$ quadrada é **ortogonal** quando $\mathbf{Q}^\top \mathbf{Q} = \mathbf{I}$, ou seja, quando sua inversa é sua transposta. Suas colunas têm comprimento 1 e são perpendiculares entre si. Matrizes ortogonais representam rotações e reflexões: preservam comprimentos e ângulos.

### Posto

::: definicao 1.5 · Posto
O **posto** (*rank*) de $\mathbf{A} \in \mathbb{R}^{m\times n}$ é a dimensão do seu espaço coluna: o maior número de colunas linearmente independentes. Vale sempre $\operatorname{posto}(\mathbf{A}) \le \min(m, n)$, e o posto das linhas é igual ao posto das colunas.
:::

Uma matriz de posto $r$ pequeno pode ser escrita como produto $\mathbf{B}\mathbf{C}$, com $\mathbf{B} \in \mathbb{R}^{m \times r}$ e $\mathbf{C} \in \mathbb{R}^{r \times n}$. Em vez de $mn$ números, bastam $r(m+n)$.

::: aplicacao Baixo posto e LoRA
A técnica LoRA (*Low-Rank Adaptation*), estudada no Capítulo 10, adapta um modelo de linguagem sem alterar a matriz de pesos original $\mathbf{W} \in \mathbb{R}^{m \times n}$. Ela treina apenas uma correção de baixo posto, $\Delta\mathbf{W} = \mathbf{B}\mathbf{C}$. Para $m = n = 4096$ e $r = 8$, são $65\,536$ parâmetros treináveis no lugar de cerca de $16{,}8$ milhões. A economia é consequência direta da definição de posto.
:::

## 1.4 Produto escalar e normas

### Motivação

Para dizer que dois imóveis são parecidos, que um erro é pequeno ou que dois textos tratam do mesmo assunto, é preciso medir comprimentos, distâncias e ângulos entre vetores. O produto escalar e as normas são os instrumentos dessa medição.

### Produto escalar

::: definicao 1.6 · Produto escalar
O **produto escalar** (*dot product*) de $\mathbf{u}, \mathbf{v} \in \mathbb{R}^n$ é o número

$$
\mathbf{u}^\top \mathbf{v} = \sum_{i=1}^{n} u_i\, v_i .
$$
:::

O produto escalar é simétrico, $\mathbf{u}^\top\mathbf{v} = \mathbf{v}^\top\mathbf{u}$, e linear em cada argumento. Sua importância vem da identidade geométrica

$$
\mathbf{u}^\top \mathbf{v} = \lVert \mathbf{u} \rVert_2\, \lVert \mathbf{v} \rVert_2 \cos\theta ,
$$

em que $\theta$ é o ângulo entre os dois vetores e $\lVert\cdot\rVert_2$ é o comprimento euclidiano, definido logo adiante. No plano e no espaço, essa identidade decorre da lei dos cossenos. Em dimensões maiores, ela é usada como **definição** de ângulo. Para que a definição faça sentido, o cosseno precisa ficar entre $-1$ e $1$, e é isso que o próximo teorema garante.

::: teorema 1.1 · Desigualdade de Cauchy–Schwarz
Para quaisquer $\mathbf{u}, \mathbf{v} \in \mathbb{R}^n$,

$$
\lvert \mathbf{u}^\top \mathbf{v} \rvert \le \lVert \mathbf{u} \rVert_2 \, \lVert \mathbf{v} \rVert_2 ,
$$

com igualdade se e somente se um dos vetores é múltiplo do outro.
:::

::: demonstracao
Se $\mathbf{v} = \mathbf{0}$, os dois lados valem zero. Suponha $\mathbf{v} \neq \mathbf{0}$ e considere, para $t \in \mathbb{R}$, o vetor $\mathbf{u} - t\mathbf{v}$. Seu comprimento ao quadrado não pode ser negativo:

$$
0 \le \lVert \mathbf{u} - t\mathbf{v} \rVert_2^2 = \lVert\mathbf{u}\rVert_2^2 - 2t\, \mathbf{u}^\top\mathbf{v} + t^2 \lVert \mathbf{v} \rVert_2^2 .
$$

A desigualdade vale para todo $t$; em particular, para $t = \mathbf{u}^\top\mathbf{v} / \lVert\mathbf{v}\rVert_2^2$, o valor que minimiza o lado direito. Substituindo:

$$
0 \le \lVert\mathbf{u}\rVert_2^2 - \frac{(\mathbf{u}^\top\mathbf{v})^2}{\lVert\mathbf{v}\rVert_2^2}.
$$

Multiplicando por $\lVert\mathbf{v}\rVert_2^2$ e extraindo a raiz quadrada, obtém-se a desigualdade. A igualdade ocorre exatamente quando $\mathbf{u} - t\mathbf{v} = \mathbf{0}$, isto é, quando $\mathbf{u}$ é múltiplo de $\mathbf{v}$.
:::

Três casos do sinal de $\mathbf{u}^\top\mathbf{v}$ merecem ser memorizados. Produto positivo: os vetores apontam para o mesmo lado (ângulo agudo). Produto zero: são **ortogonais** (perpendiculares). Produto negativo: apontam para lados opostos.

### Normas

::: definicao 1.7 · Norma
Uma **norma** em $\mathbb{R}^n$ é uma função $\lVert \cdot \rVert : \mathbb{R}^n \to \mathbb{R}$ que satisfaz, para todos $\mathbf{x}, \mathbf{y}$ e todo escalar $\alpha$:

1. **Positividade:** $\lVert\mathbf{x}\rVert \ge 0$, e $\lVert\mathbf{x}\rVert = 0$ somente se $\mathbf{x} = \mathbf{0}$.
2. **Homogeneidade:** $\lVert\alpha\mathbf{x}\rVert = \lvert\alpha\rvert\,\lVert\mathbf{x}\rVert$.
3. **Desigualdade triangular:** $\lVert\mathbf{x}+\mathbf{y}\rVert \le \lVert\mathbf{x}\rVert + \lVert\mathbf{y}\rVert$.
:::

As três exigências traduzem o que se espera de qualquer medida de tamanho: só o vetor nulo tem tamanho zero, dobrar o vetor dobra o tamanho, e um desvio nunca encurta o caminho. As normas mais usadas pertencem à família $\ell_p$:

$$
\lVert\mathbf{x}\rVert_p = \Bigl( \sum_{i=1}^n \lvert x_i\rvert^p \Bigr)^{1/p}, \qquad p \ge 1 .
$$

| Norma | Expressão | Leitura |
|---|---|---|
| $\ell_1$ | $\lVert\mathbf{x}\rVert_1 = \sum_i \lvert x_i \rvert$ | Distância percorrida andando apenas ao longo dos eixos |
| $\ell_2$ | $\lVert\mathbf{x}\rVert_2 = \sqrt{\sum_i x_i^2} = \sqrt{\mathbf{x}^\top\mathbf{x}}$ | Comprimento em linha reta (Pitágoras) |
| $\ell_\infty$ | $\lVert\mathbf{x}\rVert_\infty = \max_i \lvert x_i\rvert$ | Maior componente em módulo |

A **distância** entre dois vetores é a norma da diferença, $\lVert\mathbf{x}-\mathbf{y}\rVert$. Com a norma $\ell_2$, obtém-se a distância euclidiana.

<figure>
<svg class="fig" viewBox="0 0 640 250" role="img" aria-label="Bolas unitárias das normas L1, um losango, e L2, um círculo, com uma reta que toca o losango em um vértice sobre o eixo">
<g transform="translate(160,125)">
<line class="fraco" x1="-120" y1="0" x2="120" y2="0"/><line class="fraco" x1="0" y1="-110" x2="0" y2="110"/>
<polygon class="la" points="0,-90 90,0 0,90 -90,0"/>
<line class="ln" x1="-40" y1="-100.6" x2="118" y2="-58.6" stroke-dasharray="5 4"/>
<circle class="pa" cx="0" cy="-90" r="5"/>
<text x="-150" y="-98" font-size="14" font-weight="700">Norma ℓ₁</text>
<text x="12" y="-98" font-size="12" class="t2">toque em um vértice: x₁ = 0</text>
</g>
<g transform="translate(480,125)">
<line class="fraco" x1="-120" y1="0" x2="120" y2="0"/><line class="fraco" x1="0" y1="-110" x2="0" y2="110"/>
<circle class="lv" cx="0" cy="0" r="90"/>
<line class="ln" x1="-52" y1="-108" x2="112" y2="-64" stroke-dasharray="5 4"/>
<circle class="pt" cx="23.3" cy="-86.9" r="5"/>
<text x="-150" y="-98" font-size="14" font-weight="700">Norma ℓ₂</text>
<text x="40" y="-92" font-size="12" class="t2">toque fora dos eixos</text>
</g>
</svg>
<figcaption><b>Figura 1.1.</b> Conjuntos dos vetores de norma 1 no plano. A bola da norma ℓ₁ tem vértices sobre os eixos; a da norma ℓ₂ é redonda. Uma mesma reta toca o losango em um vértice, onde uma coordenada é exatamente zero, e toca o círculo em um ponto com as duas coordenadas não nulas.</figcaption>
</figure>

A Figura 1.1 antecipa um resultado do Capítulo 5. Penalizar a norma $\ell_1$ dos parâmetros (Lasso) tende a zerar alguns deles, produzindo modelos **esparsos**. Penalizar o quadrado da norma $\ell_2$ (Ridge) encolhe todos os parâmetros sem zerá-los. A diferença está nos vértices.

As normas $\ell_p$ são comparáveis entre si. Para todo $\mathbf{x} \in \mathbb{R}^n$:

$$
\lVert\mathbf{x}\rVert_\infty \le \lVert\mathbf{x}\rVert_2 \le \lVert\mathbf{x}\rVert_1 \le \sqrt{n}\, \lVert\mathbf{x}\rVert_2 .
$$

A última desigualdade é a de Cauchy–Schwarz aplicada ao vetor dos módulos de $\mathbf{x}$ e ao vetor de uns (Exercício 1.8).

### Similaridade por cosseno

Isolando o cosseno na identidade geométrica do produto escalar:

$$
\cos\theta = \frac{\mathbf{u}^\top\mathbf{v}}{\lVert\mathbf{u}\rVert_2\,\lVert\mathbf{v}\rVert_2}.
$$

Essa grandeza mede o alinhamento das direções e ignora os comprimentos. Vale 1 para vetores de mesma direção e sentido, 0 para ortogonais e $-1$ para opostos.

### Implementação

<<< codigo/c1_normas.py

>>> codigo/c1_normas.out

Para $\mathbf{u} = (3,4,0)^\top$, o programa confirma o que a conta à mão fornece: norma $\ell_2$ igual a 5, norma $\ell_1$ igual a 7. O teste final não demonstra a desigualdade de Cauchy–Schwarz (nenhuma quantidade de exemplos demonstra um teorema), mas ilustra um hábito útil: verificar numericamente uma propriedade em muitos casos aleatórios é uma forma barata de encontrar erros de implementação.

::: aplicacao Do produto escalar à atenção
O produto escalar é a operação mais repetida deste livro. Um neurônio calcula $\mathbf{w}^\top\mathbf{x} + b$ (Capítulo 6). A atenção compara consultas e chaves pelo produto $\mathbf{Q}\mathbf{K}^\top$ (Capítulo 9). A busca em um sistema RAG ordena documentos pela similaridade por cosseno entre vetores (Capítulo 12). Nos três casos, a pergunta é a mesma: quanto estes dois vetores apontam na mesma direção?
:::

::: erro Tratar cosseno e distância euclidiana como equivalentes
As duas medidas só ordenam os vizinhos da mesma forma quando os vetores têm norma 1. Nesse caso, $\lVert\mathbf{u}-\mathbf{v}\rVert_2^2 = 2 - 2\cos\theta$ (Exercício 1.7). Com vetores não normalizados, um documento longo pode estar distante em linha reta e, ainda assim, perfeitamente alinhado em direção.
:::

## 1.5 Determinantes

### Motivação

Dada uma matriz quadrada, há uma pergunta simples com muitas consequências: a transformação $\mathbf{x} \mapsto \mathbf{A}\mathbf{x}$ preserva, amplia ou destrói volume? O determinante responde com um único número.

::: definicao 1.8 · Determinante
O **determinante** é a única função $\det : \mathbb{R}^{n\times n} \to \mathbb{R}$ que (i) é linear em cada coluna separadamente, (ii) troca de sinal quando duas colunas são permutadas e (iii) vale 1 na identidade. Para $n = 2$:

$$
\det \begin{bmatrix} a & b \\ c & d \end{bmatrix} = ad - bc .
$$

Para $n$ maior, o determinante pode ser calculado pela expansão em cofatores ao longo de qualquer linha ou coluna.
:::

### Interpretação geométrica

O valor $\lvert\det\mathbf{A}\rvert$ é o fator pelo qual a transformação multiplica áreas (em $\mathbb{R}^2$) ou volumes (em $\mathbb{R}^n$). O quadrado unitário, de área 1, é levado em um paralelogramo de área $\lvert\det \mathbf{A}\rvert$. O sinal indica se a orientação é preservada (positivo) ou espelhada (negativo).

Se $\det\mathbf{A} = 0$, o quadrado é achatado em um segmento ou em um ponto: o volume desaparece, direções distintas são confundidas e a transformação não pode ser desfeita.

::: teorema 1.2 · Determinante e invertibilidade
Uma matriz quadrada $\mathbf{A}$ é invertível se e somente se $\det\mathbf{A} \neq 0$. Além disso, para matrizes $n \times n$:

$$
\det(\mathbf{A}\mathbf{B}) = \det\mathbf{A}\,\det\mathbf{B}, \qquad
\det(\mathbf{A}^\top) = \det\mathbf{A}, \qquad
\det(\alpha\mathbf{A}) = \alpha^n \det\mathbf{A}.
$$
:::

::: demonstracao
Admitindo a regra do produto (cuja prova decorre da unicidade na Definição 1.8 e está em Strang, 2016), a primeira afirmação é imediata em um sentido: se $\mathbf{A}$ é invertível, então $1 = \det\mathbf{I} = \det(\mathbf{A}\mathbf{A}^{-1}) = \det\mathbf{A}\,\det\mathbf{A}^{-1}$, logo $\det\mathbf{A} \neq 0$ e, de passagem, $\det\mathbf{A}^{-1} = 1/\det\mathbf{A}$. No outro sentido: se $\mathbf{A}$ não é invertível, suas colunas são linearmente dependentes, e alguma coluna é combinação das demais. Pela linearidade em cada coluna, o determinante se decompõe em uma soma de determinantes com duas colunas iguais. Cada um deles é nulo, porque permutar as duas colunas iguais não altera a matriz, mas deve trocar o sinal do determinante.
:::

::: exemplo 1.2 · Uma matriz que achata o plano
Para

$$
\mathbf{A} = \begin{bmatrix} 2 & 4 \\ 1 & 2 \end{bmatrix}, \qquad \det\mathbf{A} = 2\cdot 2 - 4 \cdot 1 = 0 .
$$

A segunda coluna é o dobro da primeira. Todo vetor $\mathbf{A}\mathbf{x} = x_1 (2,1)^\top + x_2 (4,2)^\top = (x_1 + 2x_2)(2,1)^\top$ cai sobre a reta gerada por $(2,1)^\top$. O plano foi achatado em uma reta; o posto é 1; não existe inversa.
:::

::: atencao O determinante não mede "quão perto" uma matriz está de ser singular
A matriz $0{,}1\,\mathbf{I}_{100}$ tem determinante $10^{-100}$ e é perfeitamente bem comportada: sua inversa é $10\,\mathbf{I}_{100}$. Por causa da propriedade $\det(\alpha\mathbf{A}) = \alpha^n\det\mathbf{A}$, o determinante de matrizes grandes estoura ou some com facilidade em ponto flutuante. Para avaliar a proximidade da singularidade usa-se o **número de condição** (seção 1.7). Quando o determinante é realmente necessário, como na densidade Gaussiana multivariada da seção 1.12, calcula-se o seu logaritmo com `np.linalg.slogdet`.
:::

## 1.6 Autovalores e autovetores

### Motivação

Uma transformação linear, em geral, muda a direção dos vetores. Mas quase toda matriz quadrada tem algumas direções especiais, nas quais ela age apenas esticando ou encolhendo. Encontrá-las revela a estrutura da transformação e reduz problemas matriciais a problemas escalares. Na seção 1.11, a velocidade da descida do gradiente será lida diretamente dos autovalores de uma matriz.

::: definicao 1.9 · Autovalor e autovetor
Seja $\mathbf{A} \in \mathbb{R}^{n\times n}$. Um vetor não nulo $\mathbf{v}$ é um **autovetor** de $\mathbf{A}$, com **autovalor** $\lambda$, se

$$
\mathbf{A}\mathbf{v} = \lambda \mathbf{v}.
$$
:::

A equação diz que aplicar $\mathbf{A}$ a $\mathbf{v}$ tem o mesmo efeito que multiplicar $\mathbf{v}$ pelo número $\lambda$. Se $\lambda > 1$, a direção é esticada; se $0 < \lambda < 1$, encolhida; se $\lambda < 0$, invertida; se $\lambda = 0$, aniquilada.

### Como calcular

Reescrevendo a definição como $(\mathbf{A} - \lambda\mathbf{I})\mathbf{v} = \mathbf{0}$, vê-se que existe solução não nula exatamente quando $\mathbf{A} - \lambda\mathbf{I}$ não é invertível. Pelo Teorema 1.2, isso equivale a

$$
\det(\mathbf{A} - \lambda\mathbf{I}) = 0 .
$$

O lado esquerdo é um polinômio de grau $n$ em $\lambda$, o **polinômio característico**. Suas raízes são os autovalores.

::: exemplo 1.3 · Autovalores e autovetores de uma matriz 2 × 2
Para $\mathbf{A} = \begin{bmatrix} 2 & 1 \\ 1 & 2 \end{bmatrix}$:

$$
\det(\mathbf{A}-\lambda\mathbf{I}) = (2-\lambda)^2 - 1 = \lambda^2 - 4\lambda + 3 = (\lambda - 1)(\lambda - 3).
$$

Os autovalores são $\lambda_1 = 1$ e $\lambda_2 = 3$.

Para $\lambda_2 = 3$, resolve-se $(\mathbf{A} - 3\mathbf{I})\mathbf{v} = \mathbf{0}$, ou seja, $-v_1 + v_2 = 0$. As soluções são os múltiplos de $(1, 1)^\top$. Normalizando: $\mathbf{q}_2 = \tfrac{1}{\sqrt 2}(1,1)^\top$.

Para $\lambda_1 = 1$, a equação é $v_1 + v_2 = 0$, e $\mathbf{q}_1 = \tfrac{1}{\sqrt 2}(1,-1)^\top$.

Conferências: $\mathbf{q}_1^\top\mathbf{q}_2 = 0$ (são ortogonais); $\lambda_1 + \lambda_2 = 4$ é o traço de $\mathbf{A}$; $\lambda_1\lambda_2 = 3$ é o determinante. A matriz estica o plano por um fator 3 ao longo da diagonal $(1,1)$ e mantém inalterada a direção $(1,-1)$.
:::

As duas conferências finais valem em geral: a soma dos autovalores é o **traço** (soma da diagonal) e o produto é o determinante. Em particular, uma matriz é invertível se e somente se nenhum autovalor é zero.

### Matrizes simétricas

Matrizes quaisquer podem ter autovalores complexos e autovetores não ortogonais. As matrizes simétricas são mais bem comportadas, e são justamente as que mais aparecem em aprendizado de máquina: matrizes de covariância, Hessianas e produtos $\mathbf{X}^\top\mathbf{X}$ são todas simétricas.

::: teorema 1.3 · Teorema espectral
Se $\mathbf{A} \in \mathbb{R}^{n \times n}$ é simétrica, então todos os seus autovalores são reais e existe uma base ortonormal de $\mathbb{R}^n$ formada por autovetores de $\mathbf{A}$. De modo equivalente,

$$
\mathbf{A} = \mathbf{Q}\boldsymbol{\Lambda}\mathbf{Q}^\top = \sum_{i=1}^n \lambda_i\, \mathbf{q}_i \mathbf{q}_i^\top ,
$$

em que $\mathbf{Q}$ é ortogonal, com os autovetores $\mathbf{q}_i$ nas colunas, e $\boldsymbol{\Lambda}$ é diagonal, com os autovalores $\lambda_i$.
:::

::: demonstracao
Demonstram-se aqui as duas afirmações centrais; a existência da base completa no caso de autovalores repetidos exige um argumento de indução que pode ser visto em Strang (2016).

*Autovalores reais.* Seja $\mathbf{A}\mathbf{v} = \lambda\mathbf{v}$, admitindo a princípio $\lambda$ e $\mathbf{v}$ complexos, e seja $\bar{\mathbf{v}}$ o conjugado de $\mathbf{v}$. Multiplicando à esquerda por $\bar{\mathbf{v}}^\top$, tem-se $\bar{\mathbf{v}}^\top\mathbf{A}\mathbf{v} = \lambda\, \bar{\mathbf{v}}^\top\mathbf{v}$. Conjugando a equação original e usando que $\mathbf{A}$ é real e simétrica, obtém-se também $\bar{\mathbf{v}}^\top\mathbf{A}\mathbf{v} = \bar\lambda\, \bar{\mathbf{v}}^\top\mathbf{v}$. Como $\bar{\mathbf{v}}^\top\mathbf{v} = \sum_i \lvert v_i\rvert^2 > 0$, conclui-se que $\lambda = \bar\lambda$, isto é, $\lambda$ é real.

*Autovetores ortogonais.* Sejam $\mathbf{A}\mathbf{u} = \lambda\mathbf{u}$ e $\mathbf{A}\mathbf{v} = \mu\mathbf{v}$, com $\lambda \neq \mu$. Então $\lambda\,\mathbf{u}^\top\mathbf{v} = (\mathbf{A}\mathbf{u})^\top\mathbf{v} = \mathbf{u}^\top\mathbf{A}^\top\mathbf{v} = \mathbf{u}^\top\mathbf{A}\mathbf{v} = \mu\,\mathbf{u}^\top\mathbf{v}$. Logo $(\lambda-\mu)\,\mathbf{u}^\top\mathbf{v} = 0$ e, como $\lambda\neq\mu$, segue que $\mathbf{u}^\top\mathbf{v} = 0$.
:::

A decomposição $\mathbf{A} = \mathbf{Q}\boldsymbol\Lambda\mathbf{Q}^\top$ tem leitura em três etapas: $\mathbf{Q}^\top$ gira o vetor para o sistema de eixos dos autovetores; $\boldsymbol\Lambda$ estica cada eixo pelo seu autovalor; $\mathbf{Q}$ gira de volta. Nesse sistema de eixos, a matriz é diagonal e todo cálculo se torna escalar.

### Matrizes definidas positivas

::: definicao 1.10 · Matriz definida e semidefinida positiva
Uma matriz simétrica $\mathbf{A}$ é **semidefinida positiva** se $\mathbf{x}^\top\mathbf{A}\mathbf{x} \ge 0$ para todo $\mathbf{x}$, e **definida positiva** se $\mathbf{x}^\top\mathbf{A}\mathbf{x} > 0$ para todo $\mathbf{x} \neq \mathbf{0}$.
:::

A expressão $\mathbf{x}^\top\mathbf{A}\mathbf{x} = \sum_{i,j} A_{ij}x_i x_j$ é chamada **forma quadrática**. Pelo teorema espectral, com $\mathbf{z} = \mathbf{Q}^\top\mathbf{x}$,

$$
\mathbf{x}^\top\mathbf{A}\mathbf{x} = \mathbf{z}^\top\boldsymbol\Lambda\mathbf{z} = \sum_{i=1}^n \lambda_i z_i^2 .
$$

Disso decorre o critério prático: uma matriz simétrica é definida positiva se e somente se todos os seus autovalores são positivos, e semidefinida positiva se e somente se nenhum é negativo. Geometricamente, o gráfico de $\mathbf{x} \mapsto \mathbf{x}^\top\mathbf{A}\mathbf{x}$ é uma tigela com um único ponto de mínimo quando $\mathbf{A}$ é definida positiva, e uma sela quando há autovalores de sinais opostos. Essa imagem será a base das condições de otimalidade na seção 1.10.

Toda matriz da forma $\mathbf{X}^\top\mathbf{X}$ é semidefinida positiva, pois $\mathbf{v}^\top\mathbf{X}^\top\mathbf{X}\mathbf{v} = \lVert\mathbf{X}\mathbf{v}\rVert_2^2 \ge 0$.

### Além das matrizes quadradas

Autovalores só existem para matrizes quadradas. Para uma matriz qualquer $\mathbf{A} \in \mathbb{R}^{m \times n}$, o papel análogo é desempenhado pela **Decomposição em Valores Singulares** (*Singular Value Decomposition*, SVD): $\mathbf{A} = \mathbf{U}\boldsymbol\Sigma\mathbf{V}^\top$, com $\mathbf{U}$ e $\mathbf{V}$ ortogonais e $\boldsymbol\Sigma$ diagonal com elementos $\sigma_1 \ge \sigma_2 \ge \dots \ge 0$, os valores singulares. Eles são as raízes quadradas dos autovalores de $\mathbf{A}^\top\mathbf{A}$, e o número de valores singulares não nulos é o posto de $\mathbf{A}$. A SVD fornece a melhor aproximação de baixo posto de uma matriz e reaparece na análise de componentes principais (Capítulo 3).

### Implementação

<<< codigo/c1_autovalores.py

>>> codigo/c1_autovalores.out

A rotina `np.linalg.eigh` é o **código de produção** para matrizes simétricas: explora a simetria, devolve autovalores reais em ordem crescente e autovetores ortonormais. A função `iteracao_de_potencia` é **código didático**. Ela funciona porque, ao escrever o vetor inicial na base dos autovetores, cada multiplicação por $\mathbf{A}$ multiplica a componente $i$ por $\lambda_i$; depois de $k$ passos, a componente do maior autovalor domina as demais por um fator $(\lambda_{\max}/\lambda_i)^k$. O sinal de um autovetor é arbitrário (se $\mathbf{v}$ é autovetor, $-\mathbf{v}$ também é), e por isso o programa imprime valores absolutos.

## 1.7 Álgebra linear computacional

### Motivação

A matemática das seções anteriores supõe números reais exatos. O computador trabalha com aproximações de precisão finita e com orçamento de tempo. Esta seção trata das três consequências práticas mais importantes: erro de arredondamento, condicionamento e custo.

### Ponto flutuante

O tipo `float64` representa números com cerca de 16 algarismos decimais significativos. O menor número $\varepsilon$ tal que $1 + \varepsilon \neq 1$ na máquina é aproximadamente $2{,}2 \times 10^{-16}$. Consequências imediatas:

- Igualdade exata entre números de ponto flutuante raramente é o teste correto. Usa-se tolerância: `np.isclose`, `np.allclose`.
- Subtrair números quase iguais destrói algarismos significativos (cancelamento catastrófico).
- Produtos de muitas probabilidades pequenas chegam a zero por *underflow*. Por isso trabalha-se com somas de logaritmos, prática que será constante a partir do Capítulo 4.

### Condicionamento

Alguns problemas amplificam pequenos erros nos dados, independentemente do algoritmo usado.

::: definicao 1.11 · Número de condição
Para uma matriz invertível $\mathbf{A}$, o **número de condição** na norma 2 é

$$
\kappa(\mathbf{A}) = \frac{\sigma_{\max}(\mathbf{A})}{\sigma_{\min}(\mathbf{A})},
$$

a razão entre o maior e o menor valor singular. Para matrizes simétricas definidas positivas, $\kappa = \lambda_{\max}/\lambda_{\min}$.
:::

Ao resolver $\mathbf{A}\mathbf{x} = \mathbf{b}$, um erro relativo $\delta$ em $\mathbf{b}$ pode provocar um erro relativo de até $\kappa(\mathbf{A})\,\delta$ em $\mathbf{x}$. Como regra prática, perdem-se cerca de $\log_{10}\kappa$ algarismos decimais de precisão. Com $\kappa \approx 10^{16}$, não resta nenhum.

### Resolver sistemas sem inverter matrizes

<<< codigo/c1_condicionamento.py

>>> codigo/c1_condicionamento.out

A matriz de Hilbert, $H_{ij} = 1/(i+j-1)$, é um exemplo clássico de mau condicionamento. A tabela mostra dois fatos. Primeiro, o erro cresce com $\kappa$ como a regra prática prevê: com $\kappa \approx 10^{16}$, a solução calculada não tem valor algum, embora o programa não emita aviso. Segundo, `np.linalg.solve`, que fatora a matriz, é sistematicamente mais preciso do que calcular a inversa e multiplicar. É também mais rápido.

::: atencao Regra de implementação
Sempre que uma fórmula contiver $\mathbf{A}^{-1}\mathbf{b}$, implemente como `np.linalg.solve(A, b)`. Para mínimos quadrados, use `np.linalg.lstsq`. A inversa explícita quase nunca é necessária.
:::

### Custo e vetorização

Multiplicar duas matrizes $n \times n$ pelo algoritmo usual exige da ordem de $n^3$ operações; resolver um sistema linear denso, também. O produto matriz-vetor custa $n^2$. Esses expoentes explicam por que métodos que usam apenas gradientes (custo proporcional ao número de parâmetros) dominam o treinamento de modelos grandes, enquanto métodos que usam a Hessiana completa são inviáveis nessa escala.

Em Python, o custo prático depende também de **onde** o laço é executado. Um laço `for` sobre os elementos de um arranjo é interpretado; a mesma operação escrita como expressão sobre o arranjo inteiro é executada por rotinas compiladas e otimizadas (BLAS e LAPACK). A diferença costuma ser de duas ordens de grandeza. Escrever a operação sobre arranjos inteiros chama-se **vetorizar**, e é a razão pela qual a notação matricial deste capítulo não é apenas elegante: ela é a forma eficiente de programar.
