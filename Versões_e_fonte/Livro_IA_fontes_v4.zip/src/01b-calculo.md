## 1.8 Funções multivariadas e derivadas parciais

### Motivação

O erro de um modelo depende de todos os seus parâmetros ao mesmo tempo. Uma regressão com três variáveis tem quatro parâmetros; uma rede neural pequena tem milhares; um modelo de linguagem, bilhões. Para saber como alterar os parâmetros de modo a reduzir o erro, é preciso medir a sensibilidade de uma função a cada uma de suas variáveis. Esse é o papel das derivadas parciais.

::: definicao 1.12 · Função multivariada
Uma **função escalar de várias variáveis** é uma função $f : \mathbb{R}^n \to \mathbb{R}$, que associa a cada vetor $\mathbf{x} = (x_1,\dots,x_n)^\top$ um número $f(\mathbf{x})$. Uma **função vetorial** $\mathbf{f}: \mathbb{R}^n \to \mathbb{R}^m$ associa a cada vetor de entrada um vetor de saída.
:::

Funções de perda são do primeiro tipo: recebem o vetor de parâmetros e devolvem um número. Camadas de redes neurais são do segundo tipo.

Uma função de duas variáveis pode ser visualizada como um relevo: $f(x_1, x_2)$ é a altitude no ponto $(x_1,x_2)$. As **curvas de nível** são os conjuntos em que $f$ é constante, como nas cartas topográficas. Essa imagem acompanha o restante do capítulo.

::: definicao 1.13 · Derivada parcial
A **derivada parcial** de $f:\mathbb{R}^n\to\mathbb{R}$ em relação a $x_i$, no ponto $\mathbf{x}$, é

$$
\frac{\partial f}{\partial x_i}(\mathbf{x}) = \lim_{h \to 0} \frac{f(\mathbf{x} + h\,\mathbf{e}_i) - f(\mathbf{x})}{h},
$$

quando o limite existe, em que $\mathbf{e}_i$ é o vetor com 1 na posição $i$ e 0 nas demais.
:::

Em palavras: congelam-se todas as variáveis, exceto $x_i$, e deriva-se como em uma função de uma variável. O resultado é a inclinação do relevo quando se caminha na direção do eixo $i$.

::: exemplo 1.4 · Derivadas parciais
Seja $f(x_1,x_2) = x_1^2 x_2 + 3x_2$. Tratando $x_2$ como constante: $\dfrac{\partial f}{\partial x_1} = 2x_1x_2$. Tratando $x_1$ como constante: $\dfrac{\partial f}{\partial x_2} = x_1^2 + 3$.

No ponto $(1, 2)$: $\partial f/\partial x_1 = 4$ e $\partial f/\partial x_2 = 4$. Um pequeno acréscimo $h$ em qualquer das duas variáveis aumenta $f$ em aproximadamente $4h$.
:::

## 1.9 Gradiente

::: definicao 1.14 · Gradiente
O **gradiente** de uma função diferenciável $f:\mathbb{R}^n\to\mathbb{R}$ no ponto $\mathbf{x}$ é o vetor das derivadas parciais:

$$
\nabla f(\mathbf{x}) = \begin{bmatrix} \dfrac{\partial f}{\partial x_1}(\mathbf{x}) \\ \vdots \\ \dfrac{\partial f}{\partial x_n}(\mathbf{x}) \end{bmatrix} \in \mathbb{R}^n .
$$
:::

O gradiente tem a mesma forma que a entrada: um número para cada variável. Para uma perda $\mathcal{L}(\boldsymbol\theta)$, o gradiente $\nabla\mathcal{L}$ contém uma componente por parâmetro.

### Aproximação linear

A utilidade do gradiente vem da aproximação de primeira ordem. Para um deslocamento pequeno $\boldsymbol\delta$,

$$
f(\mathbf{x} + \boldsymbol\delta) \approx f(\mathbf{x}) + \nabla f(\mathbf{x})^\top \boldsymbol\delta .
$$

Essa expressão é uma **aproximação**, e não uma identidade: o erro cometido é de ordem $\lVert\boldsymbol\delta\rVert^2$ para funções duas vezes diferenciáveis. Ela diz que, perto de $\mathbf{x}$, a função se comporta como um plano inclinado, e que a variação de $f$ é o produto escalar entre o gradiente e o deslocamento.

A **derivada direcional** de $f$ na direção de um vetor unitário $\mathbf{u}$ é a taxa de variação ao caminhar nessa direção, e vale $\nabla f(\mathbf{x})^\top\mathbf{u}$.

::: teorema 1.4 · O gradiente aponta a direção de maior crescimento
Seja $f$ diferenciável em $\mathbf{x}$, com $\nabla f(\mathbf{x}) \neq \mathbf{0}$. Entre todos os vetores unitários $\mathbf{u}$, a derivada direcional $\nabla f(\mathbf{x})^\top\mathbf{u}$ é máxima para $\mathbf{u} = \nabla f(\mathbf{x})/\lVert\nabla f(\mathbf{x})\rVert_2$ e mínima para $\mathbf{u} = -\nabla f(\mathbf{x})/\lVert\nabla f(\mathbf{x})\rVert_2$. O valor máximo é $\lVert\nabla f(\mathbf{x})\rVert_2$.
:::

::: demonstracao
Pela desigualdade de Cauchy–Schwarz (Teorema 1.1), para todo $\mathbf{u}$ unitário,

$$
-\lVert\nabla f(\mathbf{x})\rVert_2 \;\le\; \nabla f(\mathbf{x})^\top\mathbf{u} \;\le\; \lVert\nabla f(\mathbf{x})\rVert_2 ,
$$

e as igualdades ocorrem exatamente quando $\mathbf{u}$ é múltiplo do gradiente, com sinal positivo no limite superior e negativo no inferior.
:::

Duas consequências geométricas. A direção $-\nabla f$ é a de descida mais íngreme, e é nela que a descida do gradiente caminha. E o gradiente é perpendicular às curvas de nível: ao longo de uma curva de nível a função não varia, logo a derivada direcional é nula, logo o produto escalar com o gradiente é zero.

### Gradientes que convém saber de cor

Três identidades cobrem a maior parte das derivações deste livro. Para $\mathbf{a} \in\mathbb{R}^n$ e $\mathbf{A} \in \mathbb{R}^{n\times n}$ constantes:

| Função $f(\mathbf{x})$ | Gradiente $\nabla f(\mathbf{x})$ |
|---|---|
| $\mathbf{a}^\top\mathbf{x}$ | $\mathbf{a}$ |
| $\mathbf{x}^\top\mathbf{A}\mathbf{x}$ | $(\mathbf{A}+\mathbf{A}^\top)\mathbf{x}$, que é $2\mathbf{A}\mathbf{x}$ se $\mathbf{A}$ é simétrica |
| $\lVert\mathbf{x}\rVert_2^2 = \mathbf{x}^\top\mathbf{x}$ | $2\mathbf{x}$ |

::: demonstracao
*Primeira linha.* $f(\mathbf{x}) = \sum_j a_j x_j$, logo $\partial f/\partial x_k = a_k$.

*Segunda linha.* $f(\mathbf{x}) = \sum_i\sum_j A_{ij}x_ix_j$. A variável $x_k$ aparece nos termos com $i = k$ e nos termos com $j = k$. Derivando: $\partial f/\partial x_k = \sum_j A_{kj}x_j + \sum_i A_{ik}x_i$. A primeira soma é a componente $k$ de $\mathbf{A}\mathbf{x}$; a segunda, a componente $k$ de $\mathbf{A}^\top\mathbf{x}$.

*Terceira linha.* Caso particular da segunda, com $\mathbf{A} = \mathbf{I}$.
:::

::: exemplo 1.5 · Gradiente do erro quadrático médio
Considere um modelo linear com previsões $\hat{\mathbf{y}} = \mathbf{X}\boldsymbol\theta$, em que $\mathbf{X}\in\mathbb{R}^{n\times d}$ e $\boldsymbol\theta\in\mathbb{R}^d$, e respostas observadas $\mathbf{y}\in\mathbb{R}^n$. O Erro Quadrático Médio (*Mean Squared Error*, MSE) é

$$
\mathcal{L}(\boldsymbol\theta) = \frac1n\sum_{i=1}^n (y_i - \hat y_i)^2 = \frac1n \lVert \mathbf{X}\boldsymbol\theta - \mathbf{y}\rVert_2^2 .
$$

Cada termo da soma é o quadrado do **resíduo** do exemplo $i$, a diferença entre o valor observado e o previsto. Expandindo a norma:

$$
\mathcal{L}(\boldsymbol\theta) = \frac1n\Bigl( \boldsymbol\theta^\top\mathbf{X}^\top\mathbf{X}\boldsymbol\theta - 2\,\mathbf{y}^\top\mathbf{X}\boldsymbol\theta + \mathbf{y}^\top\mathbf{y} \Bigr).
$$

Aplicando as identidades da tabela, com $\mathbf{A} = \mathbf{X}^\top\mathbf{X}$ (simétrica) e $\mathbf{a} = \mathbf{X}^\top\mathbf{y}$:

$$
\nabla\mathcal{L}(\boldsymbol\theta) = \frac2n\bigl(\mathbf{X}^\top\mathbf{X}\boldsymbol\theta - \mathbf{X}^\top\mathbf{y}\bigr) = \frac2n\,\mathbf{X}^\top(\mathbf{X}\boldsymbol\theta - \mathbf{y}).
$$

Conferência de formas: $\mathbf{X}^\top$ é $d \times n$ e o resíduo é $n\times 1$, logo o gradiente é $d \times 1$, a forma de $\boldsymbol\theta$. A leitura é direta: o gradiente é a correlação entre cada variável (coluna de $\mathbf{X}$) e o vetor de resíduos. Enquanto alguma variável ainda "explica" parte do resíduo, o gradiente é não nulo. Essa expressão é implementada no Projeto 1 e retomada no Capítulo 4.
:::

### Jacobiana e regra da cadeia

Para uma função vetorial $\mathbf{f}:\mathbb{R}^n\to\mathbb{R}^m$, as derivadas parciais de todas as saídas em relação a todas as entradas formam a **matriz Jacobiana** $\mathbf{J}_{\mathbf{f}}(\mathbf{x})\in\mathbb{R}^{m\times n}$, com elementos $J_{ij} = \partial f_i/\partial x_j$. A Jacobiana de $\mathbf{x}\mapsto\mathbf{A}\mathbf{x}$ é a própria $\mathbf{A}$.

::: teorema 1.5 · Regra da cadeia multivariada
Se $\mathbf{g}:\mathbb{R}^n\to\mathbb{R}^m$ é diferenciável em $\mathbf{x}$ e $\mathbf{f}:\mathbb{R}^m\to\mathbb{R}^p$ é diferenciável em $\mathbf{g}(\mathbf{x})$, então a composta $\mathbf{f}\circ\mathbf{g}$ é diferenciável em $\mathbf{x}$ e

$$
\mathbf{J}_{\mathbf{f}\circ\mathbf{g}}(\mathbf{x}) = \mathbf{J}_{\mathbf{f}}\bigl(\mathbf{g}(\mathbf{x})\bigr)\; \mathbf{J}_{\mathbf{g}}(\mathbf{x}).
$$
:::

A demonstração segue da composição das aproximações lineares de $\mathbf{g}$ e de $\mathbf{f}$ e pode ser vista em Deisenroth, Faisal e Ong (2020, cap. 5). O conteúdo do teorema é simples de enunciar: **a derivada de uma composição é o produto das derivadas**. O produto matricial da seção 1.3 volta a aparecer porque derivadas são aproximações lineares, e compor funções lineares é multiplicar matrizes.

::: aplicacao Regra da cadeia e backpropagation
Uma rede neural é uma composição de dezenas ou centenas de funções. O algoritmo de retropropagação (*backpropagation*), derivado no Capítulo 6, nada mais é do que a regra da cadeia aplicada de forma organizada, multiplicando as Jacobianas da saída para a entrada e reaproveitando resultados intermediários. Quando a função final é escalar (a perda), essa ordem de multiplicação custa aproximadamente o mesmo que avaliar a própria função, qualquer que seja o número de parâmetros. É esse fato que torna viável treinar modelos com bilhões de parâmetros.
:::

## 1.10 Matriz Hessiana

### Motivação

O gradiente informa a inclinação. Para saber se um ponto de inclinação nula é um vale, um pico ou uma sela, e para saber o tamanho seguro de um passo, é preciso conhecer a curvatura. Em uma variável, a curvatura é a segunda derivada. Em várias, é uma matriz.

::: definicao 1.15 · Matriz Hessiana
A **matriz Hessiana** de uma função duas vezes diferenciável $f:\mathbb{R}^n\to\mathbb{R}$ é a matriz $\mathbf{H}_f(\mathbf{x})\in\mathbb{R}^{n\times n}$ das derivadas parciais de segunda ordem:

$$
\bigl[\mathbf{H}_f(\mathbf{x})\bigr]_{ij} = \frac{\partial^2 f}{\partial x_i\,\partial x_j}(\mathbf{x}).
$$
:::

Quando as derivadas segundas são contínuas, a ordem de derivação não importa (teorema de Schwarz), e a Hessiana é **simétrica**. Todo o aparato da seção 1.6 se aplica: a Hessiana tem autovalores reais e autovetores ortogonais, e os autovalores são as curvaturas de $f$ ao longo das direções dos autovetores.

### Aproximação de segunda ordem

$$
f(\mathbf{x}+\boldsymbol\delta) \approx f(\mathbf{x}) + \nabla f(\mathbf{x})^\top\boldsymbol\delta + \frac12\,\boldsymbol\delta^\top\mathbf{H}_f(\mathbf{x})\,\boldsymbol\delta .
$$

O termo novo é uma forma quadrática (seção 1.6). Em um **ponto crítico**, onde $\nabla f(\mathbf{x}) = \mathbf{0}$, o comportamento local de $f$ é decidido por ele.

::: teorema 1.6 · Condições de otimalidade de segunda ordem
Seja $f$ duas vezes continuamente diferenciável e $\mathbf{x}^\star$ um ponto com $\nabla f(\mathbf{x}^\star) = \mathbf{0}$.

1. Se $\mathbf{H}_f(\mathbf{x}^\star)$ é definida positiva, $\mathbf{x}^\star$ é um mínimo local estrito.
2. Se $\mathbf{H}_f(\mathbf{x}^\star)$ é definida negativa, $\mathbf{x}^\star$ é um máximo local estrito.
3. Se $\mathbf{H}_f(\mathbf{x}^\star)$ tem autovalores positivos e negativos, $\mathbf{x}^\star$ é um **ponto de sela**.

Se a Hessiana é apenas semidefinida, o teste é inconclusivo.
:::

::: demonstracao
Apresenta-se a justificativa do item 1; os demais são análogos. Com gradiente nulo, a aproximação de segunda ordem dá $f(\mathbf{x}^\star+\boldsymbol\delta) - f(\mathbf{x}^\star) = \tfrac12\boldsymbol\delta^\top\mathbf{H}\boldsymbol\delta + r(\boldsymbol\delta)$, em que o resto satisfaz $r(\boldsymbol\delta)/\lVert\boldsymbol\delta\rVert^2\to 0$. Se $\mathbf{H}$ é definida positiva com menor autovalor $\lambda_{\min}>0$, então $\boldsymbol\delta^\top\mathbf{H}\boldsymbol\delta\ge\lambda_{\min}\lVert\boldsymbol\delta\rVert^2$. Para $\boldsymbol\delta$ suficientemente pequeno, o resto é, em módulo, menor que $\tfrac14\lambda_{\min}\lVert\boldsymbol\delta\rVert^2$, e a diferença é positiva.
:::

::: exemplo 1.6 · Classificação de pontos críticos
Para $f(x_1,x_2) = x_1^2 - x_2^2$: $\nabla f = (2x_1, -2x_2)^\top$, que se anula apenas na origem. A Hessiana é

$$
\mathbf{H}_f = \begin{bmatrix} 2 & 0\\ 0 & -2\end{bmatrix},
$$

com autovalores $2$ e $-2$. A origem é um ponto de sela: mínimo ao longo de $x_1$, máximo ao longo de $x_2$.

Para a perda quadrática do Exemplo 1.5, derivando o gradiente mais uma vez: $\mathbf{H}_{\mathcal{L}} = \tfrac2n\mathbf{X}^\top\mathbf{X}$, que não depende de $\boldsymbol\theta$ e é semidefinida positiva (seção 1.6). A superfície de erro da regressão linear é uma tigela, sem selas e sem mínimos locais espúrios.
:::

### Convexidade

Uma função é **convexa** quando o segmento que une dois pontos quaisquer do seu gráfico fica acima do gráfico. Para funções duas vezes diferenciáveis, isso equivale a ter Hessiana semidefinida positiva em todos os pontos. A propriedade que importa: em uma função convexa, todo mínimo local é mínimo global, e todo ponto de gradiente nulo é mínimo global.

As perdas da regressão linear e da regressão logística (Capítulo 4) são convexas. As perdas de redes neurais **não são**. Em dimensão alta, os pontos críticos dessas perdas são, em sua grande maioria, pontos de sela, e não mínimos locais; esta última afirmação é sustentada por análise teórica em modelos simplificados e por evidência empírica (Goodfellow, Bengio e Courville, 2016, cap. 8), e não por um teorema geral.

## 1.11 Descida do gradiente

### Motivação e derivação

Quer-se minimizar $f(\mathbf{x})$. Em poucos casos, como o da regressão linear, é possível resolver $\nabla f = \mathbf{0}$ em forma fechada. No caso geral, constrói-se uma sequência de pontos em que $f$ diminui a cada passo.

A aproximação de primeira ordem indica como. A partir de $\mathbf{x}_k$, um passo $\boldsymbol\delta$ pequeno altera a função em cerca de $\nabla f(\mathbf{x}_k)^\top\boldsymbol\delta$. Pelo Teorema 1.4, para um tamanho de passo fixo, a maior redução ocorre na direção $-\nabla f(\mathbf{x}_k)$.

::: definicao 1.16 · Descida do Gradiente
A **Descida do Gradiente** (*Gradient Descent*, GD) gera, a partir de um ponto inicial $\mathbf{x}_0$, a sequência

$$
\mathbf{x}_{k+1} = \mathbf{x}_k - \eta\,\nabla f(\mathbf{x}_k), \qquad k = 0, 1, 2, \dots
$$

em que $\eta > 0$ é a **taxa de aprendizado** (*learning rate*).
:::

O algoritmo é uma **heurística local** justificada por uma aproximação: usa apenas a inclinação no ponto atual. A taxa $\eta$ decide quanto se confia nessa aproximação. Se $\eta$ é muito pequena, o progresso é lento. Se é grande demais, o passo ultrapassa a região em que a aproximação linear vale, e $f$ pode aumentar. Para uma classe importante de funções, é possível dizer exatamente onde está a fronteira.

### Análise exata no caso quadrático

Considere $f(\mathbf{x}) = \tfrac12\mathbf{x}^\top\mathbf{A}\mathbf{x} - \mathbf{b}^\top\mathbf{x}$, com $\mathbf{A}$ simétrica definida positiva. Então $\nabla f(\mathbf{x}) = \mathbf{A}\mathbf{x}-\mathbf{b}$, a Hessiana é $\mathbf{A}$ e o único mínimo é a solução $\mathbf{x}^\star$ de $\mathbf{A}\mathbf{x}^\star=\mathbf{b}$. O caso não é artificial: a perda da regressão linear tem essa forma e, perto de um mínimo, toda função suave é aproximadamente quadrática.

::: teorema 1.7 · Convergência da descida do gradiente em funções quadráticas
Sejam $\lambda_{\min}$ e $\lambda_{\max} = L$ o menor e o maior autovalores de $\mathbf{A}$. A descida do gradiente converge para $\mathbf{x}^\star$ a partir de qualquer ponto inicial se e somente se

$$
0 < \eta < \frac{2}{L}.
$$

Nesse caso, o erro satisfaz $\lVert\mathbf{x}_k - \mathbf{x}^\star\rVert_2 \le \rho^k\,\lVert\mathbf{x}_0 - \mathbf{x}^\star\rVert_2$, com $\rho = \max_i \lvert 1 - \eta\lambda_i\rvert$. A melhor taxa constante é $\eta = 2/(\lambda_{\min}+\lambda_{\max})$, para a qual

$$
\rho = \frac{\kappa - 1}{\kappa+1}, \qquad \kappa = \frac{\lambda_{\max}}{\lambda_{\min}}.
$$
:::

::: demonstracao
Seja $\mathbf{e}_k = \mathbf{x}_k - \mathbf{x}^\star$ o erro no passo $k$. Como $\mathbf{b} = \mathbf{A}\mathbf{x}^\star$, o gradiente é $\mathbf{A}\mathbf{x}_k - \mathbf{b} = \mathbf{A}\mathbf{e}_k$. Subtraindo $\mathbf{x}^\star$ dos dois lados da regra de atualização:

$$
\mathbf{e}_{k+1} = \mathbf{e}_k - \eta\mathbf{A}\mathbf{e}_k = (\mathbf{I} - \eta\mathbf{A})\,\mathbf{e}_k, \qquad\text{logo}\qquad \mathbf{e}_k = (\mathbf{I}-\eta\mathbf{A})^k\,\mathbf{e}_0 .
$$

Pelo teorema espectral, $\mathbf{A} = \mathbf{Q}\boldsymbol\Lambda\mathbf{Q}^\top$. Escrevendo o erro na base dos autovetores, $\mathbf{z}_k = \mathbf{Q}^\top\mathbf{e}_k$, a recorrência desacopla em $n$ recorrências escalares: $z_{k,i} = (1-\eta\lambda_i)^k z_{0,i}$. Cada componente tende a zero se e somente se $\lvert 1-\eta\lambda_i\rvert<1$, isto é, $0<\eta<2/\lambda_i$. A condição mais restritiva é a do maior autovalor, o que dá $\eta<2/L$. Como $\mathbf{Q}$ preserva normas, $\lVert\mathbf{e}_k\rVert_2 = \lVert\mathbf{z}_k\rVert_2\le\rho^k\lVert\mathbf{z}_0\rVert_2$. O valor de $\rho$ é minimizado quando os extremos se equilibram, $1-\eta\lambda_{\min} = -(1-\eta\lambda_{\max})$, o que fornece $\eta = 2/(\lambda_{\min}+\lambda_{\max})$ e o valor de $\rho$ enunciado.
:::

O teorema contém três lições que valem, qualitativamente, muito além do caso quadrático.

1. **A taxa de aprendizado segura é limitada pela maior curvatura.** A direção mais curva decide o maior passo possível.
2. **A velocidade é limitada pela menor curvatura.** Com o passo limitado pela direção mais curva, o avanço nas direções planas é lento.
3. **O número de condição $\kappa$ resume a dificuldade.** Com $\kappa = 100$, o erro cai apenas cerca de 2% por passo, mesmo com a melhor taxa constante. Problemas mal condicionados produzem a trajetória em zigue-zague da Figura 1.2.

<figure>
+++ fig_gd.svg
<figcaption><b>Figura 1.2.</b> Curvas de nível de <i>f</i>(<b>x</b>) = ½<b>x</b>ᵀ<b>Ax</b> − <b>b</b>ᵀ<b>x</b> para a matriz do programa a seguir, com duas trajetórias a partir do mesmo ponto. Com η = 1/L, a descida é direta. Com η = 0,5, próxima do limite 2/L ≈ 0,553, a trajetória oscila na direção de maior curvatura. O primeiro passo tem a mesma direção nas duas trajetórias; com η = 0,5 ele é longo demais e atravessa o vale. As coordenadas foram calculadas pelo mesmo algoritmo do programa.</figcaption>
</figure>

### Implementação

<<< codigo/c1_gradiente.py

>>> codigo/c1_gradiente.out

A saída confirma cada afirmação do teorema. A taxa $0{,}05$ converge, mas devagar. A taxa $1/L$ atinge a precisão da máquina. A taxa $0{,}5$ está abaixo de $2/L \approx 0{,}553$ e converge oscilando. A taxa $0{,}6$ está acima do limite: o erro cresce sem controle.

A função `grad_numerico` implementa uma prática indispensável, a **verificação de gradiente** (*gradient checking*): comparar o gradiente obtido analiticamente com uma aproximação por diferenças finitas. A fórmula central $\bigl(f(x+h)-f(x-h)\bigr)/2h$ tem erro de truncamento proporcional a $h^2$, contra $h$ da fórmula unilateral. O valor de $h$ não pode ser arbitrariamente pequeno, por causa do cancelamento descrito na seção 1.7; valores entre $10^{-5}$ e $10^{-7}$ funcionam bem em `float64`.

### Limitações

::: atencao O que a descida do gradiente não garante
- **Em funções não convexas**, a convergência é para um ponto crítico, que pode ser um mínimo local ou, em princípio, uma sela. O ponto atingido depende da inicialização.
- **A taxa de aprendizado não tem valor universal.** O limite $2/L$ depende da maior curvatura, que em redes neurais é desconhecida e varia ao longo do treinamento.
- **O custo por passo cresce com o número de exemplos.** O gradiente exato da perda soma contribuições de todos os dados.
:::

Cada limitação motiva um desenvolvimento do Capítulo 6. A última leva à Descida do Gradiente Estocástica (*Stochastic Gradient Descent*, SGD), que estima o gradiente com um pequeno lote de exemplos. As duas primeiras levam aos métodos com momento e com taxas adaptativas por parâmetro (Momentum, RMSProp, Adam), que tentam compensar o mau condicionamento sem calcular a Hessiana.

::: erro Confundir gradiente nulo com solução encontrada
Gradiente próximo de zero indica apenas um ponto crítico da perda **de treinamento**. Não distingue mínimo de sela e, mais importante, nada diz sobre o desempenho em dados novos. Minimizar a perda de treinamento é um meio; o fim é generalizar, assunto do Capítulo 5.
:::
