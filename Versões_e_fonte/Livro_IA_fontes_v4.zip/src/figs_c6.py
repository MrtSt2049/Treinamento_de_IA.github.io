"""Gera as figuras do Capítulo 6 (SVG) a partir de cálculos e de saídas reais dos programas."""
import numpy as np

CLS = {"v": "lv", "a": "la", "m": "lm", "g": "lg", "r": "lr"}


def fmt(v):
    return f"{v:.1f}"


def painel(x0, y0, w, h, xmin, xmax, ymin, ymax, xt, yt, xlabel=None, ylabel=None, ylog_fmt=None):
    """Eixos com grade fraca. Devolve (lista svg, funções de mapeamento)."""
    X = lambda v: x0 + (v - xmin) / (xmax - xmin) * w
    Y = lambda v: y0 + h - (v - ymin) / (ymax - ymin) * h
    s = []
    for v in yt:
        s.append(f'<line class="fraco" x1="{x0}" y1="{fmt(Y(v))}" x2="{x0+w}" y2="{fmt(Y(v))}"/>')
        lab = ylog_fmt(v) if ylog_fmt else f"{v:g}".replace(".", ",")
        s.append(f'<text class="t2" x="{x0-8}" y="{fmt(Y(v)+4)}" font-size="12" text-anchor="end">{lab}</text>')
    for v in xt:
        s.append(f'<line class="fraco" x1="{fmt(X(v))}" y1="{y0}" x2="{fmt(X(v))}" y2="{y0+h}"/>')
        s.append(f'<text class="t2" x="{fmt(X(v))}" y="{y0+h+16}" font-size="12" text-anchor="middle">{v:g}</text>')
    if xlabel:
        s.append(f'<text x="{x0+w/2}" y="{y0+h+36}" font-size="13" text-anchor="middle">{xlabel}</text>')
    if ylabel:
        s.append(f'<text transform="translate({x0-44},{y0+h/2}) rotate(-90)" font-size="13" text-anchor="middle">{ylabel}</text>')
    return s, X, Y


def curva(X, Y, xs, ys, cls, dash=None):
    pts = " ".join(f"{fmt(X(a))},{fmt(Y(b))}" for a, b in zip(xs, ys))
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<polyline class="{cls}"{d} points="{pts}"/>'


def legenda(itens, x0, y, passo):
    """itens: lista de (classe, rótulo, tracejado)."""
    out = []
    for i, (cls, nome, dash) in enumerate(itens):
        xx = x0 + i * passo
        d = f' stroke-dasharray="{dash}"' if dash else ""
        out.append(f'<line class="{cls}"{d} x1="{xx}" y1="{y}" x2="{xx+28}" y2="{y}"/><text x="{xx+36}" y="{y+4}" font-size="13">{nome}</text>')
    return out


def salvar(nome, largura, altura, aria, corpo):
    open(nome, "w").write(f'<svg class="fig" viewBox="0 0 {largura} {altura}" role="img" aria-label="{aria}">' + "".join(corpo) + "</svg>")


# ---------- Figura 6.1: ativações e derivadas ----------
z = np.linspace(-4, 4, 161)
sig = 1 / (1 + np.exp(-z))
ativ = {"v": ("sigmoide", sig), "a": ("tanh", np.tanh(z)), "g": ("ReLU", np.maximum(0, z)), "m": ("Leaky ReLU (0,1)", np.where(z > 0, z, 0.1 * z))}
deriv = {"v": sig * (1 - sig), "a": 1 - np.tanh(z) ** 2, "g": (z > 0).astype(float), "m": np.where(z > 0, 1.0, 0.1)}
c = []
s, X, Y = painel(60, 20, 270, 230, -4, 4, -1.5, 4, [-4, -2, 0, 2, 4], [-1, 0, 1, 2, 3, 4], "z", "φ(z)")
c += s
c.append(f'<line class="ln" x1="{fmt(X(0))}" y1="20" x2="{fmt(X(0))}" y2="250"/><line class="ln" x1="60" y1="{fmt(Y(0))}" x2="330" y2="{fmt(Y(0))}"/>')
for k, (nome, y) in ativ.items():
    c.append(curva(X, Y, z, y, CLS[k], "6 3" if k == "m" else None))
c.append(f'<text x="{fmt(X(-3.9))}" y="{fmt(Y(-1.15))}" font-size="12" fill="currentColor" class="t2">tanh</text>')
c.append(f'<text x="{fmt(X(1.6))}" y="{fmt(Y(3.5))}" font-size="12">ReLU</text>')
c.append(f'<text x="{fmt(X(-3.9))}" y="{fmt(Y(0.45))}" font-size="12" class="t2">sigmoide</text>')
s, X2, Y2 = painel(400, 20, 270, 230, -4, 4, 0, 1.2, [-4, -2, 0, 2, 4], [0, 0.25, 0.5, 1], "z", "φ′(z)")
c += s
for k, y in deriv.items():
    c.append(curva(X2, Y2, z, y, CLS[k], "6 3" if k == "m" else None))
c.append(f'<text x="{fmt(X2(-3.9))}" y="{fmt(Y2(1.07))}" font-size="12">ReLU: 0 ou 1</text>')
c.append(f'<text x="{fmt(X2(0.2))}" y="{fmt(Y2(0.69))}" font-size="12">tanh: máx. 1</text>')
c.append(f'<text x="{fmt(X2(-3.9))}" y="{fmt(Y2(0.31))}" font-size="12">sigmoide: máx. 0,25</text>')
# legenda
for i, (k, (nome, _)) in enumerate(ativ.items()):
    xx = 60 + i * 160
    c.append(f'<line class="{CLS[k]}" x1="{xx}" y1="312" x2="{xx+28}" y2="312"' + (' stroke-dasharray="6 3"' if k == "m" else "") + "/>")
    c.append(f'<text x="{xx+36}" y="316" font-size="13">{nome}</text>")')
salvar("fig_c6_ativ.svg", 700, 330, "Funções de ativação sigmoide, tanh, ReLU e Leaky ReLU, e suas derivadas", [x.replace('")', "") for x in c])

# ---------- Figura 6.2: otimizadores na quadrática mal condicionada ----------
h = np.load("/tmp/hist_otim.npz")
c = []
s, X, Y = painel(70, 20, 560, 250, 0, 300, -13, 2, [0, 50, 100, 150, 200, 250, 300], [-12, -9, -6, -3, 0], "iteração", "log₁₀ f(xₜ)", lambda v: f"{int(v)}")
c += s
tt = np.arange(300)
for k, cls in (("gd", "lv"), ("momentum", "la"), ("rmsprop", "lm"), ("adam", "lg")):
    c.append(curva(X, Y, tt, np.log10(np.maximum(h[k], 1e-13)), cls))
c += legenda([("lv", "GD", None), ("la", "Momentum (β=0,9)", None), ("lm", "RMSProp (η=0,05)", None), ("lg", "Adam (η=0,5)", None)], 40, 322, 160)
salvar("fig_c6_otim.svg", 660, 345, "Valor da função ao longo das iterações para GD, momentum, RMSProp e Adam", c)

# ---------- Figura 6.3: curvas de aprendizado do Projeto 3 ----------
hist = np.load("/tmp/p3_hist.npy")
c = []
s, X, Y = painel(70, 20, 560, 230, 0, 60, 0, 1.8, [0, 10, 20, 30, 40, 50, 60], [0, 0.5, 1.0, 1.5], "época", "perda (entropia cruzada)")
c += s
c.append(curva(X, Y, hist[:, 0], hist[:, 1], "lv"))
c.append(curva(X, Y, hist[:, 0], hist[:, 2], "la"))
c += legenda([("lv", "treino", None), ("la", "validação", None)], 360, 290, 110)
salvar("fig_c6_p3.svg", 660, 305, "Perda de treino e de validação por época na rede em NumPy do Projeto 3", c)

# ---------- Figura 6.4: grafo de computação com passos para frente e para trás ----------
c = ['<defs><marker id="pt-seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--tinta-2)"/></marker>'
     '<marker id="pt-setar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--rubi)"/></marker></defs>']
nos = [("x", 20, "entrada"), ("z¹ = W¹ᵀx + b¹", 120, "pré-ativação"), ("h¹ = ReLU(z¹)", 260, "ativação"), ("a = W²ᵀh¹ + b²", 400, "logits"), ("p = softmax(a)", 540, "probabilidades")]
larg = [60, 118, 118, 118, 108]
for (t, xx, sub), w in zip(nos, larg):
    c.append(f'<rect class="cx" x="{xx}" y="60" width="{w}" height="46" rx="8"/><text x="{xx+w/2}" y="88" font-size="13" text-anchor="middle">{t}</text>')
c.append('<rect class="cxm" x="560" y="170" width="88" height="40" rx="8"/><text x="604" y="195" font-size="13" text-anchor="middle">L(p, y)</text>')
fr = [(80, 120), (238, 260), (378, 400), (518, 540)]
for a, b in fr:
    c.append(f'<line class="seta" x1="{a}" y1="83" x2="{b}" y2="83"/>')
c.append('<line class="seta" x1="604" y1="106" x2="604" y2="170"/>')
c.append('<text x="30" y="40" font-size="13" class="t2">passo para frente: calcula e guarda z¹, h¹, a, p</text>')
# para trás
c.append('<line class="setar" x1="560" y1="190" x2="520" y2="130" style="marker-end:url(#pt-setar)"/>')
c.append('<path class="setar" d="M540,125 C540,150 470,150 458,112" style="marker-end:url(#pt-setar)"/>')
c.append('<path class="setar" d="M400,125 C390,150 330,150 318,112" style="marker-end:url(#pt-setar)"/>')
c.append('<path class="setar" d="M260,125 C250,150 190,150 178,112" style="marker-end:url(#pt-setar)"/>')
for xx, tt in ((470, 'δ² = p − y'), (330, 'W²δ²'), (190, '⊙ 1[z¹>0]')):
    c.append(f'<text x="{xx}" y="164" font-size="12" text-anchor="middle" style="fill:var(--rubi)">{tt}</text>')
c.append('<text x="20" y="205" font-size="13" fill="currentColor" style="fill:var(--rubi)">passo para trás (δ = ∂L/∂·):</text>')
linhas = ["δ² = ∂L/∂a = p − y", "∂L/∂W² = h¹ δ²ᵀ,   ∂L/∂b² = δ²", "δ¹ = (W² δ²) ⊙ 1[z¹ > 0]", "∂L/∂W¹ = x δ¹ᵀ,   ∂L/∂b¹ = δ¹"]
for i, t in enumerate(linhas):
    c.append(f'<text x="20" y="{232 + i*22}" font-size="13">{t}</text>')
salvar("fig_c6_backprop.svg", 680, 330, "Grafo de computação de uma rede de duas camadas, com o passo para frente e a retropropagação dos gradientes", c)
print("ok")
