<div class="objetivos">

Objetivos do capítulo

- Explicar **por que** injetar contexto privado ou atual no *prompt*: janela de contexto finita, conhecimento estático dos pesos, custo da atenção e necessidade de **fontes citáveis**; e comparar RAG, ajuste fino e contexto longo.
- Descrever o pipeline RAG de ponta a ponta e **mapear cada etapa** em objetos do LlamaIndex (`Document`, nós, fatiadores, `BaseEmbedding`, índice, recuperador, pós-processador, sintetizador, motor de consulta).
- Tratar a **ingestão** de documentos complexos (PDF, tabelas, código) e demonstrar, com código executado, o que um extrator simples perde.
- Deduzir as propriedades do **fatiamento** (número de janelas, cobertura por sobreposição) e comparar fatias fixas, semânticas e hierárquicas.
- Definir **embeddings**, mostrar que o cosseno e a distância euclidiana ordenam igual **se os vetores são unitários**, construir embeddings por **semântica latente** (TF-IDF e SVD) e medir o efeito da dimensão.
- Entender **bancos vetoriais** e a busca aproximada (IVF, HNSW), com um modelo de custo e uma medida de *recall* contra latência.
- Combinar recuperadores lexicais e densos por **fusão recíproca (RRF)**, reordenar candidatos, sintetizar a resposta com **citações** e **abster-se** quando o contexto não basta; avaliar a recuperação com perguntas de gabarito e intervalos de confiança.

**Pré-requisitos:** Capítulo 1 (álgebra linear, probabilidade), Capítulo 5 (avaliação, validação cruzada), Capítulo 9 (atenção e o custo do contexto), Capítulo 10 (tokenização, SVD e Eckart-Young), Capítulo 11 (contexto delimitado, calibração, saídas estruturadas).

</div>

## 12.1 O problema: janela de contexto e conhecimento estático

O Capítulo 11 terminou com uma constatação: a melhor defesa contra a **infidelidade ao contexto** é **dar o contexto certo**. Este capítulo trata de como escolher, a cada pergunta, o contexto certo dentre milhares de páginas.

Um LLM tem duas limitações estruturais que o contexto injetado compensa.

1. **Conhecimento estático e geral.** Os pesos refletem os dados de treino, até uma data de corte. O modelo não conhece o contrato da sua empresa, o manual do produto lançado ontem, nem este livro. Sobre o que **não** viu, ele tende a produzir texto plausível e falso (seção 11.4).
2. **Janela de contexto finita e cara.** O custo da autoatenção cresce com $O(T^2d)$ (seção 9.8), e a **qualidade** com contextos muito longos não é uniforme: a literatura relata que informações no meio de contextos longos são aproveitadas pior que as do início e do fim (Liu et al., 2024, citado de memória). Colocar "todo o corpus" no *prompt* é, em geral, caro, lento e menos preciso que colocar **os trechos certos**.

A solução é a **geração aumentada por recuperação** (*retrieval-augmented generation*, RAG; Lewis et al., 2020): antes de gerar, **recuperar** trechos relevantes de uma base externa e colocá-los no *prompt*. Formalmente, em vez de $p(y\mid x)$, o sistema usa

$$p(y\mid x)\;\approx\;p\bigl(y\mid x,\,z_1,\dots,z_k\bigr),\qquad (z_1,\dots,z_k)=\operatorname{recuperar}(x),$$

com $z_i$ os trechos recuperados. (O trabalho original **marginaliza** sobre os documentos, $\sum_zp(z\mid x)\,p(y\mid x,z)$; na prática de engenharia, concatenam-se os $k$ trechos no *prompt* e deixa-se o modelo gerar.) O desempenho do conjunto é limitado pelo **elo mais fraco**: se o trecho certo não for recuperado, nenhum LLM, por melhor que seja, pode usá-lo. Por isso **este capítulo trata principalmente de recuperação**, e a recuperação é medida **separadamente** da geração.

| | RAG | Ajuste fino (Cap. 10) | Contexto longo |
|---|---|---|---|
| O que muda | Só o *prompt*; os pesos ficam iguais | Os pesos (completo ou LoRA) | Só o *prompt* (tudo de uma vez) |
| Atualizar o conhecimento | Reindexar o documento novo | Treinar de novo | Trocar o *prompt* |
| Citar a fonte | Natural: o trecho vem com origem | Difícil: o conhecimento está nos pesos | Possível, com custo |
| Custo por consulta | Recuperação + *prompt* curto | Só o *prompt* da pergunta | *Prompt* enorme, atenção quadrática |
| Esquecimento | Nenhum | Real: no Projeto 7, o ajuste completo foi de $57{,}1$ a $83{,}3$ de perplexidade na origem | Nenhum |
| Aprende um **estilo ou formato** | Pouco | Bem | Pouco |
| Principal risco | Recuperar o trecho errado | Dados e custo de treino; alucinação continua | Custo; perda de informação no meio |

As abordagens se combinam: ajusta-se o modelo para seguir o formato e usa-se RAG para o conhecimento. Uma regra prática: **conhecimento factual que muda ou precisa de fonte vai para a recuperação; comportamento e estilo vão para o ajuste.**

## 12.2 Anatomia de um pipeline RAG

O pipeline tem duas fases com ritmos diferentes (Figura 12.1). A **indexação** roda quando o corpus muda e é cara, mas é feita uma vez; a **consulta** roda a cada pergunta e precisa ser rápida.

<figure>
+++ fig_c12_pipeline.svg
<figcaption><b>Figura 12.1.</b> O pipeline RAG deste capítulo. Em cima, a indexação (offline); embaixo, a consulta (online). A etapa de abstenção decide se o contexto recuperado basta; se não, o sistema responde que não encontrou, em vez de deixar o modelo inventar.</figcaption>
</figure>

O LlamaIndex organiza cada etapa em uma abstração. O Projeto 8 (seção 12.9) usa **todas** elas, e **estende** algumas por herança, porque o ambiente não dispõe de um modelo de *embeddings* pré-treinado nem de um LLM.

| Etapa | Abstração do LlamaIndex | Papel | No Projeto 8 |
|---|---|---|---|
| Documento | `Document` | Texto de uma fonte, com metadados | Uma seção do livro |
| Fatiamento | `SentenceSplitter`, `HierarchicalNodeParser`, `SemanticSplitterNodeParser` | Divide o documento em **nós** (`TextNode`) | Os três, mais seção inteira |
| Embedding | `BaseEmbedding` | Texto $\to$ vetor | Subclasse própria: semântica latente (LSA) |
| Índice | `VectorStoreIndex`, `StorageContext`, `FaissVectorStore` | Guarda os vetores e busca os vizinhos | Memória e FAISS (flat e HNSW) |
| Recuperação | `BaseRetriever`, `QueryFusionRetriever`, `AutoMergingRetriever` | Dada a pergunta, devolve nós com pontuação | Denso, BM25 (subclasse própria), RRF, fusão automática |
| Pós-processamento | `BaseNodePostprocessor`, `SimilarityPostprocessor` | Filtra, reordena, corta por limiar | Corte por cosseno (abstenção) |
| Síntese | `get_response_synthesizer`, `CustomLLM` | Monta o *prompt* e chama o LLM | LLM **extrativo** (stand-in, não gerativo) |
| Motor de consulta | `RetrieverQueryEngine` | Cola recuperação e síntese | Idem |

::: nota Os dois "stand-ins" do projeto, ditos logo de saída
**(1) Embeddings:** como não havia acesso ao Hugging Face Hub (nem a APIs de *embeddings*), o vetor de cada trecho vem da **semântica latente** (seção 12.5): TF-IDF reduzido por SVD, ajustado só com o texto do corpus. É um *embedding* legítimo e antigo (Deerwester et al., 1990), mas **muito mais fraco para paráfrases** do que um modelo neural treinado com aprendizado contrastivo. **(2) LLM:** a "resposta" vem de um `CustomLLM` **extrativo** que escolhe a frase do contexto de maior sobreposição com a pergunta e cita a seção. Ele **não gera** texto: serve para exercitar e medir o resto do pipeline. Nada neste capítulo mede a qualidade de respostas de um LLM real.
:::

## 12.3 Ingestão e *parsing* de documentos

A recuperação só pode achar o que **o texto extraído** contém. Boa parte dos fracassos de RAG em produção nasce aqui, e não no modelo.

- **PDF.** Um PDF guarda **instruções de desenho** (onde pôr cada caractere), não parágrafos. Extratores simples reconstroem a ordem de leitura por heurística: colunas se misturam, cabeçalhos e rodapés se repetem em todas as páginas, e **tabelas** viram células soltas. PDFs digitalizados são imagens e exigem **OCR**.
- **Tabelas.** O valor de uma célula só faz sentido junto do **cabeçalho da coluna** e do **rótulo da linha**. Se o fatiamento separa os dois, a célula vira um número órfão.
- **Código.** Indentação e a unidade lógica (função, classe) importam. Fatiar uma função ao meio destrói o sentido; o ideal é dividir por estrutura (por exemplo, por definição).
- **Metadados** (fonte, página, seção, data, autor): servem para **filtrar** ("só documentos de 2025"), para **citar** e para **depurar**. Cuidado: se o metadado entra no texto que gera o *embedding*, ele **contamina** o vetor. No LlamaIndex, isso se controla com `excluded_embed_metadata_keys`. A primeira versão do código do Projeto 8 deixava o metadado entrar; ao corrigir, os números de algumas estratégias mudaram em até cerca de $0{,}05$ no *hit@1* (o registro está em `src/brutos/`).

O **LlamaParse** é um serviço em nuvem do ecossistema LlamaIndex que converte PDFs e outros formatos complexos em Markdown preservando estrutura (tabelas, títulos, listas), tipicamente usando modelos de visão e linguagem. Como exige chave de API e rede, **não foi executado neste livro**. O padrão de uso, que muda entre versões (o pacote mudou de nome ao longo do tempo; confira a documentação atual), é:

```python
# NÃO EXECUTADO: ilustrativo; exige chave de API e rede, e os nomes de pacote e de parâmetros mudam com as versões
from llama_cloud_services import LlamaParse            # antes distribuído como o pacote "llama-parse"
from llama_index.core import SimpleDirectoryReader

analisador = LlamaParse(result_type="markdown")        # chave lida do ambiente
documentos = SimpleDirectoryReader("./pdfs", file_extractor={".pdf": analisador}).load_data()
```

O que **foi** executado é a demonstração do problema com um extrator simples (`pypdf`): um PDF gerado com um título, uma tabela e um trecho de código.

<<< codigo/c12_parsing.py

>>> codigo/c12_parsing.out

O texto sai, mas a tabela virou uma coluna de células soltas. A pergunta "qual a perplexidade do ajuste completo?" depende de ligar `51,08` ao cabeçalho e à linha, e essa ligação não está no texto. A **linearização** abaixo do código (uma frase por linha, com o cabeçalho repetido em cada célula) faz cada frase se sustentar **sozinha** como trecho: é o que um *parser* consciente de tabelas e um bom fatiador fazem por você. Para tabelas grandes, convém também indexar um **resumo** da tabela e guardar a tabela inteira como metadado, para o LLM consultar depois de recuperada.

Neste projeto, o corpus é o **texto expositivo** dos Capítulos 1 a 11, e a "ingestão" é a conversão do Markdown em prosa: remove-se a matemática ($\ldots$), as inclusões de código e de figuras e as cercas dos contêineres, e mantém-se o título de cada seção, que é **prefixado** ao texto (é informação que o autor colocou ali para o leitor, e que também ajuda a recuperar). **Sem as fórmulas**, o índice não responde a perguntas **sobre** fórmulas específicas: é uma limitação assumida.

## 12.4 Fatiamento (*chunking*)

Um documento inteiro raramente é a melhor unidade de recuperação: o vetor de um texto longo é uma **média** de muitos assuntos, e o *prompt* se enche de texto irrelevante. Fatias pequenas dão vetores mais específicos, mas perdem o contexto em volta ("ele", "essa regra", "o modelo acima"). Não há tamanho universalmente certo.

### Janelas fixas com sobreposição

A estratégia mais simples: janelas de $c$ palavras (ou tokens), avançando $p=c-o$ por vez, de modo que janelas vizinhas compartilham $o$ unidades (a **sobreposição**). O `SentenceSplitter` do LlamaIndex faz isso respeitando fronteiras de frase, e por isso as janelas reais variam em torno do tamanho pedido.

::: proposicao 12.1 · Janelas com sobreposição
Considere um texto de $L$ palavras dividido em janelas **ideais** de $c$ palavras com avanço $p=c-o$ ($0\le o<c$), a primeira começando na posição $0$.

1. O número de janelas é $\left\lceil \dfrac{L-o}{c-o}\right\rceil$, e o texto é indexado $\dfrac{c}{c-o}$ vezes (a **taxa de duplicação**), aproximadamente.
2. **Cobertura.** Todo trecho contínuo de $s$ palavras está contido em **alguma** janela se, e somente se, $s\le o+1$. Em particular, com $o=0$, trechos de duas palavras podem ser partidos ao meio.
:::

::: demonstracao
(1) As janelas começam em $0,p,2p,\dots$ e a última precisa tocar o fim do texto: o menor $n$ com $(n-1)p+c\ge L$ é $n=\lceil (L-c)/p\rceil+1=\lceil (L-o)/(c-o)\rceil$. Cada palavra aparece em $c/p$ janelas, em média. (2) Um trecho que começa na posição $i$ e termina em $i+s-1$ cabe na janela de índice $j$ se $jp\le i$ e $i+s\le jp+c$. Escreva $i=jp+r$ com $0\le r<p$ e tome $j=\lfloor i/p\rfloor$: a segunda condição vira $r+s\le c$. O pior caso é $r=p-1$, que exige $s\le c-p+1=o+1$. Se $s\le o+1$, **todo** $r$ serve (suficiência). Se $s=o+2$, o trecho que começa em $i=jp+p-1$ não cabe na janela $j$ (que termina antes dele) e começa depois do início da janela $j+1$ por uma palavra a menos que o necessário: não cabe em nenhuma, desde que o texto seja longo o bastante (necessidade).
:::

A verificação por força bruta está no Exercício 12.10 (e no programa `c12_ex_numeros.py`): para $L=1000$, $c=150$, $o=30$, trechos de $31$ palavras sempre cabem; de $32$, não. A sobreposição é, portanto, uma **garantia de não partir** uma resposta curta, paga com a taxa de duplicação (Exercício 12.1: com $c=150$ e $o=30$, cerca de $25\%$ a mais de texto para indexar).

### Fatiamento hierárquico e fusão automática

Uma alternativa é indexar **fatias pequenas** (precisas) e, na hora de montar o contexto, **devolver a fatia maior** que as contém. O `HierarchicalNodeParser` cria uma árvore (por exemplo, nós de $600$ palavras com filhos de $150$), e o `AutoMergingRetriever` troca os filhos recuperados pelo **pai** quando uma fração suficiente dos filhos dele foi recuperada. Ideia: se vários trechos vizinhos da mesma seção são relevantes, a seção inteira provavelmente é. O experimento da seção 12.9 mede o que isso ganha e o que custa.

### Fatiamento semântico

Em vez de cortar por tamanho, o `SemanticSplitterNodeParser` calcula o *embedding* de cada frase (ou grupo pequeno de frases) e **corta onde a distância entre frases vizinhas é grande**: acima de um percentil escolhido. Fatias passam a seguir os assuntos, mas o resultado depende do modelo de *embeddings* e produz fatias de tamanhos muito desiguais.

::: atencao Duas armadilhas encontradas ao construir o projeto
**1. Fragmentos vazios.** Depois de remover as fórmulas, sobram fragmentos como `Se , então .`. O vetor desse trecho é **nulo**, e a similaridade do cosseno com um vetor nulo é $0/0$, ou seja, **NaN**. Na ordenação, os NaN ficam **no topo**. Com o fatiador semântico (que gera fragmentos pequenos), o *hit@1* da recuperação densa caía para $0{,}05$; o BM25, sobre os mesmos nós, ia bem ($0{,}88$), o que denunciou que o problema era de **vetor**, não de **texto**. A correção é descartar nós com menos de $8$ termos de conteúdo (`uteis()` no código). **2. Metadados no embedding** (seção 12.3).
:::

### Resultado comparativo

O programa abaixo compara oito estratégias de fatiamento com três recuperadores (denso, BM25 e híbrido por RRF, seção 12.7), em dois conjuntos de perguntas (seção 12.9): **diretas** (43) e **parafraseadas** (24, que evitam os termos técnicos da seção). A configuração foi **fixada antes** de ver os resultados.

<<< codigo/p8_exp1_fatiamento.py

>>> codigo/p8_exp1_fatiamento.out

<figure>
+++ fig_c12_fatiamento.svg
<figcaption><b>Figura 12.2.</b> À esquerda, MRR@10 contra o tamanho médio do trecho (palavras, escala logarítmica) para recuperação densa (violeta) e BM25 (azul), nas perguntas diretas (contínua) e parafraseadas (tracejada). À direita, MRR@10 do LSA denso contra a dimensão do espaço latente (janelas de $150$ palavras); as linhas verdes pontilhadas são o TF-IDF puro, sem redução de dimensão (experimento 2, seção 12.5).</figcaption>
</figure>

O que se pode e o que não se pode concluir.

- **Nas perguntas diretas, tudo funciona** ($hit@5\ge0{,}95$ em quase todas as células, $MRR$ entre $0{,}82$ e $0{,}95$): se a pergunta usa as palavras do texto, qualquer fatiamento e qualquer recuperador acha a seção. Isso mostra que um gabarito feito só de perguntas diretas **não separa** os métodos.
- **Nas parafraseadas, os números caem** ($MRR$ de $0{,}55$ a $0{,}73$) e o BM25 é, na maior parte das linhas, **melhor** que o LSA denso: os radicais em comum (o BM25 usa os radicais do português) pesam mais que a semântica latente aprendida em apenas $60\,000$ palavras.
- **O tamanho do trecho tem efeito pequeno e não monotônico.** Trechos muito curtos ($40$ palavras) são os piores nas perguntas diretas (MRR $0{,}82$ a $0{,}84$ contra $0{,}87$ a $0{,}95$ nos demais); nas parafraseadas, o melhor valor do BM25 está em $85$ palavras ($0{,}73$) e o do denso em $234$ ($0{,}68$). Com **$24$ perguntas parafraseadas**, cada pergunta vale $4{,}2$ pontos percentuais de *hit@1*: **a maior parte dessas diferenças está dentro do ruído**. Os intervalos de confiança aparecem no experimento 3.
- **O fatiador semântico não se distingue** de uma janela simples depois da correção dos nós degenerados (melhor MRR denso nas diretas, $0{,}93$, mas $0{,}60$ nas parafraseadas), e custa mais: calcula um *embedding* por frase na indexação e descartou $48$ fragmentos inúteis.

Uma conclusão prática segura: **comece com janelas de $100$ a $300$ palavras com sobreposição de cerca de $20\%$, meça no **seu** conjunto de perguntas**, e só então refine.
