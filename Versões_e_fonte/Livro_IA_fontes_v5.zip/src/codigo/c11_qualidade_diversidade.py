"""Capítulo 11: qualidade contra diversidade para várias estratégias de decodificação, no GPT-2 minúsculo do Projeto 7.

Para cada estratégia geram-se 8 continuações de 60 tokens por prefixo (55 prefixos de 32 tokens, um por bloco de validação da origem).
Métricas (por estratégia, média):
  - NLL: perda média, em nats por token, dos tokens gerados segundo o MODELO com T=1 (baixa = tokens prováveis; não é 'qualidade' humana);
  - distinct-2: fração de bigramas distintos entre todos os bigramas das 8 continuações do mesmo prefixo (diversidade entre amostras);
  - rep-4: fração de tokens de uma continuação que pertencem a um 4-grama que já ocorreu antes na mesma continuação (repetição)."""
import numpy as np
import torch

from c11_amostragem import min_p, penalidades, temperatura, top_k, top_p
from m11 import BLOCO, carregar

d, tok, ds, modelo = carregar()
torch.manual_seed(0)
x = torch.tensor(ds["orig_va"]["input_ids"])[:, :32]
N, L, M = x.shape[0], 60, 8
V = modelo.config.vocab_size


@torch.no_grad()
def gerar(config):
    ids = x.repeat_interleave(M, 0)                                     # (N*M, 32)
    cont = torch.zeros(ids.shape[0], V)
    nll = torch.zeros(ids.shape[0])
    for _ in range(L):
        z = modelo(input_ids=ids).logits[:, -1, :]
        logp_ref = torch.log_softmax(z, -1)                              # modelo com T=1, sem truncamento
        zz = penalidades(z, cont, config.get("freq", 0.0), config.get("pres", 0.0))
        if config.get("T", 1.0) != 1.0:
            zz = temperatura(zz, config["T"])
        if "k" in config:
            zz = top_k(zz, config["k"])
        if "p" in config:
            zz = top_p(zz, config["p"])
        if "m" in config:
            zz = min_p(zz, config["m"])
        prox = zz.argmax(-1) if config.get("guloso") else torch.multinomial(torch.softmax(zz, -1), 1)[:, 0]
        nll += -logp_ref.gather(-1, prox[:, None])[:, 0]
        cont.scatter_add_(1, prox[:, None], torch.ones(len(prox), 1))
        ids = torch.cat([ids, prox[:, None]], 1)
    return ids[:, x.shape[1]:], nll / L


def distinct2(g):
    g = g.reshape(N, M, L)
    r = []
    for i in range(N):
        bi = [(int(a), int(b)) for s in g[i] for a, b in zip(s[:-1], s[1:])]
        r.append(len(set(bi)) / len(bi))
    return float(np.mean(r))


def rep4(g):
    r = []
    for s in g.tolist():
        vistos, rep = set(), np.zeros(L, bool)
        for i in range(L - 3):
            q = tuple(s[i:i + 4])
            if q in vistos:
                rep[i:i + 4] = True
            vistos.add(q)
        r.append(rep.mean())
    return float(np.mean(r))


configs = [
    ("guloso (T→0)", {"guloso": True}),
    ("T=0,5", {"T": 0.5}), ("T=0,8", {"T": 0.8}), ("T=1,0 (puro)", {}), ("T=1,3", {"T": 1.3}), ("T=2,0", {"T": 2.0}),
    ("top-k=10", {"k": 10}), ("top-k=40", {"k": 40}),
    ("top-p=0,5", {"p": 0.5}), ("top-p=0,9", {"p": 0.9}), ("min-p=0,1", {"m": 0.1}),
    ("T=0,8 + top-p=0,9", {"T": 0.8, "p": 0.9}),
    ("guloso + freq. 0,5", {"guloso": True, "freq": 0.5}),
    ("T=0,8 + freq. 0,5", {"T": 0.8, "freq": 0.5}),
]
print(f"{N} prefixos x {M} amostras x {L} tokens; vocabulário {V}")
print(f"{'estratégia':24s} {'NLL (nats)':>11} {'distinct-2':>11} {'rep-4':>7}")
for nome, cfg in configs:
    g, nll = gerar(cfg)
    print(f"{nome:24s} {float(nll.mean()):11.3f} {distinct2(g):11.3f} {rep4(g):7.3f}", flush=True)

print("\namostra (prefixo do bloco 0 e três estratégias; texto decodificado pelo tokenizador do Projeto 7):")
pref = tok.decode(x[0].tolist())
print("PREFIXO:", repr(pref[-120:]))
for nome, cfg in (("guloso", {"guloso": True}), ("T=1,0 (puro)", {}), ("T=0,8 + top-p=0,9", {"T": 0.8, "p": 0.9})):
    torch.manual_seed(1)
    g, _ = gerar(cfg)
    print(f"{nome:20s}:", repr(tok.decode(g[0].tolist())[:200]))
