"""Projeto 8, experimento 5: quando NÃO responder. Perguntas respondíveis (67) contra perguntas sem resposta no livro, longe do
domínio (16) e perto do domínio (6). Pontuações de confiança do recuperador: cosseno do melhor trecho (denso), BM25 bruto do melhor
trecho e BM25 normalizado (fração do máximo possível dado o vocabulário da pergunta)."""
import json

from llama_index.core import VectorStoreIndex
from llama_index.core.postprocessor import SimilarityPostprocessor
from llama_index.core.schema import QueryBundle
from sklearn.metrics import roc_auc_score

from p8_comum import *
from p8_gold import PERTO_DO_DOMINIO

nos = uteis(nos_fixos(S, 150, 30))
e = embedding(128)
idx = VectorStoreIndex(nos, embed_model=e)
dens = idx.as_retriever(similarity_top_k=5)
bm = BM25PT(nos, top_k=5)
idf = bm.bm25.idf
K1 = 1.5


def pontuacoes(q):
    d = dens.retrieve(q)
    b = bm.retrieve(q)
    qs = {t for t in tokens(q) if t in idf}
    maximo = sum(idf[t] * (K1 + 1) for t in qs if idf[t] > 0)
    cos0 = d[0].score if np.isfinite(d[0].score) else 0.0        # vetor nulo (nenhum termo conhecido): similaridade indefinida (NaN), tratada como 0
    return {"denso": cos0, "bm25": b[0].score, "bm25 normalizado": b[0].score / maximo if maximo > 0 else 0.0}, d, b


grupos = {"respondíveis": [q for q, _ in DIRETAS + PARAF], "longe do domínio": FORA_DO_CORPUS, "perto do domínio": PERTO_DO_DOMINIO}
pont = {g: [pontuacoes(q)[0] for q in qs] for g, qs in grupos.items()}
nulos = sum(1 for q in FORA_DO_CORPUS + PERTO_DO_DOMINIO + [q for q, _ in DIRETAS + PARAF] if not np.isfinite(dens.retrieve(q)[0].score))
print(f"perguntas com vetor nulo (nenhum radical conhecido; cosseno indefinido, tratado como 0): {nulos}")
print(f"perguntas: {', '.join(f'{g} {len(q)}' for g, q in grupos.items())}")
print(f"\n{'pontuação':18s} {'grupo':18s} {'mediana':>8} {'mín':>7} {'máx':>7}")
for nome in ("denso", "bm25", "bm25 normalizado"):
    for g in grupos:
        v = np.array([p[nome] for p in pont[g]])
        print(f"{nome:18s} {g:18s} {np.median(v):8.3f} {v.min():7.3f} {v.max():7.3f}")

rng = np.random.default_rng(0)
print("\nAUROC (probabilidade de a pontuação de uma pergunta respondível superar a de uma sem resposta; 0,5 = acaso), IC95% por bootstrap")
res = {}
for nome in ("denso", "bm25", "bm25 normalizado"):
    pos = np.array([p[nome] for p in pont["respondíveis"]])
    for neg_nome in ("longe do domínio", "perto do domínio", "ambos"):
        neg = np.array([p[nome] for g in (["longe do domínio", "perto do domínio"] if neg_nome == "ambos" else [neg_nome]) for p in pont[g]])
        y = np.r_[np.ones(len(pos)), np.zeros(len(neg))]; s = np.r_[pos, neg]
        a = roc_auc_score(y, s)
        bs = []
        for _ in range(2000):
            ip, ineg = rng.integers(0, len(pos), len(pos)), rng.integers(0, len(neg), len(neg))
            bs.append(roc_auc_score(np.r_[np.ones(len(ip)), np.zeros(len(ineg))], np.r_[pos[ip], neg[ineg]]))
        res[(nome, neg_nome)] = a
        print(f"  {nome:18s} contra {neg_nome:18s} {a:.3f}  [{np.percentile(bs, 2.5):.3f}, {np.percentile(bs, 97.5):.3f}]")

print("\nPonto de operação com o cosseno do melhor trecho: limiar t (responde se cosseno >= t)")
pos = np.array([p["denso"] for p in pont["respondíveis"]]); neg_l = np.array([p["denso"] for p in pont["longe do domínio"]]); neg_p = np.array([p["denso"] for p in pont["perto do domínio"]])
acerto_top1 = []
for q, g in DIRETAS + PARAF:
    acerto_top1.append(secao_de(dens.retrieve(q)[0].node) in g)
acerto_top1 = np.array(acerto_top1)
print(f"{'limiar':>7} {'respondíveis respondidas':>25} {'acerto do top-1 entre as respondidas':>38} {'longe respondidas':>18} {'perto respondidas':>18}")
for t in (0.0, 0.2, 0.3, 0.4, 0.5, 0.6):
    r = pos >= t
    print(f"{t:7.2f} {r.mean():25.2f} {acerto_top1[r].mean() if r.any() else float('nan'):38.2f} {(neg_l >= t).mean():18.2f} {(neg_p >= t).mean():18.2f}")

# o mesmo corte aplicado pelo componente do LlamaIndex (SimilarityPostprocessor) decide igual?
t = 0.4
pp = SimilarityPostprocessor(similarity_cutoff=t)
concorda, discordam = 0, []
todas = grupos["respondíveis"] + grupos["longe do domínio"] + grupos["perto do domínio"]
for q in todas:
    d = dens.retrieve(q)
    ok = (len(pp.postprocess_nodes(d, query_bundle=QueryBundle(q))) > 0) == (np.nan_to_num(d[0].score) >= t)
    concorda += ok
    if not ok:
        discordam.append((q, d[0].score))
print(f"\nSimilarityPostprocessor(similarity_cutoff={t}) decide como 'melhor cosseno >= {t}' em {concorda} de {len(todas)} perguntas")

for q, sc in discordam:
    print(f"   discordância: {q!r}: cosseno do melhor trecho = {sc}; o postprocessador MANTÉM o trecho (NaN < {t} é falso), a regra com NaN->0 recusaria")
json.dump({"pont": pont, "acerto_top1": acerto_top1.tolist()}, open("p8_abstencao.json", "w"))
