"""Módulo comum do Capítulo 11: carrega o GPT-2 minúsculo pré-treinado do Projeto 7 (Capítulo 10) e seus dados."""
import warnings

import numpy as np
import torch
from transformers import GPT2LMHeadModel

from p7_comum import BASE, BLOCO, dados

warnings.filterwarnings("ignore")
torch.set_num_threads(2)


def carregar():
    d, tok, ds, ntok = dados()
    modelo = GPT2LMHeadModel.from_pretrained(BASE).eval()
    return d, tok, ds, modelo


@torch.no_grad()
def logits_proximo(modelo, ids):
    """Logits do próximo token para cada prefixo (lote x vocabulário)."""
    return modelo(input_ids=ids).logits[:, -1, :]


def entropia(p, eixo=-1):
    return -(p * torch.log(p.clamp_min(1e-30))).sum(eixo)
