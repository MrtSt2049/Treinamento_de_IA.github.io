"""Projeto 8, experimento 1: estratégia de fatiamento (chunking) x recuperador, em dois conjuntos de perguntas.
Configuração FIXADA ANTES de ver os resultados: embedding LSA dim 128; BM25 k1=1,5 b=0,75; RRF com k=60; k=10 trechos."""
import time

from llama_index.core import VectorStoreIndex
from llama_index.core.retrievers import QueryFusionRetriever

from p8_comum import *

K = 10
emb = embedding(128)


def recuperadores(nos):
    idx = VectorStoreIndex(nos, embed_model=emb)
    dens = idx.as_retriever(similarity_top_k=K)
    bm = BM25PT(nos, top_k=K)
    hib = QueryFusionRetriever([dens, bm], similarity_top_k=K, num_queries=1, mode="reciprocal_rerank", use_async=False, verbose=False)
    return {"denso (LSA)": dens, "BM25": bm, "híbrido (RRF)": hib}


t0 = time.time()
todos_h, folhas = nos_hierarquicos(S, (600, 150))
brutas = {
    "seção inteira": nos_secao(S),
    "janela 50 (sobrep. 10)": nos_fixos(S, 50, 10),
    "janela 100 (sobrep. 20)": nos_fixos(S, 100, 20),
    "janela 150 (sobrep. 30)": nos_fixos(S, 150, 30),
    "janela 150 (sem sobrep.)": nos_fixos(S, 150, 0),
    "janela 300 (sobrep. 60)": nos_fixos(S, 300, 60),
    "hierárquico (folhas de 150)": folhas,
    "semântico (limiar 90)": nos_semanticos(S, emb, 90),
}
estrategias = {nome: uteis(nos) for nome, nos in brutas.items()}
print(f"{'estratégia':30s} {'nós':>5} {'descartados':>12} {'palavras/nó':>12}")
for nome, nos in estrategias.items():
    pal = np.mean([len(n.get_content().split()) for n in nos])
    print(f"{nome:30s} {len(nos):5d} {len(brutas[nome]) - len(nos):12d} {pal:12.0f}")

for rotulo, perguntas in (("PERGUNTAS DIRETAS (43)", DIRETAS), ("PERGUNTAS PARAFRASEADAS (24)", PARAF)):
    print(f"\n{rotulo}: hit@1 / hit@5 / MRR@10 / nDCG@10")
    print(f"{'estratégia':30s} " + " ".join(f"{r:>26s}" for r in ("denso (LSA)", "BM25", "híbrido (RRF)")))
    for nome, nos in estrategias.items():
        rs = recuperadores(nos)
        cel = []
        for r in ("denso (LSA)", "BM25", "híbrido (RRF)"):
            m = avaliar(rs[r], perguntas, K)
            cel.append(f"{m['hit@1']:.2f}/{m['hit@5']:.2f}/{m['MRR@10']:.2f}/{m['nDCG@10']:.2f}")
        print(f"{nome:30s} " + " ".join(f"{c:>26s}" for c in cel))
print(f"\n(tempo total {time.time() - t0:.0f} s)")
