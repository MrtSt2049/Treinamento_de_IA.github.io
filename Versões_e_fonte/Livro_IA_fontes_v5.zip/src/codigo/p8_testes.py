"""Projeto 8: testes automáticos dos componentes (rodam em poucos segundos, sem modelo de linguagem)."""
import math

import numpy as np
from llama_index.core import VectorStoreIndex
from llama_index.core.postprocessor import SimilarityPostprocessor
from llama_index.core.retrievers import QueryFusionRetriever
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode
from sklearn.model_selection import StratifiedKFold

from p8_comum import *

n_ok = 0


def teste(nome):
    def deco(f):
        global n_ok
        f(); n_ok += 1
        print(f"  ok  {nome}")
        return f
    return deco


@teste("gabarito: cada seção existe, a chave aparece em alguma seção do gabarito e, nas parafraseadas, NÃO aparece na pergunta")
def _():
    ids = {s["id"] for s in S}
    assert len(ids) == len(S) == 99
    for q, g, k in EM_CORPUS + PARAFRASEADAS:
        assert set(g) <= ids
        assert any(k in sem_acento(TEXTO[i].lower()) for i in g), (q, k)
    for q, g, k in PARAFRASEADAS:
        assert k not in sem_acento(q.lower()), (q, k)
    assert not (set(FORA_DO_CORPUS) & {q for q, _, _ in EM_CORPUS})


@teste("limpeza: o texto indexado não tem fórmulas ($), includes (<<<, >>>) nem cercas de contêiner (:::)")
def _():
    for s in S:
        assert not any(x in s["texto"] for x in ("$", "<<<", ">>>", ":::", "+++")), s["id"]


@teste("fatiamento sem sobreposição: as janelas, concatenadas, reproduzem as palavras do documento na mesma ordem")
def _():
    nos = nos_fixos(S, 150, 0)
    por_sec = {}
    for n in nos:
        por_sec.setdefault(secao_de(n), []).extend(n.get_content().split())
    for s in S[:30]:
        assert por_sec[s["id"]] == TEXTO[s["id"]].split(), s["id"]


@teste("fatiamento com sobreposição: toda palavra do documento aparece em alguma janela, e janelas consecutivas compartilham texto")
def _():
    nos = nos_fixos(S, 150, 30)
    por_sec = {}
    for n in nos:
        por_sec.setdefault(secao_de(n), []).append(n.get_content())
    for s in S[:30]:
        assert set(TEXTO[s["id"]].split()) <= set(" ".join(por_sec[s["id"]]).split())
    comuns = [len(set(a.split()[-40:]) & set(b.split()[:40])) for l in por_sec.values() for a, b in zip(l, l[1:])]
    assert np.mean([c > 0 for c in comuns]) > 0.95


@teste("hierarquia: o texto de cada folha está contido no do pai, e as folhas são os nós sem filhos")
def _():
    todos, folhas = nos_hierarquicos(S[:20], (600, 150))
    por_id = {n.node_id: n for n in todos}
    assert all(not n.child_nodes for n in folhas)
    for f in folhas:
        if f.parent_node:
            assert " ".join(f.get_content().split()) in " ".join(por_id[f.parent_node.node_id].get_content().split())


@teste("nós degenerados: 'Se , então .' é descartado por uteis(); sem o filtro, o cosseno de um vetor nulo é NaN")
def _():
    e = embedding(128)
    lixo = anotar([TextNode(text="Se , então . ", id_="x")])[0]
    assert uteis([lixo]) == []
    v = np.array(e._get_text_embeddings(["Se , então ."]))
    assert np.allclose(v, 0)
    d = VectorStoreIndex([lixo], embed_model=e).as_retriever(similarity_top_k=1).retrieve("regra da cadeia")
    assert not np.isfinite(d[0].score)


@teste("embedding LSA: vetores de trecho e de pergunta têm norma 1; texto sem termo conhecido dá vetor nulo")
def _():
    e = embedding(128)
    v = np.array(e._get_text_embeddings([TEXTO["5.4"][:600], "Qual é a capital da Austrália?"]))
    assert abs(np.linalg.norm(v[0]) - 1) < 1e-6 and np.linalg.norm(v[1]) < 1e-9


@teste("BM25: a pontuação do programa coincide com a fórmula de Okapi calculada à mão")
def _():
    docs = ["gato preto gato", "cachorro preto", "peixe azul grande", "gato azul", "ave verde", "cobra marrom"]
    nos = anotar([TextNode(text=t, id_=f"d{i}") for i, t in enumerate(docs)])
    bm = BM25PT(nos, top_k=6, k1=1.5, b=0.75)
    toks = [tokens(t) for t in docs]; N = len(docs); avg = np.mean([len(t) for t in toks])
    def manual(q, i):
        sc = 0.0
        for t in set(tokens(q)):
            n_t = sum(t in d for d in toks)
            idf = math.log((N - n_t + 0.5) / (n_t + 0.5))
            assert idf > 0
            f = toks[i].count(t)
            sc += idf * f * 2.5 / (f + 1.5 * (1 - 0.75 + 0.75 * len(toks[i]) / avg))
        return sc
    r = {x.node.node_id: x.score for x in bm.retrieve("gato azul")}
    for i in range(N):
        assert abs(r[f"d{i}"] - manual("gato azul", i)) < 1e-9, (i, r, manual("gato azul", i))


def rrf_listas(listas, k=60):
    sc = {}
    for l in listas:
        for pos, x in enumerate(l, 1):
            sc[x] = sc.get(x, 0) + 1 / (k + pos)
    return sorted(sc, key=lambda x: -sc[x])


@teste("RRF: a fórmula do texto reproduz, em todas as 67 perguntas, a ordem do QueryFusionRetriever do LlamaIndex")
def _():
    nos = uteis(nos_fixos(S, 150, 30)); e = embedding(128)
    dens = VectorStoreIndex(nos, embed_model=e).as_retriever(similarity_top_k=10); bm = BM25PT(nos, top_k=10)
    fus = QueryFusionRetriever([dens, bm], similarity_top_k=10, num_queries=1, mode="reciprocal_rerank", use_async=False)
    for q, _ in DIRETAS + PARAF:
        a = [x.node.node_id for x in fus.retrieve(q)]
        b = rrf_listas([[x.node.node_id for x in dens.retrieve(q)], [x.node.node_id for x in bm.retrieve(q)]])[:10]
        assert a == b, (q, a, b)


@teste("cosseno e euclidiana: para vetores unitários ||a-b||^2 = 2-2cos e a ordenação é idêntica; sem normalizar, difere")
def _():
    rng = np.random.default_rng(0)
    V = rng.normal(size=(200, 16)) * rng.uniform(0.2, 3, size=(200, 1)); q = rng.normal(size=16)
    Vn, qn = V / np.linalg.norm(V, axis=1, keepdims=True), q / np.linalg.norm(q)
    assert np.allclose(((Vn - qn) ** 2).sum(1), 2 - 2 * Vn @ qn)
    assert np.array_equal(np.argsort(((Vn - qn) ** 2).sum(1)), np.argsort(-(Vn @ qn)))
    assert not np.array_equal(np.argsort(((V - q) ** 2).sum(1))[:20], np.argsort(-(V @ q / np.linalg.norm(V, axis=1)))[:20])


@teste("métricas: hit@k, MRR@10 e nDCG@10 em listas escritas à mão")
def _():
    m = metricas([["a", "b", "c"], ["x", "y", "a"], ["x", "y", "z"]], [{"a"}, {"a"}, {"a"}], ks=(1, 3))
    assert m["hit@1"] == 1 / 3 and m["hit@3"] == 2 / 3
    assert abs(m["MRR@10"] - (1 + 1 / 3 + 0) / 3) < 1e-12
    assert abs(m["nDCG@10"] - (1 + 1 / math.log2(4) + 0) / 3) < 1e-12
    m2 = metricas([["a", "a", "b"]], [{"a", "b"}])                       # repetição não conta duas vezes no nDCG
    assert abs(m2["nDCG@10"] - (1 + 1 / math.log2(4)) / (1 + 1 / math.log2(3))) < 1e-12


@teste("LLM extrativo: devolve a frase de maior sobreposição com a citação da seção certa; sem sobreposição, abstém-se")
def _():
    llm = LLMExtrativo()
    p = "<<<CONTEXTO\nsecao: 2.5\n\nO framework PEAS especifica desempenho, ambiente, atuadores e sensores do agente.\n\nsecao: 9.2\n\nO softmax converte pontuações em pesos de atenção.\n<<<FIM\nPergunta: ..."
    llm.zerar("O que especifica o PEAS do agente?")
    assert llm.complete(p).text.endswith("[2.5]")
    llm.zerar("Qual a capital da Austrália?")
    assert llm.complete(p).text == "Não encontrei no contexto."
    assert llm.chamadas == 1


@teste("abstenção: SimilarityPostprocessor corta por cosseno; um NaN NÃO é cortado (precisa de tratamento explícito)")
def _():
    nos = [NodeWithScore(node=TextNode(text="a"), score=s) for s in (0.9, 0.3, float("nan"))]
    kept = SimilarityPostprocessor(similarity_cutoff=0.5).postprocess_nodes(nos, query_bundle=QueryBundle("q"))
    assert [round(x.score, 1) if np.isfinite(x.score) else "nan" for x in kept] == [0.9, "nan"]


@teste("validação cruzada por pergunta: dobras de treino e teste são disjuntas e cobrem todas as perguntas uma vez")
def _():
    N = len(DIRETAS) + len(PARAF); est = np.r_[np.zeros(len(DIRETAS)), np.ones(len(PARAF))]
    vistos = []
    for tr, te in StratifiedKFold(5, shuffle=True, random_state=0).split(np.zeros(N), est):
        assert not set(tr) & set(te); vistos += list(te)
    assert sorted(vistos) == list(range(N))

print(f"\n{n_ok} testes passaram")
