"""Números das soluções dos exercícios do Capítulo 11 (todos recalculados aqui)."""
import json
import math
from datetime import date
from typing import Literal

import numpy as np
from pydantic import BaseModel, Field, ValidationError, field_validator


def softmax(z, T=1.0):
    e = np.exp((np.asarray(z, float) - np.max(z)) / T)
    return e / e.sum()


np.set_printoptions(precision=4, suppress=True)
print("11.1 z=(2,1,0)")
for T in (0.5, 1, 2):
    print(f"   T={T}: {softmax([2, 1, 0], T)}")

print("\n11.2 p=(0.5,0.3,0.1,0.06,0.04)")
p = np.array([0.5, 0.3, 0.1, 0.06, 0.04])
k2 = p.copy(); k2[2:] = 0; print("   top-k=2:", k2 / k2.sum())
cum = np.cumsum(p); n = int(np.searchsorted(cum, 0.9) + 1); print("   acumulada", cum, "núcleo p=0,9 tem", n, "tokens")
kp = p.copy(); kp[n:] = 0; print("   top-p=0,9:", kp / kp.sum())

print("\n11.3 z=(3,2,1), contagens (2,0,1), freq 0,5, pres 1,0")
z = np.array([3., 2, 1]); c = np.array([2, 0, 1])
z2 = z - 0.5 * c - 1.0 * (c > 0); print("   logits", z2, "prob. antes", softmax(z), "depois", softmax(z2))

print("\n11.4 ECE")
n_ = np.array([50, 30, 20]); conf = np.array([.9, .6, .3]); acc = np.array([.8, .6, .4])
print("   ECE =", float((n_ / n_.sum() * np.abs(acc - conf)).sum()))

print("\n11.5 contrato Avaliacao")
class Avaliacao(BaseModel):
    rotulo: Literal["positivo", "negativo", "neutro"]
    confianca: float = Field(ge=0.0, le=1.0)
    justificativa: str = Field(min_length=3, max_length=80)
for nome, s in {
    "A": '{"rotulo": "Positivo", "confianca": 0.8, "justificativa": "bom"}',
    "B": '{"rotulo": "neutro", "confianca": "0,5", "justificativa": "sem opinião"}',
    "C": '{"rotulo": "neutro", "confianca": 1, "justificativa": "ok"}',
    "D": '{"rotulo": "negativo", "confianca": 0.3, "justificativa": "ruim", "extra": 1}',
}.items():
    try:
        r = Avaliacao.model_validate_json(s); print(f"   {nome}: OK {r.model_dump()}")
    except ValidationError as e:
        print(f"   {nome}: ERRO {[(x['type'], x['loc']) for x in e.errors()]}")
try:
    Avaliacao.model_validate_json('{"rotulo": "neutro", "confianca": "0.5", "justificativa": "sem opinião"}', strict=True)
except ValidationError as e:
    print("   texto \"0.5\" em modo estrito:", [x["type"] for x in e.errors()])

print("\n11.6 z=(2,1,0): dH/dT")
def H(T):
    q = softmax(z0, T); return float(-(q * np.log(q)).sum())
z0 = np.array([2., 1, 0]); q = softmax(z0)
var = float((q * z0 ** 2).sum() - (q * z0).sum() ** 2)
h = 1e-5
print(f"   Var_p(z) = {var:.5f}; dH/dT (fórmula) = {var:.5f}; diferença finita = {(H(1 + h) - H(1 - h)) / (2 * h):.5f}; H(1) = {H(1):.4f}")

print("\n11.7 min-p contra top-p")
p1 = np.array([0.8, 0.06, 0.05, 0.04, 0.03, 0.02]); print("   p1 min-p 0,1: limiar", 0.1 * p1.max(), "mantém", int((p1 >= 0.1 * p1.max()).sum()),
      "| top-p 0,9 mantém", int(np.searchsorted(np.cumsum(p1), 0.9) + 1))
p2 = np.array([0.22, 0.2, 0.2, 0.2, 0.1, 0.05, 0.03]); print("   p2 min-p 0,1: limiar", 0.1 * p2.max(), "mantém", int((p2 >= 0.1 * p2.max()).sum()),
      "| top-p 0,9 mantém", int(np.searchsorted(np.cumsum(p2), 0.9) + 1), "(acumulada", np.cumsum(p2), ")")

print("\n11.8 temperatura ótima, logits (2,0), 3 de 4 corretos")
def nll(T):
    pr = float(softmax([2, 0], T)[0]); return -(3 * math.log(pr) + math.log(1 - pr)) / 4
Ts = np.linspace(0.5, 4, 3501); v = [nll(T) for T in Ts]; Tm = Ts[int(np.argmin(v))]
print(f"   T* numérico = {Tm:.3f}; fórmula 2/ln3 = {2 / math.log(3):.4f}; NLL(1) = {nll(1):.4f}; NLL(T*) = {nll(2 / math.log(3)):.4f}; -ln(0.75)... entropia(0,75) = {-(0.75 * math.log(0.75) + 0.25 * math.log(0.25)):.4f}")
print(f"   confiança após T*: {softmax([2, 0], 2 / math.log(3))[0]:.4f}")

print("\n11.9 máscara token a token")
P1 = {"a": .5, "b": .5}; P2 = {"a": {"c": .2, "x": .8}, "b": {"d": .6, "x": .4}}
ver = {s: P1[s[0]] * P2[s[0]][s[1]] for s in ("ac", "bd")}; Z = sum(ver.values())
print("   verdadeira", {k: round(x / Z, 3) for k, x in ver.items()}, "| P(válido) =", Z, "| mascarada ac=0,5 bd=0,5")

print("\n11.10 nova tentativa, p=0,7 por tentativa")
pv = 0.7
print("   P(sucesso em 3) =", 1 - (1 - pv) ** 3, "| tentativas esperadas =", 1 / pv, "| P(sucesso em 5) =", 1 - (1 - pv) ** 5, "| tentativas p/ 99%:", math.ceil(math.log(0.01) / math.log(1 - pv)))

print("\n11.13 previsão seletiva")
a_tot, a_top, cov = 0.1586, 0.367, 0.2
print(f"   acurácia nos 80% restantes = {(a_tot - cov * a_top) / (1 - cov):.4f}")

print("\n11.14 contrato de data de vencimento")
class Vencimento(BaseModel):
    vencimento: date
    valor_centavos: int = Field(gt=0)
    moeda: Literal["BRL", "USD", "EUR"]

    @field_validator("vencimento")
    @classmethod
    def nao_no_passado_distante(cls, v):
        if v.year < 2000:
            raise ValueError("data anterior a 2000")
        return v
for nome, s in {
    "ok": '{"vencimento": "2026-12-05", "valor_centavos": 12990, "moeda": "BRL"}',
    "data inexistente": '{"vencimento": "2026-02-30", "valor_centavos": 12990, "moeda": "BRL"}',
    "formato BR": '{"vencimento": "05/12/2026", "valor_centavos": 12990, "moeda": "BRL"}',
    "valor negativo": '{"vencimento": "2026-12-05", "valor_centavos": -5, "moeda": "BRL"}',
    "válido mas errado (troca dia e mês)": '{"vencimento": "2026-05-12", "valor_centavos": 12990, "moeda": "BRL"}',
}.items():
    try:
        r = Vencimento.model_validate_json(s); print(f"   {nome}: OK {r.model_dump(mode='json')}")
    except ValidationError as e:
        print(f"   {nome}: ERRO {[(x['type']) for x in e.errors()]}")

print("\n11.5 (extra) com extra='forbid'")
from pydantic import ConfigDict
class AvaliacaoRigida(Avaliacao):
    model_config = ConfigDict(extra="forbid")
try:
    AvaliacaoRigida.model_validate_json('{"rotulo": "negativo", "confianca": 0.3, "justificativa": "ruim", "extra": 1}')
except ValidationError as e:
    print("   D com extra='forbid':", [(x["type"], x["loc"]) for x in e.errors()])

print("\n11.11 distância de variação total entre p e p truncado (top-p 0,9) no exemplo de 11.2")
p = np.array([0.5, 0.3, 0.1, 0.06, 0.04]); pt = np.array([0.5, 0.3, 0.1, 0, 0]); pt = pt / pt.sum()
print(f"   massa do núcleo m = {0.9}; TV = {0.5 * np.abs(p - pt).sum():.4f}; 1 - m = {1 - 0.9:.4f}")

print("\n11.13 (b) valor esperado: ganho 1 por acerto, perda 0,1 por erro, 0 se abstém")
for cob, a in ((1.0, 0.159), (0.8, 0.186), (0.6, 0.222), (0.4, 0.280), (0.2, 0.367), (0.1, 0.504), (0.05, 0.610)):
    print(f"   cobertura {cob:4.2f}: valor por previsão total = {cob * (1.0 * a - 0.1 * (1 - a)):.4f}")
