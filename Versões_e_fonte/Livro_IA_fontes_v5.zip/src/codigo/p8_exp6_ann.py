"""Projeto 8, experimento 6: busca aproximada de vizinhos mais próximos (ANN) com FAISS. (A) no corpus real (poucas centenas
de vetores: a busca exata basta); (B) em um conjunto SINTÉTICO grande (vetores gaussianos em aglomerados, normalizados), para
mostrar o compromisso entre recall e latência de HNSW e IVF. Latência medida com UMA thread, consultas uma a uma."""
import time

import faiss
import numpy as np
from llama_index.core import StorageContext, VectorStoreIndex
from llama_index.vector_stores.faiss import FaissVectorStore

from p8_comum import *

faiss.omp_set_num_threads(1)

# ------------------------------------------------------------------ (A) corpus real, via LlamaIndex + FAISS
nos = uteis(nos_fixos(S, 150, 30))
e = embedding(128)
d = e.dim
print(f"(A) corpus real: {len(nos)} vetores de dimensão {len(e._get_query_embedding('x'))}")
qs = [q for q, _ in DIRETAS + PARAF]
res = {}
for nome, indice in (("exato (IndexFlatIP)", faiss.IndexFlatIP(d)), ("HNSW (M=16, efSearch=32)", faiss.IndexHNSWFlat(d, 16, faiss.METRIC_INNER_PRODUCT))):
    if "HNSW" in nome:
        indice.hnsw.efConstruction = 100
        indice.hnsw.efSearch = 32
    vs = FaissVectorStore(faiss_index=indice)
    idx = VectorStoreIndex(nos, embed_model=e, storage_context=StorageContext.from_defaults(vector_store=vs))
    r = idx.as_retriever(similarity_top_k=10)
    t0 = time.perf_counter()
    top = [[x.node.node_id for x in r.retrieve(q)] for q in qs]
    res[nome] = (top, (time.perf_counter() - t0) / len(qs) * 1000, metricas([[secao_de(n.node) for n in r.retrieve(q)] for q in qs], [g for _, g in DIRETAS + PARAF]))
ex, hn = res["exato (IndexFlatIP)"], res["HNSW (M=16, efSearch=32)"]
rec = np.mean([len(set(a) & set(b)) / len(a) for a, b in zip(ex[0], hn[0])])
for nome, (top, ms, m) in res.items():
    print(f"  {nome:28s} {ms:7.2f} ms/pergunta (inclui o embedding da pergunta)  hit@1 {m['hit@1']:.2f}  hit@5 {m['hit@5']:.2f}  MRR {m['MRR@10']:.3f}")
print(f"  recall@10 do HNSW em relação à busca exata: {rec:.3f}")

# ------------------------------------------------------------------ (B) conjunto sintético
N, DIM, NQ, K = 100_000, 128, 500, 10
rng = np.random.default_rng(0)
centros = rng.normal(size=(1000, DIM)).astype("float32")
def amostra(n):
    c = centros[rng.integers(0, len(centros), n)]
    x = c + 1.7 * rng.normal(size=(n, DIM)).astype("float32")
    return (x / np.linalg.norm(x, axis=1, keepdims=True)).astype("float32")
X, Qn = amostra(N), amostra(NQ)
print(f"\n(B) sintético: {N} vetores unitários de dimensão {DIM} em 1000 aglomerados; {NQ} consultas; k = {K}")
flat = faiss.IndexFlatIP(DIM); flat.add(X)
t0 = time.perf_counter(); _, Ie = zip(*[flat.search(q[None], K) for q in Qn]); t_exato = (time.perf_counter() - t0) / NQ * 1000
Ie = np.vstack([i for i in Ie])
print(f"{'índice':34s} {'construção (s)':>15} {'ms/consulta':>12} {'recall@10':>10} {'memória (MB, estimada)':>24}")
print(f"{'exato (IndexFlatIP)':34s} {0:15.1f} {t_exato:12.3f} {1.0:10.3f} {N * DIM * 4 / 1e6:24.0f}")


def recall(I): return np.mean([len(set(a) & set(b)) / K for a, b in zip(Ie, I)])


t0 = time.perf_counter(); hn = faiss.IndexHNSWFlat(DIM, 16, faiss.METRIC_INNER_PRODUCT); hn.hnsw.efConstruction = 100; hn.add(X); tb = time.perf_counter() - t0
mem_h = (N * DIM * 4 + N * (16 * 2 + 16) * 4) / 1e6            # vetores + ~ (2M no nível 0 + M nos demais) arestas de 4 bytes
for ef in (8, 16, 32, 64, 128):
    hn.hnsw.efSearch = ef
    t0 = time.perf_counter(); I = np.vstack([hn.search(q[None], K)[1] for q in Qn]); t = (time.perf_counter() - t0) / NQ * 1000
    print(f"{f'HNSW M=16 efSearch={ef}':34s} {tb:15.1f} {t:12.3f} {recall(I):10.3f} {mem_h:24.0f}")
t0 = time.perf_counter(); q_ = faiss.IndexFlatIP(DIM); iv = faiss.IndexIVFFlat(q_, DIM, 1024, faiss.METRIC_INNER_PRODUCT); iv.train(X); iv.add(X); tb = time.perf_counter() - t0
mem_i = (N * DIM * 4 + N * 8 + 1024 * DIM * 4) / 1e6
for npb in (1, 2, 4, 8, 16, 32, 64):
    iv.nprobe = npb
    t0 = time.perf_counter(); I = np.vstack([iv.search(q[None], K)[1] for q in Qn]); t = (time.perf_counter() - t0) / NQ * 1000
    print(f"{f'IVF-Flat nlist=1024 nprobe={npb}':34s} {tb:15.1f} {t:12.3f} {recall(I):10.3f} {mem_i:24.0f}")
