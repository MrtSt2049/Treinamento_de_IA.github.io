"""Projeto 8: componentes do pipeline RAG com LlamaIndex, sem modelo pré-treinado externo e sem LLM.

  - embeddings LSA (TF-IDF + SVD) como subclasse de BaseEmbedding (não há modelo de embeddings pré-treinado disponível);
  - recuperador BM25 em português (normalização sem acento, radicais) como subclasse de BaseRetriever;
  - fatiadores (seção inteira, janela fixa, hierárquico, semântico), fusão por RRF, reordenador por características,
  - "LLM" extrativo (CustomLLM) que copia frases do contexto, claramente rotulado: NÃO é um modelo de linguagem gerativo."""
import re
import warnings

import numpy as np
import Stemmer
from rank_bm25 import BM25Okapi
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer

warnings.filterwarnings("ignore")
from llama_index.core import Document, Settings
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.llms import CustomLLM, CompletionResponse, CompletionResponseGen, LLMMetadata, MockLLM
from llama_index.core.llms.callbacks import llm_completion_callback
from llama_index.core.node_parser import HierarchicalNodeParser, SemanticSplitterNodeParser, SentenceSplitter, get_leaf_nodes
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode

from p8_corpus import carregar_secoes, sem_acento

Settings.llm = MockLLM()                       # evita a resolução do LLM padrão (que exigiria uma API)

STOP = set("""a o as os um uma uns umas de do da dos das em no na nos nas por para com sem sob sobre entre ate ao aos que se e ou mas
como qual quais quando onde quem porque por que e eh sao foi ser era tem ter ha mais menos muito muita muitos muitas ja nao sim
isso isto esse essa esses essas este esta estes estas aquele aquela seu sua seus suas dele dela deles delas lhe lhes eu tu ele ela
nos vos eles elas me te mim ti si faz fazem fazer pode podem usar usa usam quanto quantos quanta quantas cada tambem so apenas
entao assim ainda depois antes mesmo mesma outro outra outros outras""".split())
_STEM = Stemmer.Stemmer("portuguese")


def tokens(texto):
    """minúsculas, sem acento, só letras e dígitos, sem palavras vazias, com radical (snowball português)."""
    ts = re.findall(r"[a-z0-9]+", sem_acento(texto.lower()))
    return _STEM.stemWords([t for t in ts if t not in STOP and len(t) > 1])


# ------------------------------------------------------------------------------------------------ embeddings
class LSAEmbedding(BaseEmbedding):
    """Embedding de semântica latente: TF-IDF sublinear dos radicais, projetado por SVD truncada e normalizado (norma L2 = 1)."""
    dim: int = 128
    normalizar: bool = True
    _vec: object = None
    _svd: object = None

    def ajustar(self, textos):
        self._vec = TfidfVectorizer(analyzer=tokens, sublinear_tf=True, min_df=2)
        X = self._vec.fit_transform(textos)
        k = min(self.dim, X.shape[1] - 1, X.shape[0] - 1)
        self._svd = TruncatedSVD(n_components=k, random_state=0).fit(X)
        return self

    def _vetores(self, textos):
        Z = self._svd.transform(self._vec.transform(textos))
        if self.normalizar:
            Z = Z / np.maximum(np.linalg.norm(Z, axis=1, keepdims=True), 1e-12)
        return Z

    def _get_query_embedding(self, query): return self._vetores([query])[0].tolist()
    async def _aget_query_embedding(self, query): return self._get_query_embedding(query)
    def _get_text_embedding(self, text): return self._vetores([text])[0].tolist()
    def _get_text_embeddings(self, textos): return self._vetores(list(textos)).tolist()


# ------------------------------------------------------------------------------------------------ BM25
class BM25PT(BaseRetriever):
    """BM25 Okapi sobre os radicais em português; devolve os nós com a pontuação bruta do BM25."""
    def __init__(self, nodes, top_k=10, k1=1.5, b=0.75):
        super().__init__()
        self.nodes, self.top_k = list(nodes), top_k
        self.bm25 = BM25Okapi([tokens(n.get_content()) for n in self.nodes], k1=k1, b=b)

    def _retrieve(self, qb: QueryBundle):
        s = self.bm25.get_scores(tokens(qb.query_str))
        ordem = np.argsort(-s)[: self.top_k]
        return [NodeWithScore(node=self.nodes[i], score=float(s[i])) for i in ordem]


# ------------------------------------------------------------------------------------------------ corpus e nós
def documentos(secoes):
    """Um Document por seção, SEM metadados (assim o fatiador não gasta o orçamento de tokens com eles)."""
    return [Document(text=s["titulo"] + ". " + s["texto"], doc_id=s["id"]) for s in secoes]


def anotar(nos):
    """Acrescenta a seção como metadado e o EXCLUI do texto que vai para o embedding e para o LLM.
    (Erro frequente: se o metadado entra no texto do embedding, ele contamina o vetor; ver o experimento 1.)"""
    for n in nos:
        n.metadata = {"secao": n.ref_doc_id or n.node_id}
        n.excluded_embed_metadata_keys = ["secao"]
        n.excluded_llm_metadata_keys = ["secao"]
    return nos


def _palavras(s): return s.split()


def nos_secao(secoes):
    """Um nó por seção (fatia = documento inteiro)."""
    return anotar([TextNode(text=d.text, id_=d.doc_id) for d in documentos(secoes)])


def nos_fixos(secoes, tam=150, sobrepos=30):
    """Janelas de ~tam palavras com sobreposição, respeitando fronteiras de frase (SentenceSplitter); unidade = palavra."""
    sp = SentenceSplitter(chunk_size=tam, chunk_overlap=sobrepos, tokenizer=_palavras, include_metadata=False, include_prev_next_rel=False)
    return anotar(sp.get_nodes_from_documents(documentos(secoes)))


def nos_hierarquicos(secoes, tamanhos=(600, 150)):
    """Hierarquia de nós (pais grandes, filhos pequenos); devolve (todos os nós, folhas)."""
    sps = [SentenceSplitter(chunk_size=t, chunk_overlap=0, tokenizer=_palavras, include_metadata=False, include_prev_next_rel=False) for t in tamanhos]
    hp = HierarchicalNodeParser.from_defaults(node_parser_ids=[f"n{t}" for t in tamanhos], node_parser_map={f"n{t}": sp for t, sp in zip(tamanhos, sps)})
    todos = anotar(hp.get_nodes_from_documents(documentos(secoes)))
    return todos, get_leaf_nodes(todos)


def nos_semanticos(secoes, emb, limiar=90):
    sp = SemanticSplitterNodeParser(buffer_size=1, breakpoint_percentile_threshold=limiar, embed_model=emb, include_metadata=False, include_prev_next_rel=False)
    return anotar(sp.get_nodes_from_documents(documentos(secoes)))


def uteis(nos, minimo=8):
    """Descarta nós degenerados (menos de `minimo` radicais de conteúdo). Depois de remover a matemática do texto, sobram
    fragmentos como "Se , então ." que têm vetor nulo: a similaridade vira NaN e o fragmento domina a ordenação (ver exp. 1)."""
    return [n for n in nos if len(tokens(n.get_content())) >= minimo]


def secao_de(no):
    """Seção (id) a que um nó pertence."""
    return no.metadata.get("secao") or no.ref_doc_id


def lista_secoes(resultados):
    """Seção de cada trecho recuperado, NA ORDEM e COM repetições (k trechos = k posições)."""
    return [secao_de(r.node) for r in resultados]


def metricas(listas, golds, ks=(1, 3, 5, 10)):
    """listas: seção de cada trecho recuperado (com repetições), por pergunta; golds: conjuntos de seções corretas.
    hit@k: algum dos k primeiros trechos está em uma seção correta. MRR@10: 1/posição do primeiro trecho correto entre 10.
    nDCG@10: relevância binária por SEÇÃO (cada seção conta uma vez, na posição do primeiro trecho dela)."""
    out = {f"hit@{k}": float(np.mean([any(s in g for s in l[:k]) for l, g in zip(listas, golds)])) for k in ks}
    rr, nd = [], []
    for l, g in zip(listas, golds):
        pos = [i for i, s in enumerate(l[:10]) if s in g]
        rr.append(1 / (pos[0] + 1) if pos else 0.0)
        vistas, dcg = set(), 0.0
        for i, s in enumerate(l[:10]):
            if s in g and s not in vistas:
                dcg += 1 / np.log2(i + 2)
            vistas.add(s)
        idcg = sum(1 / np.log2(i + 2) for i in range(min(len(g), 10)))
        nd.append(dcg / idcg)
    out["MRR@10"], out["nDCG@10"] = float(np.mean(rr)), float(np.mean(nd))
    return out


# ------------------------------------------------------------------------------------------------ "LLM" extrativo
class LLMExtrativo(CustomLLM):
    """NÃO é um modelo de linguagem gerativo. Dado um prompt do LlamaIndex, escolhe, entre as frases dos trechos de contexto
    (marcados por "secao: X"), a de maior sobreposição de radicais com a pergunta e a devolve com a citação [X]. Serve para
    exercitar e medir TODO o resto do pipeline (recuperação, montagem de contexto, modos de síntese, citações) sem depender de uma API.
    Conta as chamadas e o tamanho (em palavras) dos prompts, que é o que distingue os modos de síntese."""
    janela: int = 100000
    chamadas: int = 0
    palavras_prompt: int = 0
    pergunta: str = ""

    @property
    def metadata(self) -> LLMMetadata:
        return LLMMetadata(context_window=self.janela, num_output=256, model_name="extrativo-sem-modelo")

    def zerar(self, pergunta):
        self.chamadas, self.palavras_prompt, self.pergunta = 0, 0, pergunta

    @llm_completion_callback()
    def complete(self, prompt: str, formatted: bool = False, **kwargs) -> CompletionResponse:
        self.chamadas += 1
        self.palavras_prompt += len(prompt.split())
        qs = set(tokens(self.pergunta))
        melhor, pont = ("", None), -1.0
        if "['secao: " in prompt:      # llama-index-core 0.14.25, modo simple_summarize: a LISTA de trechos entra no prompt por repr()
            prompt = prompt.replace("\\n", "\n")
        prompt = prompt.split("\n<<<FIM")[0]       # só o contexto: nunca a pergunta nem as instruções
        partes = re.split(r"secao: (\d+\.\d+)\n\n", prompt)           # [antes, sec1, texto1, sec2, texto2, ...]
        for sec, trecho in zip(partes[1::2], partes[2::2]):
            for frase in re.split(r"(?<=[.!?])\s+|\n+", trecho):
                if len(frase.split()) < 6:
                    continue
                p = len(qs & set(tokens(frase))) / (max(len(qs), 1) ** 0.5 * max(len(set(tokens(frase))), 1) ** 0.25)
                if p > pont:
                    melhor, pont = (frase.strip(), sec), p
        if pont <= 0:
            return CompletionResponse(text="Não encontrei no contexto.")
        return CompletionResponse(text=f"{melhor[0]} [{melhor[1]}]")

    @llm_completion_callback()
    def stream_complete(self, prompt: str, formatted: bool = False, **kwargs) -> CompletionResponseGen:
        yield self.complete(prompt, formatted=formatted, **kwargs)
