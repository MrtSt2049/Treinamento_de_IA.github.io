"""Capítulo 11: temperatura, top-k, top-p e penalidades, implementados do zero e conferidos contra a biblioteca transformers,
aplicados aos logits reais do GPT-2 minúsculo do Projeto 7 (vocabulário 1000)."""
import numpy as np
import torch
from transformers import MinPLogitsWarper, TemperatureLogitsWarper, TopKLogitsWarper, TopPLogitsWarper

from m11 import carregar, entropia, logits_proximo


def temperatura(z, T):
    return z / T


def top_k(z, k):
    corte = torch.topk(z, k, dim=-1).values[..., -1:]
    return z.masked_fill(z < corte, float("-inf"))


def top_p(z, p):
    """Menor conjunto de maior probabilidade cuja massa soma pelo menos p (núcleo)."""
    ordem = torch.argsort(z, dim=-1, descending=True)
    pr = torch.softmax(z.gather(-1, ordem), -1)
    acum = pr.cumsum(-1)
    fora = (acum - pr) >= p                       # exclui o token se a massa ANTES dele já alcança p
    fora_orig = torch.zeros_like(fora).scatter(-1, ordem, fora)
    return z.masked_fill(fora_orig, float("-inf"))


def min_p(z, m):
    """Mantém os tokens com probabilidade >= m vezes a do mais provável."""
    p = torch.softmax(z, -1)
    return z.masked_fill(p < m * p.max(-1, keepdim=True).values, float("-inf"))


def penalidades(z, contagens, freq=0.0, pres=0.0):
    """Penalidade de frequência e de presença: z_i - freq * c_i - pres * 1[c_i > 0]."""
    return z - freq * contagens - pres * (contagens > 0).float()


if __name__ == "__main__":
    d, tok, ds, modelo = carregar()
    x = torch.tensor(ds["orig_va"]["input_ids"])
    # um prefixo por bloco de validação (os 64 primeiros tokens)
    ids = x[:, :64]
    z = logits_proximo(modelo, ids)
    print(f"{len(ids)} prefixos de 64 tokens; logits de forma {tuple(z.shape)}")

    print("\n1) conferência contra a biblioteca transformers (máxima diferença absoluta entre as distribuições resultantes)")
    for nome, minha, lib in (
        ("temperatura T=0,7", lambda z: temperatura(z, 0.7), lambda z: TemperatureLogitsWarper(0.7)(None, z.clone())),
        ("top-k k=20", lambda z: top_k(z, 20), lambda z: TopKLogitsWarper(20)(None, z.clone())),
        ("top-p p=0,9", lambda z: top_p(z, 0.9), lambda z: TopPLogitsWarper(0.9)(None, z.clone())),
        ("min-p m=0,1", lambda z: min_p(z, 0.1), lambda z: MinPLogitsWarper(0.1)(None, z.clone())),
    ):
        a, b = torch.softmax(minha(z), -1), torch.softmax(lib(z), -1)
        print(f"   {nome:20s} diferença máxima {float((a - b).abs().max()):.2e}")

    print("\n2) efeito da temperatura sobre a distribuição do próximo token (média dos prefixos)")
    print(f"   {'T':>5} {'entropia (nats)':>16} {'prob. do mais provável':>24} {'tamanho do núcleo (p=0,9)':>27}")
    H = {}
    for T in (0.2, 0.5, 0.8, 1.0, 1.3, 2.0, 5.0):
        p = torch.softmax(temperatura(z, T), -1)
        h = entropia(p)
        H[T] = h
        nucleo = (torch.isfinite(top_p(temperatura(z, T), 0.9))).sum(-1).float().mean()
        print(f"   {T:5.1f} {float(h.mean()):16.3f} {float(p.max(-1).values.mean()):24.3f} {float(nucleo):27.1f}")
    print(f"   referência: entropia máxima ln V = {np.log(z.shape[1]):.3f}")

    print("\n3) Proposição: dH/dT = Var_p(z) / T^3 (diferença finita contra a fórmula, média nos prefixos)")
    for T in (0.5, 1.0, 2.0):
        e = 1e-4
        num = (entropia(torch.softmax(z / (T + e), -1)) - entropia(torch.softmax(z / (T - e), -1))) / (2 * e)
        p = torch.softmax(z / T, -1)
        var = (p * z ** 2).sum(-1) - ((p * z).sum(-1)) ** 2
        print(f"   T={T:3.1f}: diferença finita {float(num.mean()):.5f}   Var/T^3 {float((var / T ** 3).mean()):.5f}   (todos os prefixos com dH/dT > 0: {bool((num > 0).all())})")

    print("\n4) limites: T -> 0 recupera o argmax; T grande tende ao uniforme")
    am = z.argmax(-1)
    p_baixo = torch.softmax(z / 0.01, -1)
    print(f"   T=0,01: fração dos prefixos em que o modo da distribuição é o argmax: {float((p_baixo.argmax(-1) == am).float().mean()):.3f}; massa média no argmax {float(p_baixo.max(-1).values.mean()):.4f}")
    p_alto = torch.softmax(z / 1000, -1)
    print(f"   T=1000: distância total-variação média ao uniforme {float(0.5 * (p_alto - 1 / z.shape[1]).abs().sum(-1).mean()):.4f}")

    print("\n5) top-p: o núcleo contém massa >= p, e retirar seu menor elemento passa abaixo de p")
    p = torch.softmax(z, -1)
    zn = top_p(z, 0.9)
    massa = (p * torch.isfinite(zn)).sum(-1)
    menor = torch.where(torch.isfinite(zn), p, torch.full_like(p, 2.0)).min(-1).values
    print(f"   massa do núcleo: mínima {float(massa.min()):.4f} (>= 0,9: {bool((massa >= 0.9 - 1e-6).all())}); sem o menor elemento: máxima {float((massa - menor).max()):.4f} (< 0,9: {bool(((massa - menor) < 0.9).all())})")

    print("\n6) penalidades: exemplo com 3 tokens (z = 2, 1, 0; o token 0 já apareceu 3 vezes, o token 1 uma vez)")
    zz = torch.tensor([2.0, 1.0, 0.0]); cc = torch.tensor([3.0, 1.0, 0.0])
    for nome, kw in (("sem penalidade", {}), ("frequência 0,5", {"freq": 0.5}), ("presença 1,0", {"pres": 1.0}), ("ambas (0,5 e 1,0)", {"freq": 0.5, "pres": 1.0})):
        zp = penalidades(zz, cc, **kw)
        print(f"   {nome:20s} logits {np.round(zp.numpy(), 2)}  probabilidades {np.round(torch.softmax(zp, -1).numpy(), 3)}")
