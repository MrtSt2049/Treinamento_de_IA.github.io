"""Projeto 8, experimento 2: o embedding. (a) dimensão do LSA; (b) cosseno contra distância euclidiana, com vetores normalizados
e não normalizados; (c) LSA contra TF-IDF puro (sem redução de dimensão). Fatias: janelas de 150 palavras, sobreposição 30."""
import numpy as np
from scipy.stats import kendalltau
from sklearn.feature_extraction.text import TfidfVectorizer

from p8_comum import *

nos = uteis(nos_fixos(S, 150, 30))
textos = [n.get_content() for n in nos]
secs = [secao_de(n) for n in nos]
perguntas = {"diretas": DIRETAS, "parafraseadas": PARAF}


def avalia_matriz(sim_fn, qs):
    """sim_fn(lista de perguntas) -> matriz (perguntas x nós) de similaridades (maior = mais próximo)."""
    M = sim_fn([q for q, _ in qs])
    listas = [[secs[j] for j in np.argsort(-M[i])[:10]] for i in range(len(qs))]
    return metricas(listas, [g for _, g in qs])


def fmt(m): return f"{m['hit@1']:.2f}/{m['hit@5']:.2f}/{m['MRR@10']:.2f}"


print("(a) dimensão do LSA (cosseno)           hit@1 / hit@5 / MRR@10")
print(f"{'dim':>6} {'variância explicada':>20} {'diretas':>16} {'parafraseadas':>16}")
for dim in (8, 16, 32, 64, 128, 256, 384):
    e = embedding(dim)
    V = np.array(e._get_text_embeddings(textos))
    ve = e._svd.explained_variance_ratio_.sum()
    cel = []
    for nome, qs in perguntas.items():
        cel.append(fmt(avalia_matriz(lambda ps: np.array([e._get_query_embedding(p) for p in ps]) @ V.T, qs)))
    print(f"{dim:6d} {ve:20.3f} {cel[0]:>16} {cel[1]:>16}")

print("\n(b) cosseno contra distância euclidiana (dim 128)")
en = embedding(128, True)
eu = embedding(128, False)
Vn = np.array(en._get_text_embeddings(textos)); Vu = np.array(eu._get_text_embeddings(textos))
print(f"  normas dos vetores de trecho: normalizados min {np.linalg.norm(Vn, axis=1).min():.3f} máx {np.linalg.norm(Vn, axis=1).max():.3f}; "
      f"não normalizados min {np.linalg.norm(Vu, axis=1).min():.3f} máx {np.linalg.norm(Vu, axis=1).max():.3f}")
todas = [q for q, _ in DIRETAS + PARAF]
Qn = np.array([en._get_query_embedding(p) for p in todas]); Qu = np.array([eu._get_query_embedding(p) for p in todas])


def rank_cos(Q, V): return -(Q / np.maximum(np.linalg.norm(Q, axis=1, keepdims=True), 1e-12)) @ (V / np.maximum(np.linalg.norm(V, axis=1, keepdims=True), 1e-12)).T
def rank_l2(Q, V): return ((Q[:, None, :] - V[None, :, :]) ** 2).sum(-1)


for rot, Q, V in (("vetores normalizados", Qn, Vn), ("vetores NÃO normalizados", Qu, Vu)):
    Dc, Dl = rank_cos(Q, V), rank_l2(Q, V)
    ordem_igual = np.mean([np.array_equal(np.argsort(Dc[i]), np.argsort(Dl[i])) for i in range(len(Q))])
    topo5 = np.mean([len(set(np.argsort(Dc[i])[:5]) & set(np.argsort(Dl[i])[:5])) / 5 for i in range(len(Q))])
    tau = np.mean([kendalltau(Dc[i], Dl[i])[0] for i in range(len(Q))])
    h = {}
    for nome, qs in perguntas.items():
        a = avalia_matriz(lambda ps, Q=Q, V=V: -rank_cos(np.array([ (en if V is Vn else eu)._get_query_embedding(p) for p in ps]), V), qs)
        b = avalia_matriz(lambda ps, V=V: -rank_l2(np.array([(en if V is Vn else eu)._get_query_embedding(p) for p in ps]), V), qs)
        h[nome] = (fmt(a), fmt(b))
    print(f"  {rot:26s} ordenação idêntica em {100 * ordem_igual:5.1f}% das perguntas; sobreposição do top-5 {100 * topo5:5.1f}%; tau de Kendall médio {tau:.3f}")
    print(f"      diretas (cos | L2): {h['diretas'][0]} | {h['diretas'][1]}    parafraseadas (cos | L2): {h['parafraseadas'][0]} | {h['parafraseadas'][1]}")
# verificação da identidade ||a-b||^2 = 2 - 2 cos(a,b) para vetores unitários
a, b = Vn[0], Vn[1]
print(f"  identidade para vetores unitários: ||a-b||^2 = {np.sum((a - b) ** 2):.10f}; 2-2cos = {2 - 2 * a @ b:.10f}")

print("\n(c) LSA (128) contra TF-IDF puro (cosseno sobre vetores esparsos)")
tf = TfidfVectorizer(analyzer=tokens, sublinear_tf=True, min_df=2).fit([n.get_content() for n in nos_fixos(S, 100, 0)])
T = tf.transform(textos)
cel = []
for nome, qs in perguntas.items():
    cel.append(fmt(avalia_matriz(lambda ps: (tf.transform(ps) @ T.T).toarray(), qs)))
print(f"  TF-IDF puro, {T.shape[1]} dimensões: diretas {cel[0]}; parafraseadas {cel[1]}")
e = embedding(128); V = np.array(e._get_text_embeddings(textos))
cel = [fmt(avalia_matriz(lambda ps: np.array([e._get_query_embedding(p) for p in ps]) @ V.T, qs)) for qs in perguntas.values()]
print(f"  LSA, 128 dimensões:           diretas {cel[0]}; parafraseadas {cel[1]}")
