"""Capítulo 11: calibração da confiança do próximo token (ECE), correção por temperatura e previsão seletiva (abstenção).

Confiança = probabilidade do token mais provável; acerto = o token mais provável é o próximo token real.
Dados: validação do domínio de origem (dividida em metade de calibração e metade de teste) e validação do domínio-alvo (deslocamento de domínio)."""
import numpy as np
import torch

from m11 import carregar

d, tok, ds, modelo = carregar()


@torch.no_grad()
def logits_de(ds_):
    x = torch.tensor(ds_["input_ids"])
    zs = []
    for i in range(0, len(x), 16):
        zs.append(modelo(input_ids=x[i:i + 16]).logits[:, :-1])
    z = torch.cat(zs)                                        # (blocos, 127, V)
    y = x[:, 1:]
    return z.reshape(-1, z.shape[-1]), y.reshape(-1)


def ece(conf, acerto, nb=15):
    bins = np.minimum((conf * nb).astype(int), nb - 1)
    tot, linhas = 0.0, []
    for b in range(nb):
        m = bins == b
        if m.sum():
            tot += m.mean() * abs(acerto[m].mean() - conf[m].mean())
            linhas.append((b / nb, (b + 1) / nb, int(m.sum()), float(conf[m].mean()), float(acerto[m].mean())))
    return tot, linhas


def metricas(z, y, T=1.0):
    p = torch.softmax(z / T, -1)
    conf, pred = p.max(-1)
    acerto = (pred == y).float().numpy()
    nll = float(-torch.log(p.gather(-1, y[:, None]).clamp_min(1e-30)).mean())
    e, linhas = ece(conf.numpy(), acerto)
    return nll, e, float(acerto.mean()), linhas, conf.numpy(), acerto


zo, yo = logits_de(ds["orig_va"])
n_blocos = len(ds["orig_va"]["input_ids"])
meio = (n_blocos // 2) * 127
zc, yc, zt, yt = zo[:meio], yo[:meio], zo[meio:], yo[meio:]
za, ya = logits_de(ds["alvo_va"])
print(f"posições: calibração {len(yc)}, teste (origem) {len(yt)}, alvo (outro domínio) {len(ya)}; 15 faixas de confiança")

# ajuste de T por NLL na metade de calibração (busca em grade fina + refino)
grade = np.exp(np.linspace(np.log(0.5), np.log(3.0), 200))
nlls = [metricas(zc, yc, float(T))[0] for T in grade]
T_otimo = float(grade[int(np.argmin(nlls))])
print(f"\ntemperatura ótima na calibração (mínimo da NLL): T* = {T_otimo:.3f}")

print(f"\n{'conjunto':28s} {'T':>6} {'NLL':>7} {'ECE':>7} {'acurácia':>9}")
res = {}
for nome, z, y in (("calibração (origem)", zc, yc), ("teste (origem)", zt, yt), ("alvo (outro domínio)", za, ya)):
    for T in (1.0, T_otimo):
        nll, e, ac, linhas, conf, acerto = metricas(z, y, T)
        res[(nome, T)] = (conf, acerto, linhas)
        print(f"{nome:28s} {T:6.3f} {nll:7.3f} {e:7.4f} {ac:9.4f}")

print("\ntabela de confiabilidade (teste da origem): faixa, n, confiança média, acurácia observada")
for T in (1.0, T_otimo):
    print(f"  T = {T:.3f}")
    for lo, hi, n, c, a in res[("teste (origem)", T)][2]:
        print(f"    [{lo:.2f},{hi:.2f}) n={n:5d}  confiança {c:.3f}  acurácia {a:.3f}")

print("\nprevisão seletiva (teste da origem): acurácia entre as previsões mais confiantes")
conf, acerto, _ = res[("teste (origem)", 1.0)]
ordem = np.argsort(-conf)
print(f"  {'cobertura':>10} {'acurácia':>9} {'limiar de confiança':>20}")
for cob in (1.0, 0.8, 0.6, 0.4, 0.2, 0.1, 0.05):
    k = int(cob * len(conf))
    print(f"  {cob:10.2f} {acerto[ordem[:k]].mean():9.3f} {conf[ordem[k - 1]]:20.3f}")
