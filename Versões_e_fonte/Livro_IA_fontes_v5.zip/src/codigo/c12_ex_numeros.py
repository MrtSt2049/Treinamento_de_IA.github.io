"""Números das soluções dos exercícios do Capítulo 12."""
import math
from itertools import product

import numpy as np

np.set_printoptions(precision=4, suppress=True)

print("12.1 número de janelas: L palavras, janela c, sobreposição o  ->  ceil((L-o)/(c-o)); fator de duplicação c/(c-o)")
for L, c, o in ((1000, 150, 30), (1000, 300, 60), (1000, 150, 0)):
    n = math.ceil((L - o) / (c - o)); print(f"   L={L} c={c} o={o}: {n} janelas; fator c/(c-o) = {c / (c - o):.3f}; palavras indexadas ~ {n * c} (limite {L * c / (c - o):.0f})")

print("\n12.2 cosseno contra euclidiana, q=(1,1)")
q = np.array([1., 1]); D = {"d1": np.array([3., 3]), "d2": np.array([1., 0.8]), "d3": np.array([2., 0])}
for k, d in D.items():
    print(f"   {k} {d}: cos = {q @ d / np.linalg.norm(q) / np.linalg.norm(d):.4f}; ||q-d|| = {np.linalg.norm(q - d):.4f}")

print("\n12.3 RRF: A = (d1,d2,d3,d4), B = (d3,d1,d5,d2)")
A, B = ["d1", "d2", "d3", "d4"], ["d3", "d1", "d5", "d2"]
def rrf(listas, k):
    s = {}
    for l in listas:
        for p, x in enumerate(l, 1):
            s[x] = s.get(x, 0) + 1 / (k + p)
    return s
for k in (60, 1, 10000):
    s = rrf([A, B], k)
    print(f"   k={k}: " + ", ".join(f"{x}={v:.5f}" for x, v in sorted(s.items(), key=lambda t: -t[1])))
print("   soma das posições (Borda), ausente = 5 (mesma convenção de 'depois do último'):",
      {x: (A.index(x) + 1 if x in A else 5) + (B.index(x) + 1 if x in B else 5) for x in sorted(set(A + B))})

print("\n12.4 BM25 (k1=1,5; b=0,75), corpus de 4 documentos, consulta 'gradiente'")
docs = [["gradiente", "descida", "gradiente", "passo"], ["probabilidade", "bayes", "teorema"], ["atencao", "softmax", "chave", "valor", "consulta", "mascara"], ["pooling", "convolucao"]]
N = len(docs); avg = np.mean([len(d) for d in docs]); n_t = sum("gradiente" in d for d in docs)
idf = math.log((N - n_t + 0.5) / (n_t + 0.5))
print(f"   N={N}, n_t={n_t}, comprimento médio {avg}, idf = ln(({N}-{n_t}+0,5)/({n_t}+0,5)) = {idf:.4f}")
for i, d in enumerate(docs):
    f = d.count("gradiente")
    print(f"   d{i + 1}: f={f}, |d|={len(d)}, BM25 = {idf * f * 2.5 / (f + 1.5 * (0.25 + 0.75 * len(d) / avg)) if f else 0:.4f}")

print("\n12.5 métricas, 3 perguntas, listas de seções recuperadas")
L = [["5.4", "5.5", "5.1"], ["9.2", "9.4", "9.7"], ["3.5", "3.3", "3.6"]]; G = [{"5.4"}, {"9.7"}, {"3.3", "3.6"}]
rr = [next((1 / (i + 1) for i, s in enumerate(l) if s in g), 0) for l, g in zip(L, G)]
nd = []
for l, g in zip(L, G):
    dcg = sum(1 / math.log2(i + 2) for i, s in enumerate(l) if s in g); idcg = sum(1 / math.log2(i + 2) for i in range(len(g)))
    nd.append(dcg / idcg)
print(f"   hit@1 = {np.mean([l[0] in g for l, g in zip(L, G)]):.4f}; hit@3 = {np.mean([any(s in g for s in l) for l, g in zip(L, G)]):.4f}; MRR = {np.mean(rr):.4f}; nDCG por pergunta = {np.round(nd, 4)}; nDCG médio = {np.mean(nd):.4f}")

print("\n12.6 vetores NÃO unitários: a = (3,4), b = (3,5), q = (0,10)")
a, b, q = np.array([3., 4]), np.array([3., 5]), np.array([0., 10])
for n, v in (("a", a), ("b", b)):
    print(f"   {n}: cos(q,{n}) = {q @ v / np.linalg.norm(q) / np.linalg.norm(v):.4f}; ||q-{n}||^2 = {np.sum((q - v) ** 2):.1f}; q.{n} = {q @ v:.0f}")

print("\n12.7 IVF: N=1e6, nprobe=8")
N_, npb = 1_000_000, 8
nl = math.sqrt(npb * N_); custo = lambda n: n + npb * N_ / n
print(f"   nlist* = sqrt(nprobe N) = {nl:.0f}; custo = {custo(nl):.0f} = 2 sqrt(nprobe N) = {2 * math.sqrt(npb * N_):.0f}; aceleração sobre {N_} = {N_ / custo(nl):.0f}x; custo com nlist=1024: {custo(1024):.0f}")
print(f"   simulação no experimento (N=1e5, nlist=1024): nprobe=8 -> custo {1024 + 8 * 1e5 / 1024:.0f} comparações; fração da base {(1024 + 8 * 1e5 / 1024) / 1e5:.4f}")

print("\n12.8 memória, N=1e7, d=768, float32")
N_, d, M = 10_000_000, 768, 32
vet = N_ * d * 4; lig = N_ * 2 * M * 4
print(f"   vetores {vet / 1e9:.2f} GB; ligações do nível 0 (2M={2 * M} por vetor, 4 bytes) {lig / 1e9:.2f} GB; total {(vet + lig) / 1e9:.2f} GB (ligações = {lig / vet:.1%} dos vetores)")
for m in (96, 48):
    print(f"   com PQ de {m} bytes/vetor: {N_ * m / 1e9:.2f} GB ({vet / (N_ * m):.0f}x menor)")

print("\n12.9 ponto de operação (limiar 0,5): respondíveis respondidas 0,91, acerto do top-1 0,74, longe 0,31, perto 0,50; fluxo de 100 perguntas: 80 respondíveis, 10 longe, 10 perto")
r = 80 * 0.91; ok = r * 0.74
print(f"   respondíveis respondidas {r:.1f}; corretas {ok:.1f}; erradas {r - ok:.1f}; respondíveis recusadas {80 - r:.1f}; sem resposta respondidas {10 * 0.31 + 10 * 0.50:.1f} de 20; total de respostas ruins = {r - ok + 10 * 0.31 + 10 * 0.50:.1f} de {r + 10 * 0.31 + 10 * 0.50:.1f} respostas dadas")

print("\n12.10 cobertura de intervalos por janelas com sobreposição (força bruta)")
def cobre(L, c, o, s):
    passo = c - o; janelas = [(i, min(i + c, L)) for i in range(0, max(L - o, 1), passo)]
    return all(any(a <= i and i + s <= b for a, b in janelas) for i in range(0, L - s + 1))
for L, c, o in ((1000, 150, 30), (1000, 150, 0), (537, 100, 20), (1000, 150, 100)):
    ok = {s: cobre(L, c, o, s) for s in (1, o, o + 1, o + 2, 2 * o + 1)}
    print(f"   L={L} c={c} o={o}: intervalos de tamanho s contidos em alguma janela? {ok}")

print("\n12.11 RRF e Borda para k grande (exemplo de 12.3): ordem por RRF k=10000 vs soma de posições")
s = rrf([A, B], 10000); print("   ", sorted(s, key=lambda x: -s[x]))

print("\n12.12 dimensionamento: 200 mil páginas, ~4 trechos por página, d=768 float32")
n_ = 200_000 * 4; print(f"   {n_} trechos; vetores {n_ * 768 * 4 / 1e9:.2f} GB; HNSW (M=32) ~ {(n_ * 768 * 4 + n_ * 64 * 4) / 1e9:.2f} GB; busca exata: {n_ * 768 / 1e6:.0f} milhões de multiplicações por consulta")
print(f"   à taxa medida no experimento 6 (100000 x 128, exata, 1 núcleo: {2 * 100000 * 128 / 2.116e-3 / 1e9:.0f} GFLOP/s), a busca exata custaria ~ {n_ * 768 * 2 / (2 * 100000 * 128 / 2.116e-3):.2f} s por consulta e por núcleo")

print("\n12.13 tamanho de amostra para detectar diferença de MRR")
import sys
sys.path.insert(0, ".")
from p8_comum import *
nos = uteis(nos_fixos(S, 150, 30)); e = embedding(128); V = np.array(e._get_text_embeddings([n.get_content() for n in nos])); secs = [secao_de(n) for n in nos]
bm = BM25PT(nos, top_k=10); Qs = DIRETAS + PARAF
def rr_one(sc, g):
    l = [secs[j] for j in np.argsort(-sc)[:10]]; pos = [p for p, s_ in enumerate(l) if s_ in g]; return 1 / (pos[0] + 1) if pos else 0.0
cos_ = np.array([V @ np.array(e._get_query_embedding(q)) for q, _ in Qs]); bms_ = np.array([bm.bm25.get_scores(tokens(q)) for q, _ in Qs])
def ranks(M):
    r_ = np.empty_like(M, dtype=int)
    for i in range(len(M)): r_[i, np.argsort(-M[i])] = np.arange(1, M.shape[1] + 1)
    return r_
Rc, Rb = ranks(cos_), ranks(bms_); rf = 1 / (60 + Rc) + 1 / (60 + Rb)
dif = np.array([rr_one(bms_[i], Qs[i][1]) - rr_one(rf[i], Qs[i][1]) for i in range(len(Qs))])
sd = dif.std(ddof=1)
print(f"   diferença média BM25 - RRF = {dif.mean():+.3f}; desvio-padrão por pergunta = {sd:.3f}; erro padrão com 67 perguntas = {sd / math.sqrt(67):.3f}")
for delta in (0.03, 0.02, 0.01):
    print(f"   para detectar uma diferença real de {delta}: n >= (1,96 sigma/delta)^2 = {(1.96 * sd / delta) ** 2:.0f} perguntas (aprox., 95% de confiança, só a metade do intervalo)")

print("\n12.14 LSA: SVD de uma matriz termo-documento pequena")
X = np.array([[1, 1, 0, 0], [1, 1, 0, 0], [0, 1, 1, 0], [0, 0, 1, 1], [0, 0, 1, 1]], float)
U, sv, Vt = np.linalg.svd(X, full_matrices=False)
print("   valores singulares", sv, "; energia retida r=1,2,3:", np.cumsum(sv ** 2) / (sv ** 2).sum())
Xk = (U[:, :2] * sv[:2]) @ Vt[:2]
print("   erro de Frobenius da aproximação de posto 2:", np.linalg.norm(X - Xk), "= sqrt(soma dos sigma^2 descartados) =", math.sqrt((sv[2:] ** 2).sum()))
Z = Vt[:2].T * sv[:2]
cs = lambda a, b: a @ b / np.linalg.norm(a) / np.linalg.norm(b)
print(f"   cos entre documentos 1 e 3 no espaço original (colunas): {cs(X[:, 0], X[:, 2]):.4f}; no espaço latente de posto 2: {cs(Z[0], Z[2]):.4f}")
print(f"   cos entre documentos 1 e 2 original: {cs(X[:, 0], X[:, 1]):.4f}; latente: {cs(Z[0], Z[1]):.4f}; entre 1 e 4 original {cs(X[:, 0], X[:, 3]):.4f}; latente {cs(Z[0], Z[3]):.4f}")
