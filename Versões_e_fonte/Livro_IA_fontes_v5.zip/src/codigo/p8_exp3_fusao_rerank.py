"""Projeto 8, experimento 3: fusão (RRF e variações) e reordenação aprendida. Fatias: janelas de 150 palavras, sobreposição 30.
Todas as perguntas juntas (43 diretas + 24 parafraseadas = 67). A reordenação é treinada e avaliada por VALIDAÇÃO CRUZADA
POR PERGUNTA (as perguntas de teste de cada dobra nunca entram no treino da dobra)."""
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

from p8_comum import *

nos = uteis(nos_fixos(S, 150, 30))
textos = [n.get_content() for n in nos]
secs = np.array([secao_de(n) for n in nos])
Q = [(q, g, "dir") for q, g in DIRETAS] + [(q, g, "par") for q, g in PARAF]
e = embedding(128)
V = np.array(e._get_text_embeddings(textos))
bm = BM25PT(nos, top_k=10)
N = len(Q)
cos = np.array([V @ np.array(e._get_query_embedding(q)) for q, _, _ in Q])          # (perguntas, nós)
bms = np.array([bm.bm25.get_scores(tokens(q)) for q, _, _ in Q])


def ranks(M):
    """posição (1 = melhor) de cada nó, por pergunta."""
    r = np.empty_like(M, dtype=int)
    for i in range(len(M)):
        r[i, np.argsort(-M[i])] = np.arange(1, M.shape[1] + 1)
    return r


Rc, Rb = ranks(cos), ranks(bms)


def rrf(rs, k=60, pesos=None):
    pesos = pesos or [1.0] * len(rs)
    return sum(w / (k + r) for w, r in zip(pesos, rs))


def mm(M, top=30):
    """normalização min-max usando só os `top` melhores de cada pergunta (como se faz com um recuperador que devolve top-k)."""
    S_ = np.zeros_like(M, dtype=float)
    for i in range(len(M)):
        idx = np.argsort(-M[i])[:top]; lo, hi = M[i, idx].min(), M[i, idx].max()
        S_[i, idx] = (M[i, idx] - lo) / (hi - lo + 1e-12)
    return S_


def listas(M, k=10): return [list(secs[np.argsort(-M[i])[:k]]) for i in range(N)]
golds = [g for _, g, _ in Q]
dir_ = [i for i in range(N) if Q[i][2] == "dir"]; par = [i for i in range(N) if Q[i][2] == "par"]


def linha(nome, M):
    L = listas(M)
    m = [metricas([L[i] for i in idx], [golds[i] for i in idx]) for idx in (dir_, par, range(N))]
    print(f"{nome:44s} " + "  ".join(f"{x['hit@1']:.2f}/{x['hit@5']:.2f}/{x['MRR@10']:.2f}" for x in m))
    return L


print(f"{'método':44s} {'diretas':>16}  {'parafraseadas':>16}  {'todas (67)':>16}   (hit@1/hit@5/MRR@10)")
linha("denso (LSA)", cos)
linha("BM25", bms)
for k in (1, 10, 60, 200):
    linha(f"RRF (k={k})", rrf([Rc, Rb], k))
linha("soma de pontuações normalizadas (0,5/0,5)", 0.5 * mm(cos) + 0.5 * mm(bms))
linha("RRF ponderado (denso 1; BM25 2)", rrf([Rc, Rb], 60, [1, 2]))
linha("RRF ponderado (denso 2; BM25 1)", rrf([Rc, Rb], 60, [2, 1]))

print("\nInvariância da RRF a transformações monótonas das pontuações:")
bms_exp = np.exp(bms / 4)                          # transformação crescente das pontuações do BM25
a = np.mean([np.array_equal(np.argsort(-rrf([Rc, ranks(bms)], 60)[i]), np.argsort(-rrf([Rc, ranks(bms_exp)], 60)[i])) for i in range(N)])
b = np.mean([np.array_equal(np.argsort(-(0.5 * mm(cos) + 0.5 * mm(bms))[i])[:10], np.argsort(-(0.5 * mm(cos) + 0.5 * mm(bms_exp))[i])[:10]) for i in range(N)])
print(f"  fração de perguntas com o MESMO top-10 depois de trocar BM25 por exp(BM25/4): RRF {a:.2f}; soma normalizada {b:.2f}")

# ------------------------------------------------------------------ reordenação aprendida (validação cruzada por pergunta)
POOL = 20
base = rrf([Rc, Rb], 60)
pal_titulo = {s["id"]: set(tokens(s["titulo"])) for s in S}
pal_secao = {s["id"]: set(tokens(TEXTO[s["id"]])) for s in S}
pal_no = [set(tokens(t)) for t in textos]
comp = np.log([len(t.split()) for t in textos])


def caracteristicas(i):
    qs = set(tokens(Q[i][0])); cand = np.argsort(-base[i])[:POOL]
    X = []
    for j in cand:
        sec = secs[j]
        X.append([bms[i, j] / bms[i].max(), cos[i, j], 1 / (60 + Rc[i, j]), 1 / (60 + Rb[i, j]), len(qs & pal_no[j]) / len(qs),
                  len(qs & pal_titulo[sec]) / len(qs), len(qs & pal_secao[sec]) / len(qs), comp[j]])
    return cand, np.array(X)


dados = [caracteristicas(i) for i in range(N)]
y = [np.array([1 if secs[j] in golds[i] else 0 for j in dados[i][0]]) for i in range(N)]
estrato = np.array([0 if Q[i][2] == "dir" else 1 for i in range(N)])
REP = 20
rr_base = np.zeros(N); h1_base = np.zeros(N); rr_new = np.zeros((REP, N)); h1_new = np.zeros((REP, N)); h5_new = np.zeros((REP, N))
for i in range(N):
    l = list(secs[np.argsort(-base[i])[:10]]); pos = [p for p, s in enumerate(l) if s in golds[i]]
    rr_base[i] = 1 / (pos[0] + 1) if pos else 0; h1_base[i] = l[0] in golds[i]
for rep in range(REP):
    for tr, te in StratifiedKFold(5, shuffle=True, random_state=rep).split(np.zeros(N), estrato):
        Xtr = np.vstack([dados[i][1] for i in tr]); ytr = np.concatenate([y[i] for i in tr])
        sc = StandardScaler().fit(Xtr); lr = LogisticRegression(C=1.0, max_iter=1000).fit(sc.transform(Xtr), ytr)
        for i in te:
            p = lr.predict_proba(sc.transform(dados[i][1]))[:, 1]
            l = list(secs[dados[i][0][np.argsort(-p)][:10]]); pos = [q for q, s in enumerate(l) if s in golds[i]]
            rr_new[rep, i] = 1 / (pos[0] + 1) if pos else 0; h1_new[rep, i] = l[0] in golds[i]; h5_new[rep, i] = any(s in golds[i] for s in l[:5])
print(f"\nReordenação aprendida (regressão logística, {len(dados[0][1][0])} características, pool = {POOL} trechos da RRF; {REP} repetições de CV em 5 dobras por pergunta)")
for nome, idx in (("diretas", dir_), ("parafraseadas", par), ("todas", list(range(N)))):
    print(f"  {nome:14s} RRF: hit@1 {h1_base[idx].mean():.3f} MRR {rr_base[idx].mean():.3f}   |   reordenado: hit@1 {h1_new[:, idx].mean():.3f}"
          f" (desvio entre repetições {h1_new[:, idx].mean(1).std():.3f}), hit@5 {h5_new[:, idx].mean():.3f}, MRR {rr_new[:, idx].mean():.3f}"
          f" (desvio {rr_new[:, idx].mean(1).std():.3f})")
# bootstrap pareado sobre perguntas: diferença de MRR e de hit@1 (reordenado - RRF), médias das repetições por pergunta
rng = np.random.default_rng(0)
dm, dh = rr_new.mean(0) - rr_base, h1_new.mean(0) - h1_base
for nome, idx in (("todas", np.arange(N)), ("parafraseadas", np.array(par))):
    amostras = [rng.choice(idx, len(idx)) for _ in range(5000)]
    bs = np.array([(dm[a].mean(), dh[a].mean()) for a in amostras])      # a MESMA reamostragem de perguntas para as duas métricas
    print(f"  diferença (reordenado - RRF), {nome}: MRR {dm[idx].mean():+.3f} IC95% [{np.percentile(bs[:, 0], 2.5):+.3f}, {np.percentile(bs[:, 0], 97.5):+.3f}]; "
          f"hit@1 {dh[idx].mean():+.3f} IC95% [{np.percentile(bs[:, 1], 2.5):+.3f}, {np.percentile(bs[:, 1], 97.5):+.3f}]")
Xa = np.vstack([d[1] for d in dados]); ya = np.concatenate(y); sc = StandardScaler().fit(Xa); lr = LogisticRegression(C=1.0, max_iter=1000).fit(sc.transform(Xa), ya)
nomes = ["bm25 norm.", "cosseno", "1/(60+rank denso)", "1/(60+rank BM25)", "cobertura no trecho", "cobertura no título", "cobertura na seção", "log comprimento"]
print("  coeficientes (todas as perguntas; característica padronizada):", ", ".join(f"{n} {c:+.2f}" for n, c in zip(nomes, lr.coef_[0])))

# ------------------------------------------------------------------ incerteza das comparações (bootstrap pareado sobre as 67 perguntas)
def rr_por_pergunta(M):
    L = listas(M); out = []
    for i in range(N):
        pos = [p for p, s in enumerate(L[i]) if s in golds[i]]
        out.append(1 / (pos[0] + 1) if pos else 0.0)
    return np.array(out)


metodos = {"denso": cos, "BM25": bms, "RRF (k=60)": rrf([Rc, Rb], 60), "soma normalizada": 0.5 * mm(cos) + 0.5 * mm(bms)}
RR = {k: rr_por_pergunta(v) for k, v in metodos.items()}
rng = np.random.default_rng(1)
amostras = [rng.integers(0, N, N) for _ in range(5000)]
print("\nMRR@10 nas 67 perguntas, com IC95% por bootstrap sobre as perguntas")
for k, v in RR.items():
    bs = np.array([v[a].mean() for a in amostras])
    print(f"  {k:18s} {v.mean():.3f}  [{np.percentile(bs, 2.5):.3f}, {np.percentile(bs, 97.5):.3f}]")
for a_, b_ in (("BM25", "RRF (k=60)"), ("soma normalizada", "RRF (k=60)"), ("BM25", "denso")):
    d_ = RR[a_] - RR[b_]; bs = np.array([d_[a].mean() for a in amostras])
    print(f"  diferença {a_} - {b_}: {d_.mean():+.3f}  IC95% [{np.percentile(bs, 2.5):+.3f}, {np.percentile(bs, 97.5):+.3f}]")
