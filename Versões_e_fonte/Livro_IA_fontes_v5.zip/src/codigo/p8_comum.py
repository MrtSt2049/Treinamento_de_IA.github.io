"""Projeto 8: carregamento comum (corpus, perguntas, embedding) para os programas de experimento."""
from p8_gold import EM_CORPUS, FORA_DO_CORPUS, PARAFRASEADAS
from p8_rag import *

S = carregar_secoes()
TEXTO = {s["id"]: s["titulo"] + ". " + s["texto"] for s in S}
DIRETAS = [(q, set(g)) for q, g, _ in EM_CORPUS]
PARAF = [(q, set(g)) for q, g, _ in PARAFRASEADAS]
_cache = {}


def embedding(dim=128, normalizar=True):
    """Embedding LSA ajustado SÓ com o texto do corpus (janelas de 100 palavras, sem sobreposição); não vê perguntas nem gabarito."""
    chave = (dim, normalizar)
    if chave not in _cache:
        _cache[chave] = LSAEmbedding(dim=dim, normalizar=normalizar).ajustar([n.get_content() for n in nos_fixos(S, 100, 0)])
    return _cache[chave]


def avaliar(retriever, perguntas, k=10):
    """Roda o recuperador nas perguntas e devolve as métricas (hit@k, MRR, nDCG)."""
    listas = [lista_secoes(retriever.retrieve(q)[:k]) for q, _ in perguntas]
    return metricas(listas, [g for _, g in perguntas])
