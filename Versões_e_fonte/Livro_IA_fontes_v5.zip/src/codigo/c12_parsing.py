"""Capítulo 12: o que um extrator de PDF simples faz com uma tabela e com código (pypdf, executado), e uma linearização
da tabela que preserva o cabeçalho. NÃO usa LlamaParse (serviço em nuvem, indisponível aqui)."""
import io

from pypdf import PdfReader
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle

TABELA = [["Modelo", "Parâmetros", "Perplexidade (teste)"], ["Sem pré-treino", "937 728", "85,75"], ["Ajuste completo", "937 728", "51,08"], ["LoRA r=16", "131 072 treináveis", "58,49"]]
buf = io.BytesIO()
est = getSampleStyleSheet()
tab = Table(TABELA); tab.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]))
SimpleDocTemplate(buf, pagesize=A4).build([
    Paragraph("Resultados do ajuste fino", est["Heading2"]),
    Paragraph("A tabela compara os métodos de adaptação no domínio-alvo.", est["Normal"]), Spacer(1, 8), tab, Spacer(1, 8),
    Paragraph("O trecho de código abaixo calcula a perplexidade.", est["Normal"]),
    Preformatted("def ppl(perda):\n    return math.exp(perda)", est["Code"])])

texto = PdfReader(io.BytesIO(buf.getvalue())).pages[0].extract_text()
print("texto extraído pelo pypdf:\n" + "\n".join("  | " + l for l in texto.splitlines()))
print("\nO texto é recuperável, mas a tabela virou linhas soltas: a pergunta 'qual a perplexidade do ajuste completo?' depende de")
print("associar '51,08' ao cabeçalho 'Perplexidade (teste)' e à linha 'Ajuste completo', e essa associação não está no texto.\n")


def linearizar(tabela):
    """Uma frase por linha, repetindo o cabeçalho em cada célula: cada frase se sustenta sozinha como trecho."""
    cab, *linhas = tabela
    return [f"{linha[0]}: " + "; ".join(f"{c} = {v}" for c, v in zip(cab[1:], linha[1:])) + "." for linha in linhas]


for f in linearizar(TABELA):
    print("  ->", f)
