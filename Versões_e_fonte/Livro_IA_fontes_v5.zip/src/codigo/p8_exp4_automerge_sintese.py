"""Projeto 8, experimento 4: (A) recuperação hierárquica com fusão automática de nós (AutoMergingRetriever); (B) modos de
síntese de resposta do LlamaIndex (compact, refine, tree_summarize, simple_summarize) com o LLM EXTRATIVO (não gerativo)."""
import re

from llama_index.core import PromptTemplate, StorageContext, VectorStoreIndex, get_response_synthesizer
from llama_index.core.retrievers import AutoMergingRetriever
from llama_index.core.query_engine import RetrieverQueryEngine

from p8_comum import *

Q = DIRETAS + PARAF
emb = embedding(128)
golds = [g for _, g in Q]

# ------------------------------------------------------------------ (A) auto-merging
todos, folhas = nos_hierarquicos(S, (600, 150))
folhas = uteis(folhas)
docstore_ctx = StorageContext.from_defaults()
docstore_ctx.docstore.add_documents(todos)
idx = VectorStoreIndex(folhas, embed_model=emb, storage_context=docstore_ctx)
print(f"(A) hierarquia: {len(todos)} nós no total, {len(folhas)} folhas úteis (~{np.mean([len(n.get_content().split()) for n in folhas]):.0f} palavras), "
      f"{sum(1 for n in todos if n.child_nodes)} nós com filhos (~{np.mean([len(n.get_content().split()) for n in todos if n.child_nodes]):.0f} palavras)")
print(f"{'recuperador':34s} {'hit@1':>6} {'hit@3':>6} {'MRR':>6} {'palavras de contexto (top-5)':>30}")
for rot, base in (("denso, folhas", idx.as_retriever(similarity_top_k=10)), ("BM25, folhas", BM25PT(folhas, top_k=10))):
    for nome, ret in ((rot, base), (rot + " + fusão automática", AutoMergingRetriever(base, docstore_ctx, simple_ratio_thresh=0.4, verbose=False))):
        res = [ret.retrieve(q) for q, _ in Q]
        m = metricas([lista_secoes(r[:10]) for r in res], golds)
        pal = np.mean([sum(len(x.node.get_content().split()) for x in r[:5]) for r in res])
        print(f"{nome:34s} {m['hit@1']:6.2f} {m['hit@3']:6.2f} {m['MRR@10']:6.2f} {pal:30.0f}")

# ------------------------------------------------------------------ (B) modos de síntese
print("\n(B) modos de síntese, 5 trechos (janelas de 150 palavras) recuperados pelo BM25; LLM extrativo; 67 perguntas")
nos = uteis(nos_fixos(S, 150, 30))
for n in nos:
    n.excluded_llm_metadata_keys = []            # o "LLM" enxerga "secao: X" antes de cada trecho: é o identificador para citar
bm = BM25PT(nos, top_k=5)
QA = PromptTemplate("<<<CONTEXTO\n{context_str}\n<<<FIM\nResponda SOMENTE com base no contexto acima, citando [secao]. Pergunta: {query_str}\nResposta: ")
REF = PromptTemplate("Pergunta: {query_str}\nResposta atual: {existing_answer}\n<<<CONTEXTO\n{context_msg}\n<<<FIM\nRefine a resposta SOMENTE se o contexto acima ajudar.\nResposta: ")
for janela in (100000, 1500, 900):
    llm = LLMExtrativo(janela=janela)
    print(f"\njanela de contexto do LLM = {janela} tokens")
    print(f"{'modo':20s} {'chamadas/pergunta':>18} {'palavras de prompt/pergunta':>28} {'citação correta':>16}")
    for modo in ("simple_summarize", "compact", "refine", "tree_summarize"):
        sint = get_response_synthesizer(llm=llm, response_mode=modo, text_qa_template=QA, refine_template=REF, summary_template=QA)
        motor = RetrieverQueryEngine(retriever=bm, response_synthesizer=sint)
        ch, pa, ok, vazio = [], [], 0, 0
        for q, g in Q:
            llm.zerar(q)
            r = motor.query(q)
            ch.append(llm.chamadas); pa.append(llm.palavras_prompt)
            m = re.search(r"\[(\d+\.\d+)\]\s*$", str(r).strip())
            ok += bool(m and m.group(1) in g); vazio += not m
        print(f"{modo:20s} {np.mean(ch):18.2f} {np.mean(pa):28.0f} {ok / len(Q):16.2f}   (sem citação: {vazio})")
llm = LLMExtrativo()
exemplo = Q[6][0]
llm.zerar(exemplo)
sint = get_response_synthesizer(llm=llm, response_mode="compact", text_qa_template=QA, refine_template=REF)
r = RetrieverQueryEngine(retriever=bm, response_synthesizer=sint).query(exemplo)
print(f"\nexemplo (compact): P: {exemplo}\n  R: {str(r)[:300]}\n  seções dos trechos recuperados: {[x.node.metadata['secao'] for x in r.source_nodes]}")
