"""Capítulo 11: saída estruturada. (A) contratos de dados com Pydantic v2; (B) laço de validação e nova tentativa com um gerador
SIMULADO (não é um modelo de linguagem); (C) decodificação restrita por expressão regular sobre o GPT-2 minúsculo do Projeto 7;
(D) a distorção da máscara token a token em um exemplo exato."""
import json
import re

import numpy as np
import regex
import torch
from pydantic import BaseModel, Field, ValidationError
from typing import Literal

# ------------------------------------------------------------------ (A) contratos com Pydantic
class Avaliacao(BaseModel):
    rotulo: Literal["positivo", "negativo", "neutro"]
    confianca: float = Field(ge=0.0, le=1.0)
    justificativa: str = Field(min_length=3, max_length=80)


print("(A) esquema JSON gerado pelo Pydantic (model_json_schema):")
print(json.dumps(Avaliacao.model_json_schema(), ensure_ascii=False))

casos = {
    "válido": '{"rotulo": "positivo", "confianca": 0.9, "justificativa": "elogia o desempenho"}',
    "rótulo fora do conjunto": '{"rotulo": "ótimo", "confianca": 0.9, "justificativa": "elogia"}',
    "confiança > 1": '{"rotulo": "neutro", "confianca": 1.7, "justificativa": "sem opinião"}',
    "campo ausente": '{"rotulo": "neutro", "confianca": 0.5}',
    "JSON truncado": '{"rotulo": "neutro", "confianca": 0.5, "justificativa": "sem opin',
    "tipo coercível (texto -> número)": '{"rotulo": "neutro", "confianca": "0.5", "justificativa": "sem opinião"}',
}
print("\nvalidação de saídas (modo padrão, que COERCE tipos):")
for nome, txt in casos.items():
    try:
        obj = Avaliacao.model_validate_json(txt)
        print(f"  {nome:34s} OK   -> {obj.model_dump()}")
    except ValidationError as e:
        er = e.errors()[0]
        print(f"  {nome:34s} ERRO -> tipo '{er['type']}', local {er['loc']}")
print("\nmodo estrito (strict=True) rejeita a coerção:")
try:
    Avaliacao.model_validate_json(casos["tipo coercível (texto -> número)"], strict=True)
    print("  aceitou")
except ValidationError as e:
    print(f"  rejeitou -> tipo '{e.errors()[0]['type']}'")

# ------------------------------------------------------------------ (B) laço de validação e nova tentativa
print("\n(B) laço de nova tentativa com gerador SIMULADO (respostas pré-programadas; NÃO é um modelo de linguagem):")
respostas = iter([casos["rótulo fora do conjunto"], casos["JSON truncado"], casos["válido"]])


def gerador_simulado(prompt):
    return next(respostas)


def extrair(prompt, tentativas=4):
    erro = None
    for i in range(1, tentativas + 1):
        p = prompt if erro is None else f"{prompt}\n\nSua resposta anterior era inválida: {erro}. Responda de novo, só com o JSON."
        saida = gerador_simulado(p)
        try:
            return Avaliacao.model_validate_json(saida), i
        except ValidationError as e:
            erro = f"{e.errors()[0]['type']} em {list(e.errors()[0]['loc'])}"
            print(f"  tentativa {i}: inválida ({erro})")
    raise RuntimeError("esgotadas as tentativas")


obj, n = extrair("Classifique o sentimento do texto.")
print(f"  tentativa {n}: válida -> {obj.model_dump()}")

# ------------------------------------------------------------------ (C) decodificação restrita
from m11 import carregar

d, tok, ds, modelo = carregar()
V = modelo.config.vocab_size
PADRAO = r'\{"rotulo": "(positivo|negativo|neutro)", "confianca": 0\.[0-9][0-9], "justificativa": "[a-zà-ú ]{3,30}"\}'
texto_tok = [tok.decode([i]) for i in range(V)]
valido_tok = [("�" not in t and t != "") for t in texto_tok]


@torch.no_grad()
def gerar(prefixo_ids, restrito, rng, max_tokens=70):
    ids = torch.tensor([prefixo_ids])
    saida = ""
    mascaras = []
    for _ in range(max_tokens):
        z = modelo(input_ids=ids).logits[0, -1]
        if restrito:
            ok = torch.tensor([valido_tok[i] and regex.fullmatch(PADRAO, saida + texto_tok[i], partial=True) is not None for i in range(V)])
            mascaras.append(int(ok.sum()))
            z = z.masked_fill(~ok, float("-inf"))
        p = torch.softmax(z, -1).numpy()
        i = int(rng.choice(V, p=p / p.sum()))
        saida += texto_tok[i]
        ids = torch.cat([ids, torch.tensor([[i]])], 1)
        if restrito and regex.fullmatch(PADRAO, saida):
            break
    return saida, mascaras


x = ds["orig_va"]["input_ids"]
N = 100
rng = np.random.default_rng(0)
print(f"\n(C) decodificação restrita por expressão regular, {N} amostras (T=1), prefixos de 16 tokens do domínio de origem")
print("    padrão:", PADRAO)
resultados = {}
for restrito in (False, True):
    ok, rot, tam, masc = 0, {}, [], []
    amostras = []
    for k in range(N):
        s, m = gerar(x[k % len(x)][:16], restrito, rng)
        amostras.append(s)
        try:
            o = Avaliacao.model_validate_json(s)
            ok += 1
            rot[o.rotulo] = rot.get(o.rotulo, 0) + 1
        except ValidationError:
            pass
        masc += m
    resultados[restrito] = (ok, rot, masc, amostras)
    nome = "COM restrição" if restrito else "SEM restrição"
    print(f"  {nome}: {ok} de {N} saídas passam na validação do Pydantic" + (f"; rótulos {rot}; tokens permitidos por passo: média {np.mean(masc):.1f} de {V}, mínimo {min(masc)}" if masc else ""))
print("  exemplo sem restrição:", repr(resultados[False][3][0][:100]))
print("  exemplos com restrição:")
for s in resultados[True][3][:3]:
    print("   ", s)

# ------------------------------------------------------------------ (D) distorção da máscara token a token
print("\n(D) a máscara token a token distorce a distribuição (exemplo exato)")
print("  vocabulário {a, b, c, d, x}; únicas saídas válidas: 'ac' e 'bd'")
P1 = {"a": 0.9, "b": 0.1}
P2 = {"a": {"c": 0.01, "x": 0.99}, "b": {"d": 0.90, "x": 0.10}}
verdadeira = {s: P1[s[0]] * P2[s[0]][s[1]] for s in ("ac", "bd")}
Z = sum(verdadeira.values())
print(f"  condicional verdadeira dado 'válido': P(ac) = {verdadeira['ac'] / Z:.3f}, P(bd) = {verdadeira['bd'] / Z:.3f}")
mascarada = {"ac": P1["a"] * 1.0, "bd": P1["b"] * 1.0}   # depois de 'a' só 'c' é permitido (renormaliza para 1); idem 'd' depois de 'b'
print(f"  máscara token a token:                P(ac) = {mascarada['ac']:.3f}, P(bd) = {mascarada['bd']:.3f}")
