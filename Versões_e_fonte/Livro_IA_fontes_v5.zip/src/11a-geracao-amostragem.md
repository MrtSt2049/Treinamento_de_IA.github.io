<div class="objetivos">

Objetivos do capítulo

- Descrever a geração de texto como um **laço** que, a cada passo, transforma os *logits* do modelo em uma distribuição, escolhe um token e o realimenta, e distinguir o que é propriedade do **modelo** do que é escolha de **decodificação**.
- Deduzir as propriedades da **temperatura** (limites, monotonicidade da entropia) e das **truncagens** top-$k$, top-$p$ e min-$p$, e as penalidades de presença e de frequência como mudanças de *logits*.
- Implementar do zero esses processadores de *logits*, **conferi-los** contra a biblioteca `transformers`, e medir o compromisso entre probabilidade dos tokens gerados, diversidade e repetição.
- Definir **alucinação**, **calibração** e **previsão seletiva**, medir a calibração de um modelo real (diagrama de confiabilidade, ECE) e explicar por que a escala de temperatura não é uma solução automática.
- Delimitar o contexto de um *prompt* de forma estrita, e **forçar saídas estruturadas** de três maneiras (contrato de dados com validação, laço de nova tentativa, decodificação restrita), provando que a máscara token a token **distorce** a distribuição.

**Pré-requisitos:** Capítulo 1 (probabilidade, esperança, variância), Capítulo 5 (métricas, validação), Capítulo 9 e Capítulo 10 (Transformer, tokenização, o GPT-2 minúsculo do Projeto 7).

</div>

## 11.1 Do modelo ao texto: o laço de geração

O Capítulo 9 mostrou que um Transformer causal produz, para cada prefixo $x_{1:t}$, um vetor de **logits** $\mathbf{z}_t\in\mathbb{R}^V$, e que a distribuição do próximo token é $p(\cdot\mid x_{1:t})=\operatorname{softmax}(\mathbf{z}_t)$. O modelo, portanto, **não escreve texto**: ele entrega uma distribuição. Quem escreve é um laço externo.

::: definicao 11.1 · Geração autorregressiva com processadores de *logits*
Dado um prefixo $x_{1:t}$, a geração repete: (i) calcula $\mathbf{z}_t$ com o modelo; (ii) aplica uma sequência de **processadores de *logits*** $\mathbf{z}_t\mapsto\tilde{\mathbf{z}}_t$ (temperatura, truncagem, penalidades, máscaras); (iii) forma $\tilde p_t=\operatorname{softmax}(\tilde{\mathbf{z}}_t)$; (iv) **escolhe** $x_{t+1}\sim\tilde p_t$ (amostragem) ou $x_{t+1}=\arg\max\tilde p_t$ (decodificação gulosa); (v) acrescenta $x_{t+1}$ ao prefixo e volta a (i), até um token de fim ou um comprimento máximo.
:::

Esse desenho separa duas coisas que costumam ser confundidas.

- **O modelo** (pesos, treinados com a entropia cruzada do Capítulo 6) define $p(\cdot\mid x_{1:t})$. Nada do que se faz em (ii) altera os pesos nem o que o modelo "sabe".
- **A decodificação** (ii)-(iv) decide como **usar** essa distribuição. Mudar a decodificação muda o texto, a diversidade, a repetição e a taxa de erros factuais, mas não a perplexidade do modelo sobre os dados de avaliação, que é medida com $T=1$ e sem truncagem.

A escolha mais simples, a **decodificação gulosa**, é determinística e tende à repetição. Na seção 11.3 isso é medido: no modelo do Projeto 7, a geração gulosa repete um quarto-grama já visto em $51{,}9\%$ dos tokens. A amostragem pura ($T=1$) quase não repete, mas produz tokens improváveis: sai texto incoerente, porque, a cada passo, uma pequena massa de probabilidade em tokens ruins se acumula ao longo de dezenas de passos. As técnicas deste capítulo procuram um ponto intermediário.

::: nota O que é executado neste capítulo, e com qual modelo
Todos os experimentos de geração usam o **GPT-2 minúsculo** pré-treinado no Projeto 7 ($937\,728$ parâmetros, vocabulário BPE de $1\,000$ tokens, treinado em texto deste livro). Ele **não segue instruções**, não conversa e não sabe responder perguntas: é um modelo de linguagem de $600$ passos de treino. O que ele oferece é o essencial para estudar a decodificação: *logits* reais, de um Transformer real. O que **não** é possível estudar aqui, por falta de um LLM de verdade (o acesso a modelos pré-treinados e a APIs estava bloqueado), são os efeitos de *prompting* sobre instruções, raciocínio em cadeia e fidelidade factual de modelos grandes. Essas partes são descritas conceitualmente e rotuladas como **não executadas**.
:::

### Prompting estruturado

O *prompt* é o **condicionamento** do modelo: tudo o que precede a posição que se quer gerar. Em modelos ajustados para seguir instruções, uma estrutura estável ajuda a separar papéis e evitar ambiguidades. Uma organização usual tem cinco blocos.

| Bloco | Função | Cuidado |
|---|---|---|
| Papel e regras | Diz o que o sistema é, o que deve e o que não deve fazer, em que formato responder. | Regras longas e contraditórias degradam o cumprimento. Prefira poucas, verificáveis. |
| Contexto | Dados e documentos sobre os quais responder (no Capítulo 12, os trechos recuperados). | Delimite-o claramente e trate-o como **dado**, nunca como instrução (seção 11.5). |
| Exemplos | Pares entrada-saída que mostram o formato (*few-shot*). | Exemplos enviesados enviesam a saída; mantenha-os diversos e corretos. |
| Pergunta ou tarefa | O pedido do usuário. | Separe do contexto por delimitadores explícitos. |
| Formato de saída | Esquema, tamanho, língua. | Garanta **por validação**, não só por pedido (seção 11.6). |

Dois padrões merecem nota. O ***few-shot*** explora a capacidade de modelos grandes de **aprender no contexto**: a distribuição condicional muda com os exemplos, sem alterar pesos. A **instrução de raciocínio em etapas** (*chain of thought*) pede que a resposta contenha passos intermediários antes da conclusão; para problemas de várias etapas, isso costuma ajudar modelos grandes (Wei et al., 2022), porque os passos escritos funcionam como "memória de trabalho". Os dois efeitos são **empíricos e dependentes do modelo**, e **não foram medidos aqui**: o GPT-2 minúsculo não os exibe.

## 11.2 Temperatura

A temperatura divide os *logits* antes do softmax.

::: definicao 11.2 · Temperatura
Para $T>0$, a distribuição com temperatura $T$ é
$$p_T(i)=\frac{e^{z_i/T}}{\sum_{j=1}^{V}e^{z_j/T}}.$$
O caso $T=1$ é o modelo original. Equivalentemente, $p_T\propto p^{1/T}$: a temperatura **eleva as probabilidades a uma potência** e renormaliza.
:::

::: proposicao 11.1 · Limites e monotonicidade da entropia
Seja $\mathbf{z}$ fixo, com máximo único em $i^*$, e $H(T)=-\sum_i p_T(i)\ln p_T(i)$ a entropia (em nats) de $p_T$. Então:

1. $T\to0^+$: $p_T$ converge para a massa unitária em $i^*$ (decodificação gulosa).
2. $T\to\infty$: $p_T$ converge para a distribuição uniforme, e $H\to\ln V$.
3. $\dfrac{dH}{dT}=\dfrac{\operatorname{Var}_{p_T}(z)}{T^{3}}\ \ge 0$, com igualdade só se todos os $z_i$ forem iguais. A entropia é **estritamente crescente** em $T$ quando os *logits* não são todos iguais.
:::

::: demonstracao
**(1)** Divida numerador e denominador por $e^{z_{i^*}/T}$: $p_T(i)=e^{(z_i-z_{i^*})/T}\big/\bigl(1+\sum_{j\ne i^*}e^{(z_j-z_{i^*})/T}\bigr)$. Para $i\ne i^*$, o expoente é negativo e dividido por $T\to0^+$, logo $p_T(i)\to0$; consequentemente $p_T(i^*)\to1$. **(2)** Quando $T\to\infty$, $z_i/T\to0$ para todo $i$, e $p_T(i)\to e^0/\sum_j e^0=1/V$. **(3)** Escreva $Z(T)=\sum_je^{z_j/T}$ e $\mu(T)=\mathbb{E}_{p_T}[z]$. Como $-\ln p_T(i)=\ln Z-z_i/T$, tem-se $H=\ln Z-\mu/T$. Ora,
$$\frac{d\ln Z}{dT}=\sum_ip_T(i)\Bigl(-\frac{z_i}{T^2}\Bigr)=-\frac{\mu}{T^2},\qquad \frac{d\ln p_T(i)}{dT}=-\frac{z_i-\mu}{T^2}\ \Rightarrow\ \frac{dp_T(i)}{dT}=-p_T(i)\frac{z_i-\mu}{T^2}.$$
Logo $\dfrac{d\mu}{dT}=\sum_iz_i\dfrac{dp_T(i)}{dT}=-\dfrac{\operatorname{Var}_{p_T}(z)}{T^2}$ (usando $\sum_i p_T(i)(z_i-\mu)=0$). Derivando $H=\ln Z-\mu/T$:
$$\frac{dH}{dT}=-\frac{\mu}{T^2}-\frac{1}{T}\frac{d\mu}{dT}+\frac{\mu}{T^2}=\frac{\operatorname{Var}_{p_T}(z)}{T^3}.$$
A variância é positiva sempre que $p_T$ tem pelo menos dois valores de $z$ com probabilidade positiva e distintos, o que vale para $T$ finito se os $z_i$ não são todos iguais.
:::

A intuição de (3): aumentar $T$ achata a distribuição; quanto **mais dispersos** os *logits*, mais rápido a entropia sobe.

::: exemplo 11.1 · Três tokens
Com $\mathbf{z}=(2,1,0)$: em $T=0{,}5$, $p=(0{,}867;\,0{,}117;\,0{,}016)$; em $T=1$, $(0{,}665;\,0{,}245;\,0{,}090)$; em $T=2$, $(0{,}507;\,0{,}307;\,0{,}186)$. Baixar $T$ concentra a massa no token líder; subi-lo aproxima de $(\tfrac13,\tfrac13,\tfrac13)$. A ordem dos tokens **nunca** muda: a temperatura é uma função crescente de $z_i$, então preserva o $\arg\max$ (isso será usado na seção 11.4).
:::

## 11.3 Truncagem, penalidades e o compromisso qualidade-diversidade

Uma distribuição de $V=1\,000$ (ou $150\,000$) tokens tem uma **cauda longa** de tokens individualmente improváveis cuja massa conjunta não é desprezível. A temperatura baixa atenua a cauda, mas também achata as diferenças entre os candidatos plausíveis. As truncagens **cortam** a cauda e mantêm as proporções do resto.

::: definicao 11.3 · Truncagens
Seja $p$ a distribuição do próximo token, com tokens ordenados por probabilidade decrescente $p_{(1)}\ge p_{(2)}\ge\cdots$.

- **Top-$k$**: mantém os $k$ tokens mais prováveis e renormaliza.
- **Top-$p$ (núcleo)**: o **núcleo** $\mathcal{N}_p$ é o menor $m$ tal que $p_{(1)}+\cdots+p_{(m)}\ge p$; mantém-se só o núcleo e renormaliza (Holtzman et al., 2020).
- **Min-$p$**: mantém os tokens com $p(i)\ge m\cdot\max_jp(j)$ e renormaliza.

Em todos os casos, "mantém e renormaliza" equivale a pôr os *logits* removidos em $-\infty$ antes do softmax.
:::

O top-$k$ tem um tamanho de conjunto fixo, mesmo quando o modelo está seguro (e só $1$ token faz sentido) ou indeciso (e $200$ fazem). O top-$p$ **adapta** o tamanho ao grau de incerteza. O min-$p$ define o limiar **relativo ao líder**: quando o modelo está seguro, o limiar é alto e o conjunto, pequeno; quando está indeciso, o limiar é baixo e o conjunto, grande.

::: proposicao 11.2 · O núcleo
O núcleo $\mathcal{N}_p$ tem três propriedades. (i) Sua massa é $\ge p$. (ii) É o conjunto de **menor cardinalidade** com massa $\ge p$. (iii) Se $i\in\mathcal{N}_p$ e $p(j)\ge p(i)$, então $j\in\mathcal{N}_p$ (o núcleo é fechado para tokens mais prováveis). Além disso, a massa do núcleo **sem** seu menor elemento é $<p$.
:::

::: demonstracao
(i) e a última afirmação são a definição de $m$ como o **menor** índice com soma acumulada $\ge p$: a soma até $m-1$ é $<p$. (ii) Qualquer conjunto $S$ com $|S|=m'$ tem massa $\le p_{(1)}+\cdots+p_{(m')}$ (os $m'$ maiores valores maximizam a soma); se $m'<m$, essa soma é $<p$ pela minimalidade de $m$. Logo $|S|\ge m$. (iii) Imediata, pela ordenação.
:::

### Penalidades de presença e de frequência

Para desencorajar a repetição, subtrai-se dos *logits* um termo que depende de quantas vezes cada token **já apareceu** no texto gerado (Definição 11.1, passo ii).

::: definicao 11.4 · Penalidades
Seja $c_i$ o número de vezes que o token $i$ já apareceu na saída. Com coeficientes $\alpha_f\ge0$ (frequência) e $\alpha_p\ge0$ (presença),
$$\tilde z_i=z_i-\alpha_f\,c_i-\alpha_p\,\mathbf{1}[c_i>0].$$
:::

::: proposicao 11.3 · Penalidades reponderam as probabilidades
Depois da penalidade, $\tilde p(i)\propto p(i)\,e^{-\alpha_fc_i-\alpha_p\mathbf{1}[c_i>0]}$. Isto é, a distribuição original é **multiplicada**, token a token, por um fator em $(0,1]$ que cai exponencialmente com a contagem (penalidade de frequência) ou que desconta uma vez só os tokens já vistos (presença). Tokens com $c_i=0$ não são alterados antes da renormalização.
:::

::: demonstracao
$e^{\tilde z_i}=e^{z_i}\,e^{-\alpha_fc_i-\alpha_p\mathbf{1}[c_i>0]}$, e o fator comum $1/\sum_je^{z_j}$ da distribuição original é absorvido na renormalização.
:::

No exemplo do programa, com $\mathbf{z}=(2,1,0)$, o token $0$ já apareceu $3$ vezes e o token $1$ uma vez: a frequência $0{,}5$ dá $\tilde{\mathbf{z}}=(0{,}5;\,0{,}5;\,0)$, e a presença $1{,}0$ dá $(1;\,0;\,0)$. Observe como a ordem **muda**: diferentemente da temperatura, as penalidades podem trocar o líder (a penalidade combinada, $0{,}5$ e $1{,}0$, põe o token $2$, nunca visto, na frente).

### Implementação e conferência contra a biblioteca

O programa implementa os cinco processadores **do zero**, sobre os *logits* reais do GPT-2 minúsculo de $55$ prefixos de $64$ tokens (um por bloco de validação da origem), e os compara com as classes equivalentes da biblioteca `transformers`.

<<< codigo/m11.py

<<< codigo/c11_amostragem.py

>>> codigo/c11_amostragem.out

Leitura do resultado, item a item.

1. **Conferência.** A diferença máxima entre as distribuições finais, para temperatura, top-$k$, top-$p$ e min-$p$, é **exatamente zero**: as implementações do texto fazem o mesmo que a biblioteca.
2. **Temperatura em um modelo real.** A entropia média do próximo token sobe de $0{,}59$ nats ($T=0{,}2$) a $3{,}81$ ($T=1$) e a $6{,}15$ ($T=2$), perto do máximo $\ln V=6{,}908$. O **tamanho do núcleo** ($p=0{,}9$) é a medida mais concreta: de $1{,}9$ tokens em $T=0{,}2$ a $115{,}5$ em $T=1$ e $570$ em $T=2$. Em $T=1$, a probabilidade do token mais provável é só $0{,}22$: esse modelo minúsculo é muito incerto, e por isso a amostragem pura gera texto desordenado.
3. **A Proposição 11.1(3).** A diferença finita da entropia concorda com a fórmula a menos de $0{,}001$ em $T=0{,}5$, $1$ e $2$, e $dH/dT>0$ em **todos** os prefixos.
4. **Limites.** Com $T=0{,}01$, o modo da distribuição é o $\arg\max$ em $100\%$ dos prefixos (a massa média nele é $0{,}982$, e não $1$; provavelmente porque, em alguns prefixos, os dois maiores *logits* estão muito próximos, o que não foi investigado). Com $T=1\,000$, a distância de variação total ao uniforme é $0{,}0008$.
5. **Núcleo.** A massa do núcleo é $\ge0{,}9$ em todos os prefixos, e sem o menor elemento é $<0{,}9$ em todos (Proposição 11.2).
6. **Penalidades.** Os números batem com o cálculo à mão do parágrafo anterior.

### O compromisso entre probabilidade, diversidade e repetição

Como comparar estratégias de decodificação? Não há uma "qualidade" única. O programa a seguir mede três quantidades sobre $55$ prefixos de $32$ tokens, com $8$ continuações de $60$ tokens por prefixo:

- a **NLL dos tokens gerados**, em nats por token, segundo o próprio modelo com $T=1$: baixa significa que o modelo gerou tokens que ele mesmo considera prováveis. **Não é qualidade humana**: texto repetitivo tem NLL baixa;
- a **diversidade** (*distinct-2*): fração de bigramas distintos entre os bigramas das $8$ continuações do mesmo prefixo (quanto mais perto de $1$, mais as amostras diferem entre si);
- a **repetição** (*rep-4*): fração dos tokens de uma continuação que pertencem a um quarto-grama que já ocorreu antes na mesma continuação.

<<< codigo/c11_qualidade_diversidade.py

>>> codigo/c11_qualidade_diversidade.out

<figure>
+++ fig_c11_amostragem.svg
<figcaption><b>Figura 11.1.</b> À esquerda, entropia média do próximo token (nats) contra a temperatura $T$ nos $55$ prefixos; a linha tracejada é $\ln V$. À direita, estratégias de decodificação posicionadas pela NLL dos tokens gerados (eixo horizontal) e pela diversidade entre amostras (eixo vertical). Rótulos só para alguns pontos; todos os valores estão na tabela acima.</figcaption>
</figure>

O que a tabela e a Figura 11.1 mostram, e o que não mostram.

- **A decodificação gulosa é o extremo da repetição:** diversidade $0{,}058$ e $51{,}9\%$ de tokens em quartos-gramas repetidos. A penalidade de frequência ($0{,}5$) **não resolve sozinha**: a diversidade sobe só a $0{,}116$, e $1{,}5\%$ dos tokens ainda repetem. A amostra impressa mostra o motivo: o modelo guloso entra em um ciclo "O erro de . O erro de . O erro de", e o ciclo se reforça a cada passo.
- **A temperatura move todos os pontos ao longo de uma curva:** a NLL dos tokens gerados vai de $2{,}69$ ($T=0{,}5$) a $4{,}04$ ($T=1$) e a $7{,}03$ ($T=2$); a diversidade, de $0{,}72$ a $0{,}95$ e a $1{,}00$. Em $T=2$ a NLL é maior que $\ln V=6{,}91$ do uniforme, ou seja, os tokens gerados são **menos prováveis que se fossem sorteados ao acaso**; o texto é ruído.
- **As truncagens, em geral, ficam acima da curva da temperatura.** Interpolando linearmente entre os pontos da curva de temperatura, a diversidade esperada para a NLL de cada truncagem seria: $0{,}75$ para top-$k=10$ (NLL $2{,}80$), $0{,}77$ para min-$p=0{,}1$ ($2{,}89$), $0{,}88$ para top-$k=40$ ($3{,}29$) e $0{,}93$ para top-$p=0{,}9$ ($3{,}67$). Os valores medidos são $0{,}72$, $0{,}83$, $0{,}90$ e $0{,}945$: **três das quatro** estão acima da curva, e top-$k=10$ está **abaixo**. A combinação $T=0{,}8$ com top-$p=0{,}9$ (NLL $3{,}10$) tem diversidade $0{,}88$, contra $0{,}83$ esperados só pela temperatura.
- **Cuidado com a leitura.** É **uma** rodada, com **um** modelo minúsculo, uma semente, sem barras de erro, e a NLL é a do próprio modelo. A conclusão "truncar domina temperar" vale para **este** experimento; para modelos grandes, a literatura (Holtzman et al., 2020) relata um comportamento qualitativamente parecido, mas isso **não foi reproduzido aqui**. Ver o texto impresso ajuda a calibrar a intuição, mas nenhum desses números mede a **correção factual** nem a **utilidade** da resposta, que exigem avaliação humana ou outros métodos (Capítulo 15).

::: nota Regras práticas, lidas com cautela
(1) Para tarefas com **resposta determinada** (extração, classificação, chamadas de função), use temperatura baixa ou decodificação gulosa; a variabilidade só traz erros. (2) Para **escrita criativa** ou geração de várias alternativas, use temperatura em torno de $0{,}7$ a $1$ com top-$p$ ou min-$p$. (3) **Não combine** temperatura alta e truncagem fraca: a cauda dominará. (4) Os valores "bons" dependem do modelo e da tarefa; fixe a semente e avalie com um critério da sua aplicação, não com números copiados de outros contextos. (5) Algumas interfaces de modelos de raciocínio **fixam** a temperatura: leia a documentação.
:::
