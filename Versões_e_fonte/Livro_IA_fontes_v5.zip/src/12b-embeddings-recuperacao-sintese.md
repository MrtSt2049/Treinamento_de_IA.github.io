## 12.5 *Embeddings*: o espaço onde a busca acontece

::: definicao 12.1 · *Embedding* e recuperação densa
Um ***embedding*** de textos é uma função $f:\text{textos}\to\mathbb{R}^d$ tal que a **proximidade** entre $f(a)$ e $f(b)$ reflete a **proximidade de significado** entre $a$ e $b$. Na **recuperação densa**, indexam-se os vetores $f(t_i)$ dos trechos e, dada a pergunta $q$, devolvem-se os $k$ trechos de maior $\operatorname{sim}\bigl(f(q),f(t_i)\bigr)$, com a similaridade escolhida entre o **cosseno**
$$\cos(\mathbf{a},\mathbf{b})=\frac{\mathbf{a}^\top\mathbf{b}}{\lVert\mathbf{a}\rVert\,\lVert\mathbf{b}\rVert},$$
o **produto interno** $\mathbf{a}^\top\mathbf{b}$ ou o **negativo da distância euclidiana** $-\lVert\mathbf{a}-\mathbf{b}\rVert$.
:::

A escolha entre as três não é arbitrária, e a Proposição 12.2 diz quando ela **não importa**.

::: proposicao 12.2 · Cosseno, produto interno e distância euclidiana
Se $\lVert\mathbf{a}\rVert=\lVert\mathbf{b}\rVert=1$, então
$$\lVert\mathbf{a}-\mathbf{b}\rVert^2=2-2\cos(\mathbf{a},\mathbf{b})=2-2\,\mathbf{a}^\top\mathbf{b}.$$
Logo, para uma pergunta $\mathbf{q}$ **unitária** e trechos **unitários**, ordenar por cosseno decrescente, por produto interno decrescente ou por distância euclidiana crescente produz **exatamente a mesma ordem**. Sem a normalização, as três ordens podem diferir.
:::

::: demonstracao
Expandindo, $\lVert\mathbf{a}-\mathbf{b}\rVert^2=\lVert\mathbf{a}\rVert^2-2\mathbf{a}^\top\mathbf{b}+\lVert\mathbf{b}\rVert^2=2-2\mathbf{a}^\top\mathbf{b}$, e com normas $1$, $\mathbf{a}^\top\mathbf{b}=\cos(\mathbf{a},\mathbf{b})$. A função $s\mapsto 2-2s$ é estritamente decrescente, então inverte a ordem de modo consistente. Sem a normalização, $\lVert\mathbf{q}-\mathbf{d}\rVert^2=\lVert\mathbf{q}\rVert^2-2\mathbf{q}^\top\mathbf{d}+\lVert\mathbf{d}\rVert^2$: para $\mathbf{q}$ fixo, a ordem depende também de $\lVert\mathbf{d}\rVert^2$, que o cosseno ignora.
:::

::: exemplo 12.1 · Quando a norma decide
Seja $\mathbf{q}=(1,1)$ e três trechos $\mathbf{d}_1=(3,3)$, $\mathbf{d}_2=(1,0{,}8)$, $\mathbf{d}_3=(2,0)$. O **cosseno** prefere $\mathbf{d}_1$ ($1{,}000$, mesma direção que $\mathbf{q}$), depois $\mathbf{d}_2$ ($0{,}994$) e $\mathbf{d}_3$ ($0{,}707$). A **distância euclidiana** prefere $\mathbf{d}_2$ ($0{,}200$), depois $\mathbf{d}_3$ ($1{,}414$) e só então $\mathbf{d}_1$ ($2{,}828$). O vetor $\mathbf{d}_1$ aponta para o mesmo lugar, mas está longe porque é **grande**. O cosseno mede **direção** (o assunto); a distância mede direção **e** tamanho.
:::

O experimento 2 mede o efeito no corpus real (dimensão $128$, $533$ trechos de $150$ palavras): com **vetores unitários**, a ordem completa do cosseno e da distância euclidiana foi **idêntica em $100\%$ das perguntas**; com os mesmos vetores **sem normalizar** (normas entre $0{,}47$ e $0{,}83$), a ordem completa foi idêntica em **$0\%$** delas, a sobreposição do top-5 caiu para $59{,}4\%$, o $\tau$ de Kendall médio para $0{,}37$ e o MRR nas perguntas diretas de $0{,}89$ para $0{,}82$. Em resumo: **normalize os vetores** (ou use o cosseno) e verifique o que o seu banco vetorial usa por padrão.

### *Embeddings* por semântica latente

O modelo de *embeddings* de uma aplicação real costuma ser uma rede treinada, como um Transformer *encoder* (Capítulo 9) afinado com **aprendizado contrastivo**: pares de textos parecidos são aproximados e pares diferentes, afastados. Aqui, sem acesso a um modelo pré-treinado, usa-se a técnica clássica da **análise semântica latente** (LSA; Deerwester et al., 1990, citado de memória), que usa só a álgebra do Capítulo 1 e a SVD do Capítulo 10.

1. Cada trecho vira um vetor esparso **TF-IDF** (radicais em português, ponderação sublinear): $2\,070$ termos no corpus deste projeto. Seja $X\in\mathbb{R}^{n\times V}$ a matriz com um trecho por linha.
2. Calcula-se a **SVD truncada** $X\approx U_r\Sigma_rV_r^\top$. Pelo teorema de Eckart-Young (Capítulo 10), $X_r=U_r\Sigma_rV_r^\top$ é a **melhor** aproximação de posto $r$ no sentido de Frobenius, com erro $\lVert X-X_r\rVert_F^2=\sum_{i>r}\sigma_i^2$.
3. O *embedding* de um texto com vetor TF-IDF $\mathbf{x}$ é $\mathbf{x}V_r$ (a "dobra" no espaço latente, sem refazer a SVD), seguido de normalização unitária.

O efeito é que termos que **coocorrem** nos mesmos trechos passam a ocupar direções vizinhas, e dois textos **sem nenhuma palavra em comum** podem ter cosseno positivo. No Exercício 12.14, uma matriz $4\times4$ mostra isso: dois documentos com cosseno **zero** no espaço original passam a ter cosseno $0{,}077$ no espaço latente de posto $2$, e outro par sobe de $0{,}82$ para $0{,}97$. O custo é a **compressão**: a dimensão $r$ retém só parte da energia $\sum_{i\le r}\sigma_i^2/\sum_i\sigma_i^2$, e a recuperação lexical exata se perde um pouco.

A Figura 12.2 (painel direito) e a tabela abaixo mostram o efeito da dimensão $r$ no corpus real, para as duas famílias de perguntas.

| dim $r$ | variância explicada | diretas (hit@1 / hit@5 / MRR) | parafraseadas (hit@1 / hit@5 / MRR) |
|---:|---:|---|---|
| 8 | $0{,}064$ | $0{,}37$ / $0{,}70$ / $0{,}51$ | $0{,}04$ / $0{,}50$ / $0{,}20$ |
| 16 | $0{,}109$ | $0{,}58$ / $0{,}86$ / $0{,}69$ | $0{,}29$ / $0{,}71$ / $0{,}46$ |
| 32 | $0{,}181$ | $0{,}74$ / $0{,}95$ / $0{,}83$ | $0{,}54$ / $0{,}71$ / $0{,}63$ |
| 64 | $0{,}293$ | $0{,}86$ / $0{,}95$ / $0{,}91$ | $0{,}42$ / $0{,}75$ / $0{,}56$ |
| 128 | $0{,}462$ | $0{,}84$ / $0{,}98$ / $0{,}89$ | $0{,}42$ / $0{,}83$ / $0{,}59$ |
| 256 | $0{,}690$ | $0{,}79$ / $0{,}98$ / $0{,}88$ | $0{,}50$ / $0{,}92$ / $0{,}67$ |
| 384 | $0{,}835$ | $0{,}81$ / $0{,}98$ / $0{,}87$ | $0{,}42$ / $0{,}92$ / $0{,}62$ |
| TF-IDF puro ($2\,070$) | $1{,}000$ | $0{,}77$ / $0{,}98$ / $0{,}85$ | $0{,}58$ / $0{,}96$ / $0{,}72$ |

O que a tabela diz, e o que não diz.

- **Dimensões muito pequenas ($8$, $16$) destroem a recuperação**: a compressão joga fora informação que distingue os trechos.
- **A partir de $r\approx 64$ não há ganho claro**: nas diretas, o MRR oscila entre $0{,}87$ e $0{,}91$, e nas parafraseadas entre $0{,}56$ e $0{,}67$, sem tendência. Com $24$ perguntas parafraseadas, essas oscilações estão **dentro do ruído**; a posição do máximo ($r=256$) não deve ser tomada como "dimensão ótima".
- **O TF-IDF puro, sem redução, vence o LSA nas parafraseadas** ($\text{MRR}=0{,}72$ contra $0{,}59$ a $0{,}67$) e perde nas diretas ($0{,}85$ contra $0{,}89$). Ou seja, neste corpus minúsculo ($\approx 60\,000$ palavras) a "semântica" aprendida **não** compensou a perda de precisão lexical. Um modelo neural treinado em bilhões de palavras aprende relações que este corpus não contém; **esse** modelo **não** foi testado aqui. Não se deve concluir que *embeddings* densos são inferiores ao TF-IDF em geral.

::: atencao O corpus de ajuste importa
A SVD foi ajustada **só** com o texto do corpus a ser consultado. Em produção, o modelo de *embeddings* é treinado **fora** do seu corpus; se o seu vocabulário (siglas internas, nomes de produtos) não estava no treino, o modelo representa mal esses termos, e um índice lexical (BM25) costuma salvar. É um dos motivos de a **busca híbrida** (seção 12.7) ser tão usada.
:::

## 12.6 Bancos vetoriais e busca aproximada de vizinhos

Dado $\mathbf{q}$, a busca **exata** dos $k$ vizinhos mais próximos entre $N$ vetores de dimensão $d$ custa $O(Nd)$ multiplicações. Para $N=800\,000$ e $d=768$ são $614$ milhões de multiplicações por consulta (Exercício 12.12), cerca de $0{,}1$ s por núcleo na taxa medida no experimento. Para milhões de documentos e muitas consultas por segundo, isso é inviável, e entra a **busca aproximada de vizinhos** (*approximate nearest neighbors*, ANN): aceita-se **perder** alguns dos verdadeiros vizinhos em troca de olhar só uma fração da base. A qualidade se mede por

$$\text{recall@}k=\frac{\lvert\text{vizinhos devolvidos}\cap\text{vizinhos exatos}\rvert}{k}.$$

Duas famílias dominam.

**IVF (*inverted file*).** Um agrupamento $k$-médias (Capítulo 3) particiona a base em $n_\text{lista}$ células. Na consulta, compara-se $\mathbf{q}$ com os $n_\text{lista}$ centroides, escolhem-se as $n_\text{sonda}$ células mais próximas e a busca exata é feita **só dentro delas**. Se as células forem equilibradas, o custo em comparações é

$$C(n_\text{lista})\;=\;\underbrace{n_\text{lista}}_{\text{centroides}}\;+\;\underbrace{n_\text{sonda}\,\frac{N}{n_\text{lista}}}_{\text{vetores nas células sondadas}}.$$

::: proposicao 12.3 · O melhor número de listas
Para $N$ e $n_\text{sonda}$ fixos, $C(n_\text{lista})$ é minimizado em
$$n_\text{lista}^\star=\sqrt{n_\text{sonda}\,N},\qquad C^\star=2\sqrt{n_\text{sonda}\,N}.$$
:::

::: demonstracao
$C$ é convexa em $n_\text{lista}>0$ (soma de uma função linear e de uma função da forma $a/n$, com $a>0$). A derivada $C'=1-n_\text{sonda}N/n_\text{lista}^2$ se anula em $n_\text{lista}^2=n_\text{sonda}N$, e nesse ponto $n_\text{lista}=n_\text{sonda}N/n_\text{lista}=\sqrt{n_\text{sonda}N}$, então $C^\star=2\sqrt{n_\text{sonda}N}$.
:::

Para $N=10^6$ e $n_\text{sonda}=8$, $n_\text{lista}^\star=2\,828$ e $C^\star=5\,657$ comparações, uma aceleração de $177\times$ sobre as $10^6$ da busca exata (Exercício 12.7). O **risco** é a vizinhança que cruza a fronteira de células: se o verdadeiro vizinho está numa célula **não sondada**, ele se perde. Sondar mais células ($n_\text{sonda}\uparrow$) sobe o *recall* e o custo.

**HNSW (*hierarchical navigable small world*; Malkov e Yashunin, citado de memória).** Constrói-se um **grafo** em que cada vetor se liga a alguns vizinhos próximos, em várias camadas: poucos nós nas camadas de cima (saltos longos) e todos na camada de baixo. A busca começa no topo, desce "gulosamente" para o vizinho mais próximo de $\mathbf{q}$ em cada camada e, na camada final, explora uma lista de candidatos de tamanho $\text{ef}_\text{busca}$. Parâmetros: $M$ (ligações por nó), $\text{ef}_\text{construção}$ e $\text{ef}_\text{busca}$ (mais candidatos, mais *recall*, mais tempo). O custo é **memória**: além dos vetores, guardam-se as ligações (com $M=32$, cerca de $2M=64$ ligações de $4$ bytes por vetor no nível $0$), $8{,}3\%$ a mais que os vetores de $768$ dimensões em *float32* (Exercício 12.8).

**Quantização de produto (PQ).** Quando a base **não cabe** na memória, comprime-se cada vetor: divide-se em $m$ subvetores e cada um é substituído pelo índice do centroide mais próximo de um dicionário de $256$ centroides, de modo que cada vetor ocupa $m$ bytes. Com $d=768$ em *float32* ($3\,072$ bytes), $m=96$ comprime $32\times$ e $m=48$, $64\times$, com perda de precisão nas distâncias.

### Medindo: nenhum benefício em 533 vetores, e um compromisso em 100 mil

O experimento 6 tem duas partes, e a diferença entre elas é a lição.

**(A) No corpus real**, com $533$ vetores, a busca exata leva $1{,}94$ ms por pergunta e o HNSW, $1{,}58$ ms (ambos incluem o cálculo do *embedding* da pergunta). O HNSW tem *recall@10* de $1{,}000$ em relação à exata, e as métricas de recuperação são **idênticas** ($\text{MRR}=0{,}783$). **Para centenas de vetores, o índice aproximado não traz nada**: o custo está no resto do pipeline.

**(B) Em dados sintéticos**, com $100\,000$ vetores unitários de dimensão $128$ gerados em $1\,000$ aglomerados e $500$ consultas, o compromisso aparece (Figura 12.3).

<figure>
+++ fig_c12_ann.svg
<figcaption><b>Figura 12.3.</b> Tempo por consulta (eixo vertical, escala logarítmica) contra o <i>recall@10</i> (eixo horizontal) para HNSW (variando $\text{ef}_\text{busca}$) e IVF (variando $n_\text{sonda}$), em $100\,000$ vetores sintéticos de dimensão $128$. O ponto exato tem <i>recall</i> $1$ e $2{,}1$ ms por consulta.</figcaption>
</figure>

| índice | construção (s) | ms/consulta | *recall@10* | memória (MB, estimada) |
|---|---:|---:|---:|---:|
| exato | $0{,}0$ | $2{,}116$ | $1{,}000$ | $51$ |
| HNSW, $\text{ef}_\text{busca}=8$ | $22{,}0$ | $0{,}056$ | $0{,}478$ | $70$ |
| HNSW, $\text{ef}_\text{busca}=32$ | $22{,}0$ | $0{,}120$ | $0{,}781$ | $70$ |
| HNSW, $\text{ef}_\text{busca}=128$ | $22{,}0$ | $0{,}343$ | $0{,}875$ | $70$ |
| IVF, $n_\text{sonda}=1$ | $10{,}5$ | $0{,}023$ | $0{,}693$ | $53$ |
| IVF, $n_\text{sonda}=8$ | $10{,}5$ | $0{,}051$ | $0{,}795$ | $53$ |
| IVF, $n_\text{sonda}=32$ | $10{,}5$ | $0{,}140$ | $0{,}873$ | $53$ |
| IVF, $n_\text{sonda}=64$ | $10{,}5$ | $0{,}254$ | $0{,}910$ | $53$ |

::: atencao Leia esta tabela com as ressalvas certas
1. **Os dados são sintéticos.** O gerador (centro do aglomerado mais $1{,}7$ vezes ruído gaussiano) teve a dispersão **ajustada** para que o problema não fosse trivial: com aglomerados bem separados, qualquer índice tem *recall* próximo de $1$. O *recall* de $0{,}78$ a $0{,}91$ aqui reflete **essa** dificuldade, não o desempenho esperado em *embeddings* reais.
2. **A memória é estimada por fórmula**, não medida.
3. Nesta base, a IVF **domina** o HNSW (mesmo *recall*, menos tempo, construção mais rápida): $0{,}873$ em $0{,}14$ ms contra $0{,}875$ em $0{,}34$ ms. **Isso não é uma regra geral.** Em outras bases, outras dimensões e outros parâmetros, a ordem pode se inverter; a prática é **medir no seu próprio conjunto** o par (*recall*, latência) para vários valores do parâmetro de busca.
4. O tempo é de um núcleo, de uma única execução; a variação entre execuções não foi medida.
:::

O LlamaIndex não implementa índices: `VectorStoreIndex` delega ao **armazenamento vetorial** escolhido (memória, FAISS, bancos como Qdrant, Chroma ou pgvector). O Projeto 8 usa a integração `FaissVectorStore` para as buscas exata e HNSW; nesta escala, como a parte (A) mostrou, a escolha do índice não afeta a qualidade da resposta. Além do vetor, os bancos guardam **metadados** e permitem **filtros** (por fonte, data, permissão), uma necessidade de produção que o ANN puro não resolve: filtrar **depois** da busca pode devolver menos de $k$ resultados, e filtrar **antes** pode degradar o índice.

## 12.7 Recuperação em múltiplos estágios

Nenhum recuperador é bom em tudo. A prática é encadear: **(1)** vários recuperadores baratos e complementares trazem um *pool* amplo de candidatos; **(2)** uma **fusão** combina as listas; **(3)** um **reordenador** (*reranker*) mais caro e mais preciso reordena só o topo; **(4)** corta-se em $k$ trechos para o *prompt*.

### BM25, o recuperador lexical

::: definicao 12.2 · BM25 (Okapi)
Para a consulta $q$ com termos $t$ e um trecho $d$ de comprimento $\lvert d\rvert$ (em termos), com comprimento médio $\overline{\ell}$ na coleção de $N$ trechos,
$$\operatorname{BM25}(q,d)=\sum_{t\in q}\operatorname{idf}(t)\cdot\frac{f(t,d)\,(k_1+1)}{f(t,d)+k_1\Bigl(1-b+b\,\dfrac{\lvert d\rvert}{\overline{\ell}}\Bigr)},\qquad
\operatorname{idf}(t)=\ln\frac{N-n_t+0{,}5}{n_t+0{,}5},$$
em que $f(t,d)$ é a frequência de $t$ em $d$ e $n_t$, o número de trechos que contêm $t$. Parâmetros usuais: $k_1\in[1{,}2;2]$ (saturação da frequência) e $b=0{,}75$ (normalização por comprimento).
:::

Dois fatos explicam o sucesso do BM25: a **saturação** (a $5$ª ocorrência de um termo vale muito menos que a $1$ª) e a **normalização por comprimento** (um trecho longo não é favorecido só por ser longo). Ele é rápido, sem treino, ótimo para **termos exatos** (siglas, nomes, códigos de erro) e **cego a sinônimos**, o oposto da recuperação densa. Um cálculo à mão está no Exercício 12.4 (e verificado no teste do projeto, que compara a pontuação do programa com a fórmula).

### Fusão recíproca de *ranks* (RRF)

As pontuações de recuperadores diferentes **não são comparáveis**: o cosseno está em $[-1,1]$, o BM25 não tem teto. A RRF (Cormack, Clarke e Büttcher, 2009, citado de memória) ignora as pontuações e usa só as **posições**.

::: definicao 12.3 · Fusão recíproca de *ranks*
Sejam $m$ listas ordenadas $R_1,\dots,R_m$ e $\operatorname{pos}_j(d)\in\{1,2,\dots\}$ a posição de $d$ em $R_j$. A pontuação RRF é
$$\operatorname{RRF}(d)=\sum_{j=1}^{m}\frac{\mathbf{1}[d\in R_j]}{k+\operatorname{pos}_j(d)},$$
com $k>0$ (padrão $60$). Um documento ausente de uma lista não contribui com essa lista.
:::

::: exemplo 12.2 · RRF à mão
Lista A $=(d_1,d_2,d_3,d_4)$ e lista B $=(d_3,d_1,d_5,d_2)$, $k=60$. Então $d_1$: $\tfrac1{61}+\tfrac1{62}=0{,}03252$; $d_3$: $\tfrac1{63}+\tfrac1{61}=0{,}03227$; $d_2$: $\tfrac1{62}+\tfrac1{64}=0{,}03175$; $d_5$: $\tfrac1{63}=0{,}01587$; $d_4$: $\tfrac1{64}=0{,}01562$. A ordem final é $d_1,d_3,d_2,d_5,d_4$: os documentos presentes **nas duas listas** vêm antes dos que aparecem em uma só.
:::

::: proposicao 12.4 · Propriedades da RRF
1. **Invariância.** Se $g_j$ é estritamente crescente e substitui as pontuações do recuperador $j$, as listas e, portanto, a RRF **não mudam**.
2. **Cota.** $0<\operatorname{RRF}(d)\le m/(k+1)$ para todo $d$ que apareça em alguma lista, com igualdade se, e somente se, $d$ é o primeiro em **todas** as listas.
3. **Limite $k\to\infty$.** Para $k$ suficientemente grande, a ordem da RRF é **lexicográfica**: primeiro pelo número de listas em que o documento aparece (mais listas, melhor) e, dentro do mesmo número, pela **soma das posições** (menor, melhor), isto é, uma contagem de Borda restrita.
:::

::: demonstracao
(1) A lista depende só da **ordem** das pontuações, que $g_j$ preserva. (2) Cada parcela $1/(k+\operatorname{pos})\le1/(k+1)$, com igualdade só para $\operatorname{pos}=1$; há no máximo $m$ parcelas. (3) Se $d$ aparece em $n$ listas com posições $r_1,\dots,r_n$, então $\operatorname{RRF}(d)=\sum_i\frac1{k+r_i}=\frac nk-\frac{\sum_ir_i}{k^2}+O(k^{-3})$, com o termo de erro limitado para posições limitadas. Dois documentos com $n\ne n'$ diferem em $\ge\frac1k-O(k^{-2})$, que domina qualquer diferença de ordem $k^{-2}$; com $n=n'$, a diferença é decidida pelo termo de ordem $k^{-2}$, isto é, pela soma das posições.
:::

No exemplo 12.2, com $k=10\,000$ a ordem continua $d_1,d_3,d_2,d_5,d_4$: somas de posições $3,4,6$ para os três documentos presentes nas duas listas, depois $d_5$ ($3$) e $d_4$ ($4$). Com $k=1$, $d_1$ chega a $0{,}833$ contra $0{,}750$ de $d_3$: $k$ pequeno **amplifica** o peso do topo das listas.

O programa `p8_testes.py` verifica que esta fórmula **reproduz, nas $67$ perguntas, a ordem do `QueryFusionRetriever`** do LlamaIndex com `mode="reciprocal_rerank"` e `num_queries=1`. (Com `num_queries>1`, o retriever pede ao LLM variações da pergunta, o que está fora do alcance deste ambiente.)

### Métricas de recuperação

Antes dos resultados, as métricas, porque elas decidem o que se conclui.

::: definicao 12.4 · hit@$k$, MRR e nDCG
Para cada pergunta, o **gabarito** é o conjunto $G$ de seções que respondem à pergunta. Seja $\rho_1<\rho_2<\dots$ a lista de **seções** (sem repetição, na ordem da primeira aparição) dos trechos recuperados.
- **hit@$k$**: $1$ se algum dos $k$ primeiros trechos pertence a uma seção de $G$, senão $0$.
- **MRR@10** (*mean reciprocal rank*): a média, sobre as perguntas, de $1/\rho^\star$, em que $\rho^\star$ é a posição da primeira seção de $G$ entre as $10$ primeiras (e $0$ se não houver).
- **nDCG@10**: $\operatorname{DCG}=\sum_{i=1}^{10}\dfrac{\mathbf{1}[\rho_i\in G]}{\log_2(i+1)}$, dividido pelo $\operatorname{DCG}$ da lista ideal (todas as seções de $G$ no topo); vale $1$ para a lista perfeita e $0$ se não há acerto.
:::

O hit@$1$ pergunta "o primeiro resultado serve?", o MRR premia acertos próximos do topo, e o nDCG também considera **vários** relevantes. Um exemplo calculado à mão (Exercício 12.5): três perguntas com acertos nas posições $1$, $3$ e $2$ dão hit@1 $=1/3$, hit@3 $=1$ e MRR $=(1+\tfrac13+\tfrac12)/3=0{,}611$.

**Cuidado com a unidade.** O gabarito aponta **seções**, mas o índice contém **trechos**. A métrica hit@$k$ conta trechos (um mesmo acerto pode ocupar vários lugares do topo), e MRR e nDCG deduplicam por seção. Comparar números de estratégias com fatiamentos diferentes só faz sentido porque a **unidade de gabarito é a mesma** (a seção).

### Resultados: a fusão não ganhou do melhor recuperador isolado

O experimento 3 compara os recuperadores nas $67$ perguntas (diretas e parafraseadas juntas), trechos de $150$ palavras:

| método | diretas | parafraseadas | todas ($67$) |
|---|---|---|---|
| denso (LSA) | $0{,}84$/$0{,}98$/$0{,}89$ | $0{,}42$/$0{,}83$/$0{,}59$ | $0{,}69$/$0{,}93$/$0{,}78$ |
| BM25 | $0{,}79$/$1{,}00$/$0{,}87$ | $0{,}58$/$0{,}92$/$0{,}69$ | $0{,}72$/$0{,}97$/$0{,}81$ |
| RRF ($k=1$) | $0{,}79$/$1{,}00$/$0{,}88$ | $0{,}54$/$0{,}88$/$0{,}68$ | $0{,}70$/$0{,}96$/$0{,}81$ |
| RRF ($k=60$) | $0{,}77$/$1{,}00$/$0{,}87$ | $0{,}50$/$0{,}88$/$0{,}64$ | $0{,}67$/$0{,}96$/$0{,}78$ |
| soma de pontuações normalizadas | $0{,}84$/$1{,}00$/$0{,}90$ | $0{,}54$/$0{,}88$/$0{,}68$ | $0{,}73$/$0{,}96$/$0{,}82$ |
| RRF ponderada (denso $1$; BM25 $2$) | $0{,}77$/$1{,}00$/$0{,}87$ | $0{,}58$/$0{,}88$/$0{,}70$ | $0{,}70$/$0{,}96$/$0{,}81$ |

(cada célula é hit@1 / hit@5 / MRR@10.) E com **intervalos de confiança de $95\%$ por *bootstrap* sobre as perguntas** (reamostrando as $67$ perguntas com reposição, pareado entre métodos):

| método | MRR@10 | IC95% |
|---|---:|---|
| denso | $0{,}783$ | $[0{,}699;\ 0{,}862]$ |
| BM25 | $0{,}810$ | $[0{,}732;\ 0{,}881]$ |
| RRF ($k=60$) | $0{,}783$ | $[0{,}702;\ 0{,}859]$ |
| soma normalizada | $0{,}822$ | $[0{,}746;\ 0{,}891]$ |

| diferença | valor | IC95% |
|---|---:|---|
| BM25 $-$ RRF ($k=60$) | $+0{,}027$ | $[-0{,}017;\ +0{,}075]$ |
| BM25 $-$ denso | $+0{,}027$ | $[-0{,}049;\ +0{,}105]$ |
| soma normalizada $-$ RRF ($k=60$) | $+0{,}038$ | $[+0{,}004;\ +0{,}081]$ |

Leitura honesta:

- **A RRF com pesos iguais não superou o melhor recuperador isolado (BM25)**, o que contraria a expectativa de que "híbrido sempre ajuda". Aqui o recuperador denso (LSA) é **mais fraco** que o BM25, e uma fusão com pesos iguais dilui o melhor com o pior. A RRF **ponderada** (BM25 com peso $2$) recupera o nível do BM25 nas parafraseadas, e com $k=1$ (muito concentrada no topo) também chega perto. A fusão ajuda quando os recuperadores são **complementares e de qualidade parecida**; com um recuperador muito mais fraco, a melhor "fusão" é ignorá-lo.
- **Todas as diferenças entre denso, BM25 e RRF têm intervalos que incluem o zero**: com $67$ perguntas, **não se distingue** um do outro. Para detectar uma diferença real de $0{,}03$ de MRR seriam necessárias cerca de $160$ perguntas, e para $0{,}01$, cerca de $1\,444$ (Exercício 12.13).
- **A única diferença com intervalo fora do zero** é "soma normalizada $-$ RRF" ($+0{,}038$, $[+0{,}004;\ +0{,}081]$). Mas ela foi achada **olhando nove variantes**; sem correção para comparações múltiplas, um intervalo que mal exclui o zero é uma **hipótese a testar** em novos dados, e não uma conclusão.
- **A virtude da RRF não aparece na tabela: é a robustez.** Trocando as pontuações do BM25 por $\exp(\text{BM25}/4)$ (uma transformação monótona, que não muda a ordem), a **RRF produziu o mesmo top-10 em $100\%$ das perguntas**, enquanto a soma de pontuações normalizadas só o fez em $4\%$ (Proposição 12.4, item 1). A RRF dispensa calibrar escalas entre recuperadores, ao custo de **ignorar a margem** das pontuações (um primeiro lugar por larga vantagem vale o mesmo que um por empate).

### Reordenação (*reranking*)

O reordenador recebe os $20$ primeiros candidatos da RRF e os **reordena** com uma pontuação mais cara. Em produção, usa-se tipicamente um ***cross-encoder***, um Transformer que lê o par (pergunta, trecho) **junto** (a atenção cruza os dois textos) e dá uma nota; é muito mais preciso que comparar vetores calculados separadamente, mas custa uma passagem pela rede **por candidato**, daí o uso só no topo. **Nenhum *cross-encoder* foi executado aqui** (não há modelo pré-treinado disponível). No lugar, o projeto treina um reordenador **leve**: uma regressão logística com $8$ características por candidato (BM25 normalizado, cosseno, os dois inversos de posição da RRF, cobertura dos termos da pergunta no trecho, no título e na seção, e o logaritmo do comprimento), avaliada por **validação cruzada em $5$ dobras *por pergunta*** (candidatos da mesma pergunta nunca ficam em dobras diferentes), repetida $20$ vezes.

| | RRF | reordenado | diferença (MRR), IC95% |
|---|---|---|---|
| diretas | hit@1 $0{,}767$; MRR $0{,}865$ | hit@1 $0{,}873$; MRR $0{,}930$ | |
| parafraseadas | hit@1 $0{,}500$; MRR $0{,}637$ | hit@1 $0{,}494$; MRR $0{,}638$ | $+0{,}001$ $[-0{,}124;\ +0{,}122]$ |
| todas | hit@1 $0{,}672$; MRR $0{,}783$ | hit@1 $0{,}737$; MRR $0{,}826$ | $+0{,}042$ $[-0{,}023;\ +0{,}109]$ |

O ganho está **todo** nas perguntas diretas (de $0{,}77$ a $0{,}87$ de hit@1), e **nas parafraseadas é nulo** ($+0{,}001$). Para o conjunto total, a diferença é **compatível com zero**. Duas ressalvas: **(i)** os maiores coeficientes do modelo são das características de **cobertura** (seção $+1{,}27$, título $+0{,}58$), que exploram a coincidência entre as palavras da pergunta e o título da seção; como o gabarito foi escrito pelo próprio autor a partir do mesmo texto, esse atalho pode ser **otimista** para perguntas escritas por outras pessoas; **(ii)** o desvio entre as $20$ repetições de validação cruzada ($0{,}005$ no MRR) mede só a sensibilidade à partição das dobras, **não** a incerteza sobre perguntas novas, que é o intervalo de confiança.

### Fusão automática de nós

Com o fatiamento hierárquico (seção 12.4), o `AutoMergingRetriever` troca filhos recuperados pelo pai. O experimento 4 (A) usa $508$ folhas úteis de cerca de $118$ palavras e $153$ nós pais de cerca de $393$:

| recuperador | hit@1 | hit@3 | MRR | palavras de contexto (top-5) |
|---|---:|---:|---:|---:|
| denso, folhas | $0{,}69$ | $0{,}84$ | $0{,}78$ | $605$ |
| denso, folhas + fusão automática | $0{,}66$ | $0{,}87$ | $0{,}76$ | $1\,200$ |
| BM25, folhas | $0{,}75$ | $0{,}91$ | $0{,}83$ | $616$ |
| BM25, folhas + fusão automática | $0{,}63$ | $0{,}90$ | $0{,}77$ | $1\,144$ |

Aqui a fusão automática **dobrou o contexto** e **não melhorou** a recuperação (o hit@1 do BM25 chegou a cair $12$ pontos). A técnica pode ajudar quando as respostas ficam espalhadas por trechos vizinhos, o que **este conjunto de perguntas**, de respostas curtas e localizadas, não testa.

## 12.8 Síntese da resposta, citações e abstenção

Com os trechos escolhidos, o **sintetizador** monta o *prompt* e chama o LLM. O LlamaIndex oferece **modos de resposta** que diferem em quantas chamadas fazem e em como lidam com contexto maior que a janela:

| modo | como funciona | chamadas |
|---|---|---|
| `simple_summarize` | concatena todos os trechos em **um** *prompt* e **trunca** o que não couber | $1$ |
| `compact` | junta os trechos no menor número de *prompts* que cabem na janela, e **refina** a resposta entre eles | $1$ ou mais |
| `refine` | uma chamada **por trecho**: responde com o primeiro, depois refina com cada seguinte | $=k$ |
| `tree_summarize` | resume grupos de trechos e depois resume os resumos, até uma única resposta | $\approx\log$ |

O experimento 4 (B) mede o **custo** de cada modo com $5$ trechos recuperados pelo BM25 e o LLM **extrativo**, para três tamanhos de janela. A coluna "citação correta" é a fração de perguntas em que a seção citada na resposta pertence ao gabarito.

| janela | modo | chamadas/pergunta | palavras de *prompt*/pergunta | citação correta |
|---:|---|---:|---:|---:|
| $100\,000$ | `simple_summarize` | $1{,}00$ | $648$ | $0{,}55$ |
| | `compact` | $1{,}00$ | $674$ | $0{,}55$ |
| | `refine` | $5{,}00$ | $862$ | $0{,}31$ |
| | `tree_summarize` | $1{,}00$ | $674$ | $0{,}55$ |
| $1\,500$ | `simple_summarize` | $1{,}00$ | $640$ | $0{,}55$ |
| | `compact` | $2{,}00$ | $760$ | $0{,}31$ |
| | `tree_summarize` | $1{,}63$ | $719$ | $0{,}37$ |
| $900$ | `simple_summarize` | $1{,}00$ | $351$ | $0{,}66$ |
| | `compact` | $14{,}25$ | $1\,194$ | $0{,}00$ |
| | `tree_summarize` | $3{,}60$ | $833$ | $0{,}00$ |

O que se lê aqui **vale para o custo, e não para a qualidade**: **(i)** o número de chamadas e de palavras no *prompt* **multiplica** quando a janela é pequena em relação ao contexto ($14$ chamadas por pergunta contra $1$): em produção, cada chamada é latência e dinheiro (Capítulo 15); **(ii)** `refine` faz sempre $k$ chamadas, mesmo com janela folgada; **(iii)** `simple_summarize` **trunca em silêncio** quando a janela é pequena: com $900$ *tokens*, o *prompt* caiu para $351$ palavras, ou seja, descartou parte dos trechos recuperados sem erro nem aviso. Os valores de "citação correta" **não medem a qualidade de um LLM**: o modelo extrativo escolhe uma frase e cita a seção dela, e as quedas a $0{,}00$ ou $0{,}31$ refletem como **ele** lida com *prompts* fragmentados (a pergunta e o contexto deixam de estar na mesma chamada), e não como um LLM real se comportaria. Mesmo no melhor caso, a citação correta ($0{,}55$) fica **abaixo** do acerto do primeiro resultado ($0{,}69$ a $0{,}75$): o seletor escolhe a frase de maior sobreposição entre **cinco** trechos, e nem sempre é a do trecho certo.

Um exemplo do que "citação correta" **não** garante. Para "O que é o framework PEAS na descrição de um problema para um agente?", o programa respondeu com a frase "Projetar um agente começa por descrever o problema que ele resolverá, e não por escolher um algoritmo.", citando a seção $2.5$, que de fato é a seção que define o PEAS. A **fonte** está certa; a **frase**, não: ela não define o PEAS. Uma citação correta indica de onde veio a resposta e deixa o leitor verificar, mas **não prova que a resposta esteja certa**.

::: intuicao Por que citar importa tanto
Com a citação, o erro passa de **invisível** a **auditável**: o leitor pode abrir a seção e conferir. Isso muda o papel do sistema, de "oráculo" para "assistente de busca com leitura dirigida". É a mesma ideia do contexto delimitado com identificadores do Capítulo 11: cada trecho tem um rótulo estável (aqui, `[2.5]`), a resposta deve citar esses rótulos, e **uma citação para um rótulo que não existe no contexto é detectável por programa** como erro.
:::

### Abstenção: saber quando não responder

Se a pergunta **não tem resposta** no corpus, a recuperação devolve, mesmo assim, os $k$ trechos "menos distantes". Sem uma regra de recusa, o LLM recebe contexto irrelevante e tende a inventar ou a responder com conhecimento próprio, sem fonte. A **abstenção** é a previsão seletiva do Capítulo 11 (Definição 11.6) aplicada à recuperação: calcula-se uma **pontuação de confiança** do melhor trecho e **responde-se apenas se ela passa de um limiar** $t$.

O experimento 5 usa $67$ perguntas respondíveis, $16$ **longe do domínio** (como "Qual é a capital da Austrália?") e $6$ **perto do domínio** (assuntos vizinhos, que parecem do livro, mas que ele não cobre). As três pontuações candidatas são o cosseno do melhor trecho, o BM25 bruto do melhor trecho e o BM25 dividido pelo máximo que o vocabulário da pergunta permitiria.

<figure>
+++ fig_c12_abstencao.svg
<figcaption><b>Figura 12.4.</b> À esquerda, o cosseno do melhor trecho para perguntas respondíveis, longe do domínio e perto do domínio (cada ponto é uma pergunta; a barra é a mediana). À direita, as curvas de operação: fração das respondíveis que o sistema responde (eixo vertical) contra a fração das sem resposta que ele também responde (eixo horizontal), conforme o limiar varia.</figcaption>
</figure>

A qualidade da separação se resume pela **AUROC**: a probabilidade de uma pergunta respondível, sorteada ao acaso, ter pontuação **maior** que a de uma sem resposta, sorteada ao acaso ($0{,}5$ é o acaso, $1$ é a separação perfeita).

| pontuação | AUROC contra longe | contra perto | contra ambas ($22$ contra $67$) |
|---|---|---|---|
| cosseno denso | $0{,}933$ $[0{,}868;\ 0{,}979]$ | $0{,}838$ $[0{,}667;\ 0{,}968]$ | $0{,}907$ $[0{,}832;\ 0{,}964]$ |
| BM25 bruto | $0{,}993$ $[0{,}978;\ 1{,}000]$ | $0{,}920$ $[0{,}806;\ 1{,}000]$ | $0{,}974$ $[0{,}934;\ 0{,}998]$ |
| BM25 normalizado | $0{,}763$ $[0{,}587;\ 0{,}925]$ | $0{,}662$ $[0{,}408;\ 0{,}891]$ | $0{,}735$ $[0{,}588;\ 0{,}868]$ |

(Intervalos de $95\%$ por *bootstrap*; com apenas $6$ perguntas "perto" e $16$ "longe", os intervalos são largos.) O BM25 **bruto** foi a melhor pontuação, e o BM25 **normalizado** que propus foi **pior** que ambos: o que parecia uma melhoria, dividir pelo máximo possível, **destruiu** informação útil (o BM25 bruto cresce com o número de termos raros casados, que é justamente o sinal de que o corpus fala do assunto). Tampouco se deve esperar que isso valha para outro corpus. As perguntas **perto do domínio** são sempre as mais difíceis de rejeitar.

O **ponto de operação** é a escolha do limiar, um compromisso (Capítulo 11): para o cosseno,

| limiar $t$ | respondíveis respondidas | acerto do top-1 entre as respondidas | longe respondidas | perto respondidas |
|---:|---:|---:|---:|---:|
| $0{,}00$ | $1{,}00$ | $0{,}69$ | $1{,}00$ | $1{,}00$ |
| $0{,}30$ | $1{,}00$ | $0{,}69$ | $0{,}88$ | $1{,}00$ |
| $0{,}40$ | $1{,}00$ | $0{,}69$ | $0{,}56$ | $0{,}83$ |
| $0{,}50$ | $0{,}91$ | $0{,}74$ | $0{,}31$ | $0{,}50$ |
| $0{,}60$ | $0{,}58$ | $0{,}87$ | $0{,}00$ | $0{,}17$ |

Subir o limiar **sobe a precisão** do que é respondido (de $0{,}69$ a $0{,}87$) e **reduz a cobertura** (de $100\%$ a $58\%$ das respondíveis); em $t=0{,}6$ o sistema já recusa $42\%$ das perguntas que sabia responder. **Nenhum limiar zera os dois erros.** O limiar certo depende do custo relativo de **responder errado** e de **recusar sem necessidade**, que é decisão de produto, e não de estatística (Exercício 12.9). E, por ter sido lido **nos mesmos dados** em que se avalia, este quadro é **otimista**: o limiar deve ser escolhido em um conjunto de validação e avaliado em outro.

::: atencao O NaN que atravessa o filtro
Duas perguntas ("Qual é a capital da Austrália?" e "Qual é a receita tradicional da feijoada?") não têm **nenhum radical conhecido** no vocabulário do índice. O vetor da pergunta é nulo, o cosseno é $0/0=\text{NaN}$, e **`NaN < 0.4` é falso**: o `SimilarityPostprocessor` do LlamaIndex (com `similarity_cutoff=0.4`) **mantém** os trechos em vez de cortá-los. É o mesmo defeito que contaminava o fatiamento semântico (seção 12.4), agora na abstenção: o sistema **responderia** exatamente as perguntas que mais precisavam de recusa. A regra do projeto trata NaN como $0$. Em geral: **valide as entradas numéricas** antes de usá-las em comparações (o teste correspondente está em `p8_testes.py`).
:::

Um resumo operacional da seção: **(1)** recuperar; **(2)** calcular a confiança do melhor trecho; **(3)** se abaixo do limiar, responder "não encontrei" (e talvez sugerir reformular); **(4)** senão, montar o contexto delimitado com identificadores, gerar com instrução de **citar** e **só usar o contexto**, validar a saída estruturada (Capítulo 11) e **verificar as citações**.
