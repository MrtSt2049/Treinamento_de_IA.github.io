## 12.9 Projeto 8: um sistema RAG com fontes, avaliado com perguntas de gabarito

::: projeto Perguntar ao próprio livro
O projeto constrói, com o **LlamaIndex**, um sistema de perguntas e respostas sobre o texto expositivo dos **Capítulos 1 a 11 deste livro** (99 seções, cerca de $60\,000$ palavras): ingestão, fatiamento, *embeddings*, índices, recuperação densa, lexical e híbrida, reordenação, síntese com citação da seção e abstenção. A ênfase é a **medição**: um conjunto de perguntas com gabarito, métricas definidas antes dos experimentos, intervalos de confiança e testes automáticos. Como não há acesso a modelos pré-treinados nem a APIs de LLM, **dois componentes são substitutos honestos**: um *embedding* por semântica latente e um "LLM" **extrativo** (seção 12.2). O que o projeto mede, portanto, é o **encanamento** do RAG e a **recuperação**; ele **não** mede a qualidade de respostas geradas por um LLM real.
:::

### Objetivo

Responder a seis perguntas com experimentos controlados: (1) o tamanho e o tipo de fatiamento mudam a qualidade da recuperação? (2) Como a dimensão do espaço latente e a normalização dos vetores afetam a busca densa? (3) A fusão (RRF) e a reordenação melhoram a recuperação, comparadas ao melhor recuperador isolado? (4) A fusão automática de nós ajuda, e quanto custam os modos de síntese? (5) Dá para decidir **quando não responder**, e a que preço? (6) Um índice aproximado (HNSW, IVF) traz benefício, e em que escala?

### Problema

**Corpus.** Uma unidade (`Document`) por seção expositiva dos Capítulos 1 a 11, depois de remover o que não é prosa (fórmulas, programas, figuras, cercas de contêineres) e as seções de resumo, exercícios, soluções e referências. O título da seção é prefixado ao texto. O **Capítulo 12 não entra** no corpus.

**Perguntas e gabarito.** São $67$ perguntas com resposta no corpus, e para cada uma o gabarito lista a(s) **seção(ões)** que a respondem: $43$ **diretas** (usam o vocabulário da seção) e $24$ **parafraseadas** (escritas para **evitar** a expressão-chave da seção). Há ainda $22$ perguntas **sem resposta**: $16$ **longe do domínio** (por exemplo, "Qual é a capital da Austrália?") e $6$ **perto do domínio** (assuntos de aprendizado de máquina que o livro não cobre, como SVM e DBSCAN). **O gabarito foi escrito pelo autor, a partir do mesmo texto**, o que o torna **otimista** (seção "Limitações"); para reduzir o risco, cada pergunta tem uma **chave** (expressão que deve aparecer na seção do gabarito) e um teste confere isso, e nas parafraseadas, que a chave **não** apareça na pergunta.

**Métricas.** hit@$k$, MRR@10 e nDCG@10 (Definição 12.4), calculados sobre a **seção** como unidade, e AUROC e curva de operação para a abstenção. Os intervalos de confiança são por *bootstrap* sobre as perguntas.

**Protocolo.** A configuração-base foi **fixada antes** de ver os resultados: *embedding* LSA de $128$ dimensões (ajustado só com o texto do corpus), BM25 com $k_1=1{,}5$ e $b=0{,}75$, RRF com $k=60$, janelas de $150$ palavras com sobreposição de $30$, $K=10$ resultados. As variações exploradas (tamanhos, dimensões, $k$ da RRF) estão **todas** nas tabelas, e as duas primeiras execuções com **defeitos de implementação** (que contaminavam os resultados) estão guardadas em `src/brutos/`, com a explicação das correções nas seções 12.3 e 12.4.

### Requisitos

- Pipeline com as abstrações do LlamaIndex: `Document`, `SentenceSplitter`, `HierarchicalNodeParser`, `SemanticSplitterNodeParser`, `BaseEmbedding` (subclasse), `VectorStoreIndex`, `FaissVectorStore`, `BaseRetriever` (subclasse BM25), `QueryFusionRetriever`, `AutoMergingRetriever`, `SimilarityPostprocessor`, `get_response_synthesizer`, `CustomLLM` (subclasse extrativa), `RetrieverQueryEngine`.
- Oito estratégias de fatiamento × três recuperadores × duas famílias de perguntas.
- *Embeddings* LSA em $7$ dimensões; comparação cosseno × distância euclidiana, com e sem normalização; comparação com TF-IDF puro.
- RRF com vários $k$, RRF ponderada, soma normalizada e um reordenador treinado, **todos comparados com intervalos de confiança**.
- Quatro modos de síntese em três tamanhos de janela; fusão automática de nós.
- Abstenção: três pontuações de confiança, AUROC, ponto de operação e conferência do `SimilarityPostprocessor`.
- ANN: HNSW e IVF contra a busca exata, no corpus real e em $100\,000$ vetores sintéticos.
- **Testes automáticos** (gabarito, limpeza, fatiamento, hierarquia, nós degenerados, *embedding*, BM25, RRF contra o LlamaIndex, métricas, LLM extrativo, abstenção, validação cruzada).

### Arquitetura

| Etapa | Programa | O que faz |
|---|---|---|
| Corpus | `p8_corpus.py` | Lê o Markdown dos capítulos e produz as seções em prosa. |
| Gabarito | `p8_gold.py` | Perguntas diretas, parafraseadas, fora e perto do domínio, com seções e chaves. |
| Componentes | `p8_rag.py` | Tokenização, `LSAEmbedding`, `BM25PT`, `LLMExtrativo`, fatiadores, métricas. |
| Comum | `p8_comum.py` | Carrega o corpus, ajusta o *embedding* e avalia um recuperador. |
| Testes | `p8_testes.py` | $14$ testes automáticos. |
| Experimento 1 | `p8_exp1_fatiamento.py` | Fatiamento × recuperador (seção 12.4). |
| Experimento 2 | `p8_exp2_embeddings.py` | Dimensão do LSA, cosseno × L2, TF-IDF puro (seção 12.5). |
| Experimento 3 | `p8_exp3_fusao_rerank.py` | RRF, soma normalizada, reordenação, intervalos (seção 12.7). |
| Experimento 4 | `p8_exp4_automerge_sintese.py` | Fusão automática e modos de síntese (seções 12.7 e 12.8). |
| Experimento 5 | `p8_exp5_abstencao.py` | Pontuações de confiança, AUROC, limiar (seção 12.8). |
| Experimento 6 | `p8_exp6_ann.py` | HNSW e IVF contra a busca exata (seção 12.6). |

### Fundamentos teóricos

- **Proposição 12.1:** número de janelas e cobertura por sobreposição (fatiamento).
- **Proposição 12.2:** cosseno, produto interno e distância euclidiana coincidem para vetores unitários.
- **SVD truncada e Eckart-Young (Capítulo 10):** o espaço latente do LSA.
- **Definição 12.2:** BM25. **Definição 12.3 e Proposição 12.4:** RRF (invariância, cota, limite $k\to\infty$).
- **Proposição 12.3:** número ótimo de listas da IVF.
- **Definição 12.4:** hit@$k$, MRR, nDCG. **Capítulo 11 (Definição 11.6):** previsão seletiva, que fundamenta a abstenção.

### Implementação

Primeiro o corpus e o gabarito; em seguida, os componentes (com as subclasses do LlamaIndex) e o módulo comum.

<<< codigo/p8_corpus.py

<<< codigo/p8_gold.py

<<< codigo/p8_rag.py

<<< codigo/p8_comum.py

::: nota Um detalhe do fatiador
O `SentenceSplitter` do LlamaIndex mede o tamanho em **tokens** de um *tokenizador* (por padrão, o `tiktoken`, que baixa seu vocabulário da rede). Como o ambiente restringe a rede, o código passa um **tokenizador por palavras** (`str.split`), e portanto "$150$" é **palavras**, não *tokens* de um LLM. Para um LLM real, os tamanhos devem ser dados na unidade do **seu** tokenizador, pois é ela que enche a janela de contexto.
:::

### Testes e resultados

#### Testes automáticos

Os testes cobrem as peças em que um erro **silencioso** deformaria as conclusões. Três deles merecem atenção: o do **gabarito** (as chaves existem nas seções indicadas e, nas parafraseadas, não estão na pergunta), o do **RRF** (a fórmula do texto reproduz a ordem do `QueryFusionRetriever` nas $67$ perguntas) e o dos **nós degenerados** (mostra que um fragmento sem conteúdo dá cosseno NaN).

<<< codigo/p8_testes.py

>>> codigo/p8_testes.out

#### Experimento 1: fatiamento

Código e saída estão na seção 12.4 (Figura 12.2, painel esquerdo). A conclusão: nas perguntas diretas, todos os fatiamentos funcionam; nas parafraseadas, o BM25 supera o LSA na maior parte das linhas; as diferenças entre tamanhos estão dentro do ruído de $24$ perguntas.

#### Experimento 2: *embeddings*

<<< codigo/p8_exp2_embeddings.py

>>> codigo/p8_exp2_embeddings.out

#### Experimento 3: fusão, reordenação e intervalos de confiança

<<< codigo/p8_exp3_fusao_rerank.py

>>> codigo/p8_exp3_fusao_rerank.out

#### Experimento 4: fusão automática e modos de síntese

<<< codigo/p8_exp4_automerge_sintese.py

>>> codigo/p8_exp4_automerge_sintese.out

#### Experimento 5: abstenção

<<< codigo/p8_exp5_abstencao.py

>>> codigo/p8_exp5_abstencao.out

#### Experimento 6: busca aproximada

<<< codigo/p8_exp6_ann.py

>>> codigo/p8_exp6_ann.out

#### Síntese dos resultados

| Pergunta | Resposta medida | Confiança |
|---|---|---|
| Fatiamento importa? | Pouco: nas diretas, todos funcionam (MRR $0{,}82$ a $0{,}95$); nas parafraseadas, $0{,}55$ a $0{,}73$, com diferenças dentro do ruído | Baixa (24 perguntas) |
| Dimensão do LSA? | $\ge 64$ não distingue; $\le 16$ destrói; TF-IDF puro vence nas parafraseadas | Média |
| Cosseno ou L2? | Idênticos se os vetores são unitários ($100\%$); sem normalizar, $0\%$ de ordens idênticas | Alta (é um teorema) |
| RRF ajuda? | Não superou o BM25; a única diferença fora do zero (soma normalizada contra RRF) é hipótese | Baixa |
| Reordenação? | $+0{,}042$ de MRR, $[-0{,}023;\ +0{,}109]$; nulo nas parafraseadas | Baixa |
| Fusão automática? | Dobrou o contexto e não melhorou | Média |
| Abstenção? | AUROC do BM25 bruto $0{,}974$; cosseno $0{,}907$; limiar $0{,}5$ cobre $91\%$ das respondíveis com precisão $0{,}74$ | Média (poucas perguntas sem resposta) |
| ANN? | Sem benefício em $533$ vetores; compromisso claro em $100\,000$ sintéticos | Média |

### Limitações

- **Os dois componentes substitutos.** O LSA **não é** um *embedding* neural treinado em grande escala; as conclusões sobre recuperação densa **não se transferem** para esses modelos, que provavelmente superam o BM25 nas parafraseadas. O LLM extrativo **não gera** texto: a "citação correta" mede o seletor de frases e a recuperação, **não** a fidelidade de um LLM. **Fidelidade factual, relevância do contexto e correção de respostas geradas não foram medidas** (o Capítulo 15 trata de como medi-las, e não foi executado aqui).
- **Gabarito do mesmo autor e do mesmo texto**, com $67$ + $22$ perguntas. Os intervalos de confiança refletem a variação **entre perguntas**, não a possibilidade de o gabarito ser enviesado. Perguntas escritas por outras pessoas, que não conhecem o texto, seriam, provavelmente, mais difíceis.
- **Várias comparações sem correção** para comparações múltiplas; o único resultado "estatisticamente separado" (soma normalizada contra RRF) deve ser tomado como **hipótese**.
- **Corpus pequeno e homogêneo** ($99$ seções), em um único idioma e domínio, com a matemática removida: o sistema **não responde** a perguntas sobre fórmulas.
- **ANN em dados sintéticos**, com dificuldade ajustada à mão; memória estimada por fórmula; um núcleo, uma execução.
- **Sem LlamaParse, sem *cross-encoder*, sem modelos de *embeddings* neurais e sem LLM real**: o código de uso dessas peças, quando mostrado, está marcado como **não executado**.
- **Abstenção avaliada nos mesmos dados** que definem os limiares, e com apenas $22$ perguntas sem resposta.

### Melhorias possíveis

- Trocar o LSA por um modelo de *embeddings* neural (por exemplo, da família `sentence-transformers`, com o `HuggingFaceEmbedding` do LlamaIndex) e repetir **todos** os experimentos; é a mudança que mais afeta as conclusões.
- Trocar o LLM extrativo por um LLM real e medir a **fidelidade** e a **correção** das respostas com um conjunto de avaliação, incluindo verificação das citações (Capítulo 15).
- Usar um *cross-encoder* como reordenador e comparar com o reordenador leve, **com o mesmo conjunto de perguntas**.
- Ampliar o gabarito (centenas de perguntas, escritas por **terceiros**), com anotação de mais de um avaliador, e corrigir as comparações múltiplas.
- Indexar as fórmulas (por exemplo, mantendo o LaTeX como texto) e tabelas, e avaliar a recuperação delas; usar o LlamaParse em PDFs reais.
- Escolher o limiar de abstenção em um conjunto de validação e avaliar em outro; calibrar a pontuação (Capítulo 11).
