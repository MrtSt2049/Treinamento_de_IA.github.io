## 11.7 Resumo do capítulo

::: resumo Capítulo 11
- **Geração.** O modelo dá uma distribuição; um laço de **processadores de *logits*** e de escolha produz o texto (Definição 11.1). Mudar a decodificação não muda o que o modelo sabe.
- **Temperatura.** $p_T\propto p^{1/T}$; preserva a ordem; $T\to0$ dá o $\arg\max$, $T\to\infty$ dá o uniforme, e $dH/dT=\operatorname{Var}_{p_T}(z)/T^3\ge0$ (Proposição 11.1, verificada numericamente). No modelo do Projeto 7, a entropia média vai de $0{,}59$ a $6{,}15$ nats entre $T=0{,}2$ e $T=2$.
- **Truncagens e penalidades.** Top-$k$, top-$p$ (núcleo: menor conjunto de massa $\ge p$, Proposição 11.2) e min-$p$ cortam a cauda; as penalidades de presença e de frequência reponderam as probabilidades por $e^{-\alpha_fc_i-\alpha_p\mathbf{1}[c_i>0]}$ (Proposição 11.3) e, diferentemente da temperatura, **podem trocar o líder**. As implementações do texto coincidem **exatamente** com as da biblioteca.
- **Compromisso medido.** A geração gulosa repete ($51{,}9\%$ dos tokens em quartos-gramas repetidos; diversidade $0{,}058$); a amostragem pura é diversa e de baixa probabilidade (NLL $4{,}04$). Em geral, as truncagens deram mais diversidade que a temperatura para a mesma NLL (exceto top-$k=10$). É **uma** rodada, com um modelo minúsculo, e nenhuma dessas métricas mede correção factual.
- **Alucinação.** Infidelidade ao contexto (verificável) e erro factual (exige fonte externa). Mitigação em **camadas**: contexto, recuperação, saída estruturada com citação, abstenção, verificação, revisão humana. Nenhuma taxa de alucinação de LLM real foi medida aqui.
- **Calibração.** ECE (Definição 11.5) depende do número de faixas e não é regra própria. A escala de temperatura preserva a acurácia e minimiza uma NLL **convexa** em $1/T$, com condição de ótimo por igualação de momentos (Proposição 11.4). O modelo do Projeto 7 é razoavelmente calibrado (ECE $0{,}036$), a escala **não** o melhorou ($T^*=0{,}982$; ECE $0{,}041$ no teste) e o deslocamento de domínio dobrou o erro ($0{,}065$).
- **Previsão seletiva.** Responder só quando a confiança é alta sobe a acurácia de $0{,}159$ (cobertura $100\%$) a $0{,}610$ (cobertura $5\%$); depende de a confiança **ordenar** os acertos.
- **Contexto delimitado.** Marcas com identificador, neutralização do conteúdo, instrução de "dado, não ordem", limites e privilégio mínimo. Os testes cobrem a **estrutura**; o comportamento de um LLM diante de texto hostil **não foi testado**.
- **Saída estruturada.** Contrato de dados com validação (Pydantic), laço de nova tentativa ($1-(1-p)^n$ sob independência) e decodificação restrita por máscara ($0$ para $100$ saídas válidas no GPT-2 minúsculo). A máscara garante a **forma** e **distorce** a distribuição, a menos que $w$ seja constante entre as continuações permitidas (Proposição 11.5); **válido não é correto**.
:::

**Ponte para o Capítulo 12.** A melhor defesa contra a infidelidade ao contexto é **dar o contexto certo**. O Capítulo 12 constrói o caminho que leva do conjunto de documentos privados ao trecho relevante, que será delimitado e citado como visto aqui: ingestão, fatiamento, *embeddings*, índices vetoriais, recuperação em múltiplos estágios, reordenação e síntese, com o LlamaIndex e um **Projeto 8** que mede, com perguntas de gabarito, se a recuperação acha o que deveria.

## 11.8 Exercícios

### Nível I: consolidação

**11.1** Calcule a distribuição de $\mathbf{z}=(2,1,0)$ com $T=0{,}5$ e com $T=2$. O que acontece com a ordem dos tokens?

**11.2** Dada $p=(0{,}5;\,0{,}3;\,0{,}1;\,0{,}06;\,0{,}04)$, determine as distribuições resultantes de top-$k=2$ e de top-$p=0{,}9$ (com renormalização).

**11.3** Com $\mathbf{z}=(3,2,1)$, contagens $\mathbf{c}=(2,0,1)$, penalidade de frequência $0{,}5$ e de presença $1{,}0$, calcule os *logits* penalizados e as probabilidades antes e depois. O líder mudou?

**11.4** Um classificador tem três faixas de confiança, com $n=(50,30,20)$, confiança média $(0{,}9;\,0{,}6;\,0{,}3)$ e acurácia observada $(0{,}8;\,0{,}6;\,0{,}4)$. Calcule o ECE. Em que faixas o modelo é confiante demais?

**11.5** Com o contrato `Avaliacao` da seção 11.6 (rótulo em $\{$positivo, negativo, neutro$\}$, confiança em $[0,1]$, justificativa de $3$ a $80$ caracteres), diga, sem executar, quais das saídas abaixo são válidas e, nas inválidas, qual restrição falha. (A) `{"rotulo": "Positivo", "confianca": 0.8, "justificativa": "bom"}`; (B) `{"rotulo": "neutro", "confianca": "0,5", "justificativa": "sem opinião"}`; (C) `{"rotulo": "neutro", "confianca": 1, "justificativa": "ok"}`; (D) `{"rotulo": "negativo", "confianca": 0.3, "justificativa": "ruim", "extra": 1}`. Como impedir que (D) passe?

### Nível II: desenvolvimento

**11.6** Para $\mathbf{z}=(2,1,0)$ e $T=1$, calcule $\operatorname{Var}_p(z)$ e confira $dH/dT=\operatorname{Var}_p(z)/T^3$ com uma diferença finita.

**11.7** Compare min-$p$ ($m=0{,}1$) e top-$p$ ($p=0{,}9$) nas distribuições $p_1=(0{,}8;\,0{,}06;\,0{,}05;\,0{,}04;\,0{,}03;\,0{,}02)$ e $p_2=(0{,}22;\,0{,}20;\,0{,}20;\,0{,}20;\,0{,}10;\,0{,}05;\,0{,}03)$. Quantos tokens cada método mantém? O que isso ilustra?

**11.8** Um modelo dá, a $4$ exemplos, os *logits* $(2,0)$ para as classes $(0,1)$; a classe correta é $0$ em $3$ deles e $1$ em um. Calcule a NLL com $T=1$, encontre a $T^*$ que a minimiza **de forma analítica** e confira a condição de igualação de momentos da Proposição 11.4. Que confiança o modelo passa a ter?

**11.9** Repita a distorção da máscara (Proposição 11.5) com $P(a)=P(b)=0{,}5$; depois de $a$, $P(c)=0{,}2$ e $P(x)=0{,}8$; depois de $b$, $P(d)=0{,}6$ e $P(x)=0{,}4$. Só $ac$ e $bd$ são válidas. Calcule a condicional exata, a distribuição da máscara e $w(a)$, $w(b)$.

**11.10** Um modelo produz uma saída válida em cada tentativa com probabilidade $0{,}7$, independentemente. Qual é a probabilidade de sucesso em até $3$ tentativas? Qual o número esperado de tentativas? Quantas tentativas são necessárias para chegar a $99\%$? Por que a hipótese de independência é arriscada?

### Nível III: avançado

**11.11** Seja $\tilde p$ a distribuição depois do top-$p$, e $m\ge p$ a massa do núcleo. Mostre que a distância de variação total $\operatorname{TV}(p,\tilde p)=\tfrac12\sum_i|p(i)-\tilde p(i)|$ vale $1-m\le1-p$. Confira no Exercício 11.2.

**11.12** No experimento da seção 11.4, a escala de temperatura **reduziu** (ou manteve) a NLL na calibração e **aumentou** o ECE no teste. Dê duas razões pelas quais isso não é contraditório e descreva um procedimento estatístico para decidir se a diferença de ECE ($0{,}0355$ contra $0{,}0413$) é ruído.

**11.13** Na previsão seletiva da seção 11.4 (teste da origem; acurácia total $0{,}1586$): (a) calcule a acurácia **nas $80\%$ previsões menos confiantes**, sabendo que, nas $20\%$ mais confiantes, é $0{,}367$; (b) suponha que cada acerto vale $+1$, cada erro custa $0{,}1$ e a abstenção vale $0$. Para cada cobertura da tabela, calcule o valor total por previsão e escolha o ponto de operação. Que premissa sobre a confiança está implícita?

**11.14** Escreva um contrato Pydantic para extrair de uma nota fiscal a data de vencimento, o valor em centavos (inteiro positivo) e a moeda (BRL, USD ou EUR). Execute-o em cinco saídas: uma correta; uma com data inexistente (30 de fevereiro); uma com a data em formato brasileiro (`05/12/2026`); uma com valor negativo; e uma **válida mas errada** (dia e mês trocados). O que cada camada (contrato, decodificação restrita, citação do trecho) é capaz de capturar?

## 11.9 Soluções comentadas

::: solucao 11.1
Programa `c11_ex_numeros.py`. Em $T=0{,}5$: $(0{,}867;\,0{,}117;\,0{,}016)$. Em $T=2$: $(0{,}507;\,0{,}307;\,0{,}186)$. Reduzir $T$ concentra a massa no líder; aumentá-la a espalha. A **ordem** é a mesma ($z_i/T$ é crescente em $z_i$): a temperatura nunca troca o líder (Exemplo 11.1).
:::

::: solucao 11.2
**Top-$k=2$:** mantém $0{,}5$ e $0{,}3$ (soma $0{,}8$), logo $(0{,}625;\,0{,}375;\,0;0;0)$. **Top-$p=0{,}9$:** as acumuladas são $0{,}5;\,0{,}8;\,0{,}9;\,0{,}96;\,1$; o menor $m$ com acumulada $\ge0{,}9$ é $m=3$ (a acumulada de $3$ tokens é **exatamente** $0{,}9$, e a regra é "$\ge$"). Renormalizando por $0{,}9$: $(0{,}556;\,0{,}333;\,0{,}111;\,0;0)$. O top-$k$ cortou o terceiro token, que o top-$p$ manteve.
:::

::: solucao 11.3
Frequência: $-0{,}5c_i$ $=(-1;\,0;\,-0{,}5)$. Presença: $-1\cdot\mathbf{1}[c_i>0]=(-1;\,0;\,-1)$. Logo $\tilde{\mathbf{z}}=(3-1-1;\ 2;\ 1-0{,}5-1)=(1;\,2;\,-0{,}5)$. As probabilidades vão de $(0{,}665;\,0{,}245;\,0{,}090)$ para $(0{,}254;\,0{,}690;\,0{,}057)$. **O líder mudou** do token $0$ (que já tinha aparecido duas vezes) para o token $1$ (nunca visto): é o efeito desejado, e o que a temperatura jamais faz.
:::

::: solucao 11.4
$\operatorname{ECE}=0{,}5\cdot|0{,}8-0{,}9|+0{,}3\cdot|0{,}6-0{,}6|+0{,}2\cdot|0{,}4-0{,}3|=0{,}05+0+0{,}02=0{,}07$. Na faixa $0{,}9$, a acurácia ($0{,}8$) é menor que a confiança: **confiante demais**. Na faixa $0{,}6$ está calibrado. Na faixa $0{,}3$, a acurácia ($0{,}4$) é maior: **pouco confiante**. Os erros de sinais opostos **não se cancelam** no ECE porque cada faixa entra em módulo.
:::

::: solucao 11.5
Executando (programa `c11_ex_numeros.py`): **(A)** inválida, `literal_error` em `rotulo` (a maiúscula de "Positivo" não pertence ao conjunto). **(B)** inválida, `float_parsing` em `confianca` (a vírgula decimal não é um número em JSON; o texto `"0.5"` com ponto **passaria** no modo padrão, que coage, e falharia no estrito com `float_type`). **(C)** inválida, `string_too_short` em `justificativa` ($2<3$ caracteres); o inteiro `1` em `confianca` é aceito (é um número válido). **(D)** **válida**: por padrão, o Pydantic **ignora** campos extras. Para rejeitá-los, declara-se `model_config = ConfigDict(extra="forbid")`; executado, o erro passa a ser `extra_forbidden` em `extra`. Campos extras silenciosamente descartados podem esconder um modelo que "inventou" informação.
:::

::: solucao 11.6
$p=(0{,}665;\,0{,}245;\,0{,}090)$; $\mathbb{E}[z]=2\cdot0{,}665+1\cdot0{,}245=1{,}575$ e $\mathbb{E}[z^2]=0{,}665\cdot4+0{,}245\cdot1=2{,}905$; $\operatorname{Var}=2{,}905-1{,}575^2\approx0{,}4244$ (o programa dá $0{,}42440$). A diferença finita central com passo $10^{-5}$ dá $0{,}42440$, e $H(1)=0{,}8324$ nats. Como $T=1$, $\operatorname{Var}/T^3=0{,}4244$: coincidem.
:::

::: solucao 11.7
Em $p_1$ (modelo seguro), o limiar do min-$p$ é $0{,}1\cdot0{,}8=0{,}08$: **$1$** token fica. Top-$p=0{,}9$: acumuladas $0{,}8;\,0{,}86;\,0{,}91$, logo mantém **$3$** tokens (inclui dois de cauda). Em $p_2$ (modelo indeciso), o limiar do min-$p$ é $0{,}1\cdot0{,}22=0{,}022$ e **todos os $7$** tokens passam ($0{,}03\ge0{,}022$); top-$p=0{,}9$ (acumuladas $0{,}22;\,0{,}42;\,0{,}62;\,0{,}82;\,0{,}92$) mantém **$5$**. O min-$p$ é **mais restritivo quando o modelo está seguro** e **mais permissivo quando está indeciso**, porque o limiar é relativo ao líder; o top-$p$ fixa a **massa**, não o limiar.
:::

::: solucao 11.8
Com $T=1$ e *logits* $(2,0)$: $p(0)=\sigma(2)=0{,}881$. NLL $=-\bigl[3\ln0{,}881+\ln0{,}119\bigr]/4=0{,}6269$. Com temperatura, $p(0)=\sigma(2\beta)$ e a NLL é a entropia cruzada entre a frequência empírica $(0{,}75;\,0{,}25)$ e $(\sigma,1-\sigma)$; pela desigualdade de Gibbs, é mínima quando $\sigma(2\beta)=0{,}75$, isto é, $2\beta=\ln3$, $\beta=\tfrac12\ln3$, **$T^*=2/\ln3=1{,}8205$** (busca numérica: $1{,}820$). A NLL cai para $0{,}5623$, que é a entropia de $(0{,}75;\,0{,}25)$. **Igualação de momentos:** o *logit* médio da classe correta é $(3\cdot2+1\cdot0)/4=1{,}5$; o *logit* esperado pelo modelo com $\beta^*$ é $2\sigma(2\beta^*)=2\cdot0{,}75=1{,}5$. A confiança, que era $0{,}881$ para uma acurácia de $0{,}75$ (**confiante demais**), passa a $0{,}750$: calibrada.
:::

::: solucao 11.9
Probabilidades das saídas válidas: $P(ac)=0{,}5\cdot0{,}2=0{,}10$ e $P(bd)=0{,}5\cdot0{,}6=0{,}30$; $P(\text{válido})=0{,}40$. **Condicional exata:** $P(ac\mid\text{válido})=0{,}25$ e $P(bd\mid\text{válido})=0{,}75$. **Máscara:** o primeiro token tem ambos $a$ e $b$ permitidos, com $0{,}5$ cada; depois de $a$, só $c$ é permitido (renormaliza a $1$); idem $d$ depois de $b$: $P(ac)=P(bd)=0{,}5$. $w(a)=P(c\mid a)=0{,}2$ e $w(b)=P(d\mid b)=0{,}6$ **não são iguais**, por isso a máscara distorce (Proposição 11.5); a razão $w(b)/w(a)=3$ é justamente a razão $0{,}75/0{,}25$ que a máscara não recupera.
:::

::: solucao 11.10
$1-(1-0{,}7)^3=1-0{,}027=0{,}973$. Número esperado (geométrica): $1/0{,}7=1{,}43$. Para $99\%$: $1-0{,}3^n\ge0{,}99\Rightarrow n\ge\ln0{,}01/\ln0{,}3=3{,}8$, logo **$4$** tentativas ($1-0{,}3^4=0{,}992$). A independência é arriscada porque as tentativas **compartilham a causa do erro**: se o modelo não entende o esquema, ou o *prompt* induz o erro, a probabilidade de acerto da segunda tentativa **é menor** que $0{,}7$, e o custo real (tokens e latência) é maior que o calculado. A decodificação restrita dá garantia de forma sem depender de tentativas.
:::

::: solucao 11.11
Seja $\mathcal{N}$ o núcleo, com massa $m$. Então $\tilde p(i)=p(i)/m$ em $\mathcal{N}$ e $0$ fora. Em $\mathcal{N}$, $|p(i)-\tilde p(i)|=p(i)(1/m-1)$; somando, $m(1/m-1)=1-m$. Fora de $\mathcal{N}$, $\sum|p(i)-0|=1-m$. Logo $\operatorname{TV}=\tfrac12\bigl[(1-m)+(1-m)\bigr]=1-m$. Como $m\ge p$ (Proposição 11.2), $\operatorname{TV}\le1-p$: **cortar a cauda custa, no máximo, a massa da cauda**. No Exercício 11.2, $m=0{,}9$, e o programa dá $\operatorname{TV}=0{,}1000=1-m$. Interpretação: o top-$p$ com $p=0{,}9$ altera a distribuição em no máximo $0{,}1$ em variação total, independentemente do número de tokens cortados.
:::

::: solucao 11.12
**Duas razões.** (i) A NLL é uma regra de pontuação **própria**; o ECE não é: o ECE com faixas é uma estatística diferente, com viés e variância que dependem de $B$ e do número de exemplos por faixa, e dois modelos com NLL praticamente iguais ($4{,}008$ nos dois casos) podem ter ECE de estimativa ligeiramente diferente. (ii) $T^*=0{,}982$ foi escolhido **na metade de calibração** para minimizar a NLL; a NLL é plana perto do ótimo, e a mudança de $T$ é tão pequena ($1{,}8\%$) que o efeito sobre as faixas é da mesma ordem que o erro amostral. **Procedimento.** Fazer um **bootstrap por blocos** (reamostrar os **blocos de $128$ tokens** com reposição, e não as posições, que são correlacionadas dentro do bloco), recalcular os dois ECE em cada réplica **com as mesmas amostras**, e examinar o intervalo da **diferença**. Se o intervalo incluir $0$, a diferença é compatível com ruído. Convém repetir com outras quantidades de faixas e com faixas de **mesmo número de exemplos** (quantis). **Isso não foi executado**; é a análise que se faria antes de afirmar qualquer coisa além de "a escala de temperatura não ajudou".
:::

::: solucao 11.13
**(a)** Seja $a_{\text{res}}$ a acurácia nas $80\%$ restantes. A acurácia total é uma média ponderada: $0{,}1586=0{,}2\cdot0{,}367+0{,}8\,a_{\text{res}}$, logo $a_{\text{res}}=(0{,}1586-0{,}0734)/0{,}8=\mathbf{0{,}1065}$. As previsões que o sistema recusa são, de fato, as piores: $0{,}107$ de acurácia contra $0{,}367$ nas respondidas. **(b)** Valor total $=c\,[a-0{,}1(1-a)]$: $c=1$: $0{,}0749$; $0{,}8$: $0{,}0837$; $\mathbf{0{,}6}$: $\mathbf{0{,}0865}$; $0{,}4$: $0{,}0832$; $0{,}2$: $0{,}0607$; $0{,}1$: $0{,}0454$; $0{,}05$: $0{,}0285$. O **ponto de operação ótimo é cobertura $0{,}6$** (limiar de confiança $\approx0{,}117$). Com perdas por erro menores ou maiores, o ótimo se desloca: se o erro custasse $1$, o valor total seria $c(2a-1)$ e só as coberturas de $10\%$ e $5\%$ teriam valor positivo ($0{,}0008$ e $0{,}011$). A premissa implícita é que **a confiança ordena os acertos** de forma **estável** entre o conjunto em que o limiar foi escolhido e o de uso: sob deslocamento de domínio (acurácia $0{,}120$ e ECE $0{,}065$ no alvo), o limiar escolhido na origem pode deixar de valer.
:::

::: solucao 11.14
Contrato executado em `c11_ex_numeros.py`:

```python
class Vencimento(BaseModel):
    vencimento: date
    valor_centavos: int = Field(gt=0)
    moeda: Literal["BRL", "USD", "EUR"]
```

Resultados: a saída correta passa; a data inexistente (`2026-02-30`) e a data brasileira (`05/12/2026`) falham com `date_from_datetime_parsing`; o valor negativo falha com `greater_than`; a saída **com dia e mês trocados** (`2026-05-12`) **passa**, porque é uma data válida. **Camadas.** O **contrato** pega formato, tipo e faixa. A **decodificação restrita** a um padrão como `[0-9]{4}-[0-9]{2}-[0-9]{2}` garantiria o formato ISO desde a geração (mas não rejeitaria $30$ de fevereiro: um padrão regular não conhece o calendário, e seria necessário um validador depois). A **citação do trecho** (pedir ao modelo que devolva, junto, o trecho exato da nota em que leu a data, e conferir por programa que o trecho **existe** na nota e **contém** a data) pega a troca de dia e mês, porque a data do trecho (`05/12/2026`) não coincide com a extraída. Nenhuma camada substitui a **amostragem revisada por pessoas**.
:::

## 11.10 Referências e leituras

### Livros didáticos

- JURAFSKY, D.; MARTIN, J. H. *Speech and Language Processing*. 3. ed. (rascunho), Stanford. Capítulos sobre modelos de linguagem, decodificação e avaliação. Texto completo no site dos autores.
- ZHANG, A.; LIPTON, Z. C.; LI, M.; SMOLA, A. J. *Dive into Deep Learning*. Cambridge: Cambridge University Press, 2023. Texto completo em d2l.ai.

### Artigos originais

- BROWN, T. et al. Language models are few-shot learners. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 33, 2020.
- FAN, A.; LEWIS, M.; DAUPHIN, Y. Hierarchical neural story generation. In: *Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2018.
- GEIFMAN, Y.; EL-YANIV, R. Selective classification for deep neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017.
- GRESHAKE, K. et al. Not what you've signed up for: compromising real-world LLM-integrated applications with indirect prompt injection. In: *Proceedings of the 16th ACM Workshop on Artificial Intelligence and Security (AISec)*, 2023.
- GUO, C.; PLEISS, G.; SUN, Y.; WEINBERGER, K. Q. On calibration of modern neural networks. In: *Proceedings of the 34th International Conference on Machine Learning (ICML)*, 2017.
- HOLTZMAN, A.; BUYS, J.; DU, L.; FORBES, M.; CHOI, Y. The curious case of neural text degeneration. In: *8th International Conference on Learning Representations (ICLR)*, 2020.
- JI, Z. et al. Survey of hallucination in natural language generation. *ACM Computing Surveys*, v. 55, n. 12, 2023.
- KADAVATH, S. et al. Language models (mostly) know what they know. *arXiv*, 2022.
- NAEINI, M. P.; COOPER, G. F.; HAUSKRECHT, M. Obtaining well calibrated probabilities using Bayesian binning. In: *Proceedings of the AAAI Conference on Artificial Intelligence*, 2015.
- NGUYEN, M. et al. Turning up the heat: min-$p$ sampling for creative and coherent LLM outputs. In: *13th International Conference on Learning Representations (ICLR)*, 2025.
- OVADIA, Y. et al. Can you trust your model's uncertainty? Evaluating predictive uncertainty under dataset shift. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 32, 2019.
- WANG, X. et al. Self-consistency improves chain of thought reasoning in language models. In: *11th International Conference on Learning Representations (ICLR)*, 2023.
- WEI, J. et al. Chain-of-thought prompting elicits reasoning in large language models. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 35, 2022.
- WILLARD, B. T.; LOUF, R. Efficient guided generation for large language models. *arXiv*, 2023.

### Documentação técnica

- Hugging Face: classes de processadores de *logits* da biblioteca `transformers` (`TemperatureLogitsWarper`, `TopKLogitsWarper`, `TopPLogitsWarper`, `MinPLogitsWarper`), em huggingface.co/docs.
- Pydantic: documentação de modelos, validadores, modo estrito e `model_json_schema`, em docs.pydantic.dev (versão $2{,}13{,}5$ nas execuções deste livro).
- Biblioteca `regex` (correspondência parcial, `partial=True`), em pypi.org/project/regex (versão $2026{,}11{,}9$ nas execuções).

::: nota Sobre as referências
As referências deste capítulo foram citadas **de memória**, sem consulta às páginas originais (o ambiente de produção não tem acesso aos sites dos periódicos e repositórios). Autores, títulos e locais de publicação são os que o autor conhece com confiança, mas páginas, volumes e URLs podem conter imprecisões; **confira cada uma antes de citar**. Os números de volume e de edição de alguns itens foram omitidos de propósito quando não eram seguros.
:::
