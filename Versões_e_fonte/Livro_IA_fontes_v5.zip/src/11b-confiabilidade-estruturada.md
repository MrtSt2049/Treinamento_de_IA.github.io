## 11.4 O desafio da confiabilidade

Um modelo de linguagem é treinado para **prever o próximo token provável**, não para dizer a verdade (Capítulo 6, entropia cruzada). Quando o contexto torna provável uma continuação fluente e falsa, o modelo a produz com a mesma desenvoltura com que produz uma continuação verdadeira. É disso que se trata quando se fala em alucinação.

### Alucinação

Convém separar dois problemas que a palavra mistura.

- **Infidelidade ao contexto:** a resposta **contradiz ou acrescenta** algo ao que foi fornecido no *prompt* (um documento, um trecho recuperado). É verificável: basta comparar a resposta com o contexto. É o problema central dos sistemas RAG (Capítulo 12), e as métricas de **fidelidade** do Capítulo 15 o medem.
- **Erro factual:** a resposta contradiz o mundo (uma data errada, uma citação que não existe), com ou sem contexto. Só se verifica contra uma fonte externa confiável.

As causas combinam: (i) a função objetivo premia a plausibilidade; (ii) conhecimento **ausente ou raro** nos dados de treino, para o qual o modelo não tem sinal e, ainda assim, precisa emitir um token; (iii) conhecimento **desatualizado** (os pesos são estáticos, seção 12.1); (iv) **decodificação** com entropia alta, que amostra da cauda (seção 11.3); (v) **contexto** ambíguo, contraditório ou longo demais; (vi) ausência de um comportamento de **abstenção**: modelos ajustados para ajudar tendem a responder mesmo sem base.

::: nota Sobre o que se afirma aqui
Esta seção descreve **mecanismos e práticas** da literatura. Nenhuma taxa de alucinação de um LLM real foi medida neste livro (não havia acesso a um). O que o ambiente permite medir, e é medido adiante, é uma propriedade necessária das defesas baseadas em confiança: **o quanto a probabilidade que o modelo atribui a um token prediz que ele acertou**.
:::

### Degraus de mitigação

As defesas se somam, e nenhuma é suficiente sozinha. Em ordem aproximada de custo crescente:

| Degrau | Ideia | Onde aparece |
|---|---|---|
| 1. Temperatura baixa | Reduz a amostragem da cauda. Não corrige conhecimento ausente. | Seção 11.3 |
| 2. Contexto delimitado | Dar a informação no *prompt*, mandar usar **só** ela, permitir "não sei". | Seção 11.5 |
| 3. Recuperação (RAG) | Buscar o contexto relevante em uma base privada ou atual. | Capítulo 12 |
| 4. Saída estruturada com citação | Forçar a resposta a apontar **qual trecho** a sustenta, e validar. | Seção 11.6 |
| 5. Abstenção por confiança | Só responder quando a confiança for alta o bastante. | Esta seção |
| 6. Verificação | Um segundo passo (outro modelo, regra ou ferramenta) confere a resposta; consistência entre várias amostras. | Capítulos 13 e 15 |
| 7. Revisão humana | Para decisões de alto risco. | Capítulo 15 |

O degrau 5 depende de uma **confiança** que valha alguma coisa. Para isso, precisamos de uma definição e de uma medida.

### Calibração

::: definicao 11.5 · Calibração e erro de calibração esperado (ECE)
Um classificador que dá a cada previsão uma **confiança** $\hat c\in[0,1]$ (aqui, a probabilidade do token mais provável) está **calibrado** se, entre as previsões com confiança $\hat c=c$, a fração de acertos é $c$: $\ \mathbb{P}(\text{acerto}\mid\hat c=c)=c$. Para medir o desvio, dividem-se as confianças em $B$ faixas $I_1,\dots,I_B$ e define-se
$$\operatorname{ECE}=\sum_{b=1}^{B}\frac{n_b}{n}\,\bigl|\operatorname{acc}(b)-\operatorname{conf}(b)\bigr|,$$
em que $n_b$ é o número de previsões na faixa $b$, $\operatorname{acc}(b)$ a acurácia observada nela e $\operatorname{conf}(b)$ a confiança média. O gráfico de $\operatorname{acc}(b)$ contra $\operatorname{conf}(b)$ é o **diagrama de confiabilidade**; um modelo calibrado fica sobre a diagonal.
:::

Três cuidados de leitura. **(1)** O ECE **depende de $B$** e do esquema de faixas, e as faixas com poucas amostras têm acurácia muito ruidosa. **(2)** Ele mede calibração **marginal**, não discriminação: um classificador que sempre diz "confiança $=$ acurácia global" é calibrado e inútil. **(3)** Não é uma regra de pontuação **própria** (como a entropia cruzada): não há garantia de que o ECE mínimo coincida com a melhor probabilidade. A calibração de redes profundas foi estudada por Guo et al. (2017), que relatou excesso de confiança em redes de classificação de imagens modernas e propôs a **escala de temperatura**.

::: proposicao 11.4 · Escala de temperatura
Dados os *logits* $\mathbf{z}^{(n)}$ e os rótulos $y_n$ de $N$ exemplos, seja $\beta=1/T>0$ e $\mathcal{L}(\beta)=-\frac1N\sum_n\ln p_\beta(y_n\mid\mathbf{z}^{(n)})$ a NLL com temperatura $T$. Então:

1. A escala de temperatura **não altera a acurácia** nem o $\arg\max$ de nenhum exemplo.
2. $\mathcal{L}$ é **convexa** em $\beta$, com $\mathcal{L}''(\beta)=\frac1N\sum_n\operatorname{Var}_{p_\beta}(z^{(n)})$.
3. No mínimo, $\ \dfrac1N\sum_nz^{(n)}_{y_n}=\dfrac1N\sum_n\mathbb{E}_{p_\beta}\bigl[z^{(n)}\bigr]$: o *logit* médio da classe correta iguala o *logit* médio esperado pelo modelo.
:::

::: demonstracao
(1) Já visto no Exemplo 11.1: dividir todos os *logits* por $T>0$ preserva a ordem. (2) Para um exemplo, $-\ln p_\beta(y)=-\beta z_y+\ln\sum_je^{\beta z_j}$. O segundo termo é a função log-soma-exponencial de uma função **afim** de $\beta$, portanto convexa; somar uma função linear ($-\beta z_y$) preserva a convexidade; a média de funções convexas é convexa. Derivando, $\frac{d}{d\beta}\ln\sum_je^{\beta z_j}=\mathbb{E}_{p_\beta}[z]$ e a segunda derivada é $\operatorname{Var}_{p_\beta}(z)\ge0$ (mesmo cálculo da Proposição 11.1). (3) $\mathcal{L}'(\beta)=\frac1N\sum_n\bigl(-z^{(n)}_{y_n}+\mathbb{E}_{p_\beta}[z^{(n)}]\bigr)=0$.
:::

A convexidade explica por que ajustar $T$ é uma **busca em uma dimensão sem mínimos locais**, e por isso se faz com pouquíssimos dados. A condição (3) é uma **igualação de momentos**: se, em média, o modelo "espera" *logits* maiores do que os da classe correta, ele é confiante demais, e $\beta$ deve cair (isto é, $T$ deve subir). O Exercício 11.8 tem uma solução fechada.

### Medindo a calibração em um modelo real

O modelo é o GPT-2 minúsculo do Projeto 7. A "previsão" é o token mais provável a cada posição; o "acerto" é ele ser o token real; a confiança é sua probabilidade. A validação do **domínio de origem** é dividida ao meio (primeira metade dos blocos para **ajustar** $T$, segunda para **testar**); a validação do **domínio-alvo** é um conjunto de **outro domínio**, para ver o efeito do deslocamento. Como $T^*$ é ajustado só na metade de calibração, a metade de teste não participou do ajuste.

<<< codigo/c11_calibracao.py

>>> codigo/c11_calibracao.out

<figure>
+++ fig_c11_calibracao.svg
<figcaption><b>Figura 11.2.</b> À esquerda, diagrama de confiabilidade do GPT-2 minúsculo no teste da origem ($T=1$): acurácia observada contra confiança média, em $15$ faixas (círculos maiores, mais amostras; a linha tracejada é a calibração perfeita). À direita, previsão seletiva: acurácia entre as previsões respondidas ao responder apenas as mais confiantes.</figcaption>
</figure>

Quatro leituras, e uma ressalva.

1. **O modelo é, em conjunto, razoavelmente calibrado.** O ECE é $0{,}036$ no teste da origem, com acurácia de apenas $15{,}9\%$: prever o token seguinte a partir de $1\,000$ subpalavras é difícil, e a confiança média também é baixa. As faixas mais populosas ficam perto da diagonal.
2. **Há excesso de confiança no meio da escala.** Nas faixas de $0{,}27$ a $0{,}60$ de confiança, a acurácia observada é menor que a confiança (por exemplo, confiança $0{,}43$ e acurácia $0{,}39$; confiança $0{,}57$ e acurácia $0{,}46$; confiança $0{,}30$ e acurácia $0{,}20$). Acima de $0{,}8$ de confiança as faixas têm só $15$, $10$ e $5$ exemplos, e a curva oscila ($0{,}60$, $0{,}60$, $1{,}00$): **ruído amostral**, não um padrão.
3. **O deslocamento de domínio piora a calibração.** No alvo, o ECE sobe de $0{,}036$ para $0{,}065$ e a acurácia cai de $0{,}159$ para $0{,}120$. É o comportamento que a literatura relata para modelos sob deslocamento de distribuição (Ovadia et al., 2019, citado de memória), e aqui ocorre em **um** modelo, com **uma** divisão.
4. **A escala de temperatura não ajudou, e isto é informativo.** $T^*=0{,}982$ é quase $1$: a NLL na calibração mal muda ($4{,}008$ nos dois casos), porque o modelo já foi treinado com entropia cruzada, que **é** a função minimizada pela escala. O ECE no teste **subiu** de $0{,}0355$ para $0{,}0413$. Não é contradição: o ECE e a NLL são critérios diferentes (cuidado (3) acima); a curva da NLL é muito plana perto do ótimo, de modo que a mudança em $T$ é pequena, e o ECE com $15$ faixas e algumas centenas de exemplos por faixa tem erro de estimativa da mesma ordem de grandeza que a diferença observada (isto é **plausível, mas não foi testado** por reamostragem). A lição de método é que a escala de temperatura **corrige um desajuste global de escala**, e este modelo não tinha um.
5. **Ressalva.** A divisão em metades de calibração e teste é por **blocos contíguos**, não aleatória; blocos vizinhos do mesmo capítulo se parecem entre si, e isso pode tornar as duas metades diferentes.

### Previsão seletiva: abster-se quando a confiança é baixa

::: definicao 11.6 · Previsão seletiva
Dado um limiar $\tau$, o sistema **responde** apenas nas previsões com confiança $\hat c\ge\tau$ e **abstém-se** nas demais. A **cobertura** é a fração respondida, e a **acurácia seletiva** é a acurácia **entre as respondidas**. A curva cobertura-acurácia mostra o que se ganha em acerto ao recusar mais.
:::

A previsão seletiva só funciona se a confiança **ordena** os acertos: se as previsões de maior confiança acertam mais. No painel direito da Figura 11.2 e na tabela, é o que se vê: com cobertura $100\%$ a acurácia é $0{,}159$; com $40\%$, $0{,}280$; com $10\%$, $0{,}504$; com $5\%$, $0{,}610$. Responder só os $5\%$ mais confiantes **quase quadruplica** a acurácia ($0{,}610/0{,}159\approx3{,}8$), ao custo de se abster em $95\%$ dos casos. Em um sistema real, o custo de cada erro e de cada abstenção define o ponto de operação (Exercício 11.13). Atenção: a confiança do **próximo token** é uma medida local; a confiança de uma **resposta inteira** de um LLM é outra coisa, e há várias propostas (probabilidade da sequência, consistência entre amostras, pedir ao modelo que estime sua certeza). **Nenhuma foi avaliada aqui.**

## 11.5 Delimitar o contexto

Quando o *prompt* contém **texto de terceiros** (um documento recuperado, uma página da web, o e-mail de um cliente), o modelo vê, em um só fluxo de tokens, as **instruções do desenvolvedor** e **dados** que podem conter instruções. Não há, no Transformer, uma separação de hardware entre os dois: a distinção é **aprendida** no ajuste de instruções e, por isso, imperfeita. Uma **injeção de *prompt* indireta** é um texto no contexto que tenta fazer o modelo obedecer a ele em vez de ao desenvolvedor ("ignore as regras anteriores...").

Delimitar o contexto de forma estrita tem três partes, que se complementam:

1. **Estrutura.** Cada trecho entra com marcas de abertura e fechamento e um **identificador** (para citação). O conteúdo do trecho é **neutralizado**: se ele contiver as próprias marcas, elas são alteradas, de modo que um trecho não consiga "fechar" a região e inventar outra.
2. **Instrução de uso.** As regras dizem que o conteúdo das marcas é **dado**, que a resposta deve se basear **somente** nele, que deve citar os identificadores e que, na falta de base, deve dizer que não encontrou.
3. **Limites.** Tamanho máximo por trecho e no total (a janela de contexto é finita, seção 12.1) e **privilégio mínimo** nas ferramentas que o modelo pode chamar (Capítulo 13): mesmo que o modelo seja enganado, o dano possível deve ser pequeno.

O programa abaixo implementa a parte (1) e a testa com um trecho hostil.

<<< codigo/c11_contexto.py

>>> codigo/c11_contexto.out

::: atencao Isto garante a estrutura, não o comportamento
Os testes verificam o **texto** do *prompt*: o trecho hostil não consegue criar um trecho falso (`t9`), e o truncamento e a validação do identificador funcionam. **Não verificam** se um modelo de linguagem real obedeceria ao texto hostil: isso **não foi testado** (não havia LLM). Delimitadores **reduzem** o risco, mas os modelos ainda podem ser enganados; por isso se acrescentam as defesas em camadas (instrução, privilégio mínimo, validação da saída, revisão humana de ações críticas, Capítulo 15).
:::

## 11.6 Saídas estruturadas

Programas consomem **estruturas** (JSON com campos tipados), não prosa. Pedir "responda em JSON" em linguagem natural costuma funcionar, e falha de maneiras que quebram sistemas: campo ausente, rótulo fora do conjunto, número fora da faixa, JSON truncado por limite de tokens, texto antes ou depois do JSON. Há três camadas de defesa.

::: definicao 11.7 · Contrato de dados
Um **contrato de dados** é uma descrição **verificável** da saída esperada: campos, tipos, restrições (conjunto de valores, faixas, comprimentos) e obrigatoriedade. Um **validador** recebe uma saída e a aceita ou rejeita, indicando **qual** restrição foi violada e **onde**. Em Python, a biblioteca Pydantic gera o contrato a partir de uma classe com anotações de tipo e produz, dela, o **esquema JSON** que se pode enviar ao modelo ou a um servidor de inferência.
:::

### (A) Contrato e validação

O programa define o contrato de uma avaliação de sentimento (rótulo em um conjunto de três valores, confiança em $[0,1]$, justificativa de $3$ a $80$ caracteres), mostra o esquema JSON gerado e valida seis saídas.

### (B) Laço de validação e nova tentativa

Se a validação falha, o erro (tipo e local) é devolvido ao modelo para uma **nova tentativa**. Com probabilidade $p$ de saída válida por tentativa e tentativas **independentes**, a probabilidade de sucesso em até $n$ tentativas é $1-(1-p)^n$, e o número esperado de tentativas é $1/p$ (Exercício 11.10). O **custo** é latência e tokens, e a independência é otimista: se o modelo erra por uma razão sistemática (por exemplo, não entende o esquema), as tentativas falham juntas. No programa, o gerador é **simulado** (respostas pré-programadas): serve para mostrar o laço, **não é um modelo de linguagem** e nenhuma taxa de sucesso é medida.

### (C) Decodificação restrita

A terceira camada atua **dentro** da geração: a cada passo, **proíbe-se** todo token que não possa fazer parte de uma saída válida.

::: definicao 11.8 · Decodificação restrita por máscara
Seja $\mathcal{V}$ o conjunto de saídas válidas (por exemplo, uma linguagem regular ou uma gramática). Em cada passo, com prefixo $y_{<t}$, o conjunto de tokens **permitidos** é $A(y_{<t})=\{v:\ y_{<t}v\ \text{é prefixo de alguma saída em }\mathcal{V}\}$. Os *logits* dos tokens fora de $A$ são postos em $-\infty$ e escolhe-se o token entre os restantes (Definição 11.1). A saída final é **sempre** válida (se o conjunto $A$ nunca ficar vazio e a geração terminar).
:::

Para uma expressão regular, o teste "prefixo de alguma saída válida" é feito pela biblioteca `regex` com correspondência **parcial** (`partial=True`), que responde se a cadeia ainda pode ser completada. O programa aplica isso ao GPT-2 minúsculo, comparando geração livre e geração restrita a um padrão JSON, e depois examina uma distorção.

<<< codigo/c11_estruturada.py

>>> codigo/c11_estruturada.out

Leitura.

- **(A)** O esquema gerado pelo Pydantic mostra o contrato em JSON, pronto para enviar a um servidor que aceite esquemas. Das seis saídas, duas são aceitas e **quatro** rejeitadas, cada uma com um **tipo de erro e um local** (`literal_error` em `rotulo`; `less_than_equal` em `confianca`; `missing` em `justificativa`; `json_invalid`). Atenção ao sexto caso: o **modo padrão coage tipos**: o texto `"0.5"` virou o número $0{,}5$ e passou. Isso pode ser desejável ou não; o modo **estrito** (`strict=True`) rejeita (`float_type`).
- **(B)** O laço rejeita duas respostas inválidas (conjunto de rótulos e JSON truncado) e aceita a terceira. O teste é do **laço**, e não do modelo.
- **(C)** **Sem restrição, $0$ de $100$ saídas passam na validação**: o GPT-2 minúsculo não sabe fazer JSON, e o exemplo mostra texto livre. **Com restrição, $100$ de $100$ passam**, e o modelo escolheu entre, em média, $104{,}3$ dos $1\,000$ tokens em cada passo (em algum passo, havia **um único** token permitido). Os rótulos ($73$ positivo, $12$ negativo, $15$ neutro) **não** significam nada: o modelo não foi treinado para classificar sentimento, e a restrição garante a **forma**, não o conteúdo. Os exemplos de justificativa ("não se o candária") mostram exatamente isso: uma saída **válida** pode ser **absurda**.

::: atencao Válido não é correto
Um contrato garante que a resposta **tem a forma certa**. Não garante que o valor seja **verdadeiro**: um extrator de datas pode devolver `2026-05-12` quando a nota diz $5$ de dezembro (Exercício 11.14), e passará pelo validador. A validação semântica exige outras camadas: regras de negócio, conferência com a fonte (aqui entra a citação do trecho), amostras revisadas por pessoas (Capítulo 15).
:::

### A máscara token a token distorce a distribuição

Há um efeito sutil e importante. Uma máscara **renormaliza localmente** a distribuição a cada passo. Isso **não** produz, em geral, a distribuição do modelo **condicionada a ser válida**.

::: proposicao 11.5 · A máscara local não é a condicional
Seja $p$ a distribuição de sequências do modelo, $\mathcal{V}$ o conjunto de saídas válidas e $w(y_{\le t})=\mathbb{P}_p(Y\in\mathcal{V}\mid Y_{\le t}=y_{\le t})$ a probabilidade de, a partir de um prefixo, o modelo completar uma saída válida. A distribuição **exata** de $p$ condicionada a $\mathcal{V}$ escolhe, a cada passo, 
$$p(v\mid y_{<t},\mathcal{V})=\frac{p(v\mid y_{<t})\,w(y_{<t}v)}{w(y_{<t})},$$
ao passo que a **máscara** escolhe $q(v\mid y_{<t})=p(v\mid y_{<t})\,\mathbf{1}[v\in A]\big/\sum_{u\in A}p(u\mid y_{<t})$. Os dois coincidem em todos os passos **se, e somente se,** $w(y_{<t}v)$ **não depende de $v\in A(y_{<t})$** (isto é, se todas as continuações permitidas têm a mesma probabilidade de levar a uma saída válida).
:::

::: demonstracao
Pela definição de probabilidade condicional, $\mathbb{P}(Y_t=v\mid Y_{<t}=y_{<t},\,Y\in\mathcal{V})=\dfrac{p(v\mid y_{<t})\,w(y_{<t}v)}{\sum_up(u\mid y_{<t})\,w(y_{<t}u)}$, e o denominador é $w(y_{<t})$ pela lei da probabilidade total. Só tokens em $A$ têm $w>0$. Se $w(y_{<t}v)=\bar w$ para todo $v\in A$, o fator $\bar w$ sai do numerador e do denominador e resta $q$. Reciprocamente, suponha $p(v\mid y_{<t},\mathcal{V})=q(v\mid y_{<t})$ para todo $v\in A$ e seja $m=\sum_{u\in A}p(u\mid y_{<t})$. Então $p(v\mid y_{<t})\,w(y_{<t}v)/w(y_{<t})=p(v\mid y_{<t})/m$, e, como $p(v\mid y_{<t})>0$ (softmax), $w(y_{<t}v)=w(y_{<t})/m$ **para todo** $v\in A$: não depende de $v$.
:::

O exemplo exato do programa (parte D): vocabulário $\{a,b,c,d,x\}$, só $ac$ e $bd$ são válidas; $P(a)=0{,}9$, $P(b)=0{,}1$; depois de $a$, $P(c)=0{,}01$ e $P(x)=0{,}99$; depois de $b$, $P(d)=0{,}90$ e $P(x)=0{,}10$. A condicional exata dá $P(ac)=0{,}009/0{,}099=0{,}091$ e $P(bd)=0{,}09/0{,}099=0{,}909$. A máscara, porém, escolhe $a$ com $0{,}9$ (e depois $c$ com probabilidade $1$) e dá $P(ac)=0{,}900$ e $P(bd)=0{,}100$: **inverte** as proporções. O motivo é que $a$ levava a um beco quase sem saída válida ($w(a)=0{,}01$), e a máscara só percebe isso **depois** de ter escolhido $a$.

O que fazer? A decodificação restrita **garante a forma**, mas pode empurrar o modelo para saídas em que ele "não acreditava". As mitigações usuais são deixar o modelo **raciocinar livremente** antes de uma etapa estruturada, usar **buscas em feixe** ou amostragem com rejeição para recuperar parte da distribuição, e **validar o conteúdo** além da forma. Quando as saídas válidas são todas "prováveis" no modelo (o caso de um modelo ajustado para o formato), $w$ é quase constante e o efeito é pequeno. **Não foi medido aqui** o tamanho dessa distorção em um LLM real.
