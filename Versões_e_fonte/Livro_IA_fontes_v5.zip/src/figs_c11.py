"""Figuras do Capítulo 11 (SVG), a partir das saídas reais dos programas em codigo/."""
import re

from figs_c6 import curva, fmt, legenda, painel, salvar

# ---------- Figura 11.1: entropia contra T (esq.) e qualidade-diversidade (dir.) ----------
T, H = [], []
for lin in open("codigo/c11_amostragem.out"):
    m = re.match(r"^\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s*$", lin)
    if m and float(m.group(1)) <= 2.0 and len(T) < 6:
        T.append(float(m.group(1))); H.append(float(m.group(2)))
c = []
s, X, Y = painel(60, 20, 230, 230, 0, 2, 0, 7, [0, 0.5, 1, 1.5, 2], [0, 1, 2, 3, 4, 5, 6, 7], "temperatura T", "entropia do próximo token (nats)")
c += s
c.append(curva(X, Y, T, H, "lv"))
for t, h in zip(T, H):
    c.append(f'<circle cx="{fmt(X(t))}" cy="{fmt(Y(h))}" r="3.5" class="lv" style="fill:var(--papel);stroke-width:2"/>')
c.append(f'<line class="fraco" x1="{fmt(X(0))}" y1="{fmt(Y(6.908))}" x2="{fmt(X(2))}" y2="{fmt(Y(6.908))}" style="stroke:var(--rubi);stroke-dasharray:2 4"/><text class="t2" x="{fmt(X(0)+4)}" y="{fmt(Y(6.908)-5)}" font-size="10">ln V = 6,91 (uniforme)</text>')

pts = {}
for lin in open("codigo/c11_qualidade_diversidade.out"):
    m = re.match(r"^(.+?)\s{2,}([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s*$", lin)
    if m and not lin.startswith("estrat"):
        pts[m.group(1).strip()] = (float(m.group(2)), float(m.group(3)))
s, X2, Y2 = painel(390, 20, 230, 230, 2, 7.5, 0, 1.05, [2, 3, 4, 5, 6, 7], [0, 0.25, 0.5, 0.75, 1], "NLL dos tokens gerados (nats)", "diversidade (distinct-2)")
c += s
rot = {"guloso (T→0)": ("guloso", 8, 4), "T=0,5": ("T=0,5", -7, 15), "T=1,0 (puro)": ("T=1", 0, -9), "T=2,0": ("T=2", -6, 16),
       "top-p=0,5": ("p=0,5", -8, 4), "top-k=10": ("k=10", 7, 15), "min-p=0,1": ("min-p", 8, 15), "guloso + freq. 0,5": ("guloso+freq.", 8, 4)}
for nome, (nll, dist) in pts.items():
    gr = nome.startswith("guloso")
    cls = "lr" if gr else ("lv" if nome.startswith("T=") and "+" not in nome else "la")
    c.append(f'<circle cx="{fmt(X2(nll))}" cy="{fmt(Y2(dist))}" r="4" class="{cls}" style="fill:var(--papel);stroke-width:2"/>')
    if nome in rot:
        t, dx, dy = rot[nome]
        c.append(f'<text class="t2" x="{fmt(X2(nll)+dx)}" y="{fmt(Y2(dist)+dy)}" font-size="10" text-anchor="{"middle" if dx == 0 else ("end" if dx < 0 else "start")}">{t}</text>')
c += legenda([("lr", "guloso", None), ("lv", "temperatura", None), ("la", "truncamento / combinações", None)], 60, 306, 170)
salvar("fig_c11_amostragem.svg", 640, 330, "À esquerda, a entropia do próximo token cresce com a temperatura; à direita, estratégias de decodificação posicionadas por probabilidade dos tokens gerados e diversidade", c)

# ---------- Figura 11.2: calibração e previsão seletiva ----------
conf, acc, bins_ = [], [], []
sec = None
cob, risco = [], []
for lin in open("codigo/c11_calibracao.out"):
    if lin.strip().startswith("T = 1.000"):
        sec = "t1"
    elif lin.strip().startswith("T = 0.982"):
        sec = "t2"
    elif lin.startswith("previsão seletiva"):
        sec = "sel"
    m = re.match(r"^\s+\[([0-9.]+),([0-9.]+)\) n=\s*(\d+)\s+confiança ([0-9.]+)\s+acurácia ([0-9.]+)", lin)
    if m and sec == "t1":
        conf.append(float(m.group(4))); acc.append(float(m.group(5))); bins_.append(int(m.group(3)))
    m = re.match(r"^\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s*$", lin)
    if m and sec == "sel":
        cob.append(float(m.group(1))); risco.append(float(m.group(2)))
c = []
s, X, Y = painel(60, 20, 230, 230, 0, 1, 0, 1, [0, 0.25, 0.5, 0.75, 1], [0, 0.25, 0.5, 0.75, 1], "confiança do token mais provável", "acurácia observada")
c += s
c.append(f'<line x1="{fmt(X(0))}" y1="{fmt(Y(0))}" x2="{fmt(X(1))}" y2="{fmt(Y(1))}" class="fraco" style="stroke:var(--rubi);stroke-dasharray:4 4;stroke-width:1.5"/>')
c.append(curva(X, Y, conf, acc, "lv"))
for cf, a, n in zip(conf, acc, bins_):
    r = 2.5 + 5.5 * (n / max(bins_)) ** 0.5
    c.append(f'<circle cx="{fmt(X(cf))}" cy="{fmt(Y(a))}" r="{fmt(r)}" class="lv" style="fill:var(--papel);stroke-width:2"/>')
c.append(f'<text class="t2" x="{fmt(X(0.5))}" y="{fmt(Y(0.06))}" font-size="10">círculo ∝ √n da faixa</text>')
s, X, Y = painel(390, 20, 230, 230, 0, 1, 0, 0.7, [0, 0.25, 0.5, 0.75, 1], [0, 0.2, 0.4, 0.6], "cobertura (fração de previsões respondidas)", "acurácia nas respondidas")
c += s
cs = sorted(zip(cob, risco))
c.append(curva(X, Y, [a for a, _ in cs], [b for _, b in cs], "la"))
for a, b in cs:
    c.append(f'<circle cx="{fmt(X(a))}" cy="{fmt(Y(b))}" r="3.5" class="la" style="fill:var(--papel);stroke-width:2"/>')
salvar("fig_c11_calibracao.svg", 640, 290, "À esquerda, diagrama de confiabilidade do GPT-2 minúsculo; à direita, acurácia em função da cobertura ao responder apenas as previsões mais confiantes", c)
print("figs c11 ok", len(T), len(pts), len(conf), len(cob))
