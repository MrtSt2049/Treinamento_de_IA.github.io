## 12.10 Resumo do capítulo

::: resumo Capítulo 12
- **Por que RAG.** Os pesos são estáticos e a janela é finita e cara; injetar os trechos certos dá conhecimento atual, privado e **citável** (seção 12.1). O desempenho é limitado pelo elo mais fraco, a **recuperação**, que deve ser medida separadamente da geração.
- **Pipeline.** Indexação (documentos $\to$ *parsing* $\to$ fatiamento $\to$ *embeddings* $\to$ índices) e consulta (recuperação $\to$ fusão $\to$ reordenação $\to$ abstenção $\to$ contexto $\to$ resposta com citação), cada etapa uma abstração do LlamaIndex (Figura 12.1).
- **Ingestão.** O que o extrator perde (tabelas viram células soltas, ordem de leitura, metadados) não se recupera depois. Metadados **fora** do texto do *embedding* (`excluded_embed_metadata_keys`).
- **Fatiamento.** Com janelas de $c$ palavras e sobreposição $o$: $\lceil (L-o)/(c-o)\rceil$ janelas, duplicação $c/(c-o)$, e **todo** trecho de até $o+1$ palavras cabe em alguma janela (Proposição 12.1). No corpus, o tamanho teve efeito pequeno e dentro do ruído; o fatiador semântico não se distinguiu de janelas simples. Fragmentos sem conteúdo geram **vetores nulos e cosseno NaN**.
- ***Embeddings*.** Para vetores **unitários**, cosseno, produto interno e distância euclidiana dão a **mesma ordem** ($\lVert\mathbf{a}-\mathbf{b}\rVert^2=2-2\cos$; Proposição 12.2): $100\%$ das perguntas idênticas com normalização, $0\%$ sem. O LSA (TF-IDF + SVD) com $\ge 64$ dimensões não se distinguiu entre si, e o **TF-IDF puro venceu o LSA nas parafraseadas** ($0{,}72$ contra $0{,}59$ de MRR); isso **não** vale para *embeddings* neurais, que não foram testados.
- **Busca aproximada.** IVF custa $\approx n_\text{lista}+n_\text{sonda}N/n_\text{lista}$, mínimo $2\sqrt{n_\text{sonda}N}$ (Proposição 12.3); HNSW navega um grafo em camadas; PQ comprime vetores $32\times$ ou mais. Em $533$ vetores, **nenhum benefício**; em $100\,000$ sintéticos, o compromisso entre *recall* e latência é claro, e a IVF dominou o HNSW **naquela** base.
- **Recuperação híbrida.** BM25 (saturação e normalização por comprimento) é forte em termos exatos e cego a sinônimos. A RRF usa só as posições, é **invariante a transformações monótonas** das pontuações ($100\%$ de top-10 idêntico, contra $4\%$ da soma normalizada) e, para $k$ grande, tende a uma contagem de Borda (Proposição 12.4). **Não superou o BM25** (diferença $+0{,}027$, $[-0{,}017;\ +0{,}075]$): a fusão ajuda quando os recuperadores são complementares e de qualidade parecida.
- **Reordenação.** Um reordenador leve ganhou $+0{,}042$ de MRR ($[-0{,}023;\ +0{,}109]$, compatível com zero), tudo nas perguntas diretas; um *cross-encoder* real **não foi executado**.
- **Fusão automática de nós.** Dobrou o contexto e não melhorou nesse conjunto de perguntas.
- **Síntese e citações.** Os modos (`simple_summarize`, `compact`, `refine`, `tree_summarize`) diferem em **chamadas** e **tamanho de *prompt***, que multiplicam quando a janela é pequena; `simple_summarize` **trunca em silêncio**. Citação aponta a fonte e **não prova** a resposta.
- **Abstenção.** Limiar sobre uma pontuação de confiança: precisão sobe e cobertura cai; nenhum limiar zera os dois erros. O BM25 bruto separou melhor ($\text{AUROC}=0{,}974$) e o cosseno, $0{,}907$; a normalização que propus **piorou** ($0{,}735$). **NaN atravessa o filtro** do `SimilarityPostprocessor`.
- **Medir.** Perguntas de gabarito, hit@$k$, MRR e nDCG, **intervalos de confiança** por *bootstrap* sobre as perguntas e, para detectar diferenças de $0{,}03$ de MRR, cerca de $160$ perguntas (não $67$). Várias comparações sem correção produzem **hipóteses**, não conclusões.
:::

**Ponte para o Capítulo 13.** Até aqui o sistema segue um roteiro fixo: recupera, monta o contexto e responde. O Capítulo 13 abre o roteiro. Um **agente** baseado em LLM usa o modelo como **motor de raciocínio** que decide, a cada passo, **o que fazer**: consultar o índice deste capítulo, chamar uma API, executar código ou responder. A recuperação vira **uma ferramenta** entre outras, e entram os padrões de raciocínio (ReAct, planejar e resolver, reflexão) e a chamada de funções com argumentos tipados, na linha dos contratos do Capítulo 11.

## 12.11 Exercícios

### Nível I: consolidação

**12.1** Um documento de $L=1\,000$ palavras é dividido em janelas de $c=150$ palavras com sobreposição $o=30$. (a) Quantas janelas resultam? (b) Qual o fator de duplicação $c/(c-o)$ e quantas palavras são indexadas no total? (c) Repita para $c=300$, $o=60$ e para $c=150$, $o=0$.

**12.2** No Exemplo 12.1 ($\mathbf{q}=(1,1)$; $\mathbf{d}_1=(3,3)$, $\mathbf{d}_2=(1;0{,}8)$, $\mathbf{d}_3=(2,0)$), **normalize** $\mathbf{q}$ e os três trechos para norma $1$ e calcule a distância euclidiana de $\hat{\mathbf{q}}$ a cada $\hat{\mathbf{d}}_i$. A ordem agora coincide com a do cosseno? Confira o resultado com $\lVert\hat{\mathbf{q}}-\hat{\mathbf{d}}\rVert^2=2-2\cos$.

**12.3** Para as listas A $=(d_1,d_2,d_3,d_4)$ e B $=(d_3,d_1,d_5,d_2)$ do Exemplo 12.2, calcule a RRF com $k=1$ e com $k=10\,000$. Compare as ordens com a de $k=60$ e explique o efeito de $k$.

**12.4** Quatro trechos, já em termos: $d_1=($gradiente, descida, gradiente, passo$)$; $d_2=($probabilidade, bayes, teorema$)$; $d_3=($atenção, softmax, chave, valor, consulta, máscara$)$; $d_4=($pooling, convolução$)$. Calcule o BM25 da consulta "gradiente" para cada trecho, com $k_1=1{,}5$ e $b=0{,}75$. Em seguida, supondo o mesmo comprimento médio, qual seria a pontuação de $d_1$ se "gradiente" aparecesse $4$ vezes (mantendo $\lvert d_1\rvert=4$)? O que isso mostra?

**12.5** Três perguntas têm as seguintes listas de seções recuperadas (da primeira à última) e gabaritos: (1) $(5.4;\,5.5;\,5.1)$, gabarito $\{5.4\}$; (2) $(9.2;\,9.4;\,9.7)$, gabarito $\{9.7\}$; (3) $(3.5;\,3.3;\,3.6)$, gabarito $\{3.3;\,3.6\}$. Calcule hit@1, hit@3, MRR e o nDCG de cada pergunta e a média.

### Nível II: aprofundamento

**12.6** (a) Prove a Proposição 12.2. (b) Para $\mathbf{a}=(3,4)$, $\mathbf{b}=(3,5)$ e $\mathbf{q}=(0,10)$, calcule o cosseno, a distância euclidiana ao quadrado e o produto interno de $\mathbf{q}$ com cada um. (c) Substitua $\mathbf{a}$ por $\mathbf{a}'=(0,3)$ e mostre que, agora, o cosseno **discorda** do produto interno e da distância euclidiana. Explique.

**12.7** (a) Deduza o número ótimo de listas da IVF (Proposição 12.3). (b) Para $N=10^6$ vetores e $n_\text{sonda}=8$, calcule $n_\text{lista}^\star$, o custo mínimo em comparações e a aceleração sobre a busca exata, e compare com $n_\text{lista}=1\,024$. (c) No experimento 6 ($N=10^5$, $n_\text{lista}=1\,024$, $n_\text{sonda}=8$), qual a fração da base examinada? Por que, mesmo assim, o *recall@10* foi de apenas $0{,}795$?

**12.8** Uma base tem $N=10^7$ vetores de $d=768$ dimensões em *float32*. (a) Quanta memória ocupam só os vetores? (b) Um HNSW com $M=32$ guarda $2M$ ligações de $4$ bytes por vetor no nível $0$: quanto isso soma, e qual a fração dos vetores? (c) Com quantização de produto de $96$ e de $48$ bytes por vetor, qual o tamanho total e a taxa de compressão?

**12.9** Um sistema recebe $100$ perguntas: $80$ respondíveis, $10$ longe e $10$ perto do domínio. Com o limiar $0{,}5$ do experimento 5, ele responde $91\%$ das respondíveis (com acerto do top-1 de $0{,}74$ entre as respondidas), $31\%$ das longe e $50\%$ das perto. (a) Quantas respostas dá, e quantas são **ruins** (erradas ou dadas a perguntas sem resposta)? (b) Compare com o sistema **sem abstenção** (acerto do top-1 de $0{,}69$). (c) Se uma resposta ruim custa $5$ vezes mais que uma recusa indevida, qual dos dois sistemas é melhor?

**12.10** Prove, em detalhe, o item 2 da Proposição 12.1 (cobertura): todo trecho de $s$ palavras cabe em alguma janela **se, e somente se,** $s\le o+1$. Depois verifique por força bruta, para $L=1\,000$, $c=150$, $o=30$, os tamanhos $s\in\{1,30,31,32,61\}$.

### Nível III: desafio

**12.11** (a) Complete a prova do item 3 da Proposição 12.4: para $k$ grande, a ordem da RRF é lexicográfica por (número de listas, soma das posições). (b) Aplique às listas do Exemplo 12.2 e confira com $k=10\,000$. (c) Discuta em uma frase por que $k=60$ fica entre os dois regimes ($k$ pequeno, que prioriza o topo, e $k$ grande, estilo Borda).

**12.12** Uma empresa tem $200\,000$ páginas, com cerca de $4$ trechos por página, e *embeddings* de $768$ dimensões em *float32*. (a) Quantos trechos, e quanta memória para os vetores e para um HNSW com $M=32$? (b) Quantas multiplicações custa a busca exata por consulta e, na taxa medida no experimento 6, quanto tempo por consulta e por núcleo? (c) Dado que o sistema recebe $50$ consultas por segundo, o que você recomendaria, e o que mediria antes de decidir?

**12.13** No experimento 3, a diferença média de MRR entre BM25 e RRF foi $+0{,}027$, com desvio-padrão por pergunta de $0{,}194$ e $67$ perguntas. (a) Qual o erro-padrão? (b) Quantas perguntas seriam necessárias para que a **meia-largura** do intervalo de $95\%$ fosse menor que $0{,}03$, $0{,}02$ e $0{,}01$? (c) Por que isso é **menos** do que o necessário para detectar uma diferença real com $80\%$ de poder? Quanto mais?

**12.14** Seja a matriz termo-documento (termos nas linhas, documentos nas colunas) $X=\begin{pmatrix}1&1&0&0\\1&1&0&0\\0&1&1&0\\0&0&1&1\\0&0&1&1\end{pmatrix}$. (a) Calcule a SVD e a energia retida para $r=1,2,3$. (b) Verifique que o erro de Frobenius da aproximação de posto $2$ é $\sqrt{\sum_{i>2}\sigma_i^2}$. (c) Em um espaço latente de posto $2$ (documento $j$ representado por $\Sigma_2V_2^\top$ restrito à coluna $j$), calcule o cosseno entre os documentos $1$ e $3$, $1$ e $2$, $1$ e $4$ e compare com o espaço original. O que o resultado diz sobre o LSA?

## 12.12 Soluções comentadas

::: solucao 12.1
Programa `c12_ex_numeros.py`. (a) $\lceil(1000-30)/(150-30)\rceil=\lceil 8{,}08\rceil=9$ janelas. (b) $c/(c-o)=1{,}25$, ou seja, $25\%$ a mais **assintoticamente**; como a última janela quase sempre sobra, o total real é $9\times150=1\,350$ palavras ($35\%$), contra o limite de $1\,250$. (c) Com $c=300$, $o=60$: $\lceil 940/240\rceil=4$ janelas, $1\,200$ palavras indexadas, mesma razão $1{,}25$. Com $o=0$: $\lceil 1000/150\rceil=7$ janelas, $1\,050$ palavras, fator $1$. A sobreposição é um **seguro** contra o corte de uma resposta curta, pago em índice maior e em trechos repetidos nos resultados.
:::

::: solucao 12.2
Normas: $\lVert\mathbf{q}\rVert=\sqrt2$; $\lVert\mathbf{d}_1\rVert=3\sqrt2$; $\lVert\mathbf{d}_2\rVert=\sqrt{1{,}64}=1{,}281$; $\lVert\mathbf{d}_3\rVert=2$. Depois de normalizar, $\hat{\mathbf{q}}=\hat{\mathbf{d}}_1=(0{,}707;0{,}707)$, $\hat{\mathbf{d}}_2=(0{,}781;0{,}625)$ e $\hat{\mathbf{d}}_3=(1,0)$. As distâncias são $0$, $0{,}111$ e $0{,}765$: a ordem é $\mathbf{d}_1,\mathbf{d}_2,\mathbf{d}_3$, **igual** à do cosseno ($1{,}000;\,0{,}994;\,0{,}707$). Conferência: $2-2\cdot0{,}9939=0{,}0122=0{,}111^2$ e $2-2\cdot0{,}7071=0{,}586=0{,}765^2$. Antes de normalizar, a distância preferia $\mathbf{d}_2$ e deixava $\mathbf{d}_1$ por último; **a normalização remove o tamanho** do critério.
:::

::: solucao 12.3
Programa `c12_ex_numeros.py`. Com $k=1$: $d_1=0{,}8333$, $d_3=0{,}7500$, $d_2=0{,}5333$, $d_5=0{,}2500$, $d_4=0{,}2000$. Com $k=60$: $0{,}03252$; $0{,}03227$; $0{,}03175$; $0{,}01587$; $0{,}01562$. Com $k=10\,000$: todos próximos de $0{,}0002$ (os de duas listas) ou de $0{,}0001$ (os de uma). A **ordem** é a mesma, $d_1,d_3,d_2,d_5,d_4$, nos três casos; o que muda é a **margem**: com $k=1$, a diferença entre o primeiro e o terceiro é de $0{,}30$ (um peso forte ao topo das listas); com $k=10\,000$, ela some em termos relativos, e a pontuação praticamente só conta **em quantas listas** o documento aparece. Um $k$ pequeno é "ganha quem for bem colocado em alguma lista"; um $k$ grande é "ganha quem aparece em mais listas".
:::

::: solucao 12.4
Programa `c12_ex_numeros.py`. $N=4$, $n_t=1$, comprimento médio $=(4+3+6+2)/4=3{,}75$, $\operatorname{idf}=\ln\frac{4-1+0{,}5}{1+0{,}5}=\ln 2{,}333=0{,}8473$. Para $d_1$ ($f=2$, $\lvert d\rvert=4$): $\dfrac{2\cdot2{,}5}{2+1{,}5\,(0{,}25+0{,}75\cdot4/3{,}75)}=\dfrac{5}{3{,}575}=1{,}3986$, e $\operatorname{BM25}=0{,}8473\cdot1{,}3986=1{,}185$. Os demais têm $f=0$ e pontuação $0$. Com $f=4$ (mesmo $\lvert d_1\rvert=4$ e mesmo comprimento médio): $\frac{4\cdot2{,}5}{4+1{,}575}=1{,}794$, e $\operatorname{BM25}=1{,}520$. Dobrar a frequência aumentou a pontuação em **$28\%$**, e não em $100\%$: é a **saturação**; o limite, quando $f\to\infty$, é $\operatorname{idf}\cdot(k_1+1)=2{,}12$.
:::

::: solucao 12.5
Programa `c12_ex_numeros.py`. hit@1: só a pergunta 1 acerta o primeiro, $1/3=0{,}333$. hit@3: as três têm acerto nos $3$ primeiros, $1{,}000$. Posições do primeiro acerto: $1$, $3$, $2$, logo $\text{MRR}=(1+\tfrac13+\tfrac12)/3=0{,}611$. nDCG: pergunta 1, $1$ (acerto no topo, único relevante); pergunta 2, $1/\log_2 4=0{,}5$ (acerto na posição $3$); pergunta 3, dois relevantes nas posições $2$ e $3$: $\operatorname{DCG}=\tfrac1{\log_23}+\tfrac1{\log_24}=0{,}631+0{,}5=1{,}131$; o ideal é $1+\tfrac1{\log_23}=1{,}631$; razão $0{,}693$. Média $=(1+0{,}5+0{,}693)/3=0{,}731$. Observe como o hit@3 **esconde** a diferença entre acertar no topo e acertar no fim.
:::

::: solucao 12.6
(a) Ver a demonstração da Proposição 12.2. (b) Programa `c12_ex_numeros.py`: $\cos(\mathbf{q},\mathbf{a})=0{,}800$ e $\cos(\mathbf{q},\mathbf{b})=0{,}857$; $\lVert\mathbf{q}-\mathbf{a}\rVert^2=45$ e $\lVert\mathbf{q}-\mathbf{b}\rVert^2=34$; $\mathbf{q}^\top\mathbf{a}=40$ e $\mathbf{q}^\top\mathbf{b}=50$. As três medidas preferem $\mathbf{b}$: aqui concordam, mas por coincidência (os vetores não são unitários). (c) Com $\mathbf{a}'=(0,3)$: $\cos(\mathbf{q},\mathbf{a}')=1$ (mesma direção que $\mathbf{q}$), $\lVert\mathbf{q}-\mathbf{a}'\rVert^2=49$, $\mathbf{q}^\top\mathbf{a}'=30$. O cosseno prefere $\mathbf{a}'$ ($1>0{,}857$), enquanto a distância ($49>34$) e o produto interno ($30<50$) preferem $\mathbf{b}$, que é **maior**: o produto interno recompensa a norma, e a distância penaliza a **diferença de norma**, enquanto o cosseno só olha a direção. Se a norma dos vetores de trecho carrega informação sem relação com a relevância (por exemplo, o comprimento do texto), prefira o cosseno.
:::

::: solucao 12.7
(a) Ver a demonstração da Proposição 12.3. (b) Programa `c12_ex_numeros.py`: $n_\text{lista}^\star=\sqrt{8\cdot10^6}=2\,828$; custo $2\cdot2\,828=5\,657$ comparações; aceleração $10^6/5\,657=177\times$. Com $n_\text{lista}=1\,024$: $1\,024+8\cdot10^6/1\,024=8\,836$ comparações, $56\%$ **mais** que o mínimo, ainda $113\times$ mais rápido que o exato. (c) $1\,024+8\cdot(10^5/1\,024)=1\,805$ comparações, $1{,}8\%$ da base. O *recall* de $0{,}795$ vem das **fronteiras**: os vizinhos de uma consulta estão espalhados por células que **não** estão entre as $8$ sondadas, em dados com muito ruído intra-aglomerado. A fração examinada é pequena **porque** a aproximação é agressiva, e o preço é o *recall*; sondar $64$ células sobe o *recall* a $0{,}910$ ao custo de $\approx 5\times$ mais tempo.
:::

::: solucao 12.8
Programa `c12_ex_numeros.py`. (a) $10^7\cdot768\cdot4=30{,}72$ GB. (b) $10^7\cdot64\cdot4=2{,}56$ GB, ou $8{,}3\%$ dos vetores; total de $33{,}28$ GB. (c) Com $96$ bytes por vetor: $10^7\cdot96=0{,}96$ GB, compressão de $3\,072/96=32\times$. Com $48$: $0{,}48$ GB, $64\times$. A compressão cabe na memória de **uma** máquina, e o preço é a **perda de precisão** nas distâncias, em geral corrigida com um reordenamento exato dos melhores candidatos, usando os vetores originais guardados em disco.
:::

::: solucao 12.9
(a) Respondíveis respondidas: $80\cdot0{,}91=72{,}8$; corretas: $72{,}8\cdot0{,}74=53{,}9$; erradas: $18{,}9$. Sem resposta mas respondidas: $10\cdot0{,}31+10\cdot0{,}50=8{,}1$. Total de respostas: $72{,}8+8{,}1=80{,}9$; ruins: $18{,}9+8{,}1=27{,}0$. Recusas indevidas: $80-72{,}8=7{,}2$. (b) **Sem abstenção** (limiar $0$), as $100$ perguntas são respondidas: $55{,}2$ respostas certas ($80\cdot0{,}69$), $24{,}8$ erradas e $20$ dadas a perguntas sem resposta, ou $44{,}8$ **ruins**, contra $27{,}0$ com o limiar, ao custo de $7{,}2$ recusas indevidas. (c) Com custo relativo $5$ por resposta ruim e $1$ por recusa indevida: com abstenção, $5\cdot27{,}0+7{,}2=142{,}2$; sem, $5\cdot44{,}8+0=224$. O sistema com limiar é melhor. Se, em vez disso, a resposta ruim custasse **menos** que $\approx 0{,}4$ de uma recusa indevida, a ordem se inverteria: o ponto de equilíbrio é onde $c\cdot(44{,}8-27{,}0)=7{,}2$, ou seja, $c=0{,}40$. As porcentagens vêm do mesmo conjunto que escolhe o limiar, e as contas são **otimistas**.
:::

::: solucao 12.10
**Prova.** As janelas começam em $0,p,2p,\dots$, com $p=c-o$, e a janela $j$ cobre as posições $jp,\dots,jp+c-1$. Um trecho de $s$ palavras que começa em $i$ ocupa $i,\dots,i+s-1$. Escreva $i=jp+r$ com $j=\lfloor i/p\rfloor$ e $0\le r<p$. **Suficiência:** o trecho cabe na janela $j$ se $r+s\le c$; como $r\le p-1$, basta $p-1+s\le c$, isto é, $s\le c-p+1=o+1$. **Necessidade:** tome $s=o+2$ e $i=jp+p-1$ (o pior caso, $r=p-1$), com $i+s\le L$. O trecho termina na posição $i+s-1=jp+p+o=jp+c$, **uma** posição além do fim da janela $j$ (que termina em $jp+c-1$). A janela $j+1$ começa em $(j+1)p=i+1$, **depois** do início do trecho, e as janelas anteriores terminam ainda antes. Nenhuma janela contém o trecho; logo, $s\le o+1$ é necessário. **Verificação** (programa): $s=1,30,31$ cabem sempre; $s=32$ e $s=61$ **não**: o maior trecho garantido tem $o+1=31$ palavras. Para $o=0$, só trechos de $0$ ou $1$ palavra, e um par de palavras vizinhas pode ser partido. Com $o=100$ e $c=150$, o garantido é $101$, ao custo de triplicar o índice ($c/(c-o)=3$).
:::

::: solucao 12.11
(a) Ver a prova da Proposição 12.4. Para tornar o argumento preciso: se todas as posições são $\le R$, então $\left|\operatorname{RRF}(d)-\bigl(\tfrac nk-\tfrac{\sum r_i}{k^2}\bigr)\right|\le\tfrac{mR^2}{k^3}$, e dois documentos com $n>n'$ diferem em pelo menos $\tfrac1k-\tfrac{mR}{k^2}-\tfrac{2mR^2}{k^3}>0$ quando $k$ é grande; com $n=n'$, a diferença de ordem $k^{-2}$ é $\tfrac{\sum r'-\sum r}{k^2}$, com $\sum r'-\sum r\ge1$ (são inteiros), que domina o erro de ordem $k^{-3}$ quando $k>2mR^2$. (b) Programa `c12_ex_numeros.py`: $d_1,d_2,d_3$ estão nas duas listas, com somas de posições $1+2=3$, $2+4=6$, $3+1=4$; $d_5$ ($3$) e $d_4$ ($4$) estão numa só. A ordem lexicográfica é $d_1,d_3,d_2,d_5,d_4$, a mesma que a RRF com $k=10\,000$ produziu. (c) Para $k=60$ e posições típicas de $1$ a $20$, $\tfrac1{k+r}$ varia de $\tfrac1{61}$ a $\tfrac1{80}$ (um fator de apenas $1{,}3$): o topo conta mais que o fundo, mas bem menos que com $k=1$ (fator $10{,}5$ entre as posições $1$ e $20$), e a pontuação premia **concordância** entre listas sem chegar ao regime puramente Borda.
:::

::: solucao 12.12
Programa `c12_ex_numeros.py`. (a) $800\,000$ trechos; vetores: $800\,000\cdot768\cdot4=2{,}46$ GB; HNSW com $M=32$: $+0{,}20$ GB, total $\approx 2{,}66$ GB (cabe na memória de um servidor comum). (b) $800\,000\cdot768=614$ milhões de multiplicações por consulta; a $\approx12$ GFLOP/s por núcleo (taxa medida em $100\,000\times128$; **extrapolação**, pois a taxa depende da memória e da vetorização), $\approx0{,}10$ s por consulta e por núcleo. (c) A $50$ consultas por segundo, a busca exata exigiria $\approx5$ núcleos **só** para isso, o que é viável; um HNSW ou IVF reduziria o custo em uma ou duas ordens de grandeza, mas o ganho só importa se a latência de recuperação for o gargalo, e **normalmente não é**: o LLM leva segundos. Medir antes de decidir: (i) a latência de cada etapa (consulta ao índice, reordenação, geração); (ii) o *recall@10* do índice aproximado **nos seus dados** contra a busca exata; (iii) o efeito dos filtros por metadados. Nesta escala, o ponto sensível costuma ser a **qualidade do fatiamento e da recuperação**, e não o índice.
:::

::: solucao 12.13
Programa `c12_ex_numeros.py`. (a) $\text{EP}=0{,}194/\sqrt{67}=0{,}024$, então o intervalo de $95\%$ tem meia-largura $\approx1{,}96\cdot0{,}024=0{,}046$, bem **maior** que a diferença observada de $0{,}027$. (b) $n\ge(1{,}96\sigma/\delta)^2$: $\delta=0{,}03\Rightarrow160$ perguntas; $\delta=0{,}02\Rightarrow361$; $\delta=0{,}01\Rightarrow1\,444$. (c) Esse critério só garante que o intervalo **tenha** a largura desejada; para **detectar** uma diferença real $\delta$ com poder de $80\%$ a $5\%$ de significância, usa-se $n\ge(1{,}96+0{,}84)^2\sigma^2/\delta^2=7{,}84\,\sigma^2/\delta^2$, cerca de $2{,}04$ vezes o valor acima: $\approx 330$ perguntas para $\delta=0{,}03$ (cálculo à mão, com $(2{,}8/1{,}96)^2=2{,}04$). Com $67$ perguntas, o experimento só poderia detectar com poder de $80\%$ diferenças da ordem de $2{,}8\cdot0{,}194/\sqrt{67}\approx0{,}07$ de MRR, e todas as diferenças entre recuperadores aqui estão **abaixo** disso.
:::

::: solucao 12.14
Programa `c12_ex_numeros.py`. (a) Valores singulares: $2{,}288;\ 2{,}000;\ 0{,}874;\ 0$ (a matriz tem posto $3$). Energia $\sum_{i\le r}\sigma_i^2/\sum\sigma_i^2$: $0{,}524$ ($r=1$), $0{,}924$ ($r=2$), $1$ ($r=3$). (b) O erro de Frobenius da aproximação de posto $2$ é $0{,}8740=\sqrt{\sigma_3^2+\sigma_4^2}$, igual ao previsto por Eckart-Young. (c) Representando o documento $j$ pela coluna $j$ de $\Sigma_2V_2^\top$: documentos $1$ e $3$ **não** compartilham termos, e o cosseno original é $0$, mas no espaço latente é $0{,}077$ (o documento $2$ faz a ponte: compartilha termos com os dois); documentos $1$ e $2$ vão de $0{,}817$ a $0{,}972$ (mais próximos); documentos $1$ e $4$ vão de $0$ a $-0{,}160$ (**negativo**). O LSA **aproxima** o que coocorre e **afasta** o que não se relaciona, mas o cosseno latente pode ser **negativo** e o sinal não tem interpretação de "oposto"; e a melhora para paráfrases depende de haver, no corpus, a coocorrência que faz a ponte.
:::

## 12.13 Referências e leituras

### Livros didáticos

- MANNING, C. D.; RAGHAVAN, P.; SCHÜTZE, H. *Introduction to Information Retrieval*. Cambridge: Cambridge University Press, 2008. Índices invertidos, TF-IDF, modelos de espaço vetorial e avaliação de recuperação (hit, MRR, nDCG).
- ROBERTSON, S.; ZARAGOZA, H. The probabilistic relevance framework: BM25 and beyond. *Foundations and Trends in Information Retrieval*, v. 3, n. 4, 2009.
- EFRON, B.; TIBSHIRANI, R. J. *An Introduction to the Bootstrap*. Nova York: Chapman & Hall, 1993.

### Artigos originais

- CORMACK, G. V.; CLARKE, C. L. A.; BÜTTCHER, S. Reciprocal rank fusion outperforms Condorcet and individual rank learning methods. In: *Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval*, 2009.
- DEERWESTER, S.; DUMAIS, S. T.; FURNAS, G. W.; LANDAUER, T. K.; HARSHMAN, R. Indexing by latent semantic analysis. *Journal of the American Society for Information Science*, v. 41, n. 6, 1990.
- JÄRVELIN, K.; KEKÄLÄINEN, J. Cumulated gain-based evaluation of IR techniques. *ACM Transactions on Information Systems*, v. 20, n. 4, 2002.
- JÉGOU, H.; DOUZE, M.; SCHMID, C. Product quantization for nearest neighbor search. *IEEE Transactions on Pattern Analysis and Machine Intelligence*, v. 33, n. 1, 2011.
- JOHNSON, J.; DOUZE, M.; JÉGOU, H. Billion-scale similarity search with GPUs. *IEEE Transactions on Big Data*, v. 7, n. 3, 2021 (a biblioteca FAISS).
- KARPUKHIN, V. et al. Dense passage retrieval for open-domain question answering. In: *Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2020.
- LEWIS, P. et al. Retrieval-augmented generation for knowledge-intensive NLP tasks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 33, 2020.
- LIU, N. F. et al. Lost in the middle: how language models use long contexts. *Transactions of the Association for Computational Linguistics*, v. 12, 2024.
- MALKOV, Y. A.; YASHUNIN, D. A. Efficient and robust approximate nearest neighbor search using hierarchical navigable small world graphs. *IEEE Transactions on Pattern Analysis and Machine Intelligence*, v. 42, n. 4, 2020.
- NOGUEIRA, R.; CHO, K. Passage re-ranking with BERT. *arXiv*, 2019.
- REIMERS, N.; GUREVYCH, I. Sentence-BERT: sentence embeddings using Siamese BERT-networks. In: *Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2019.

### Documentação técnica

- LlamaIndex: documentação de `Document`, `SentenceSplitter`, `HierarchicalNodeParser`, `AutoMergingRetriever`, `QueryFusionRetriever`, `get_response_synthesizer` e dos modos de resposta (`llama-index-core` $0{,}14{,}25$ nas execuções deste livro), no site oficial do projeto.
- FAISS (Facebook AI Research): `IndexFlatIP`, `IndexIVFFlat`, `IndexHNSWFlat` (`faiss-cpu` $1{,}16{,}0$ nas execuções), no repositório do projeto.
- `rank-bm25` (BM25 Okapi) e `PyStemmer` (radicais *snowball* do português), no índice de pacotes do Python.
- LlamaParse e `llama-cloud-services`: documentação do LlamaIndex. **Não executados neste livro.**

::: nota Sobre as referências
As referências deste capítulo foram citadas **de memória**, sem consulta às páginas originais (o ambiente de produção não tem acesso aos sites dos periódicos e repositórios). Autores, títulos e locais de publicação são os que o autor conhece com confiança, mas páginas, volumes, edições e URLs podem conter imprecisões e **devem ser conferidos** antes de qualquer citação formal.
:::
