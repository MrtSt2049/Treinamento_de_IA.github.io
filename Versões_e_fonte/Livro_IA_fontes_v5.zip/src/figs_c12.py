"""Figuras do Capítulo 12 (SVG), a partir das saídas reais de codigo/p8_*.out."""
import json
import math
import re

import numpy as np

from figs_c6 import curva, fmt, legenda, painel, salvar
from figs_c9 import SETA, caixa, rotulo, seta

# ---------- Figura 12.1: arquitetura do pipeline RAG ----------
c = [SETA]
c.append('<text x="10" y="22" font-size="13" font-weight="600">Indexação (offline, uma vez por atualização do corpus)</text>')
xs = [10, 150, 290, 430, 570]
nomes = ["Documentos<tspan x='80' dy='15'>(PDF, HTML, código)</tspan>", "Parsing e<tspan x='220' dy='15'>limpeza</tspan>", "Fatiamento<tspan x='360' dy='15'>(chunking)</tspan>",
         "Embeddings<tspan x='500' dy='15'>dos trechos</tspan>", "Índices<tspan x='640' dy='15'>vetorial + BM25</tspan>"]
for i, (x, t) in enumerate(zip(xs, nomes)):
    c.append(caixa(x, 36, 140 if i < 4 else 130, 52, t.replace("<tspan", "<tspan").replace("dy='15'", "dy='15'"), "cx", 12).replace(f'y="{36 + 26 + 5}"', f'y="{36 + 22}"'))
    if i < 4:
        c.append(seta(x + 140, 62, xs[i + 1], 62))
c.append(f'<path class="setar" d="M640,88 L640,108 L185,108 L185,148"/>')
c.append(rotulo(412, 102, "a recuperação consulta o índice", 11, "t2"))
c.append('<text x="10" y="134" font-size="13" font-weight="600">Consulta (online, a cada pergunta)</text>')
ys = 148
q = [("Pergunta", 10, 90, "cxa"), ("Recuperação<tspan x='185' dy='15'>densa + BM25</tspan>", 120, 130, "cx"), ("Fusão<tspan x='315' dy='15'>(RRF)</tspan>", 270, 90, "cx"),
     ("Reordenação", 380, 100, "cx"), ("Abstenção?<tspan x='550' dy='15'>limiar</tspan>", 500, 100, "cxm"), ("Contexto<tspan x='670' dy='15'>delimitado</tspan>", 620, 100, "cxg")]
for t, x, w, cls in q:
    c.append(caixa(x, ys, w, 52, t, cls, 12).replace(f'y="{ys + 26 + 5}"', f'y="{ys + 22}"'))
for (_, x, w, _), (_, x2, _, _) in zip(q, q[1:]):
    c.append(seta(x + w, ys + 26, x2, ys + 26))
c.append(caixa(560, 240, 160, 50, "LLM<tspan x='640' dy='15'>resposta + citações</tspan>", "cxg", 12).replace(f'y="{240 + 25 + 5}"', f'y="{240 + 21}"'))
c.append(seta(670, 200, 670, 240))
c.append(caixa(340, 240, 160, 50, "\"Não encontrei\"<tspan x='420' dy='15'>(sem contexto útil)</tspan>", "cx", 12).replace(f'y="{240 + 25 + 5}"', f'y="{240 + 21}"'))
c.append('<path class="seta" d="M550,200 C550,222 440,222 420,240"/>')
salvar("fig_c12_pipeline.svg", 740, 306, "Arquitetura RAG: indexação offline (documentos, parsing, fatiamento, embeddings, índices) e consulta online (recuperação, fusão, reordenação, abstenção, contexto, resposta)", c)


# ---------- leitura das saídas ----------
def tabela_exp1(txt, titulo):
    bloco = txt.split(titulo)[1].split("\n\n")[0].splitlines()[2:]
    out = {}
    for lin in bloco:
        m = re.match(r"^(.+?)\s{2,}(\S+/\S+/\S+/\S+)\s+(\S+/\S+/\S+/\S+)\s+(\S+/\S+/\S+/\S+)\s*$", lin)
        if m:
            out[m.group(1).strip()] = [[float(x) for x in g.split("/")] for g in m.groups()[1:]]
    return out


exp1 = open("codigo/p8_exp1_fatiamento.out").read()
dirt, part = tabela_exp1(exp1, "PERGUNTAS DIRETAS (43)"), tabela_exp1(exp1, "PERGUNTAS PARAFRASEADAS (24)")
pal = {}
for lin in exp1.split("PERGUNTAS DIRETAS")[0].splitlines():
    m = re.match(r"^(.+?)\s+(\d+)\s+(\d+)\s+(\d+)\s*$", lin)
    if m:
        pal[m.group(1).strip()] = int(m.group(4))
estr = ["janela 50 (sobrep. 10)", "janela 100 (sobrep. 20)", "janela 150 (sobrep. 30)", "janela 300 (sobrep. 60)", "seção inteira"]
P = [pal[e] for e in estr]

# ---------- Figura 12.2: tamanho do trecho (esq.) e dimensão do LSA (dir.) ----------
c = []
s, X, Y = painel(60, 20, 270, 220, 0, 7, 0.5, 1.0, [], [0.5, 0.6, 0.7, 0.8, 0.9, 1.0], "palavras por trecho (escala logarítmica)", "MRR@10")
lx = lambda p: math.log2(p / 20)           # 40 -> 1; 85 -> 2.1; 126 -> 2.7; 234 -> 3.5; 607 -> 4.9
X = lambda p, x0=60, w=270: x0 + (lx(p) - 0.5) / (5.2 - 0.5) * w
c += s
for p_ in P:
    c.append(f'<line class="fraco" x1="{fmt(X(p_))}" y1="20" x2="{fmt(X(p_))}" y2="240"/><text class="t2" x="{fmt(X(p_))}" y="256" font-size="12" text-anchor="middle">{p_}</text>')
for tab, cls, dash in ((dirt, "lv", None), (part, "lv", "6 3")):
    pass
series = [("denso, diretas", dirt, 0, "lv", None), ("denso, parafraseadas", part, 0, "lv", "6 3"), ("BM25, diretas", dirt, 1, "la", None), ("BM25, parafraseadas", part, 1, "la", "6 3")]
for nome, tab, j, cls, dash in series:
    ys_ = [tab[e][j][2] for e in estr]
    c.append(curva(lambda v: X(v), Y, P, ys_, cls, dash))
    for p_, y_ in zip(P, ys_):
        c.append(f'<circle cx="{fmt(X(p_))}" cy="{fmt(Y(y_))}" r="3" class="{cls}" style="fill:var(--papel);stroke-width:1.6"/>')
c.append(f'<text x="60" y="276" font-size="13" class="t2" text-anchor="start"></text>')
# painel direito: dimensão do LSA
exp2 = open("codigo/p8_exp2_embeddings.out").read()
dims, d_dir, d_par = [], [], []
for lin in exp2.split("(b)")[0].splitlines():
    m = re.match(r"^\s+(\d+)\s+([0-9.]+)\s+(\S+)/(\S+)/(\S+)\s+(\S+)/(\S+)/(\S+)\s*$", lin)
    if m:
        dims.append(int(m.group(1))); d_dir.append(float(m.group(5))); d_par.append(float(m.group(8)))
tf = re.search(r"TF-IDF puro, \d+ dimensões: diretas (\S+)/(\S+)/(\S+); parafraseadas (\S+)/(\S+)/(\S+)", exp2)
tf_dir, tf_par = float(tf.group(3)), float(tf.group(6))
s, X2, Y2 = painel(400, 20, 270, 220, 0, 9, 0.1, 1.0, [], [0.2, 0.4, 0.6, 0.8, 1.0], "dimensão do LSA", "MRR@10")
c += s
ld = lambda d: math.log2(d)
XX = lambda d: 400 + (ld(d) - 2.8) / (8.7 - 2.8) * 270
for d in dims:
    c.append(f'<line class="fraco" x1="{fmt(XX(d))}" y1="20" x2="{fmt(XX(d))}" y2="240"/><text class="t2" x="{fmt(XX(d))}" y="256" font-size="12" text-anchor="middle">{d}</text>')
c.append(curva(lambda v: XX(v), Y2, dims, d_dir, "lv"))
c.append(curva(lambda v: XX(v), Y2, dims, d_par, "lv", "6 3"))
for d, a, b in zip(dims, d_dir, d_par):
    c.append(f'<circle cx="{fmt(XX(d))}" cy="{fmt(Y2(a))}" r="3" class="lv" style="fill:var(--papel);stroke-width:1.6"/><circle cx="{fmt(XX(d))}" cy="{fmt(Y2(b))}" r="3" class="lv" style="fill:var(--papel);stroke-width:1.6"/>')
c.append(f'<line class="lg" x1="400" y1="{fmt(Y2(tf_dir))}" x2="670" y2="{fmt(Y2(tf_dir))}" stroke-dasharray="2 4"/>')
c.append(f'<line class="lg" x1="400" y1="{fmt(Y2(tf_par))}" x2="670" y2="{fmt(Y2(tf_par))}" stroke-dasharray="2 4"/>')
c.append(f'<text class="t2" x="404" y="{fmt(Y2(tf_dir) - 5)}" font-size="11">TF-IDF puro, diretas</text><text class="t2" x="404" y="{fmt(Y2(tf_par) - 5)}" font-size="11">TF-IDF puro, parafraseadas</text>')
c += legenda([("lv", "denso (LSA)", None), ("la", "BM25", None)], 60, 296, 130)
c.append('<text class="t2" x="330" y="300" font-size="12">linha contínua: perguntas diretas; tracejada: parafraseadas</text>')
salvar("fig_c12_fatiamento.svg", 700, 320, "À esquerda, MRR contra o tamanho do trecho para recuperação densa e BM25; à direita, MRR contra a dimensão do LSA, com o TF-IDF puro como referência", c)

# ---------- Figura 12.3: abstenção ----------
dados = json.load(open("codigo/p8_abstencao.json"))["pont"]
grupos = ["respondíveis", "perto do domínio", "longe do domínio"]
rng = np.random.default_rng(0)
c = []
s, X, Y = painel(60, 20, 250, 220, 0, 3, 0, 0.9, [], [0, 0.2, 0.4, 0.6, 0.8], None, "cosseno do melhor trecho")
c += s
cores = {"respondíveis": "lg", "perto do domínio": "la", "longe do domínio": "lr"}
for i, g in enumerate(grupos):
    xc = 60 + (i + 0.5) / 3 * 250
    v = [p["denso"] for p in dados[g]]
    for y_ in v:
        c.append(f'<circle cx="{fmt(xc + rng.uniform(-22, 22))}" cy="{fmt(Y(y_))}" r="3" class="{cores[g]}" style="fill:var(--papel);stroke-width:1.5"/>')
    c.append(f'<line class="{cores[g]}" x1="{xc - 30}" y1="{fmt(Y(np.median(v)))}" x2="{xc + 30}" y2="{fmt(Y(np.median(v)))}" stroke-width="2.5"/>')
    c.append(f'<text x="{xc}" y="258" font-size="12" text-anchor="middle">{["respondíveis", "perto", "longe"][i]}</text><text class="t2" x="{xc}" y="272" font-size="11" text-anchor="middle">n = {len(v)}</text>')
c.append(f'<line class="fraco" x1="60" y1="{fmt(Y(0.4))}" x2="310" y2="{fmt(Y(0.4))}" style="stroke:var(--rubi);stroke-dasharray:3 3"/><text class="t2" x="64" y="{fmt(Y(0.4) + 13)}" font-size="11">limiar 0,4</text>')
# curvas ROC
s, X2, Y2 = painel(400, 20, 230, 220, 0, 1, 0, 1, [0, 0.25, 0.5, 0.75, 1], [0, 0.25, 0.5, 0.75, 1], "sem resposta, mas respondidas", "respondíveis respondidas")
c += s
c.append(f'<line class="fraco" x1="{fmt(X2(0))}" y1="{fmt(Y2(0))}" x2="{fmt(X2(1))}" y2="{fmt(Y2(1))}" style="stroke:var(--rubi);stroke-dasharray:4 4"/>')
for nome, cls in (("denso", "lv"), ("bm25", "la"), ("bm25 normalizado", "lg")):
    pos = np.array([p[nome] for p in dados["respondíveis"]]); neg = np.array([p[nome] for g in ("longe do domínio", "perto do domínio") for p in dados[g]])
    ts = np.unique(np.r_[pos, neg, np.inf])[::-1]
    fp = [np.mean(neg >= t) for t in ts]; tp = [np.mean(pos >= t) for t in ts]
    c.append(curva(X2, Y2, fp, tp, cls, "6 3" if nome == "bm25 normalizado" else None))
c += legenda([("lv", "cosseno (denso)", None), ("la", "BM25", None), ("lg", "BM25 normalizado", "6 3")], 60, 304, 190)
salvar("fig_c12_abstencao.svg", 680, 325, "À esquerda, o cosseno do melhor trecho para perguntas respondíveis e sem resposta; à direita, curvas de operação de três pontuações de confiança", c)

# ---------- Figura 12.4: ANN, recall contra latência ----------
txt = open("codigo/p8_exp6_ann.out").read().split("(B)")[1]
pts = {"HNSW": [], "IVF": []}
exato = None
for lin in txt.splitlines():
    m = re.match(r"^(HNSW|IVF-Flat)\s.*?=(\d+)\s+[0-9.]+\s+([0-9.]+)\s+([0-9.]+)\s+\d+\s*$", lin)
    if m:
        pts["HNSW" if m.group(1) == "HNSW" else "IVF"].append((float(m.group(4)), float(m.group(3)), int(m.group(2))))
    m = re.match(r"^exato.*\s0\.0\s+([0-9.]+)\s+1\.000", lin)
    if m:
        exato = float(m.group(1))
c = []
lt = [0.02, 0.05, 0.1, 0.3, 1, 2.5]
s, X, Y = painel(70, 20, 540, 240, 0, 1.0, math.log10(0.02), math.log10(4), [0, 0.2, 0.4, 0.6, 0.8, 1.0], [math.log10(v) for v in lt], "recall@10 (fração dos 10 vizinhos exatos encontrados)", "ms por consulta", lambda v: f"{10 ** v:.2g}".replace(".", ","))
c += s
for nome, cls in (("HNSW", "lv"), ("IVF", "la")):
    rs = [p[0] for p in pts[nome]]; ls = [math.log10(p[1]) for p in pts[nome]]
    c.append(curva(X, Y, rs, ls, cls))
    for r, l, par in zip(rs, ls, [p[2] for p in pts[nome]]):
        c.append(f'<circle cx="{fmt(X(r))}" cy="{fmt(Y(l))}" r="3.5" class="{cls}" style="fill:var(--papel);stroke-width:1.8"/>')
c.append(f'<circle cx="{fmt(X(1.0))}" cy="{fmt(Y(math.log10(exato)))}" r="5" class="lg" style="fill:var(--papel);stroke-width:2"/><text x="{fmt(X(1.0) - 10)}" y="{fmt(Y(math.log10(exato)) + 4)}" font-size="12" text-anchor="end">busca exata ({exato:.1f} ms)</text>'.replace(".", ",", 0))
c += legenda([("lv", "HNSW (M=16; efSearch = 8 a 128)", None), ("la", "IVF-Flat (1024 listas; nprobe = 1 a 64)", None)], 70, 316, 300)
salvar("fig_c12_ann.svg", 640, 340, "Compromisso entre recall e latência de HNSW e IVF em 100 mil vetores sintéticos, com a busca exata como referência", c)
print("figs c12 ok", len(pts["HNSW"]), len(pts["IVF"]), exato, dims)
