## Página de título

**INTELIGÊNCIA ARTIFICIAL**
**Da Teoria Zero à Engenharia Mestre**

Fundamentos Matemáticos, Machine Learning, Deep Learning, Transformers, LLMs, RAG e Agentes Inteligentes.

Marcus Rafael Iwasaki Marquini Amaral

Obra em seis módulos e quinze capítulos, com dez projetos integradores, exercícios em três níveis e soluções comentadas. Esta edição em produção contém os elementos pré-textuais e os Módulos I a III completos (Capítulos 1 a 8, Projetos 1 a 6). O estado exato da produção está registrado ao final desta abertura.

## Prefácio

Este livro nasce de uma pergunta prática: o que uma pessoa precisa saber para construir, com responsabilidade, um sistema moderno de Inteligência Artificial, e em que ordem?

A resposta curta costuma ser uma lista de ferramentas. Ela envelhece em meses. A resposta longa é uma cadeia de ideias em que cada elo sustenta o seguinte. Um agente que consulta documentos privados e decide qual ferramenta chamar depende de um modelo de linguagem. O modelo de linguagem é uma rede neural com mecanismo de atenção. A rede neural é uma composição de funções treinada por otimização. A otimização usa gradientes, que são objetos do cálculo aplicados a matrizes, e o critério que ela minimiza vem da probabilidade. Quem conhece apenas o último elo consegue montar uma demonstração. Quem conhece a cadeia inteira consegue explicar por que o sistema falha e o que fazer a respeito.

O livro percorre essa cadeia do primeiro elo ao último. Começa em vetores e derivadas parciais e termina em avaliação, observabilidade e governança de sistemas com agentes em produção. Entre um ponto e outro não há atalhos: cada resultado importante é derivado, cada algoritmo é implementado duas vezes (uma para entender, outra como se faz profissionalmente), e cada capítulo termina com exercícios que exigem usar o que foi construído.

Três compromissos orientam a escrita.

**Rigor sem ornamento.** Uma equação só aparece quando trabalha. Para cada uma, o texto diz o que cada símbolo representa, quais são as dimensões dos objetos, de que hipóteses ela depende e o que muda na prática por causa dela. O texto também distingue, sempre que a diferença importa, o que é identidade matemática, o que é hipótese estatística, o que é aproximação, o que é heurística e o que é apenas resultado empírico.

**Código que roda.** Todos os programas deste livro foram executados antes da publicação, e as saídas impressas são as saídas reais dessas execuções, com as versões das bibliotecas indicadas. Código didático e código recomendado para produção aparecem identificados como tais.

**Honestidade sobre limites.** Modelos de linguagem geram texto plausível, e plausível não significa verdadeiro. Agentes executam ações dentro de limites definidos por quem os projeta. Um bom resultado em um conjunto de teste não garante confiabilidade fora dele. O livro trata esses limites como parte do conteúdo técnico, e não como ressalva de rodapé.

Estude com lápis e com um interpretador Python abertos. Refaça as derivações antes de ler a solução. Altere os programas e observe o que quebra. É assim que os elos se formam.

## Apresentação da obra

O livro está organizado em seis módulos, que correspondem a seis níveis de formação.

| Módulo | Nível | O que o leitor passa a ser capaz de fazer |
|---|---|---|
| I. Fundamentos Matemáticos, Estatísticos e Paradigmas Iniciais | Base | Ler e manipular a matemática usada em IA; descrever qualquer sistema como um agente em um ambiente |
| II. Aprendizado Estatístico e Machine Learning Clássico | Intermediário | Formular problemas de aprendizado, ajustar modelos clássicos e avaliá-los corretamente |
| III. Deep Learning e Redes Neurais Profundas | Avançado | Derivar e implementar redes neurais, CNNs e redes recorrentes |
| IV. A Era dos Transformers e Modelos de Linguagem | Especialista | Explicar e implementar a atenção; ajustar modelos pré-treinados |
| V. Engenharia de Aplicações com LLMs, RAG e Sistemas de Conhecimento | Mestre | Projetar aplicações confiáveis com LLMs e recuperação de conhecimento |
| VI. Orquestração de Agentes Autônomos e Sistemas em Produção | Arquiteto | Orquestrar, avaliar, monitorar e governar sistemas com agentes |

Cada capítulo segue a mesma progressão: motivação, intuição, definição formal, derivação, exemplo resolvido, implementação, aplicação, limitações, erros frequentes e exercícios. Os elementos visuais têm função fixa em todo o livro:

::: definicao Boxes de definição
Enunciam formalmente um conceito. São numerados por capítulo.
:::

::: teorema Boxes de teorema e proposição
Enunciam resultados com suas hipóteses. A demonstração vem logo em seguida, em um bloco próprio.
:::

::: exemplo Boxes de exemplo
Resolvem um caso com números concretos, passo a passo.
:::

::: atencao Boxes de atenção
Marcam hipóteses fáceis de esquecer e limites de validade.
:::

::: erro Boxes de erro frequente
Descrevem um engano conceitual comum e a forma correta de pensar.
:::

::: aplicacao Boxes de aplicação
Mostram onde o conceito reaparece em sistemas reais e em capítulos posteriores.
:::

Dez projetos integradores acompanham os capítulos. Cada projeto apresenta objetivo, problema, requisitos, arquitetura, fundamentos, implementação, testes, resultados esperados, limitações e melhorias possíveis.

| Projeto | Tema | Capítulo |
|---|---|---|
| 1 | Fundamentos matemáticos computacionais com NumPy | 1 |
| 2 | Pipeline de Machine Learning com scikit-learn | 5 |
| 3 | Rede neural do zero com NumPy | 6 |
| 4 | Deep Learning com PyTorch | 6 |
| 5 | Classificação de imagens com CNN e Transfer Learning | 7 |
| 6 | Modelagem sequencial com RNN, LSTM ou GRU | 8 |
| 7 | Fine-tuning de LLM com Hugging Face e LoRA | 10 |
| 8 | Sistema RAG com fontes | 12 |
| 9 | Agente com ferramentas | 13 |
| 10 | Sistema multiagente stateful com LangGraph | 14 e 15 |

## Público-alvo

O livro foi escrito para quatro perfis.

- **Estudantes universitários** de computação, engenharias, matemática, estatística e áreas afins, que queiram um texto único cobrindo dos fundamentos à engenharia.
- **Desenvolvedores** que já programam e querem entender o que há por trás das bibliotecas que utilizam.
- **Profissionais de dados** que dominam o Machine Learning clássico e precisam avançar para Deep Learning, LLMs e agentes.
- **Pesquisadores iniciantes** que precisam de base sólida antes de ler artigos científicos.

Supõe-se matemática de ensino médio bem assentada (funções, polinômios, sistemas lineares simples) e familiaridade básica com programação. Noções de cálculo de uma variável ajudam, mas as ideias necessárias são retomadas quando usadas. Nenhum conhecimento prévio de IA é exigido.

## Como utilizar o livro

**Leitura linear.** A ordem dos capítulos é a ordem de dependência. Quem tem tempo deve segui-la.

**Leitura por objetivo.** Quem já domina parte do conteúdo pode entrar por outro ponto, respeitando o mapa de pré-requisitos da próxima seção. As seções de erros frequentes e o resumo de cada capítulo permitem verificar rapidamente se o pré-requisito está de fato dominado.

**Ritmo sugerido para um curso.** O material corresponde a cerca de dois semestres: Módulos I a III no primeiro, Módulos IV a VI no segundo. Em estudo individual, um capítulo ocupa de uma a três semanas, contando exercícios e projeto.

**Exercícios.** Cada capítulo tem três níveis. O Nível I (consolidação) confere se as definições foram compreendidas. O Nível II (desenvolvimento) exige derivar ou implementar. O Nível III (avançado) pede análise crítica, pesquisa ou projeto. As soluções comentadas ficam recolhidas ao final do capítulo: tente antes de abrir.

**Código.** Os programas estão em Python e podem ser copiados com o botão no canto de cada bloco. O bloco tracejado logo abaixo de um programa mostra a saída obtida na execução feita para esta edição.

## Mapa de pré-requisitos

<figure>
<svg class="fig" viewBox="0 0 720 396" role="img" aria-label="Mapa dos quinze capítulos em seis linhas, uma por módulo, com setas indicando a ordem de estudo">
<defs><marker id="seta" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" class="pt"/></marker></defs>
<g font-size="12" class="t2"><text x="0" y="36">I · Base</text><text x="0" y="100">II · Intermediário</text><text x="0" y="164">III · Avançado</text><text x="0" y="228">IV · Especialista</text><text x="0" y="292">V · Mestre</text><text x="0" y="356">VI · Arquiteto</text></g>
<g font-size="13" font-weight="700">
<rect class="cx" x="130" y="14" width="170" height="36" rx="6"/><text x="215" y="37" text-anchor="middle">1 · Matemática</text>
<rect class="cx" x="340" y="14" width="170" height="36" rx="6"/><text x="425" y="37" text-anchor="middle">2 · Agentes racionais</text>
<rect class="cx" x="130" y="78" width="170" height="36" rx="6"/><text x="215" y="101" text-anchor="middle">3 · Formulação</text>
<rect class="cx" x="340" y="78" width="170" height="36" rx="6"/><text x="425" y="101" text-anchor="middle">4 · Modelos clássicos</text>
<rect class="cx" x="550" y="78" width="170" height="36" rx="6"/><text x="635" y="101" text-anchor="middle">5 · Avaliação</text>
<rect class="cx" x="130" y="142" width="170" height="36" rx="6"/><text x="215" y="165" text-anchor="middle">6 · Redes neurais</text>
<rect class="cx" x="340" y="142" width="170" height="36" rx="6"/><text x="425" y="165" text-anchor="middle">7 · CNNs</text>
<rect class="cx" x="550" y="142" width="170" height="36" rx="6"/><text x="635" y="165" text-anchor="middle">8 · RNNs</text>
<rect class="cx" x="130" y="206" width="170" height="36" rx="6"/><text x="215" y="229" text-anchor="middle">9 · Transformer</text>
<rect class="cx" x="340" y="206" width="170" height="36" rx="6"/><text x="425" y="229" text-anchor="middle">10 · Hugging Face</text>
<rect class="cxa" x="130" y="270" width="170" height="36" rx="6"/><text x="215" y="293" text-anchor="middle">11 · LLMs em produção</text>
<rect class="cxa" x="340" y="270" width="170" height="36" rx="6"/><text x="425" y="293" text-anchor="middle">12 · RAG</text>
<rect class="cxa" x="130" y="334" width="170" height="36" rx="6"/><text x="215" y="357" text-anchor="middle">13 · Agentes com LLM</text>
<rect class="cxa" x="340" y="334" width="170" height="36" rx="6"/><text x="425" y="357" text-anchor="middle">14 · LangGraph</text>
<rect class="cxa" x="550" y="334" width="170" height="36" rx="6"/><text x="635" y="357" text-anchor="middle">15 · Governança</text>
</g>
<g class="ln" marker-end="url(#seta)">
<path d="M300 32H338"/><path d="M215 50V76"/><path d="M300 96H338"/><path d="M510 96H548"/>
<path d="M635 114V128H215V140"/><path d="M300 160H338"/><path d="M510 160H548"/>
<path d="M635 178V192H215V204"/><path d="M300 224H338"/>
<path d="M425 242V256H215V268"/><path d="M300 288H338"/>
<path d="M425 306V320H215V332"/><path d="M300 352H338"/><path d="M510 352H548"/>
</g>
</svg>
<figcaption><b>Figura 0.1.</b> Ordem de estudo. Em violeta, os capítulos de fundamentos permanentes; em azul, os que dependem de ferramentas contemporâneas. As dependências que saltam módulos estão na tabela a seguir.</figcaption>
</figure>

| Capítulo | Requer diretamente | Conteúdo reutilizado |
|---|---|---|
| 3 a 5 | 1 | Vetores e matrizes, gradiente, esperança, variância, Teorema de Bayes |
| 6 | 1, 4 e 5 | Regra da cadeia, descida do gradiente, regressão logística, validação |
| 7 e 8 | 6 | Backpropagation, laço de treinamento em PyTorch |
| 9 | 1 e 8 | Produto escalar, softmax, limitações das redes recorrentes |
| 10 | 9 | Arquitetura Transformer; posto de matrizes (Capítulo 1) para LoRA |
| 11 | 9 e 10 | Geração autoregressiva, distribuições de probabilidade |
| 12 | 1 e 11 | Similaridade por cosseno e distância euclidiana |
| 13 | 2 e 11 | Arquitetura de agentes, PEAS, saídas estruturadas |
| 14 | 13 | Agentes com ferramentas |
| 15 | 5, 12 e 14 | Métricas de avaliação, RAG, orquestração |

## Sumário

**Módulo I. Fundamentos Matemáticos, Estatísticos e Paradigmas Iniciais**

1. [Fundamentos Matemáticos para Computação e Aprendizado](#cap-1) (inclui o Projeto 1)
2. [Fundamentos da Inteligência Artificial e Agentes Racionais](#cap-2)

**Módulo II. Aprendizado Estatístico e Machine Learning Clássico**

3. [Formulação do Aprendizado Supervisionado e Não Supervisionado](#cap-3)
4. [Modelos Clássicos de Regressão e Classificação](#cap-4)
5. [Avaliação, Generalização e Seleção de Modelos](#cap-5) (inclui o Projeto 2)

**Módulo III. Deep Learning e Redes Neurais Profundas**

6. [Redes Neurais Artificiais](#cap-6) (inclui os Projetos 3 e 4)
7. [Visão Computacional com CNNs](#cap-7) (inclui o Projeto 5)
8. [Processamento de Sequências e RNNs](#cap-8) (inclui o Projeto 6)

**Módulo IV. A Era dos Transformers e Modelos de Linguagem**

9. A Revolução da Atenção e a Arquitetura Transformer
10. Ecossistema Hugging Face e Ajuste Fino (inclui o Projeto 7)

**Módulo V. Engenharia de Aplicações com LLMs, RAG e Sistemas de Conhecimento**

11. Engenharia de Contexto e Fundamentos de LLMs em Produção
12. Arquitetura RAG com LlamaIndex (inclui o Projeto 8)

**Módulo VI. Orquestração de Agentes Autônomos e Sistemas em Produção**

13. Frameworks de Agentes Autônomos e Execução de Ferramentas (inclui o Projeto 9)
14. Orquestração Stateful e Grafos com LangChain e LangGraph (inclui o Projeto 10)
15. Avaliação, Monitoramento e Governança de Sistemas de IA

**Elementos finais:** conclusão, trilhas de aprofundamento, glossário técnico, índice de símbolos, bibliografia geral e índice remissivo.

## Convenções matemáticas e computacionais

### Notação

A notação abaixo vale para o livro inteiro. Ela segue de perto a de Goodfellow, Bengio e Courville (2016), com adaptações mínimas.

| Símbolo | Significado |
|---|---|
| $a,\ \alpha,\ n$ | Escalares: letras minúsculas em itálico |
| $\mathbf{x},\ \mathbf{w}$ | Vetores: minúsculas em negrito; por convenção, vetores são colunas |
| $\mathbf{A},\ \mathbf{X}$ | Matrizes: maiúsculas em negrito |
| $\mathcal{T}$ | Tensores de ordem três ou maior |
| $x_i$,  $A_{ij}$ | Componente $i$ do vetor $\mathbf{x}$; elemento da linha $i$ e coluna $j$ de $\mathbf{A}$ |
| $\mathbf{A}^\top$,  $\mathbf{A}^{-1}$ | Transposta e inversa |
| $\mathbf{I}_n$ | Matriz identidade de ordem $n$ |
| $\mathbb{R}^n$,  $\mathbb{R}^{m\times n}$ | Conjunto dos vetores reais com $n$ componentes; das matrizes reais $m \times n$ |
| $\lVert \mathbf{x} \rVert_p$ | Norma $\ell_p$ de $\mathbf{x}$; sem índice, entende-se $p=2$ |
| $\nabla f$,  $\mathbf{H}_f$ | Gradiente e matriz Hessiana de $f$ |
| $X,\ Y$ | Variáveis aleatórias: maiúsculas em itálico |
| $P(A)$,  $p(x)$ | Probabilidade do evento $A$; função de massa ou densidade em $x$ |
| $\mathbb{E}[X]$,  $\operatorname{Var}(X)$,  $\operatorname{Cov}(X,Y)$ | Esperança, variância e covariância |
| $\mathcal{N}(\mu,\sigma^2)$ | Distribuição Gaussiana de média $\mu$ e variância $\sigma^2$ |
| $\boldsymbol{\theta}$ | Vetor de parâmetros de um modelo |
| $\mathcal{L}$ | Função de perda |
| $\eta$ | Taxa de aprendizado |
| $n,\ d$ | Número de exemplos; número de variáveis preditoras |
| $\hat{y}$ | Valor previsto por um modelo para a resposta $y$ |

Um conjunto de dados com $n$ exemplos e $d$ variáveis é guardado em uma matriz $\mathbf{X} \in \mathbb{R}^{n \times d}$: cada linha é um exemplo, cada coluna é uma variável. Essa é a convenção de NumPy, scikit-learn e PyTorch.

Logaritmos sem base indicada são naturais. Nos textos em português, o separador decimal é a vírgula; em código e nas saídas de programas, o ponto.

### Código

- **Linguagem:** Python 3.10 ou superior. Os programas foram executados em Python 3.13, com NumPy 2.5, SciPy 1.18, scikit-learn 1.9, pandas 3.0, statsmodels 0.15, PyTorch 2.15 (execução em CPU) e torchvision 0.29 (novembro de 2026).
- **Importações padrão:** `import numpy as np`; nos capítulos seguintes, `import pandas as pd`, `import matplotlib.pyplot as plt`, `import torch`.
- **Nomes:** identificadores em português, sem acentos, em `snake_case`; classes em `CamelCase`.
- **Reprodutibilidade:** toda fonte de aleatoriedade recebe uma semente explícita, por exemplo `np.random.default_rng(42)`.
- **Formas:** os comentários indicam a forma (*shape*) dos arranjos sempre que ela não for evidente. Conferir formas é o teste mais barato que existe.
- **Dois registros:** *código didático* privilegia a correspondência com as equações; *código de produção* usa as rotinas das bibliotecas, mais rápidas e numericamente mais estáveis. Cada bloco informa a que registro pertence quando a diferença importa.

### Três camadas de conteúdo

O ecossistema de IA muda depressa, mas nem tudo muda na mesma velocidade. O livro separa três camadas.

1. **Fundamentos permanentes:** matemática, estatística, algoritmos, redes neurais, atenção e princípios de arquitetura. Os Módulos I a IV concentram essa camada.
2. **Ferramentas contemporâneas:** bibliotecas, modelos, APIs e plataformas. Aparecem com a versão ou a data de referência, e as interfaces citadas são conferidas na documentação oficial no momento da escrita de cada capítulo.
3. **Práticas de engenharia:** avaliação, observabilidade, segurança, implantação e manutenção. Mudam devagar, e por isso são ensinadas como princípios antes de serem ensinadas como ferramentas.

## Introdução geral

### Do que trata este livro

Inteligência Artificial (*Artificial Intelligence*, IA) é o estudo e a construção de sistemas que escolhem ações adequadas aos seus objetivos a partir do que percebem. O Capítulo 2 torna essa frase precisa. Por ora, basta notar o que ela não diz: não fala em imitar pessoas, nem em consciência, nem em uma técnica específica. Redes neurais, árvores de decisão, busca em grafos e modelos de linguagem são meios diferentes de construir tais sistemas.

Nas últimas décadas, um desses meios tornou-se dominante: o Aprendizado de Máquina (*Machine Learning*, ML), em que o comportamento do sistema é ajustado a partir de dados, em vez de ser escrito regra por regra. Dentro dele, o Aprendizado Profundo (*Deep Learning*, DL) usa redes neurais com muitas camadas. Dentro do Aprendizado Profundo, a arquitetura Transformer tornou possíveis os Grandes Modelos de Linguagem (*Large Language Models*, LLMs). Em torno dos LLMs formou-se uma engenharia própria, com recuperação de conhecimento (*Retrieval-Augmented Generation*, RAG) e agentes que usam ferramentas.

### A cadeia de ideias

O percurso do livro pode ser lido como uma sequência de sustentações. Cada item abaixo é uma afirmação que o texto demonstra no capítulo indicado.

1. **A álgebra linear sustenta as redes neurais.** Uma camada de rede neural calcula $\mathbf{W}\mathbf{x}+\mathbf{b}$ e aplica uma função não linear. Dados, parâmetros e ativações são vetores, matrizes e tensores (Capítulos 1 e 6).
2. **A otimização sustenta o treinamento.** Treinar é procurar parâmetros que minimizam uma função de perda, andando na direção contrária ao gradiente (Capítulos 1 e 6).
3. **A estatística sustenta a generalização.** O que interessa é o erro em dados não vistos, e ele só pode ser estimado e controlado com ferramentas estatísticas (Capítulos 3 e 5).
4. **O Machine Learning clássico evolui para o Deep Learning.** A regressão logística é uma rede neural de uma camada; a rede profunda aprende as representações que antes eram projetadas à mão (Capítulos 4 e 6).
5. **O Deep Learning sustenta os Transformers.** Atenção, conexões residuais e normalização são camadas diferenciáveis treinadas pelo mesmo backpropagation (Capítulos 6 a 9).
6. **Os Transformers sustentam os LLMs.** Um LLM é um Transformer treinado para prever o próximo token em grande volume de texto (Capítulos 9 a 11).
7. **LLMs podem integrar sistemas RAG.** A recuperação fornece ao modelo conhecimento que ele não tem em seus parâmetros (Capítulo 12).
8. **RAG pode ser integrado a agentes.** A recuperação torna-se uma entre várias ferramentas que o agente decide quando usar (Capítulo 13).
9. **Agentes podem ser orquestrados em grafos.** Estado, ciclos, persistência e aprovação humana tornam o comportamento controlável (Capítulo 14).
10. **Sistemas completos exigem avaliação e governança.** Sem medir e monitorar, nada do que foi construído é confiável (Capítulo 15).

### Três cuidados de linguagem

Algumas confusões são tão comuns que convém afastá-las desde já.

**Gerar não é compreender tudo.** A capacidade de produzir texto fluente não equivale a inteligência geral. Se e em que sentido os modelos atuais "compreendem" é uma questão científica em aberto, com posições divergentes, e o livro a apresenta como tal.

**Agente não é autonomia ilimitada.** Neste livro, agente é um termo técnico: um sistema que percebe e age. O grau de autonomia é uma decisão de projeto, e os Capítulos 13 a 15 mostram como limitá-la.

**Desempenho medido não é garantia.** Um resultado experimental vale para as condições em que foi obtido. Extrapolá-lo exige argumento, e o Capítulo 5 mostra como esse argumento é construído.

## Estado da produção

Esta seção registra o ponto exato em que a obra se encontra, para que a continuação preserve notação, convenções e identidade visual.

| Parte | Conteúdo | Situação |
|---|---|---|
| 1 | Elementos pré-textuais; Capítulos 1 e 2; Projeto 1 | Concluída e revisada |
| 2 | Módulo II: Capítulos 3 a 5; Projeto 2 | Concluída e revisada |
| 3 | Módulo III: Capítulos 6 a 8; Projetos 3 a 6 | Concluída e revisada |
| 4 | Módulo IV: Capítulos 9 e 10; Projeto 7 | A produzir |
| 5 | Módulo V: Capítulos 11 e 12; Projeto 8 | A produzir |
| 6 | Módulo VI: Capítulos 13 a 15; Projetos 9 e 10 | A produzir |
| 7 | Conclusão, trilhas, glossário, índice de símbolos, bibliografia geral, índice remissivo e revisão consolidada | A produzir |

Último ponto concluído: Capítulo 8, seção de referências. Próximo ponto: Capítulo 9, seção 9.1.
