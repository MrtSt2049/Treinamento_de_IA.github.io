<div class="objetivos">

Objetivos do capítulo

- Explicar por que uma **cadeia linear** (um grafo acíclico) não expressa o laço de um agente e como um **grafo com ciclos** o faz, com **limite de recursão** como rede de segurança.
- Modelar um sistema como **grafo de estados**: nós, arestas fixas, arestas condicionais, esquema de estado compartilhado e **redutores**; entender a execução em **passos** (super-passos).
- Demonstrar quando um redutor torna o resultado de um passo **independente da ordem** das escritas paralelas, e verificar por execução o erro de escritas concorrentes sem redutor.
- Usar **checkpointers** para salvar e retomar execuções, e calcular quanto custa uma falha **com** e **sem** eles; projetar efeitos externos **idempotentes**.
- Implementar **humano no laço**: pausa dinâmica (`interrupt`) e estática (`interrupt_before`), resposta por `Command(resume=...)`, e as armadilhas de reexecução do nó.
- Montar **sistemas multiagente** (supervisor, hierarquia por subgrafos, fan-out com `Send`) e saber o custo da coordenação.
- Construir o **Projeto 10**: uma equipe de agentes com revisão, aprovação humana e publicação com retomada, sobre o LangGraph **real** e com agentes que decidem por regras (**nenhum LLM foi consultado**).

**Pré-requisitos:** Capítulo 13 (laço ReAct, ferramentas, erro composto, Reflexion) e Capítulo 2 (agentes e ambientes).

</div>

## 14.1 Por que grafos: os limites das cadeias lineares

Uma **cadeia** (*chain*) liga etapas em sequência fixa: a saída de uma é a entrada da seguinte. Em termos de grafos, é um **grafo acíclico dirigido** (DAG): o caminho é decidido **ao projetar** o programa, e cada etapa roda **no máximo uma vez**. Isso basta para fluxos como "carregar, fatiar, indexar, consultar" (o RAG do Capítulo 12). Mas o laço do agente do Capítulo 13 não é assim: decidir, agir, observar e decidir de novo é um **ciclo**, e o número de voltas só se sabe **durante** a execução.

Dois problemas aparecem quando se tenta usar cadeias para isso.

- **Profundidade desconhecida.** Se o número de etapas depende dos dados (quantas ferramentas serão chamadas, quantas revisões o texto pede), uma cadeia de profundidade fixa ou desperdiça etapas ou termina antes da hora.
- **Controle de fluxo espalhado.** Ramificar ("se faltar dado, pesquise; senão, escreva"), repetir e parar acaba escondido em `if` e `while` dentro de uma função gigante, sem lugar claro para **salvar o estado**, **pausar** para uma pessoa ou **retomar** depois de uma falha.

Um exemplo mínimo mostra o primeiro problema. O método de Newton para $\sqrt{a}$ itera $x\leftarrow\tfrac12\bigl(x+a/x\bigr)$ **até convergir**, e o número de iterações cresce com $a$. A cadeia fixa de três aplicações converge para $a=4$, mas não para $a$ grande; o grafo com ciclo repete até o critério ser satisfeito.

<<< codigo/c14_grafos_basico.py

>>> codigo/c14_grafos_basico.out

O erro relativo da cadeia vai de $6\times10^{-4}$ (para $a=4$) a $1{,}6\times10^{6}$ (para $a=10^8$), enquanto o ciclo faz de $5$ a $17$ iterações e atinge o critério em todos os casos. O custo do ciclo é um **risco**: se o critério nunca for satisfeito, o laço nunca termina. Por isso o LangGraph impõe um **limite de recursão** (`recursion_limit`) e levanta `GraphRecursionError` ao atingi-lo. É o mesmo papel do `max_passos` do Capítulo 13: nenhum ciclo em produção deve existir sem um limite explícito de passos.

## 14.2 O modelo de grafo com estado

O **LangGraph** descreve a aplicação como um grafo cujos nós leem e escrevem um **estado compartilhado**.

::: definicao 14.1 · Grafo de estados
Um **grafo de estados** é uma tupla $\mathcal{G}=(\mathcal{S},N,E,E_c,\{\rho_k\})$ em que

- $\mathcal{S}$ é o **esquema do estado**: um conjunto de chaves $k_1,\dots,k_m$ com tipos;
- $N$ é o conjunto de **nós**; cada nó $n$ é uma função $f_n:\mathcal{S}\to\Delta$ que lê o estado e devolve uma **atualização parcial** $\delta\in\Delta$ (valores para algumas chaves);
- $E\subseteq (N\cup\{\mathsf{START}\})\times(N\cup\{\mathsf{END}\})$ são as **arestas fixas**;
- $E_c$ são as **arestas condicionais**: de um nó $n$ sai uma função $r_n:\mathcal{S}\to N\cup\{\mathsf{END}\}$ que escolhe o próximo nó **olhando o estado**;
- $\rho_k$ é o **redutor** da chave $k$: uma função que combina o valor atual com uma atualização, $s_k\leftarrow\rho_k(s_k,u)$. Sem redutor declarado, a atualização **substitui** o valor.
:::

Três ideias sustentam o modelo.

**Nós são funções comuns.** Um nó é uma função Python que recebe o estado e devolve um dicionário com as chaves que quer alterar. Pode chamar um LLM, uma ferramenta, outro grafo, ou apenas calcular.

**O fluxo é dado de dados.** Em vez de `if/while` escondidos, o grafo declara as arestas. Uma **aresta condicional** é uma função que lê o estado e devolve o nome do próximo nó (ou `END`). O laço ReAct do Capítulo 13 vira o grafo da Figura 14.1: o nó `modelo` decide, a aresta condicional pergunta se há chamada de ferramenta, e a aresta fixa `ferramentas → modelo` fecha o ciclo.

<figure>
+++ fig_c14_anatomia.svg
<figcaption><b>Figura 14.1.</b> Anatomia de um grafo com estado. Os nós leem e atualizam o estado compartilhado; as arestas condicionais decidem o próximo nó a partir do estado; o ciclo ferramentas → modelo é uma aresta fixa. É exatamente a estrutura do laço ReAct do Capítulo 13.</figcaption>
</figure>

**A execução acontece em passos.** O LangGraph executa em **super-passos**, no estilo do modelo *Pregel* de processamento de grafos (Malewicz et al., 2010): em cada passo, todos os nós **prontos** (cujas arestas de entrada foram ativadas no passo anterior) rodam, as atualizações são **fundidas** no estado pelos redutores, e só então começa o passo seguinte. Nós de um mesmo passo são **paralelos**: não veem as escritas uns dos outros. O exemplo da seção 14.1 (parte C da saída) mostra isso: depois de `ler`, os nós `a`, `b` e `c` rodam **no mesmo passo 2**, e `juntar`, que espera os três, roda no passo 3.

### Estado compartilhado e redutores

Duas escritas paralelas na mesma chave criam um problema: quem vence? O LangGraph **não** decide por você. Sem redutor, a execução do programa acima levanta `InvalidUpdateError` (parte B da saída). A solução é declarar **como combinar**, com um redutor na anotação do tipo da chave: `operator.add` concatena listas, uma função própria (aqui `maximo`) escolhe o maior valor, e `add_messages` concatena mensagens e **substitui** a de mesmo identificador (útil para editar uma mensagem do histórico).

::: proposicao 14.1 · Redutores comutativos tornam o passo independente da ordem
Seja $s$ o valor de uma chave antes de um passo e $u_1,\dots,u_m$ as atualizações escritas em paralelo por $m$ nós nesse passo. Se o redutor $\rho$ satisfaz $\rho(\rho(s,u),v)=\rho(\rho(s,v),u)$ para todos $s,u,v$ (**atualizações comutativas**), o valor da chave ao final do passo é o **mesmo para qualquer ordem** de aplicação das $m$ atualizações. Isso vale para $\rho=\max$, para a união de conjuntos e para a soma numérica. Para a concatenação de listas, **não** vale: $[a]+[b]\neq[b]+[a]$.
:::

::: demonstracao
Duas ordens quaisquer de aplicação diferem por uma sequência de **trocas de duas atualizações adjacentes**. Pela hipótese, $\rho(\rho(t,u),v)=\rho(\rho(t,v),u)$ para **qualquer** valor intermediário $t$, logo cada troca preserva o valor final, e a ordem não importa. Para a concatenação, $\rho(\rho(s,[a]),[b])=s+[a]+[b]$ difere de $s+[b]+[a]$, e a hipótese falha.
:::

A consequência prática é uma regra de projeto: **prefira redutores comutativos** (união, máximo, soma, mesclar dicionários com chaves distintas) para chaves escritas em paralelo. Concatenar listas funciona, mas a **ordem** do resultado passa a depender da ordem em que o motor aplica as atualizações. Nas 50 execuções da parte C, a sequência final foi **sempre a mesma**, o que mostra que o motor é determinístico nesse caso; o que o livro **não** verificou é se essa ordem é garantida pela documentação em todas as versões, então um programa **não deve depender dela**.

::: atencao Escritas em passos diferentes não conflitam
O erro `InvalidUpdateError` só ocorre para escritas **no mesmo passo**. Um nó que roda no passo seguinte sobrescreve a chave sem redutor sem nenhum aviso: é a semântica de "último valor". O redutor é necessário para **combinar**, e não para **sobrescrever**.
:::

### O `create_agent` do Capítulo 13 já é um grafo

O agente do Capítulo 13 foi criado com `create_agent`. Ele é um grafo do LangGraph com **quatro nós**: `__start__`, `model`, `tools` e `__end__`, e as arestas da Figura 14.1 (a saída abaixo mostra as arestas condicionais `model→tools` e `model→__end__`, e a fixa `tools→model`). Isso importa porque tudo o que este capítulo mostra (checkpointers, pausas, subgrafos) se aplica ao agente pronto.

<<< codigo/c14_create_agent_grafo.py

>>> codigo/c14_create_agent_grafo.out

A parte 2 mostra a **aprovação humana** de uma ferramenta crítica já embutida no agente, por um *middleware* que usa `interrupt` por baixo (seção 14.4). Note que o texto final "Feito." veio do **modelo roteirizado**, que ignora a rejeição; um modelo real leria a mensagem de rejeição e responderia de acordo. O que o experimento verifica é a **mecânica**: a pausa aconteceu antes de executar `enviar_email`, e a rejeição entrou no histórico como mensagem de ferramenta.
