## 15.5 Rastreamento e observabilidade

Quando um agente erra, a pergunta é **o que ele fez**: quais chamadas ao modelo, com qual contexto, quais ferramentas, quanto tempo, quantos *tokens*. Um sistema **observável** responde a isso sem reproduzir o erro. Três tipos de dado se complementam.

- **Logs**: eventos pontuais ("ferramenta X falhou com Y").
- **Métricas**: séries agregadas no tempo (latência p95, custo por hora, taxa de erro).
- **Traços** (*traces*): a **árvore de execução** de **um** pedido, em que cada **span** é uma etapa (nó, chamada de modelo, ferramenta) com início, duração, entradas, saídas e relação de pai e filho.

::: definicao 15.4 · Span e traço
Um **span** é o registro de uma execução delimitada: identificador, **pai**, tipo, nome, instantes de início e fim, e atributos (*tokens* de entrada e saída, erro, versão do componente). Um **traço** é o conjunto de spans de um pedido, que forma uma **árvore** pelo campo "pai". A **latência** de um span é $t_\text{fim}-t_\text{início}$, e a de um pai inclui a dos filhos.
:::

O LangChain e o LangGraph emitem eventos de início e fim para cada cadeia, nó, modelo e ferramenta, por **callbacks**. O programa abaixo escreve um `Rastreador` (um `BaseCallbackHandler`) que monta os spans, e o aplica a dois sistemas **reais**: o agente `create_agent` do Capítulo 13 e o grafo do Projeto 10. O modelo é **roteirizado** (nenhuma LLM foi consultada): os *tokens* são **estimados** (caracteres divididos por $4$) e os preços são **ilustrativos**, e não de qualquer provedor. As durações foram **medidas nesta execução** e variam de uma execução a outra.

<<< codigo/c15_rastreamento.py

>>> codigo/c15_rastreamento.out

### O que a árvore mostra (parte A)

A árvore tem o nó `model` (que contém a chamada ao modelo) e o nó `tools` (que contém a ferramenta), alternados, como na Figura 14.1. Dois fatos saltam aos olhos.

- **Onde o tempo vai.** Cada chamada ao modelo leva cerca de $20$ ms (a latência artificial de $20$ ms do roteiro), e cada ferramenta, cerca de $0{,}4$ ms. Num sistema real, o modelo costuma dominar a latência e o custo, e é por isso que as ferramentas são raramente o gargalo.
- **A entrada cresce a cada chamada**: $151$, $171$, $191$ e $213$ *tokens*. O agente **relê o histórico** em cada passo, como a Proposição 13.1 prevê. O total de entrada ($726$) é a soma dessas parcelas, e a **identidade de contabilidade** da última linha ($726=726$) confere: o custo total de uma tarefa é a soma dos custos dos spans de modelo.

::: definicao 15.5 · Custo de uma tarefa
Se a tarefa faz chamadas $j=1,\dots,n$ ao modelo, com $t^\text{ent}_j$ *tokens* de entrada e $t^\text{sai}_j$ de saída, e os preços por *token* são $\pi_\text{ent}$ e $\pi_\text{sai}$, o custo é $\displaystyle C=\pi_\text{ent}\sum_jt^\text{ent}_j+\pi_\text{sai}\sum_jt^\text{sai}_j$. Com $\pi_\text{ent}=3$ e $\pi_\text{sai}=15$ dólares por milhão (valores **ilustrativos**), a tarefa da parte A custa $726\cdot3\times10^{-6}+48\cdot15\times10^{-6}=0{,}002898$ dólares. A $100\,000$ tarefas por dia, são $289{,}80$ dólares por dia: **o custo por tarefa, multiplicado pela escala**, é o que decide a viabilidade.
:::

### O rastro confere com a execução? (parte B)

Um rastreamento só vale se for **fiel ao que aconteceu**. A parte B compara, para cada nó do grafo do Projeto 10, o número de spans do rastro com o número de execuções contado **pelo próprio programa** (`Mundo.execucoes`): $7$ do supervisor, $3$ dos pesquisadores, $2$ do aprovador (a pausa reinicia o nó, Capítulo 14), e assim por diante. **Conferem em todos os nós.** Essa checagem é um teste de **consistência da instrumentação**, e vale a pena fazê-la quando se confia no rastro para depurar ou cobrar.

### A latência tem cauda (parte C)

A **média** de latência esconde o que o usuário sente. Se a latência de uma chamada é lognormal (um modelo comum para tempos de serviço, com mediana $1$ s e $\sigma=0{,}6$, parâmetros **ilustrativos**), a média teórica é $e^{\mu+\sigma^2/2}=1{,}197$ s, **maior que a mediana**, e a cauda é pesada: o $p99$ de uma chamada isolada é cerca de $4$ s, quatro vezes a mediana. Os **percentis** (p50, p95, p99) são a forma de reportar latência.

Um agente soma **chamadas sequenciais**, e a soma de variáveis independentes tem cauda **relativa** menor ($p99/p50$ cai de $4{,}03$ para $1{,}42$ com $20$ chamadas), mas **absoluta** maior: o p95 de $20$ chamadas é $30{,}2$ s (Figura 15.3, à direita). Duas ressalvas. Primeiro, a redução da cauda relativa supõe **independência**; numa degradação do provedor, as chamadas ficam **todas** lentas ao mesmo tempo, e a cauda não encolhe. Segundo, em **fan-out paralelo** a latência é o **máximo** dos ramos, e a cauda **cresce** com o número de ramos.

::: proposicao 15.3 · A cauda em escala
Se cada um de $n$ ramos paralelos independentes é "lento" com probabilidade $q$, a probabilidade de **ao menos um** ser lento (e portanto de o pedido ser lento) é $1-(1-q)^n$.
:::

::: demonstracao
O pedido só é rápido se todos os $n$ ramos forem rápidos, o que tem probabilidade $(1-q)^n$.
:::

Com $q=0{,}01$ (um ramo é lento em $1\%$ das vezes), $n=10$ dá $9{,}6\%$ e $n=100$ dá $63{,}4\%$ (programa `c15_ex_numeros.py`): **um evento raro por ramo vira o caso típico quando há muitos ramos** (Dean e Barroso, 2013, citado de memória). É o argumento para limites de tempo por ramo, para chamadas redundantes e para limitar o *fan-out*.

### Orçamento como disjuntor (parte D)

O rastreador pode também **agir**. Com um orçamento de $400$ *tokens*, a execução da parte D foi **interrompida** na terceira chamada ao modelo ($549>400$), por uma exceção levantada no *callback*. O orçamento (de *tokens*, de passos, de tempo ou de custo) é uma contenção barata e eficaz contra o laço desgovernado do Capítulo 13. Duas observações. A exceção do *callback* **interrompe** a execução, e a mensagem de erro aparece no registro; e o orçamento precisa ser **por pedido** (e por usuário, por dia), porque um só agente em laço pode gastar mais que o resto do sistema.

::: nota O LangSmith
O LangSmith é a plataforma de rastreamento e avaliação do ecossistema LangChain: com variáveis de ambiente (`LANGSMITH_TRACING`, a chave de API e o nome do projeto), as execuções do LangChain e do LangGraph são enviadas e exibidas como árvores de spans, com latência, *tokens* e custo, e permitem montar conjuntos de avaliação a partir de traços reais. **O envio ao LangSmith não foi executado** neste livro (não há credencial nem rede no ambiente): o `Rastreador` acima faz **localmente** o que o serviço faz como coletor, e usa a mesma interface de *callbacks*. Os nomes das variáveis são citados de memória e devem ser conferidos na documentação.
:::

::: atencao O que se grava num traço é dado do usuário
Entradas e saídas completas dos modelos contêm dados pessoais, segredos e conteúdo de terceiros. Gravar tudo é útil para depurar e **arriscado** para a privacidade (a LGPD, Lei 13.709/2018, trata dados pessoais). Defina **o que** se registra, por **quanto tempo**, **quem** acessa, e **redija** dados pessoais antes de gravar (seção 15.7).
:::

## 15.6 Resiliência: o que fazer quando algo falha

Num sistema com LLM, as falhas vêm de várias fontes: a **rede** (tempo esgotado, conexão recusada), o **provedor** (limite de taxa, indisponibilidade), as **ferramentas** (erro de execução), e a **saída do modelo** (formato inválido, Capítulo 11). Nem todas se tratam igual.

| Tipo | Exemplo | Tratamento |
|---|---|---|
| Transitória | rede instável, limite de taxa | **repetir** com espera |
| Persistente | serviço fora do ar | **disjuntor** e **plano alternativo** |
| Erro de programação | argumento do tipo errado | **não** repetir: corrigir |
| Saída inválida | JSON malformado | **revalidar** e repetir com a mensagem de erro (Capítulo 13) |

### Repetir: quanto ajuda e quanto custa

::: proposicao 15.4 · Repetições independentes
Cada tentativa falha com probabilidade $f$, de forma independente, e há no máximo $m$ tentativas. A probabilidade de sucesso é $1-f^m$, e o número esperado de chamadas é $\dfrac{1-f^m}{1-f}$.
:::

::: demonstracao
Só falha tudo se as $m$ tentativas falham: $f^m$. A tentativa $i+1$ só ocorre se as $i$ anteriores falharam, o que tem probabilidade $f^i$, logo o número esperado de chamadas é $\sum_{i=0}^{m-1}f^i=(1-f^m)/(1-f)$. É a Proposição 13.3 com avaliador perfeito.
:::

A parte A do programa verifica isso com o `with_retry` do LangChain, em $20\,000$ chamadas por linha: com $f=0{,}5$ e $m=3$, o sucesso medido foi $0{,}8746$ (previsto $0{,}875$) com $1{,}752$ chamadas por pedido (previsto $1{,}750$). O `with_fallbacks` troca a resposta de uma chamada que sempre falha por uma **resposta degradada** (aqui, uma frase fixa), o que mantém o serviço de pé, com qualidade menor.

**A hipótese de independência é a fraca.** Se o serviço **caiu**, as tentativas não são independentes: todas falham, e repetir só aumenta a carga. Daí as quatro práticas seguintes.

<<< codigo/c15_resiliencia.py

>>> codigo/c15_resiliencia.out

1. **Repetir só o que é transitório** (parte B). O `RetryPolicy` do LangGraph, em um nó, repete até `max_attempts` vezes e, na versão usada, **não** repete erros de programação (um `ValueError` rodou uma única vez). Com `max_attempts=3`, o nó que falha duas vezes termina na terceira; com `max_attempts=2`, o erro se propaga.
2. ***Backoff* com *jitter*** (parte C). Muitos clientes que falham juntos e repetem **juntos** voltam em ondas sincronizadas e derrubam o servidor de novo (a **tempestade de tentativas**). Na simulação ($2000$ clientes, capacidade $100$ requisições por tick, queda de $20$ ticks), a repetição **imediata** enviou $61\,000$ requisições, e a **fixa** e a **exponencial sem jitter** tiveram **pico de $2000$ requisições em um só tick**, porque os clientes ficam sincronizados. A exponencial **com *jitter*** (espera aleatória dentro da janela) enviou $11\,840$ requisições com **pico de $190$**, e $95\%$ dos clientes terminaram no tick $63$ (contra $200$ e $574$ para a fixa e a exponencial sem *jitter*; a imediata termina no tick $38$, mas ao custo de $61\,000$ requisições, que num servidor real o derrubariam de novo, e o simulador apenas descarta o excesso). O *jitter* espalha a carga: se $N$ clientes escolhem o instante da repetição uniformemente em uma janela de $W$ ticks, a carga esperada é $N/W$ por tick, e $W\ge N/C$ mantém a carga abaixo da capacidade $C$ (aqui, $W\ge20$ ticks). Essa é a recomendação clássica de Brooker (2015, citada de memória).
3. **Disjuntor** (parte D). Depois de $3$ falhas seguidas, o disjuntor **abre**: as chamadas seguintes **falham rápido**, sem chamar o serviço, e depois de uma espera ele fica **semiaberto**, deixa passar **uma** tentativa de teste e **fecha** se ela der certo. No roteiro, dos $9$ pedidos, só $6$ chegaram ao serviço; os $3$ pedidos feitos com o disjuntor aberto **poupam** o serviço doente (e o usuário de esperar um tempo limite). É o padrão de Nygard (*Release It!*, citado de memória).
4. **Limites de tempo e orçamento** em **cada** chamada e em cada pedido (seção 15.5), e **degradação graciosa**: quando o modelo principal falha, usar um menor, uma resposta em cache, ou "não consegui, um humano vai atender".

<figure>
+++ fig_c15_operacao.svg
<figcaption><b>Figura 15.3.</b> Operação. À esquerda, o pico de carga que chega ao servidor logo após a volta, para quatro estratégias de repetição (capacidade de $100$ requisições por tick): sem <i>jitter</i>, os clientes ressincronizam e o pico é de $2000$. À direita, os percentis de latência de um agente contra o número de chamadas sequenciais (simulação, latência lognormal por chamada): a mediana, o p95 e o p99 crescem juntos com o número de chamadas.</figcaption>
</figure>

Em um grafo com efeitos externos, repetir **exige idempotência** (Capítulo 14): a tentativa repetida não pode duplicar a cobrança ou o e-mail.

::: atencao Uma tentativa a mais pode ser um custo a mais
Cada repetição de uma chamada de LLM **cobra de novo** os *tokens* de entrada (a Proposição 13.1 e a Definição 15.5). Repetir sem limite uma chamada que falha por **conteúdo** (por exemplo, um *prompt* que o provedor recusa) gasta e não resolve. O limite de tentativas e a classificação do erro (seção acima) são parte do orçamento.
:::

## 15.7 Guardrails: contenção em camadas

Um **guardrail** é um controle que **limita** o que o sistema aceita, faz ou devolve. Nenhum é suficiente sozinho, e a engenharia consiste em **empilhá-los** de modo que a falha de um seja contida pelo seguinte. O programa abaixo mede três camadas, com dados **sintéticos** gerados por programa (nenhum dado pessoal real).

<<< codigo/c15_guardrails.py

>>> codigo/c15_guardrails.out

**Camada 1: dados pessoais.** Redigir (mascarar) CPFs, e-mails e telefones **antes** de enviar ao modelo ou gravar no traço. A expressão regular de $11$ dígitos mascara **todo** número de $11$ dígitos: os $300$ números comuns (pedidos, protocolos) foram mascarados por engano. Acrescentar a verificação do **dígito verificador** do CPF (um algoritmo determinístico) reduziu os falsos mascaramentos a $4$ em $300$ (cerca de $1\%$, porque a chance de um número aleatório passar nos dois dígitos é de aproximadamente $1/100$, que a simulação confirmou: $0{,}0100$), **sem perder nenhum** dos $237$ CPFs reais. **A verificação estrutural vale mais que a expressão regular.**

**Camada 2: um detector de instruções suspeitas.** Um detector por palavras-chave pegou **$12$ de $12$** instruções diretas e **$0$ de $12$** reescritas com outras palavras, e marcou por engano $2$ de $24$ pedidos benignos ("Responda apenas com sim ou não..."). **A detecção por padrões é fácil de contornar** e erra para os dois lados: reescrever o ataque derrota o detector, e um pedido legítimo parecido com um ataque é bloqueado. Mesmo um detector **bom** sofre do problema da **taxa-base** (Capítulo 1, teorema de Bayes): com $\text{TPR}=0{,}9$ e $\text{FPR}=0{,}05$, o valor preditivo positivo é $0{,}947$ se metade dos pedidos for ataque, mas **$0{,}154$ se $1\%$ forem**, e $0{,}018$ se $0{,}1\%$ forem: quando o ataque é raro, **a maioria dos alertas é falso**. Detectores servem para **monitorar e priorizar revisão**, e não para sustentar a segurança.

**Camada 3: uma política imposta pelo código.** A proteção que **funciona mesmo quando o modelo é enganado** não olha o texto: limita o que a ação pode **ser**. Aqui, uma **lista de permissões** de ferramentas, de argumentos e de destinatários, mais aprovação humana para a ferramenta irreversível (Capítulos 13 e 14). Das $800$ chamadas de um modelo "sequestrado" (simuladas), **as $800$ foram bloqueadas**: $300$ por destinatário fora dos domínios permitidos, $300$ por ferramenta fora da lista, $100$ por exigirem aprovação, $100$ por argumento não permitido; as chamadas legítimas passaram. O resultado vem da **estrutura** (menor privilégio), e não de reconhecer o ataque: é por isso que a segurança de um agente se projeta **na arquitetura**, e não no *prompt*.

::: aplicacao Uma ordem de prioridade para as contenções
(1) **Menor privilégio**: o agente só tem as ferramentas e permissões de que precisa. (2) **Aprovação humana** para o irreversível. (3) **Validação estrutural** de entradas e saídas (esquemas, dígitos verificadores, listas de permissões). (4) **Orçamentos e limites** (passos, tempo, custo). (5) **Detectores heurísticos e juízes por LLM**, como camada de monitoramento, e não como a única defesa. Uma lista conhecida de riscos para aplicações com LLM é a do projeto OWASP (*Top 10 for LLM Applications*, citada de memória), útil como roteiro de revisão.
:::

## 15.8 Governança: o que se espera de um sistema em produção

**Governança** é o conjunto de práticas que torna um sistema de IA **auditável, atualizável e responsável**. Não é código novo: é **disciplina** sobre o que já foi construído. Os elementos a seguir são o mínimo defensável, e cada um aponta para uma medida deste capítulo.

| Elemento | O que garante | Onde apareceu |
|---|---|---|
| **Versionamento** de modelo, *prompt*, índice, ferramentas e conjunto de avaliação | reproduzir e comparar execuções | seção 15.1 |
| **Portão de avaliação** antes de publicar uma mudança | nenhuma regressão acima da tolerância declarada | seções 15.2 a 15.4 |
| **Rastreamento** com política de retenção e acesso | depurar, cobrar, auditar | seção 15.5 |
| **Resiliência** e orçamentos | falhas contidas e custo previsível | seção 15.6 |
| **Guardrails** em camadas e **aprovação humana** de ações críticas | contenção do dano | seção 15.7 e Capítulo 14 |
| **Documentação** (limites, dados, uso pretendido) | uso adequado e transparência | abaixo |
| **Resposta a incidentes** (detectar, conter, corrigir, aprender) | tempo de reparo e memória institucional | abaixo |

**Portão de avaliação.** Uma regra útil é **promover** uma versão nova apenas se o **limite inferior do IC pareado** da diferença nas métricas principais for maior que $-\delta$, com $\delta$ uma **tolerância de regressão declarada antes** (por exemplo, $2$ pontos percentuais), e se as métricas de **segurança** (por exemplo, $\text{pass}^k$ em tarefas críticas) não caírem. A seção 15.2 mostrou por que o IC pareado, e não a comparação das médias, decide.

**Documentação.** Documentos curtos e públicos sobre o sistema (para que serve, para que **não** serve, em que dados foi avaliado, quais as limitações conhecidas) seguem a ideia dos *model cards* (Mitchell et al., 2019) e dos *datasheets* para conjuntos de dados (Gebru et al., 2021), ambos citados de memória. Para este livro, é o papel das seções "Limitações" dos projetos.

**Marcos regulatórios e de risco.** Dependendo do uso e da jurisdição, há obrigações legais e referenciais de gestão de risco: a LGPD (Lei 13.709/2018) para dados pessoais no Brasil, o regulamento europeu de IA (Regulamento (UE) 2024/1689) e o *AI Risk Management Framework* do NIST (2023). São citados **de memória e apenas como ponteiros**: o conteúdo e a aplicabilidade **devem ser conferidos nas fontes oficiais e, quando for o caso, com orientação jurídica**. Este livro não oferece aconselhamento jurídico.

::: atencao Governança sem medida é cerimônia
Um documento que diz "o sistema é avaliado" sem **números, versão e conjunto** é decoração. As práticas acima valem quando cada afirmação tem uma **medida reproduzível** por trás, como as deste capítulo, e quando as **limitações** são ditas com a mesma clareza que as qualidades.
:::
