## 14.6 Projeto 10: uma equipe de agentes com revisão, aprovação humana e retomada

::: projeto Equipe que produz um relatório sobre o livro e só publica com aprovação
O projeto monta, no **LangGraph real**, uma equipe de seis papéis: um **supervisor**, **pesquisadores** em paralelo, um **calculador**, um **redator**, um **revisor** e um **publicador**, com um **portão humano** antes da publicação e um **checkpointer** sob tudo. As ferramentas são as **reais** do Projeto 9 (contagem de seções do livro e calculadora segura). Os agentes **decidem por regras e por sorteios controlados**: o redator erra em silêncio com probabilidade $p$, e o revisor percebe o erro com probabilidade $q$. **Nenhum LLM foi consultado.** O que o projeto mede é a **arquitetura**: ciclo de revisão, pausa para pessoa, retomada após falha, idempotência.
:::

### Objetivo

Verificar, por teste e por experimento, quatro afirmações do capítulo: (1) o ciclo revisor $\to$ redator segue a Proposição 13.3 do capítulo anterior; (2) o portão humano segue a Proposição 14.3; (3) o custo de uma falha na publicação segue a Proposição 14.2, e a idempotência evita publicações duplicadas; (4) a pausa para aprovação acontece **antes** de qualquer efeito externo e sobrevive à troca da instância do grafo.

### Problema

Um **pedido** é uma lista de capítulos do livro (de $2$ a $6$ capítulos entre $1$ e $11$). A equipe deve produzir um relatório do tipo

> Relatório de seções: cap 3 = 8; cap 5 = 8; cap 8 = 6. Total = 22. Média = 7,33.

com os números **corretos** (as ferramentas reais definem a verdade), e **publicá-lo** num mural (o efeito externo irreversível) somente depois da aprovação de uma pessoa. Falhas na publicação (a rede cai **depois** de publicar) devem ser toleradas sem duplicar a mensagem e sem refazer o trabalho já feito.

### Requisitos

1. Os pesquisadores consultam um capítulo cada, **em paralelo**, e o estado reúne as contagens por um **redutor** (sem conflito).
2. O redator pode errar **em silêncio**. O revisor **confere** o texto contra os fatos do estado e devolve ao redator, até $R$ vezes.
3. Antes de publicar, o grafo **pausa** e entrega o relatório a uma pessoa, que pode **aprovar**, **rejeitar** ou **editar**.
4. A publicação é **idempotente** (chave derivada do texto) e pode falhar de forma transitória; a execução é **retomada** do último checkpoint.
5. Há um **limite de recursão**, e cada pedido tem sua **thread**.
6. Todo o comportamento acima é **testado** com probabilidades fixadas em $0$ ou $1$, para que os testes sejam determinísticos.

### Arquitetura

O **supervisor** é o centro (Figura 14.2): depois de cada especialista, o controle **volta** a ele, que olha o estado e escolhe o próximo nó. A regra é a de um fluxo de trabalho com um ciclo: faltam contagens? Despacha os pesquisadores (com `Send`, um por capítulo). Falta o total? Calculador. Não há relatório, ou o revisor pediu refação e ainda restam tentativas? Redator. Falta o veredito? Revisor. Falta a aprovação? Aprovador (a pausa). Aprovado? Publicador. Publicado ou rejeitado? `END`. Quando as tentativas se esgotam com o relatório ainda reprovado, o relatório segue **assim mesmo** para a pessoa, **com o veredito e o aviso** no pedido de aprovação.

<figure>
+++ fig_c14_projeto10.svg
<figcaption><b>Figura 14.2.</b> Arquitetura do Projeto 10. Todo trabalhador devolve o controle ao supervisor; o ciclo revisor–redator corrige erros de transcrição; o aprovador pausa a execução para uma pessoa; o publicador faz o único efeito irreversível, protegido por chave de idempotência; o checkpointer grava o estado após cada passo.</figcaption>
</figure>

O estado tem as chaves `caps`, `contagens` (com o redutor de dicionários `mescla_dicts`, escrito em paralelo), `total`, `media`, `relatorio`, `revisoes`, `veredito`, `feedback`, `aprovacao`, `publicado` e `trilha` (lista de quem agiu, com redutor de concatenação). O mundo externo (ferramentas, mural, chaves de idempotência, sorteios) fica **fora** do estado, num objeto `Mundo`: o estado do grafo só guarda o que precisa ser salvo e retomado.

### Fundamentos teóricos

**O ciclo de revisão é o Reflexion do Capítulo 13.** Uma tentativa do redator acerta com probabilidade $s=1-p$. Se errou, o revisor **percebe** com probabilidade $q$ e devolve o rascunho; senão, o erro passa. Com $K=R+1$ rascunhos no máximo, a probabilidade de o relatório ser **correto** é, pela Proposição 13.3 com $u=pq$,
$$P_\text{correto}=(1-p)\,\frac{1-(pq)^{K}}{1-pq},\qquad \mathbb{E}[\text{rascunhos}]=\frac{1-(pq)^{K}}{1-pq}.$$
(Se o último rascunho ainda for reprovado, o relatório segue adiante para a pessoa; sem portão humano, seria publicado errado, e a fórmula já o conta como **não correto**.) O número de revisões ajuda **menos** que a qualidade do revisor: com $q=0{,}4$, mesmo com $R$ grande, $P_\text{correto}\to(1-p)/(1-pq)=0{,}795$.

**O portão humano segue a Proposição 14.3**, com $e=1-P_\text{correto}$.

**A retomada segue a Proposição 14.2**, e a **idempotência** protege o único efeito irreversível.

### Implementação

O arquivo `p10_equipe.py` contém o estado, o redutor, o `Mundo` e a função `construir`, que monta o grafo com o **LangGraph real**; a função `executa` conduz a execução, atendendo a pausa com a política humana e retomando após `ConnectionError`.

<<< codigo/p10_equipe.py

### Testes e resultados

Os testes (`p10_testes.py`) fixam as probabilidades em valores extremos, para que cada verificação seja determinística.

<<< codigo/p10_testes.py

>>> codigo/p10_testes.out

As $19$ verificações passam. Merecem destaque: o redutor mescla cinco capítulos paralelos em cinco chaves; o revisor perfeito reaciona o redator e o segundo rascunho passa; o humano que **edita** faz o texto editado chegar ao mural; antes da resposta humana o grafo está **pausado** no aprovador e o mural está **vazio**; e, depois de uma falha na publicação, a retomada **não repete** a pesquisa, o cálculo, a redação, a revisão nem a aprovação, e a mensagem aparece **uma** vez.

**Experimento 1: revisão e portão humano.** Com $N=400$ pedidos por linha e $p=0{,}3$:

<<< codigo/p10_exp1_revisao_humano.py

>>> codigo/p10_exp1_revisao_humano.out

Na parte A, os relatórios corretos seguem a fórmula dentro do ruído de amostragem (o desvio-padrão de uma fração perto de $0{,}8$ com $N=400$ é de cerca de $0{,}02$). Com **revisor perfeito** ($q=1$), $R=3$ refações levam a $0{,}988$; com **revisor que erra** ($q=0{,}4$), o acerto **satura** perto de $0{,}80$ **qualquer que seja $R$**: mais tentativas não compensam um verificador fraco. Na parte B, com $q=0{,}7$ e $R=1$, o portão humano troca erros publicados por relatórios não publicados, como na Proposição 14.3: a taxa de erros publicados cai de $0{,}165$ para $0{,}080$ ($d=0{,}5$), $0{,}007$ ($d=0{,}9$) e $0{,}000$ ($d=1$), e a fração sem publicação sobe de $0$ a $0{,}165$. A fração de corretos **não muda** ($0{,}835$), porque as linhas da parte B usam a **mesma** semente, e só a decisão humana muda.

**Experimento 2: falhas na publicação.**

<<< codigo/p10_exp2_falhas.py

>>> codigo/p10_exp2_falhas.out

Duas conclusões. **O checkpoint**: sem ele, as chamadas de ferramenta por pedido sobem de $5{,}94$ para $8{,}69$ ($f=0{,}3$) e $14{,}90$ ($f=0{,}6$), como prevê $5{,}94/(1-f)$ (Proposição 14.2); com ele, ficam em $5{,}94$ nos três casos, e só o publicador repete. **A idempotência**: com a falha **depois** do efeito, o nó sem chave (com checkpoint) deixa $0{,}48$ ($f=0{,}3$) e $1{,}55$ ($f=0{,}6$) mensagens **duplicadas** por pedido, em média; com a chave, $0{,}00$ em todos os casos, **com ou sem** checkpoint. O checkpoint economiza **trabalho**; só a idempotência evita **duplicação**. As duas coisas são ortogonais, e uma não substitui a outra.

<figure>
+++ fig_c14_resultados.svg
<figcaption><b>Figura 14.3.</b> À esquerda, relatórios corretos contra o número de refações $R$, para revisores com $q=1$, $0{,}7$ e $0{,}4$ (círculos: medido; linhas: fórmula da Proposição 13.3). O acerto satura em um teto que depende de $q$. À direita, chamadas de ferramenta por pedido contra a probabilidade de falha $f$: sem checkpoint (recomeço) o custo segue $5{,}94/(1-f)$; com checkpoint (retomada), é constante.</figcaption>
</figure>

### Limitações

- Os **agentes são regras e sorteios**, e não modelos de linguagem. As taxas $p$, $q$ e $d$ são **parâmetros**, e não medidas de um sistema real; os resultados confirmam a **estrutura** (as fórmulas), e não a qualidade de um agente de LLM.
- O revisor **recomputa** os números a partir dos fatos do estado. Um revisor real (um LLM) conferiria um texto livre, e a taxa $q$ dependeria do que ele checa; revisores de LLM também erram e podem **concordar com um erro** do redator.
- O **humano é uma função**: $d$ não envolve cansaço, pressa nem a tendência a aprovar o que parece bom.
- O checkpointer é o `InMemorySaver`. **Não** foram executados os checkpointers duráveis (SQLite, Postgres), e a retomada por **outra instância** foi testada no mesmo processo (com o mesmo armazenamento em memória).
- A falha injetada é uma exceção em **um** nó. Falhas de processo (o programa morre no meio de um passo) não foram simuladas.
- O mural e as chaves de idempotência vivem **na memória**. Num sistema real, a chave precisaria estar num armazenamento compartilhado e durável, e a janela de duplicação entre "publicar" e "gravar a chave" precisaria ser tratada.

### Melhorias possíveis

1. Trocar o supervisor e os especialistas por **LLMs reais** com saída estruturada (Capítulo 11) e medir $p$, $q$ e $d$ em um conjunto com gabarito.
2. Usar um checkpointer **durável** (SQLite ou Postgres) e testar a retomada com **reinício real** do processo.
3. Dar ao revisor um **segundo canal de verdade**: recalcular a partir das ferramentas, e não do estado que o redator também leu.
4. Medir, com as métricas do Capítulo 15, a **fidelidade** dos relatórios (cada número do texto tem suporte nas observações?), em vez de só conferir a igualdade.
5. Acrescentar **tempo limite** e **orçamento** por pedido (chamadas de ferramenta e *tokens*) e uma política de escalonamento para a pessoa quando o orçamento se esgota.
