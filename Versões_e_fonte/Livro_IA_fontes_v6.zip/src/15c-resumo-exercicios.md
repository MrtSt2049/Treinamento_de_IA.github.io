## 15.9 Resumo do capítulo

::: resumo Capítulo 15
- **Avalie por camadas**: recuperação, geração, agente e sistema. A camada que falha localiza o defeito. Offline (conjunto com gabarito, regressão) e online (monitoramento) se complementam.
- **Métricas de recuperação** (Definição 15.1): precisão@$k$ (limitada por $|G|/k$, Proposição 15.1), revocação@$k$, acerto@$k$, MRR, MAP, nDCG. Escolha pela pergunta que o sistema faz com os resultados.
- **Incerteza**: reporte **IC por *bootstrap***, **fatias** (diretas e parafraseadas diferem muito) e **comparações pareadas** (Proposição 15.2). Para $\pm\varepsilon$ em uma proporção, $n\ge1{,}96^2p(1-p)/\varepsilon^2$.
- **Triângulo do RAG**: relevância do contexto, **fidelidade** (suporte no contexto, Definição 15.2) e relevância da resposta. Fidelidade **não** é correção factual.
- **Todo proxy se valida**: o verificador lexical detectou $97\%$ das afirmações externas, $75\%$ dos números alterados e $0\%$ das negações. Reporte a detecção **por tipo de erro**; $\kappa$ de Cohen para concordância além do acaso. Juízes por LLM têm vieses e **não foram executados** aqui.
- **Agentes**: resultado, trajetória e consistência. $\text{pass@}k=1-(1-s)^k$ mede capacidade; $\text{pass}^k=s^k$, confiabilidade.
- **Rastreamento**: spans em árvore (latência, *tokens*, custo), conferidos contra a execução; o custo é a soma por chamada; a entrada cresce a cada passo. **Latência é cauda** (percentis, não média); a cauda cresce com o *fan-out* ($1-(1-q)^n$, Proposição 15.3). Orçamentos interrompem laços.
- **Resiliência**: repetições independentes ($1-f^m$; $(1-f^m)/(1-f)$ chamadas, Proposição 15.4), ***backoff* com *jitter*** (evita a tempestade), **disjuntor** (falha rápida), degradação graciosa, idempotência.
- **Guardrails em camadas**: a validação estrutural (dígito verificador) supera a regex; detectores heurísticos são fáceis de contornar e sofrem com a taxa-base; a **política imposta por código** (menor privilégio, listas de permissões, aprovação humana) bloqueou $800$ de $800$ chamadas sequestradas.
- **Governança**: versionamento, portão de avaliação com IC pareado, rastreamento com retenção, documentação, resposta a incidentes. Medida reproduzível por trás de cada afirmação; ponteiros regulatórios **de memória**.
- **Limites deste capítulo**: sem LLM-juiz, sem LangSmith, preços e tokens ilustrativos, dados sintéticos, simulações rotuladas como tais.
:::

**Ponte para o fechamento.** Os quinze capítulos percorreram a trilha da matemática ao agente em produção. As próximas páginas **fecham** o curso: a conclusão, as trilhas de aprofundamento, o glossário, o índice de símbolos, a bibliografia consolidada, o índice remissivo e a **revisão editorial consolidada**, que lista com franqueza o que foi executado e o que não foi.

## 15.10 Exercícios

### Nível I: consolidação

**15.1** Um recuperador devolve o ranking com relevância $(0,1,0,1,0,0)$ para uma pergunta com $|G|=3$ (um relevante **não** foi recuperado). Calcule precisão@$k$ e revocação@$k$ para $k=1,3,5$, o rank recíproco, a precisão média e o nDCG@6.

**15.2** Dois avaliadores (uma pessoa e um LLM-juiz) classificam $100$ respostas como fiéis ou não. A tabela é: ambos "fiel", $40$; pessoa "fiel" e juiz "infiel", $10$; pessoa "infiel" e juiz "fiel", $5$; ambos "infiel", $45$. Calcule $p_o$, $p_e$ e $\kappa$.

**15.3** Quantas perguntas são necessárias para estimar uma proporção com meia-largura $\pm0{,}05$ de IC de $95\%$, se $p\approx0{,}8$? E se não se sabe nada sobre $p$ (pior caso)? Repita para $\pm0{,}03$.

**15.4** Um agente tem taxa de sucesso $s=0{,}8$ por execução. Calcule $\text{pass@}k$ e $\text{pass}^k$ para $k=1,3,5,10$. Qual métrica um sistema de atendimento ao cliente deve usar?

**15.5** Uma chamada falha com probabilidade $f=0{,}3$ e há no máximo $m=4$ tentativas, independentes. Calcule a probabilidade de sucesso e o número esperado de chamadas.

### Nível II: aprofundamento

**15.6** Um sistema faz uma requisição a $n$ ramos paralelos, cada um lento com probabilidade $q$. Calcule a probabilidade de o pedido ser lento para $(q,n)=(0{,}01;10)$, $(0{,}01;100)$ e $(0{,}001;100)$. Que $q$ é necessário para que, com $n=100$, a probabilidade fique abaixo de $5\%$?

**15.7** Um detector de ataques tem $\text{TPR}=0{,}9$ e $\text{FPR}=0{,}02$, e a prevalência de ataques é de $2\%$. Calcule o valor preditivo positivo. Se o detector **bloqueia** o que marca, que fração dos pedidos **legítimos** é bloqueada? E dos ataques que passam?

**15.8** A tarefa de um agente teve entradas por chamada de $151$, $171$, $191$ e $213$ *tokens* e saídas totais de $48$. Com os preços ilustrativos da Definição 15.5, calcule o custo da tarefa e o custo diário a $100\,000$ tarefas. Se um mecanismo de cache de prefixo cobrasse $10\%$ do preço pelos *tokens* repetidos (que aqui são, em cada chamada, os $151$ iniciais), qual seria o custo?

**15.9** Mostre, a partir do crescimento linear da entrada por chamada ($P_0+jm$, com $m$ constante), que a entrada **total** de $n$ chamadas é quadrática em $n$, e use os dados do exercício 15.8 para estimar $m$ e $P_0$. Compare com a Proposição 13.1.

**15.10** No disjuntor da seção 15.6 (limite $3$, espera $30$ s), os pedidos chegam em $t=0,1,2,3,10,31,40$ s, e o serviço volta no instante $40$. Quais pedidos chegam ao serviço? Se o pedido em $t=31$ ocorresse em $t=33$, o que mudaria?

### Nível III: desafio

**15.11** No Capítulo 15, o MRR do BM25 e do LSA tem IC pareado $[-0{,}009;\,+0{,}113]$. Proponha um **protocolo** para decidir se o BM25 é melhor: que dados adicionais, que métrica declarada antes, que tamanho de amostra para detectar uma diferença de $0{,}05$ com o desvio-padrão da diferença por pergunta observado (aproximadamente $0{,}26$), e que **análise por fatias** faria.

**15.12** Projete um verificador de fidelidade que **detecte negações**, sem LLM generativo: que representação, que sinal compara, como o testaria (que casos construídos) e que limites esperaria. Em seguida, descreva como calibraria um **LLM-juiz** contra o seu verificador e contra pessoas.

**15.13** Em uma queda, $N=2000$ clientes repetem com *jitter* uniforme em uma janela de $W$ ticks, e o servidor aguenta $C=100$ requisições por tick. (a) Qual o menor $W$ para que a carga **esperada** não ultrapasse $C$? (b) Por que a carga **real** em um tick pode ultrapassar $N/W$? Estime o desvio-padrão da carga em um tick. (c) Como o *backoff* exponencial interage com isso quando os clientes falham várias vezes?

**15.14** Defina o **portão de avaliação** de uma mudança de *prompt* em um sistema de RAG com agente: métricas (por camada), tolerâncias, tamanho de amostra, o que fazer com métricas **que pioram e outras que melhoram**, e o que registrar para auditoria. Aponte **três** formas de o portão ser enganado (por exemplo, vazamento do conjunto) e a contenção de cada uma.

## 15.11 Soluções comentadas

::: solucao 15.1
Programa `c15_ex_numeros.py`. $\mathrm{P@}1=0$, $\mathrm{R@}1=0$; $\mathrm{P@}3=1/3$, $\mathrm{R@}3=1/3$; $\mathrm{P@}5=2/5=0{,}4$, $\mathrm{R@}5=2/3=0{,}667$. $\mathrm{RR}=1/2$. $\mathrm{AP}=\tfrac13\bigl(\tfrac12+\tfrac24\bigr)=0{,}333$ (o relevante não recuperado conta como zero no denominador $|G|=3$). $\mathrm{DCG}=\tfrac1{\log_23}+\tfrac1{\log_25}=0{,}631+0{,}431=1{,}062$; $\mathrm{IDCG}=1+\tfrac1{\log_23}+\tfrac12=2{,}131$; $\mathrm{nDCG@}6=0{,}498$.
:::

::: solucao 15.2
$p_o=(40+45)/100=0{,}85$. As marginais: pessoa "fiel" $=50$, juiz "fiel" $=45$; $p_e=0{,}50\cdot0{,}45+0{,}50\cdot0{,}55=0{,}225+0{,}275=0{,}500$. $\kappa=(0{,}85-0{,}50)/(1-0{,}50)=0{,}70$, **concordância substancial**. Note que a acurácia bruta ($85\%$) parece melhor que o $\kappa$, porque metade da concordância seria esperada por acaso.
:::

::: solucao 15.3
$n=\lceil1{,}96^2p(1-p)/\varepsilon^2\rceil$. Para $p=0{,}8$: $246$ ($\pm0{,}05$) e $683$ ($\pm0{,}03$). No pior caso, $p=0{,}5$: $385$ e $1068$. Sem informação sobre $p$, o pior caso protege; em geral, quanto mais perto de $0{,}5$ a proporção, mais perguntas são necessárias.
:::

::: solucao 15.4
$k=1$: $0{,}80$ e $0{,}80$. $k=3$: $\text{pass@}3=0{,}992$, $\text{pass}^3=0{,}512$. $k=5$: $0{,}99968$ e $0{,}328$. $k=10$: $1{,}000$ e $0{,}107$. Atendimento ao cliente exige **confiabilidade**: o cliente quer que **todas** as execuções deem certo, e não que **alguma** dê. A métrica é $\text{pass}^k$. Já em tarefas verificáveis, com tentativas baratas (geração de código com testes), $\text{pass@}k$ descreve a capacidade.
:::

::: solucao 15.5
Programa `c15_ex_numeros.py`. Sucesso: $1-0{,}3^4=1-0{,}0081=0{,}9919$. Chamadas esperadas: $0{,}9919/0{,}7=1{,}417$. Quase todo o ganho vem das primeiras repetições: $m=2$ dá $0{,}91$, e $m=3$ dá $0{,}973$.
:::

::: solucao 15.6
Programa `c15_ex_numeros.py`. $1-0{,}99^{10}=0{,}0956$; $1-0{,}99^{100}=0{,}634$; $1-0{,}999^{100}=0{,}0952$. Para $n=100$ e probabilidade abaixo de $0{,}05$: $(1-q)^{100}>0{,}95\Rightarrow q<1-0{,}95^{1/100}=0{,}000513$, ou seja, cada ramo só pode ser lento em cerca de $0{,}05\%$ das vezes. Daí a prática de **limite de tempo por ramo** com resposta parcial e de **chamadas redundantes** (cobrir os lentos).
:::

::: solucao 15.7
Programa `c15_ex_numeros.py`. $\text{VPP}=\dfrac{0{,}9\cdot0{,}02}{0{,}9\cdot0{,}02+0{,}02\cdot0{,}98}=\dfrac{0{,}018}{0{,}0376}=0{,}479$: **menos da metade dos alertas é ataque**, mesmo com um detector de $\text{FPR}$ de apenas $2\%$. Legítimos bloqueados: $\text{FPR}=2\%$ de $98\%$ dos pedidos, ou seja, $1{,}96\%$ de **todos** os pedidos (e $2\%$ dos legítimos). Ataques que passam: $10\%$ dos ataques ($\text{FNR}=1-\text{TPR}$), ou $0{,}2\%$ de todos os pedidos. Bloquear com base nesse detector traz $\sim10$ vezes mais pedidos legítimos barrados que ataques que passam.
:::

::: solucao 15.8
Custo: $726\cdot3\times10^{-6}+48\cdot15\times10^{-6}=0{,}002178+0{,}00072=0{,}002898$ dólares por tarefa; a $100\,000$ tarefas, $289{,}80$ dólares por dia. Com cache, os $151$ *tokens* iniciais das chamadas $2$ a $4$ (três repetições, total $453$) custam $10\%$: entrada efetiva $=726-453+0{,}1\cdot453=318{,}3$ *tokens*, e o custo é $318{,}3\cdot3\times10^{-6}+0{,}00072=0{,}001675$ dólares, uma redução de $42\%$. Os resultados dependem dos preços (**ilustrativos**) e da política de cache do provedor.
:::

::: solucao 15.9
A chamada $j$ ($j=1,\dots,n$) lê $P_0+(j-1)m$ *tokens* (o histórico acumulado), e o total é $\sum_{j=1}^{n}\bigl(P_0+(j-1)m\bigr)=nP_0+m\,\tfrac{n(n-1)}2$, **quadrático** em $n$ (com coeficiente $m/2$ no termo dominante), como na Proposição 13.1. Dos dados: os incrementos são $20,20,22$, logo $m\approx20$ (a rodada de ferramenta e resposta acrescenta cerca de $20$ *tokens*), e $P_0\approx151$. O total previsto para $n=4$: $4\cdot151+20\cdot6=724$, próximo dos $726$ medidos (a diferença vem do incremento de $22$).
:::

::: solucao 15.10
Pedidos em $t=0,1,2$ **chegam** ao serviço e falham (três falhas seguidas abrem o disjuntor em $t=2$). Em $t=3$, $10$ e $31$ o disjuntor está **aberto** e a espera ($30$ s a partir de $t=2$) ainda não terminou: falha rápida, sem chamar o serviço. Em $t=40$, a espera acabou ($40-2\ge30$): o disjuntor fica **semiaberto**, a tentativa de teste chega ao serviço (que voltou) e dá certo, e o disjuntor **fecha**. Chegam ao serviço, portanto, os pedidos de $t=0,1,2$ e $40$. Se o pedido de $t=31$ ocorresse em $t=33$, como $33-2=31\ge30$, o disjuntor ficaria **semiaberto** nesse instante e a tentativa de teste chegaria ao serviço, que **ainda estava fora do ar**: falharia e **reabriria** o disjuntor por mais $30$ s (de $t=33$ a $t=63$). O pedido de $t=40$ seria então de **falha rápida**, mesmo com o serviço já de volta. **O momento da tentativa de teste importa**: testar antes da volta do serviço reinicia a espera, e por isso a espera costuma crescer (como um *backoff*) a cada reabertura.
:::

::: solucao 15.11
**Protocolo.** (1) **Declarar** a métrica principal **antes** (por exemplo, MRR ou nDCG@10) e a tolerância (por exemplo, o BM25 só é adotado se o limite inferior do IC pareado for $>0$). (2) **Ampliar o conjunto**: com desvio-padrão da diferença por pergunta de $\approx0{,}26$, o erro-padrão da diferença é $\sigma/\sqrt n$, e uma diferença de $0{,}05$ só é distinguível de zero ($z=1{,}96$) se $0{,}05>1{,}96\cdot0{,}26/\sqrt n$, ou seja, $n>(1{,}96\cdot0{,}26/0{,}05)^2\approx104$ perguntas (para $50\%$ de poder de detecção; para $80\%$ de poder, $n\approx(2{,}8\cdot0{,}26/0{,}05)^2\approx212$). Com $67$, o IC inclui o zero. (3) **Fatias**: separar diretas e parafraseadas (o MRR do BM25 cai de $0{,}946$ para $0{,}693$), por capítulo e por comprimento da pergunta, porque a vantagem pode estar toda em uma fatia. (4) **Conjunto separado** do usado para ajustar $k_1$ e $b$ do BM25 e a dimensão do LSA, para evitar otimismo. (5) Reportar também a **latência** e o custo de cada um, pois a decisão não é só de acurácia.
:::

::: solucao 15.12
**Verificador com negação.** Representação: cada frase vira uma tupla (sujeito, relação, objeto, **polaridade**) por regras ou um analisador sintático, ou pares de frases comparados por um **modelo de inferência de linguagem natural** (NLI: implicação, contradição, neutro) treinado com dados rotulados. Sinal: a resposta é fiel a uma afirmação se o contexto a **implica** e infiel se a **contradiz** ou é **neutro**. **Teste**: o mesmo conjunto construído (fiel, externa, número, negação), mais **paráfrases** (para medir o falso alarme, que o conjunto atual não mede) e negações de outros tipos (antônimos, quantificadores). **Limites**: modelos de NLI erram com negações dentro de condicionais e com o raciocínio numérico; o contexto longo excede o comprimento do modelo (é preciso fatiar o contexto e agregar). **Calibração do LLM-juiz**: aplicar juiz, verificador e pessoas à **mesma amostra** (com os tipos de erro balanceados), calcular o $\kappa$ do juiz contra as pessoas e contra o verificador, **por tipo de erro**, trocar a **ordem** dos itens para medir o viés de posição, e repetir a calibração quando o modelo-juiz mudar.
:::

::: solucao 15.13
(a) A carga esperada por tick é $N/W$, e $N/W\le C\Rightarrow W\ge N/C=2000/100=20$ ticks (programa `c15_ex_numeros.py`). (b) Cada cliente cai em um tick específico com probabilidade $1/W$, de modo que a carga em um tick é **binomial** $\text{Bin}(N,1/W)$, com média $N/W$ e desvio-padrão $\sqrt{N\frac1W(1-\frac1W)}$. Para $W=20$: média $100$, desvio-padrão $\sqrt{2000\cdot0{,}05\cdot0{,}95}=9{,}7$, e a carga ultrapassa $C=100$ em cerca de metade dos ticks, e passa de $120$ em cerca de $2\%$. É necessária **folga**: $W$ maior que $N/C$, como $W=30$ (média $67$, desvio-padrão $8{,}1$, pico bem abaixo de $100$). (c) Com *backoff* exponencial, a janela **cresce** a cada falha ($1+\text{aleatório}(0,\min(2^k,64))$ no programa), e a carga por tick **diminui** com $k$: os clientes que falham de novo se espalham mais. É por isso que o pico medido foi só $190$, e não $2000$, mesmo com a primeira janela pequena.
:::

::: solucao 15.14
**Métricas por camada**: recuperação (acerto@$k$ e nDCG@10, com IC pareado), geração (fidelidade pelo verificador **validado** e, se houver, pelo juiz **calibrado**, mais relevância da resposta), agente ($\text{pass}^k$ nas tarefas críticas, passos e custo por tarefa), sistema (p95 de latência, custo por tarefa, taxa de erro de ferramenta). **Tolerâncias** declaradas **antes**: nenhuma queda de recuperação acima de $2$ pontos percentuais (limite inferior do IC pareado $>-0{,}02$), nenhuma queda em $\text{pass}^k$ de segurança, custo e latência dentro de $+10\%$. **Amostra**: o suficiente para IC de meia-largura menor que a tolerância (seção 15.2), com **fatias** (diretas, parafraseadas, fora do escopo). **Métricas que melhoram e outras que pioram**: a **regra de promoção declarada antes** decide (uma melhoria em fidelidade não compensa uma queda em segurança, por exemplo); casos em conflito vão a **revisão humana** com amostra dos traços. **Auditoria**: versão de cada componente (modelo, *prompt*, índice, ferramentas, conjunto), resultados com IC, decisão e responsável. **Três formas de enganar o portão**: (1) **vazamento** do conjunto de avaliação para o ajuste do *prompt* (contenção: conjunto de teste separado, congelado, e renovado periodicamente); (2) **ajuste à métrica** (otimizar o que se mede e piorar o que não se mede; contenção: métricas múltiplas, amostras revisadas por pessoas, e métricas de segurança com veto); (3) **conjunto que não representa o uso** (as perguntas reais mudaram; contenção: amostrar traços reais de produção, com privacidade, e atualizar o conjunto).
:::

## 15.12 Referências e leituras

### Livros e artigos de método

- COHEN, J. A coefficient of agreement for nominal scales. *Educational and Psychological Measurement*, 1960.
- EFRON, B.; TIBSHIRANI, R. *An Introduction to the Bootstrap*. Chapman & Hall, 1993.
- JÄRVELIN, K.; KEKÄLÄINEN, J. Cumulated gain-based evaluation of IR techniques. *ACM Transactions on Information Systems*, 2002.
- MANNING, C.; RAGHAVAN, P.; SCHÜTZE, H. *Introduction to Information Retrieval*. Cambridge University Press, 2008. Métricas de recuperação.

### Avaliação de sistemas com LLM

- ES, S. et al. RAGAs: automated evaluation of retrieval augmented generation. *arXiv*, 2023.
- YAO, S. et al. $\tau$-bench: a benchmark for tool-agent-user interaction in real-world domains. *arXiv*, 2024. A métrica $\text{pass}^k$.
- ZHENG, L. et al. Judging LLM-as-a-judge with MT-Bench and Chatbot Arena. In: *NeurIPS (Datasets and Benchmarks)*, 2023.

### Operação, resiliência e segurança

- BROOKER, M. Exponential backoff and jitter. *AWS Architecture Blog*, 2015.
- DEAN, J.; BARROSO, L. A. The tail at scale. *Communications of the ACM*, 2013.
- NYGARD, M. *Release It!* 2. ed. Pragmatic Bookshelf, 2018. Disjuntor e padrões de estabilidade.
- GRESHAKE, K. et al. Not what you've signed up for: compromising real-world LLM-integrated applications with indirect prompt injection. *arXiv*, 2023.
- OWASP. *Top 10 for Large Language Model Applications*. Projeto OWASP.

### Governança

- GEBRU, T. et al. Datasheets for datasets. *Communications of the ACM*, 2021.
- MITCHELL, M. et al. Model cards for model reporting. In: *Conference on Fairness, Accountability, and Transparency (FAccT)*, 2019.
- NIST. *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*. 2023.
- BRASIL. Lei nº 13.709, de 14 de agosto de 2018 (Lei Geral de Proteção de Dados Pessoais).
- UNIÃO EUROPEIA. Regulamento (UE) 2024/1689 (regulamento sobre inteligência artificial).

### Documentação técnica

- LangChain (`langchain` $1{,}5{,}0$, *callbacks*, `with_retry`, `with_fallbacks`), LangGraph (`langgraph` $1{,}2{,}21$, `RetryPolicy`) e LangSmith (`langsmith` $0{,}14{,}17$ instalado; **não** usado), nas documentações oficiais.

::: nota Sobre as referências
Citadas **de memória**, sem consulta às páginas originais. Autores, títulos e locais são os que o autor conhece com confiança; páginas, volumes, números de versão e URLs podem conter imprecisões e **devem ser conferidos** antes de qualquer citação formal. Os documentos legais e normativos devem ser lidos **nas fontes oficiais**, e este livro **não** é aconselhamento jurídico.
:::
