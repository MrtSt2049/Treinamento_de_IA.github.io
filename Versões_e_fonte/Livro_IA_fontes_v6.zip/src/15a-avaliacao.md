<div class="objetivos">

Objetivos do capítulo

- Organizar a avaliação de um sistema com LLM em **camadas** (recuperação, geração, agente) e distinguir avaliação **offline** de monitoramento **online**.
- Definir e calcular as métricas de recuperação (precisão@$k$, revocação@$k$, acerto@$k$, MRR, MAP, nDCG), conhecer seus **limites** e reportá-las com **intervalos de confiança** e comparação **pareada**.
- Distinguir **relevância do contexto**, **fidelidade** e **relevância da resposta** (o triângulo da avaliação de RAG), e **fidelidade** de **correção factual**.
- Construir e **validar** um verificador de fidelidade sem LLM-juiz, medindo onde ele acerta e onde é cego, e discutir a calibração de um juiz por LLM com o coeficiente $\kappa$.
- Avaliar **agentes** por trajetória e por consistência ($\text{pass@}k$ contra $\text{pass}^k$).
- Instrumentar um sistema com **rastreamento** (spans, latência, *tokens*, custo), entender a **cauda** da latência e impor **orçamentos**.
- Projetar **resiliência** (tentativas, *backoff* com *jitter*, disjuntor, degradação) e **guardrails** em camadas, medindo o que cada camada realmente protege.
- Reconhecer o que a **governança** exige (versionamento, portões de avaliação, auditoria, resposta a incidentes), sem prometer o que o código não entrega.

**Pré-requisitos:** Capítulos 11 a 14. Este é o capítulo final do curso: aplica ao que foi construído (Projetos 8, 9 e 10) as medidas que dizem **se funciona**, **quanto custa** e **o que acontece quando falha**.

</div>

## 15.1 Por que avaliar, e o que avaliar

Até aqui, cada projeto terminou com um experimento, mas o critério foi sempre **do próprio autor**. Num sistema em produção, "parece bom" não é critério: a saída de um LLM é variável, o erro é sutil, e a mudança de um *prompt*, de um modelo ou de um índice pode **piorar** o sistema sem que ninguém perceba. Avaliar é transformar "parece bom" em **números comparáveis ao longo do tempo**.

Um sistema com LLM tem partes que falham de formas diferentes, e cada uma tem sua avaliação.

| Camada | Pergunta | Medida típica |
|---|---|---|
| **Recuperação** | Os trechos certos foram encontrados? | precisão, revocação, MRR, nDCG |
| **Geração** | A resposta é fiel ao contexto e responde à pergunta? | fidelidade, relevância da resposta |
| **Agente** | A trajetória (ferramentas, passos) leva à tarefa cumprida, com custo razoável? | taxa de sucesso, passos, custo, consistência |
| **Sistema** | É rápido, barato, estável e seguro? | latência (percentis), custo, taxa de erro, incidentes |

A avaliação por camada tem uma vantagem decisiva: quando a resposta final está errada, ela **localiza** o defeito. Se a recuperação falhou, melhorar o *prompt* é inútil; se o contexto estava certo e a resposta ignorou parte dele, o problema é a geração.

Duas distinções organizam o resto do capítulo.

- **Offline e online.** A avaliação **offline** roda o sistema sobre um conjunto de perguntas com gabarito, antes de publicar uma mudança (é um teste de regressão). O monitoramento **online** observa o sistema em uso: latência, custo, taxas de erro, avaliações de usuários, amostras revisadas por pessoas. Um não substitui o outro: o conjunto offline **envelhece** (os usuários perguntam coisas novas), e o online não tem gabarito.
- **Gabarito e proxy.** Um **gabarito** (rótulo de referência) é caro e limitado; um **proxy** (uma regra, um verificador, um LLM-juiz) é barato e abrangente, mas pode estar **errado de forma sistemática**. Todo proxy deve ser **validado** contra rótulos humanos ou construídos, e é isso que as seções 15.3 e 15.7 fazem.

::: atencao Um conjunto de avaliação é um instrumento de medida
Ele precisa ser **representativo** do uso real (inclusive perguntas parafraseadas, ambíguas e fora do escopo, como no Projeto 8), **separado** do que foi usado para ajustar o sistema (senão a medida é otimista, como o vazamento do Capítulo 5), **versionado** (para comparar versões do sistema sobre o mesmo conjunto) e **grande o bastante** para que a incerteza seja menor que a diferença que se quer detectar (seção 15.2).
:::

## 15.2 Métricas de recuperação, e a incerteza de medi-las

Seja uma pergunta $q$ com o conjunto $G$ das unidades **relevantes** (aqui, seções do livro), e um **ranking** $r_1,r_2,\dots$ devolvido pelo recuperador. Seja $\mathrm{rel}_i=1$ se $r_i\in G$, e $0$ caso contrário.

::: definicao 15.1 · Métricas de recuperação com relevância binária
- **Precisão@$k$**: $\displaystyle \mathrm{P@}k=\frac1k\sum_{i\le k}\mathrm{rel}_i$. **Revocação@$k$**: $\displaystyle \mathrm{R@}k=\frac1{|G|}\sum_{i\le k}\mathrm{rel}_i$. **Acerto@$k$** (*hit rate*): $1$ se há algum relevante entre os $k$ primeiros.
- **Rank recíproco** $\mathrm{RR}=1/i^\star$, em que $i^\star$ é a posição do **primeiro** relevante ($0$ se não há); **MRR** é a média sobre as perguntas.
- **Precisão média** $\displaystyle \mathrm{AP}=\frac1{|G|}\sum_{i:\,\mathrm{rel}_i=1}\mathrm{P@}i$; **MAP** é a média sobre as perguntas.
- **nDCG@$k$**: $\displaystyle \mathrm{DCG@}k=\sum_{i\le k}\frac{\mathrm{rel}_i}{\log_2(i+1)}$ e $\mathrm{nDCG@}k=\mathrm{DCG@}k/\mathrm{IDCG@}k$, em que $\mathrm{IDCG@}k$ é o $\mathrm{DCG@}k$ do ranking **ideal** (todos os relevantes no topo).
:::

O desconto $1/\log_2(i+1)$ faz um relevante na posição $1$ valer $1$, na posição $3$ valer $0{,}5$ e na posição $7$ valer $\tfrac13$: **a ordem importa**, mas suavemente (Järvelin e Kekäläinen, 2002). A escolha da métrica deve seguir o uso: se o sistema só usa o **primeiro** resultado, MRR e acerto@1; se um LLM lê os $k$ primeiros trechos, revocação@$k$ e nDCG@$k$.

::: proposicao 15.1 · Limites das métricas
(a) $0\le\mathrm{nDCG@}k\le1$, e $\mathrm{nDCG@}k=1$ se, e só se, os $\min(|G|,k)$ primeiros itens do ranking são todos relevantes. (b) $\mathrm{P@}k\le\min\{1,\,|G|/k\}$.
:::

::: demonstracao
(a) O $\mathrm{DCG@}k$ de qualquer ranking é no máximo o do ranking ideal, porque o ideal põe os $\min(|G|,k)$ relevantes nas posições de maior peso, e $1/\log_2(i+1)$ é decrescente; logo $\mathrm{nDCG@}k\le1$, e a igualdade exige que todos os pesos estejam nos relevantes. (b) O numerador $\sum_{i\le k}\mathrm{rel}_i$ não passa de $\min(k,|G|)$, e divide-se por $k$.
:::

O programa a seguir calcula tudo à mão, sobre as $67$ perguntas do Projeto 8 (unidade: seção), com **BM25** e com o embedding **LSA**, e acrescenta **intervalos de confiança por *bootstrap*** (reamostrar as perguntas com reposição, $10\,000$ vezes, e tomar os percentis $2{,}5$ e $97{,}5$ da média; Efron e Tibshirani, 1993).

<<< codigo/c15_metricas_recuperacao.py

>>> codigo/c15_metricas_recuperacao.out

O que se lê dessa saída:

- **Precisão@5 é limitada pelo gabarito** (Proposição 15.1b): como quase toda pergunta tem **uma** seção relevante, $\mathrm{P@}5\le1/5=0{,}2$, e os $0{,}206$ (BM25) e $0{,}200$ (LSA) medidos estão **colados no teto** (algumas perguntas têm duas seções relevantes, o que explica o excedente). Não é um mau resultado: é uma métrica **inadequada** para esse gabarito. Com um relevante por pergunta, use acerto@$k$ e MRR.
- **As perguntas parafraseadas custam caro**: o MRR do BM25 cai de $0{,}946$ (diretas) para $0{,}693$ (parafraseadas), e o do LSA de $0{,}902$ para $0{,}630$. **Uma média global esconde isso.** Reporte **fatias** (por tipo de pergunta, por capítulo, por comprimento).
- **Intervalos largos**: com $67$ perguntas, o MRR do BM25 é $0{,}855$ com IC $[0{,}785;\,0{,}918]$, e os intervalos de BM25 e LSA **se sobrepõem**. Olhar os dois intervalos separados sugere "empate", mas essa comparação é fraca; a correta é a **pareada**.

### Comparar dois sistemas: a diferença pareada

Os dois recuperadores respondem **às mesmas perguntas**, e as perguntas difíceis o são para ambos. Isso cria **correlação positiva** entre os resultados, e a variância da diferença fica menor do que a soma das variâncias.

::: proposicao 15.2 · Variância da diferença pareada
Sejam $X_i,Y_i$ as medidas de dois sistemas na pergunta $i$ ($i=1,\dots,n$), e $D_i=X_i-Y_i$. Então $\operatorname{Var}(\bar D)=\dfrac1n\bigl[\operatorname{Var}(X)+\operatorname{Var}(Y)-2\operatorname{Cov}(X,Y)\bigr]$. Quando $\operatorname{Cov}(X,Y)>0$, o erro-padrão da diferença é **menor** que o de duas amostras independentes, $\sqrt{(\operatorname{Var}X+\operatorname{Var}Y)/n}$. Ignorar o pareamento **superestima** a incerteza e faz perder diferenças reais.
:::

::: demonstracao
$\operatorname{Var}(\bar D)=\operatorname{Var}(D)/n$ e $\operatorname{Var}(X-Y)=\operatorname{Var}X+\operatorname{Var}Y-2\operatorname{Cov}(X,Y)$ (Capítulo 1). O erro-padrão independente corresponde a $\operatorname{Cov}=0$.
:::

Na parte C da saída, o erro-padrão da diferença de nDCG@10 é $0{,}022$ no cálculo pareado, e $0{,}043$ se (erradamente) se tratassem as amostras como independentes: quase o **dobro**. O resultado: a diferença BM25 $-$ LSA em nDCG@10 é $+0{,}047$ com IC pareado $[+0{,}005;\,+0{,}092]$, que **exclui o zero**; no MRR a diferença é $+0{,}051$ com IC $[-0{,}009;\,+0{,}113]$, que **inclui** o zero. Com os dados disponíveis, o BM25 é melhor em nDCG@10 e inconclusivo em MRR: duas conclusões diferentes para duas métricas, e a lição é **declarar a métrica antes** de olhar o resultado.

### Quantas perguntas?

Para uma proporção $p$ medida em $n$ perguntas, a meia-largura aproximada do IC de $95\%$ é $1{,}96\sqrt{p(1-p)/n}$. Para obter meia-largura $\varepsilon$, precisa-se de $n\ge1{,}96^2\,p(1-p)/\varepsilon^2$. A parte D mostra $\pm0{,}111$ com $50$ perguntas e $\pm0{,}039$ com $400$; para $\pm0{,}03$ em $p=0{,}8$, são $683$ perguntas. Como a diferença entre dois sistemas que se quer detectar é, em geral, de poucos pontos percentuais, **conjuntos de dezenas de perguntas só detectam diferenças enormes**. Em contrapartida, o pareamento reduz o $n$ necessário.

## 15.3 Avaliar a geração: relevância, fidelidade e correção

Depois da recuperação, o LLM recebe pergunta e contexto e escreve uma resposta. Três relações entre os três objetos (Figura 15.1) são medidas separadamente.

<figure>
+++ fig_c15_triangulo.svg
<figcaption><b>Figura 15.1.</b> O triângulo da avaliação de RAG. A <b>relevância do contexto</b> liga pergunta e contexto recuperado; a <b>fidelidade</b> liga o contexto à resposta (cada afirmação tem suporte nele?); a <b>relevância da resposta</b> liga a resposta à pergunta. A <b>correção factual</b>, comparada a um gabarito externo, é uma quarta medida e não é implicada por nenhuma das três.</figcaption>
</figure>

::: definicao 15.2 · Fidelidade
Decomponha a resposta em **afirmações** (por exemplo, frases) $a_1,\dots,a_m$. A resposta é **fiel** ao contexto $C$ se cada afirmação é **sustentada** por $C$. A **pontuação de fidelidade** é $F=\dfrac{\#\{j:\,a_j\text{ sustentada por }C\}}{m}$. Uma afirmação **verdadeira**, mas ausente do contexto, **não** é sustentada: fidelidade mede a **atribuição**, e não a verdade.
:::

Esta é a formulação adotada por *frameworks* de avaliação de RAG, como o RAGAS (Es et al., 2023, citado de memória), em que um LLM faz a decomposição em afirmações e o julgamento de suporte. **Esse julgamento por LLM não foi executado neste livro** (não há LLM disponível no ambiente), e por isso o capítulo faz outra coisa, que é pedagogicamente mais forte: constrói um verificador **sem LLM**, e **mede o quanto ele é válido**.

### Um verificador lexical, e a medida da sua validade

O verificador (`suporte`) calcula, para cada frase da resposta, a **fração dos radicais da frase que aparecem no contexto**, e dá $0$ se algum **número** da frase não está no contexto. A pontuação da resposta é a da frase **menos apoiada**. Para saber se ele funciona, constroem-se respostas com **rótulo conhecido por construção**, a partir dos $67$ contextos recuperados:

- **fiel**: duas frases copiadas do contexto;
- **externa**: uma frase fiel e uma frase **verdadeira** do livro, mas de uma seção **fora** do contexto;
- **número**: uma frase fiel e uma frase do contexto com um **número alterado**;
- **negação**: uma frase fiel e uma frase do contexto com **"não" inserido** (contradiz o contexto).

<<< codigo/c15_fidelidade.py

>>> codigo/c15_fidelidade.out

Os resultados dizem **onde o verificador vale e onde é cego**:

- **Afirmação externa**: AUC $=1{,}000$. Com $\tau=0{,}8$, detecta $97\%$. Note que a frase externa é **verdadeira** (parte D): fidelidade a marca, e um verificador de **correção** a aprovaria. Esse é o caso que um sistema de RAG precisa detectar para não "completar" a resposta com conhecimento do modelo.
- **Número alterado**: AUC $=0{,}888$, detecção de $74{,}6\%$. A causa dos $25\%$ restantes é que o número alterado às vezes **aparece em outro lugar** do contexto.
- **Negação**: AUC $=0{,}500$ (acaso) e detecção $0{,}00$. **O verificador é cego à negação**: ele compara radicais sem palavras vazias, e "não" é palavra vazia (parte E: em $100\%$ dos casos, a frase negada e a original têm os mesmos radicais). Trocar o verificador por um que considere a **ordem** e a **polaridade** (um modelo de inferência de linguagem natural, ou um LLM-juiz) é o que a tarefa exige.
- **O falso alarme de $0{,}000$ é um artefato** (parte F): as respostas fiéis foram **copiadas** do contexto, então têm suporte $1{,}0$ por construção. Respostas fiéis reais **parafraseiam**, e o verificador lexical errará ali. Medir isso exigiria um gerador de paráfrases, que é um LLM.

<figure>
+++ fig_c15_qualidade.svg
<figcaption><b>Figura 15.2.</b> Duas medidas de qualidade, com a incerteza à vista. À esquerda, a taxa com que o verificador lexical de fidelidade detecta cada tipo de infidelidade ($\tau=0{,}8$): quase tudo nas afirmações externas, três quartos nos números alterados e nada nas negações. À direita, o MRR de BM25 e LSA com IC de $95\%$ por <i>bootstrap</i>, separado em perguntas diretas e parafraseadas: as duas fatias diferem muito, e os intervalos de $67$ perguntas são largos.</figcaption>
</figure>

O coeficiente de concordância $\kappa$ global ficou em $0{,}40$ ($\tau=0{,}8$), **moderado**: o verificador acerta bastante em dois tipos e nada em um, e o $\kappa$ resume isso em um número que **esconde** a estrutura. A lição de método: **uma métrica de avaliação é um modelo, e modelos têm domínio de validade**. Antes de confiar em um verificador (lexical, NLI ou LLM-juiz), teste-o em **casos construídos** que cubram os tipos de erro que importam, e reporte a taxa de detecção **por tipo**.

::: definicao 15.3 · Coeficiente $\kappa$ de Cohen
Dois avaliadores classificam $n$ itens. Seja $p_o$ a proporção de **concordância observada** e $p_e=\sum_c p_{c\cdot}\,p_{\cdot c}$ a concordância **esperada por acaso** (produto das proporções marginais de cada classe). Então $\kappa=\dfrac{p_o-p_e}{1-p_e}$. Vale $\kappa=1$ para concordância perfeita e $\kappa=0$ para a concordância esperada por acaso (Cohen, 1960).
:::

O $\kappa$ corrige a concordância pelo acaso: dois avaliadores que dizem "sim" em $90\%$ dos casos concordam muito por acaso, e a acurácia bruta engana. É a medida padrão para **calibrar um juiz**: compare o veredito do LLM-juiz com o de pessoas em uma amostra e reporte $\kappa$ (e a matriz de confusão), **antes** de usá-lo como métrica.

::: atencao Juízes por LLM têm vieses conhecidos
Estudos de LLM-juiz (por exemplo, Zheng et al., 2023, citado de memória) descrevem **viés de posição** (preferir a primeira resposta apresentada), **viés de verbosidade** (preferir respostas longas) e **autopreferência** (preferir respostas do próprio modelo). As contenções são as de qualquer instrumento: trocar a ordem e exigir consistência, instruções com critérios explícitos, juiz **diferente** do modelo avaliado, e **calibração periódica** contra pessoas. Este livro **não** executou um juiz por LLM e, portanto, não afirma números para ele.
:::

### Relevância da resposta e do contexto

A **relevância da resposta** pergunta se a resposta **trata da pergunta** (uma resposta fiel e inútil, como "o texto é longo", falha aqui). A **relevância do contexto** pergunta se o que foi recuperado **serve** à pergunta, e coincide com as métricas da seção 15.2 quando há gabarito, ou com uma estimativa por julgamento quando não há (a fração do contexto que é necessária à resposta). Ambas costumam ser estimadas por LLM-juiz, com a ressalva de calibração acima.

## 15.4 Avaliar agentes

Um agente não produz só um texto: produz uma **trajetória** (as chamadas de ferramenta e as observações). A avaliação tem três eixos.

1. **Resultado**: a tarefa foi cumprida? É a taxa de sucesso, contra gabarito programático quando possível (como no Projeto 9, em que o gabarito vem de **executar** a sequência correta).
2. **Trajetória**: as ferramentas certas foram chamadas, com argumentos válidos, em quantidade razoável? Custo em passos e *tokens*, e as taxas de erro de ferramenta.
3. **Consistência**: o agente acerta **sempre**, ou só às vezes? Como a saída é estocástica, a mesma tarefa pode dar resultados diferentes.

Seja $s$ a probabilidade de sucesso em **uma execução** da tarefa. Duas métricas, com $k$ execuções independentes:
$$\text{pass@}k=1-(1-s)^k\quad(\text{ao menos uma das }k\text{ dá certo}),\qquad \text{pass}^k=s^k\quad(\text{as }k\text{ dão certo}).$$
A primeira mede a **capacidade** (útil quando se pode verificar e tentar de novo, como no Reflexion do Capítulo 13); a segunda mede a **confiabilidade** (um atendimento ao cliente não pode acertar "às vezes"). Para $s=0{,}8$: $\text{pass@}5=0{,}9997$ e $\text{pass}^5=0{,}328$ (programa `c15_ex_numeros.py`). **O mesmo agente parece quase perfeito ou medíocre, conforme a métrica**; a escolha depende do uso. A métrica $\text{pass}^k$ foi popularizada pelo $\tau$-bench (Yao et al., 2024, citado de memória).

::: nota Avaliação como parte do desenvolvimento
Uma prática consolidada é **escrever o conjunto de avaliação antes de melhorar o sistema** e rodá-lo a cada mudança (de *prompt*, modelo, índice, ferramenta), como testes de regressão. Mudanças só entram se não piorarem as métricas além de uma tolerância **declarada**, e os resultados são guardados **com a versão** de cada componente. É o que a seção 15.8 chama de portão de avaliação.
:::
