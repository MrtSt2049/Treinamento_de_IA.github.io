## 13.4 Tarefas longas e o erro composto

Um agente erra de dois modos muito diferentes, e a diferença decide como projetá-lo.

- **Erro detectável**: a ferramenta recusa a chamada (formato inválido, ferramenta inexistente, argumento fora do contrato). O agente **vê** o erro e pode tentar de novo.
- **Erro silencioso**: a chamada é **válida** e executa, mas é a chamada **errada** (o capítulo trocado, a seção vizinha, um número transcrito com um dígito a mais). Ninguém avisa, o resultado errado entra no histórico e **contamina** os passos seguintes.

::: proposicao 13.2 · Erro composto no ReAct
Considere uma tarefa que exige $n$ ações de ferramenta, seguidas da resposta final. Em cada decisão, o modelo erra com probabilidade $p$, independentemente das demais; uma fração $\delta$ dos erros nas ações é **detectável** (o agente repete o passo, sem limite de tentativas) e a fração $1-\delta$ é **silenciosa** e irrecuperável. Um erro na resposta final é sempre silencioso. A probabilidade de resposta correta é
$$P_\text{acerto}=\Bigl(\frac{1-p}{1-\delta p}\Bigr)^{n}(1-p).$$
Em particular, com $\delta=0$, $P_\text{acerto}=(1-p)^{n+1}$: **decai exponencialmente** com o horizonte.
:::

::: demonstracao
Em uma ação, o resultado é: correto, com probabilidade $1-p$ (o passo avança); erro detectável, com $\delta p$ (o passo se repete); erro silencioso, com $(1-\delta)p$ (a tarefa está perdida). A probabilidade de o passo **terminar correto** é a de acertar antes do primeiro erro silencioso: $\sum_{k\ge0}(\delta p)^k(1-p)=\dfrac{1-p}{1-\delta p}$. As $n$ ações são independentes, e a resposta final acerta com $1-p$. $\square$
:::

::: exemplo 13.1 · Quanto se perde em horizontes longos
Sem detecção ($\delta=0$) e com $p=0{,}01$ ($99\%$ de acerto por decisão, um número que parece excelente): para $n=10$ ações, $0{,}99^{11}=0{,}895$; para $n=100$, $0{,}99^{101}=0{,}362$. Com $p=0{,}05$ e $n=10$, $0{,}95^{11}=0{,}569$. **Um modelo muito bom por passo pode ser ruim por tarefa.** Daí a importância de **reduzir o horizonte** (passos que não precisam existir), **detectar** erros (contratos, validadores) e **verificar** resultados parciais.
:::

O experimento 1 do Projeto 9 mede isso (60 tarefas com $1$ a $3$ ações, $100$ sementes; o "modelo" simulado erra com probabilidade $p$ e metade dos erros é detectável, $\delta=\tfrac12$):

| $p$ | previsto (Prop. 13.2) | observado (ReAct) | diferença |
|---:|---:|---:|---:|
| $0{,}05$ | $0{,}906$ | $0{,}916$ | $+0{,}010$ |
| $0{,}10$ | $0{,}815$ | $0{,}819$ | $+0{,}005$ |
| $0{,}20$ | $0{,}646$ | $0{,}651$ | $+0{,}005$ |
| $0{,}30$ | $0{,}494$ | $0{,}507$ | $+0{,}013$ |

O observado fica **um pouco acima** do previsto, e a razão é conhecida: parte dos erros "silenciosos" do simulador é **inofensiva por acaso** (por exemplo, "capítulo $-1$" no Capítulo 1 é cortado para o próprio $1$, e uma busca com duas palavras a menos ainda recupera a seção certa). A Proposição dá a **forma** do decaimento, e o modelo de independência é uma simplificação.

## 13.5 Plan-and-Solve: planejar antes de agir

::: definicao 13.4 · Plan-and-Solve
Em vez de decidir **um** passo por chamada, o modelo recebe a pergunta e produz, em **uma** chamada, o **plano inteiro** (a lista de ações, com *marcadores* para os resultados ainda desconhecidos). Um **executor** (código, sem LLM) roda o plano passo a passo, preenchendo os marcadores. Se uma ferramenta devolve **erro**, o executor pede um **novo plano** para o que falta (*replanejamento*). Ao final, uma chamada compõe a resposta a partir dos resultados.
:::

A ideia (Wang et al., 2023, citado de memória, em um contexto de raciocínio por *prompt*, que se estende a agentes) é separar **deliberar** de **executar**. As vantagens esperadas:
- **Menos chamadas ao modelo** e **menos *tokens***: o histórico não é reenviado a cada ferramenta (Proposição 13.1). No simulador, **duas** chamadas por tarefa contra $2{,}85$ do ReAct, e $245$ palavras de entrada contra $398$ (com $p=0$).
- **Previsibilidade e auditoria**: o plano pode ser **mostrado e aprovado** por uma pessoa antes de qualquer execução.
- **Foco**: o modelo vê o objetivo inteiro ao planejar, sem se distrair com observações longas no meio.

E os riscos: um plano feito **sem** as observações pode ser **errado de partida**, se o ambiente surpreende; o replanejamento só dispara em erros **detectáveis**; e o número de ações do plano não se ajusta ao que se descobre.

O simulador dá ao Plan-and-Solve **a mesma estrutura de erros** do ReAct (cada passo do plano erra com probabilidade $p$, nos quatro modos, e a composição final também), de modo que o experimento isola o **custo**. O resultado confirma o que se espera de um modelo de erro igual: **a mesma taxa de acerto**, com custo menor.

<figure>
+++ fig_c13_resultados.svg
<figcaption><b>Figura 13.2.</b> À esquerda, taxa de acerto contra a taxa de erro $p$ do modelo simulado para ReAct (violeta), Plan-and-Solve (azul tracejado, quase sobreposto ao ReAct), Reflexion sem aprendizado (verde) e com aprendizado ($\rho=0{,}5$, marrom pontilhado). À direita, palavras de entrada contra o número de passos $T$ para ReAct e Plan-and-Solve em uma tarefa de somas encadeadas.</figcaption>
</figure>

| $p$ | ReAct: acerto / chamadas / palavras | Plan-and-Solve: acerto / chamadas / palavras |
|---:|---|---|
| $0{,}00$ | $1{,}000$ / $2{,}85$ / $398$ | $1{,}000$ / $2{,}00$ / $245$ |
| $0{,}10$ | $0{,}819$ / $2{,}87$ / $403$ | $0{,}822$ / $2{,}04$ / $250$ |
| $0{,}20$ | $0{,}651$ / $2{,}89$ / $410$ | $0{,}646$ / $2{,}08$ / $255$ |
| $0{,}30$ | $0{,}507$ / $2{,}90$ / $416$ | $0{,}504$ / $2{,}13$ / $260$ |

Em tarefas **mais longas** a economia cresce, pois o ReAct paga $T+1$ chamadas e um custo quadrático, e o Plan-and-Solve, um custo quase **linear**: para $T=32$ passos, $13\,398$ palavras contra $332$ (Figura 13.2, direita, e experimento 2). **Cuidado ao generalizar:** a igualdade de acerto é **consequência do modelo de erros** do simulador. Com um LLM real, o planejador pode errar **menos** que o reativo (por ver o todo) ou **mais** (por não ter as observações), e **só a medição** com o seu modelo e as suas tarefas diz qual.

Quando o replanejamento reconstrói o plano **inteiro** a cada erro detectável (em vez de só o que falta), o custo pode virar contra o plano: com probabilidade $e$ de erro detectável por passo e $n$ passos, o número esperado de planos é $(1-e)^{-n}$ e o de chamadas do ReAct (que repete só o passo falho) é $n/(1-e)+1$. Para $e=0{,}1$ e $n=5$, o plano gasta $2{,}7$ chamadas contra $6{,}6$; para $e=0{,}3$ e $n=10$, o plano gasta $36{,}4$ contra $15{,}3$ (Exercício 13.9).

## 13.6 Reflexion: aprender com a falha

::: definicao 13.5 · Reflexion
O Reflexion (Shinn et al., 2023, citado de memória) executa **várias tentativas** da mesma tarefa. Após cada uma, um **avaliador** julga o resultado (por exemplo, testes que passam ou falham, uma verificação do ambiente, um validador). Se o resultado é considerado errado, o modelo escreve uma **reflexão** em linguagem natural ("errei porque usei o capítulo errado; devo conferir o número antes de calcular"), guardada em uma **memória episódica** e **incluída no *prompt*** da tentativa seguinte.
:::

Duas hipóteses distintas estão embutidas, e convém separá-las.

**(H1) Repetição com avaliador.** Só **tentar de novo** já ajuda, se o avaliador sabe dizer quando falhou: o erro silencioso de uma tentativa é independente do da próxima.

**(H2) Aprendizado pela reflexão.** O texto da reflexão **reduz** a chance de errar de novo.

::: proposicao 13.3 · Reflexion sem aprendizado (somente H1)
Seja $s$ a probabilidade de uma tentativa acertar, $q$ a probabilidade de o avaliador **detectar** uma resposta errada (e, por simplificação, ele nunca reprova uma correta), $K$ o máximo de tentativas, e $u=q(1-s)$ a probabilidade de uma tentativa **ser descartada**. Então
$$P_\text{acerto}(K)=s\,\frac{1-u^{K}}{1-u},\qquad \mathbb{E}[\text{tentativas}]=\frac{1-u^{K}}{1-u}.$$
Com um avaliador perfeito ($q=1$): $P_\text{acerto}=1-(1-s)^K$ e $\mathbb{E}[\text{tentativas}]=P_\text{acerto}/s$.
:::

::: demonstracao
A tentativa $k+1$ só acontece se as $k$ anteriores foram descartadas, o que tem probabilidade $u^k$, e acerta com probabilidade $s$. Soma-se $\sum_{k=0}^{K-1}s\,u^k=s(1-u^K)/(1-u)$. O número esperado de tentativas é $\sum_{k=0}^{K-1}u^k$, e com $q=1$, $u=1-s$ e $(1-u^K)/(1-u)=(1-(1-s)^K)/s$. $\square$
:::

O experimento 3 mede o simulador com $p=0{,}2$ (acerto de uma tentativa $s=0{,}668$) e compara com a fórmula:

| $K$ | $q$ | acerto observado | previsto | chamadas ao LLM por tarefa |
|---:|---:|---:|---:|---:|
| $1$ | qualquer | $0{,}668$ | $0{,}668$ | $2{,}88$ |
| $3$ | $1{,}0$ | $0{,}958$ | $0{,}963$ | $4{,}25$ |
| $3$ | $0{,}7$ | $0{,}853$ | $0{,}859$ | $3{,}78$ |
| $3$ | $0{,}4$ | $0{,}766$ | $0{,}768$ | $3{,}33$ |
| $5$ | $1{,}0$ | $0{,}994$ | $0{,}996$ | $4{,}47$ |
| $5$ | $0{,}4$ | $0{,}768$ | $0{,}770$ | $3{,}34$ |

O que se conclui:
- **O avaliador vale mais que o número de tentativas.** Com $q=0{,}4$ (o avaliador deixa passar $60\%$ dos erros), $K=5$ **não** supera $K=3$ ($0{,}768$ contra $0{,}766$): o teto é $s/(1-u)=0{,}668/(1-0{,}4\cdot0{,}332)=0{,}770$. Com $q=1$, $K=3$ já dá $0{,}958$.
- **Sem avaliador confiável, não há Reflexion.** Em tarefas com **verificação externa** (código com testes, respostas checáveis contra uma base), o avaliador pode ser quase perfeito. Em tarefas abertas, ele costuma ser o **próprio LLM**, e a literatura relata que modelos **não corrigem bem** o próprio raciocínio **sem** sinal externo (Huang et al., 2024, citado de memória). Nesse caso, $q$ é baixo e pode haver **falsos alarmes** que descartam respostas certas (Exercício 13.12).
- **O custo cresce com $K$, mas menos que linearmente:** o número esperado de tentativas é limitado por $1/(1-u)$. Com $q=1$, é $P_\text{acerto}/s$, e o custo esperado por **resposta correta** fica em $\approx1/s$ tentativas, **constante em $K$**. Isso muda a pergunta de "quantas tentativas?" para "**vale pagar** $c_1/s$ chamadas por tarefa?" (Exercício 13.11).
- **(H2) é uma suposição, não um resultado.** O gráfico com $\rho=0{,}5$ (cada reflexão corta a taxa de erro pela metade) mostra acertos de $0{,}944$ com $K=2$, mas **esse efeito foi escrito no simulador**. Se uma reflexão de um LLM real reduz de fato a taxa de erro, e em quanto, **precisa ser medido** com um modelo real, e foi **o ponto não executado** deste capítulo.

## 13.7 Memória e contexto

O histórico do laço é a **memória de curto prazo** e compete por espaço com tudo o mais na janela. Quatro técnicas controlam o seu crescimento (Proposição 13.1), cada uma com um preço.

- **Janela deslizante.** Manter só as últimas $w$ rodadas. O custo vira $(T+1)P_0+\sum_jm_j\min(T-j,w)$, **linear** em $T$ para $w$ fixo. No exemplo do experimento 2 ($T=32$, $P_0=150$, $m\approx16$), com $w=4$ são $6\,902$ palavras contra $13\,398$ (Exercício 13.13). O **preço**: o agente **esquece** o que ficou fora da janela, inclusive a pergunta original, se ela não for fixada no *prompt*.
- **Resumo.** Substituir rodadas antigas por um resumo gerado por um LLM. Comprime mais que a janela, mas **perde detalhe** (números, identificadores) e o resumo pode **inventar**: é uma chamada a mais, sujeita às alucinações do Capítulo 11.
- **Truncar ou filtrar observações.** Observações longas (páginas web, tabelas) devem ser **cortadas, resumidas ou trocadas por um identificador** que o agente possa consultar sob demanda. Uma só observação de $20\,000$ palavras pesa mais que dezenas de passos.
- **Memória de longo prazo.** Gravar fatos, preferências e reflexões em um **índice vetorial** (Capítulo 12) e **recuperar** os relevantes a cada tarefa. É RAG sobre a história do agente, e herda todos os problemas de recuperação: o que **não** é recuperado **não existe** para o agente.

::: atencao Como agentes falham em produção
- **Laços**: repetir a mesma ação com o mesmo erro. Contenção: limite de passos e **detecção de repetição** (mesma ação com a mesma entrada duas vezes seguidas).
- **Erro silencioso e composto** (seção 13.4): o resultado intermediário errado é tratado como fato. Contenção: validadores de resultado, redundância (calcular duas vezes por vias diferentes) e verificação humana nos pontos críticos.
- **Uso indevido de ferramentas**: argumentos errados, ferramenta errada, ferramenta poderosa demais. Contenção: contratos estritos, menor privilégio e aprovação humana.
- **Instruções injetadas por conteúdo**: o texto lido por uma ferramenta (uma página web, um e-mail) pode conter ordens que o modelo trata como se fossem do usuário (*injeção de instrução indireta*; Greshake et al., 2023, citado de memória). É o risco de segurança central dos agentes, tratado no Capítulo 15.
- **Custo e latência fora de controle**: histórico que cresce, muitas tentativas. Contenção: orçamentos de passos, de *tokens* e de tempo, **verificados pelo código, e não pelo modelo**.
:::
