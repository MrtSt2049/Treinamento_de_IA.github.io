## O percurso, em uma página

O livro começou com vetores e derivadas parciais e terminou com avaliação, observabilidade e governança de sistemas de agentes. Entre os dois extremos, cada capítulo usou o anterior como alicerce, e é essa dependência, mais do que qualquer técnica isolada, que o leitor leva consigo.

| Módulo | O que foi construído | Onde o leitor pode verificar |
|---|---|---|
| I | A linguagem matemática (matrizes, gradientes, probabilidade) e a descrição de qualquer sistema como agente, ambiente e medida de desempenho | Projeto 1; Capítulo 2 |
| II | O problema de aprender: erro redutível e irredutível, modelos clássicos, viés e variância, validação e métricas | Projeto 2 |
| III | Redes neurais do zero e em PyTorch, convolução, recorrência e o problema do gradiente | Projetos 3 a 6 |
| IV | Atenção, o bloco Transformer, as três famílias de modelos, tokenização, ajuste fino e LoRA | Projeto 7 |
| V | Geração controlada, confiabilidade, saídas estruturadas, recuperação, embeddings e RAG com fontes | Projeto 8 |
| VI | Agentes que usam ferramentas, grafos de estado com persistência e aprovação humana, avaliação, resiliência, segurança e governança | Projetos 9 e 10 |

A cadeia apresentada na Introdução geral pode agora ser lida de trás para a frente. Um sistema multiagente que falha em produção (Capítulo 14) falha porque um modelo de linguagem errou em um passo (Capítulo 11), e esse erro se compõe com os dos passos seguintes (Capítulo 13). O modelo errou porque estima probabilidades de *tokens*, e não fatos (Capítulos 9 e 11). Ele estima probabilidades porque é uma rede treinada por gradiente para reduzir uma perda (Capítulos 1 e 6), e a perda baixa em dados de treino não garante nada fora deles (Capítulos 3 e 5). Cada pergunta de depuração, quando seguida até o fim, termina em um dos fundamentos do Módulo I.

## Seis ideias que atravessam o livro

Algumas ideias reapareceram em capítulos muito diferentes. Vale reuni-las, porque são elas que se transferem para tecnologias que ainda não existem.

**1. Medir antes de afirmar.** O erro de treino não é o erro que importa (Capítulo 5); a qualidade de um recuperador não se vê lendo três exemplos (Capítulo 12); a taxa de acerto de um agente precisa de intervalo de confiança e de comparação pareada (Capítulo 15). Em todos os níveis, a pergunta é a mesma: *com que evidência, e com que incerteza, sabemos isso?*

**2. Erros se compõem.** Uma cadeia de $n$ decisões independentes, cada uma com probabilidade $a$ de acerto, acerta com probabilidade $a^n$; é o caso sem erros detectáveis da Proposição 13.2. O mesmo raciocínio explica por que gradientes desaparecem em redes recorrentes (Capítulo 8), por que a verificação em série reduz o erro publicado (Proposição 14.3) e por que repetir uma chamada que falha tem custo esperado e precisa de limite (Proposição 15.4).

**3. Contratos explícitos valem mais que instruções persuasivas.** Esquemas tipados e validação (Capítulo 11), ferramentas com argumentos restritos (Capítulo 13), listas de permissão aplicadas em código e não no texto do *prompt* (Capítulo 15): quando algo importa, ele é imposto por um mecanismo que não depende de o modelo "obedecer".

**4. Estrutura vence improviso.** Um grafo com estado e arestas condicionais torna o fluxo inspecionável, interrompível e reexecutável (Capítulo 14). O que era uma conversa livre vira um programa com pontos de controle.

**5. Custo é restrição de projeto, e não detalhe.** A entrada de um agente cresce de forma quadrática com o número de passos (Proposição 13.1); a memória de um ajuste fino completo é muitas vezes a de um ajuste com LoRA (Capítulo 10); latência de cauda e orçamento de *tokens* decidem se um sistema é viável (Capítulo 15).

**6. Limites fazem parte do conteúdo.** Cada capítulo de ferramenta registrou o que não foi executado e o que não se sabe. Dizer "este verificador de fidelidade é lexical, e a negação o engana" é mais útil ao leitor do que um resultado sem ressalva.

## O que este livro não cobre

Um livro de quinze capítulos escolhe. Estes são os assuntos importantes que ficaram de fora, e é bom que o leitor saiba que existem:

- **Modelos generativos de imagem e áudio** (difusão, GANs, autoencoders variacionais) e **modelos multimodais**, que combinam texto, imagem e áudio.
- **Aprendizado por reforço profundo** e o alinhamento de modelos por preferências (RLHF e variantes). O Capítulo 3 apresentou apenas o conceito; o tratamento completo é outra obra.
- **Treinamento em larga escala:** paralelismo de dados e de modelo, precisão mista, leis de escala. O Capítulo 10 tocou em memória e quantização, sem entrar na engenharia de grandes aglomerados de computação.
- **Serviço de modelos (*inference serving*):** lotes contínuos, *cache* de chaves e valores, decodificação especulativa.
- **Interpretabilidade** de redes e de modelos de linguagem.
- **Inferência causal.** O livro trata de associação e previsão; decidir o que *fazer* a partir de dados exige o aparato causal.
- **Engenharia de dados e MLOps** em profundidade: versionamento de dados, *pipelines* de treinamento contínuo, monitoramento de deriva.
- **Segurança adversarial** além das noções do Capítulo 15, e **ética e regulação** além dos ponteiros ali indicados.
- **Modelos probabilísticos estruturados** (redes bayesianas, processos gaussianos, inferência variacional).

## Trilhas de aprofundamento

As trilhas abaixo seguem direções diferentes a partir do ponto em que o livro termina. Cada uma indica o pré-requisito do livro, uma sequência de estudo e um **projeto de síntese** para consolidar. As obras marcadas com ♦ constam na **Bibliografia consolidada**; as demais não foram citadas nos capítulos, vêm da memória do autor e devem ser conferidas antes de qualquer citação.

### Trilha A. Teoria do aprendizado e pesquisa

*Para quem quer ler e, depois, escrever artigos.* **Pré-requisito:** Capítulos 1, 3 e 5.

1. Fundamentos de otimização convexa e não convexa: ♦ Boyd e Vandenberghe; ♦ Nocedal e Wright.
2. Teoria estatística do aprendizado: Shalev-Shwartz e Ben-David, *Understanding Machine Learning* (Cambridge, 2014); Mohri, Rostamizadeh e Talwalkar, *Foundations of Machine Learning* (MIT Press).
3. Perspectiva probabilística: Bishop, *Pattern Recognition and Machine Learning* (Springer, 2006); Murphy, *Probabilistic Machine Learning: An Introduction* (MIT Press, 2022).
4. Fenômenos modernos: ♦ Belkin et al. sobre a descida dupla (Capítulo 5), ♦ Aghajanyan et al. sobre dimensão intrínseca (Capítulo 10).

**Projeto de síntese.** Estender o exercício 5.13 (descida dupla): reproduzir a curva com outro modelo e outro conjunto de dados, relatando semente, variância entre repetições e uma hipótese explícita sobre o que a curva mostra.

### Trilha B. Engenharia de LLMs: treino, ajuste e eficiência

*Para quem quer personalizar e servir modelos de linguagem.* **Pré-requisito:** Capítulos 9 a 11.

1. Revisitar ♦ Hu et al. (LoRA), ♦ Dettmers et al. (QLoRA) e ♦ Rajbhandari et al. (ZeRO) com a prática do Capítulo 10.
2. Eficiência de atenção: ♦ Dao et al. (FlashAttention); ♦ Shazeer e ♦ Ainslie et al. (atenção de múltiplas consultas e de consultas agrupadas).
3. Leis de escala e treino ótimo: Kaplan et al., *Scaling laws for neural language models* (2020); Hoffmann et al., *Training compute-optimal large language models* (2022).
4. Alinhamento por preferências: Ouyang et al., *Training language models to follow instructions with human feedback* (2022); Rafailov et al., *Direct preference optimization* (2023).
5. Serviço de modelos: Kwon et al., *Efficient memory management for large language model serving with PagedAttention* (2023).

**Projeto de síntese.** Ajustar com LoRA um modelo pequeno em uma tarefa em português, comparar três posições do posto $r$ e dois conjuntos de módulos-alvo, e medir memória, tempo e qualidade com intervalo de confiança.

### Trilha C. Agentes e sistemas em produção

*Para quem quer construir produtos.* **Pré-requisito:** Capítulos 11 a 15.

1. Substituir os "modelos de teste" scriptados dos Projetos 9 e 10 por um modelo real, mantendo **a mesma bateria de testes** do livro. A diferença entre os resultados simulados e os reais é, em si, um resultado de pesquisa.
2. Ligar o rastreamento do Capítulo 15 a uma ferramenta de observabilidade e acompanhar custo, latência de cauda e taxa de erro por etapa.
3. Trocar o *checkpointer* em memória por um persistente e repetir os experimentos de falha do Projeto 10.
4. Estudar padrões de agentes e de segurança: ♦ Yao et al. (ReAct), ♦ Shinn et al. (Reflexion), ♦ Greshake et al. (injeção indireta), ♦ OWASP.

**Projeto de síntese.** Um agente de atendimento com RAG sobre documentos reais (com autorização), com aprovação humana para ações irreversíveis, painel de métricas e um relatório de avaliação com intervalos de confiança.

### Trilha D. Dados, avaliação e MLOps

*Para quem quer que sistemas continuem funcionando depois do lançamento.* **Pré-requisito:** Capítulos 5, 12 e 15.

1. Huyen, *Designing Machine Learning Systems* (O'Reilly, 2022).
2. Kleppmann, *Designing Data-Intensive Applications* (O'Reilly, 2017).
3. Deriva de dados e incerteza sob mudança de distribuição: ♦ Ovadia et al.; calibração: ♦ Guo et al.
4. Avaliação com juízes automáticos: ♦ Zheng et al. (*LLM-as-a-judge*); ♦ Es et al. (RAGAs). Releia o Capítulo 15 sobre os vieses desses juízes e **meça** a concordância com anotadores humanos, usando o kappa de Cohen.

**Projeto de síntese.** Construir um conjunto de avaliação dourado para um domínio escolhido, com protocolo de anotação, concordância entre anotadores e um relatório que decida, com a regra de aprovação do Capítulo 15, se uma nova versão do sistema pode ser promovida.

### Trilha E. Visão computacional e modelos multimodais

*Para quem quer ir além do texto.* **Pré-requisito:** Capítulos 7 e 9.

1. Retomar ♦ He et al. (ResNets) e ♦ Yosinski et al. (transferência).
2. Transformers para imagens: Dosovitskiy et al., *An image is worth 16x16 words* (ViT, 2021).
3. Texto e imagem em um espaço comum: Radford et al., *Learning transferable visual models from natural language supervision* (CLIP, 2021).
4. Modelos de difusão: Ho, Jain e Abbeel, *Denoising diffusion probabilistic models* (2020).

**Projeto de síntese.** Um sistema de busca de imagens por descrição em português, com avaliação por MRR e nDCG (Capítulo 15) e análise de falhas por categoria.

### Trilha F. IA responsável e governança

*Para quem decide, audita ou regula.* **Pré-requisito:** Capítulos 5, 11 e 15.

1. Documentação de modelos e dados: ♦ Mitchell et al. (*model cards*); ♦ Gebru et al. (*datasheets*).
2. Gestão de risco: ♦ NIST, AI RMF 1.0.
3. Normas: ♦ LGPD (Lei nº 13.709/2018) e ♦ Regulamento (UE) 2024/1689, lidos **nas fontes oficiais**.
4. Vieses e justiça algorítmica em avaliação: desdobrar as métricas do Capítulo 5 por subgrupo e discutir os conflitos entre definições de justiça.

**Projeto de síntese.** Um dossiê de governança completo para o sistema do Projeto 10: *model card*, *datasheet*, mapa de riscos, política de guardrails aplicada em código e plano de resposta a incidentes.

### Trilha G. Aprendizado por reforço

*Para quem quer agentes que aprendem pela interação.* **Pré-requisito:** Capítulos 2, 3 e 6.

1. ♦ Sutton e Barto, *Reinforcement Learning: An Introduction* (2. ed.), na íntegra.
2. Aprendizado por reforço profundo: Mnih et al., *Human-level control through deep reinforcement learning* (*Nature*, 2015); Schulman et al., *Proximal policy optimization algorithms* (2017).
3. Ligação com este livro: o laço agente–ambiente do Capítulo 2 é o mesmo do aprendizado por reforço, e a otimização de políticas por gradiente usa a regra da cadeia do Capítulo 6.

**Projeto de síntese.** Implementar do zero um agente com aprendizado por diferença temporal em um ambiente discreto, comparando taxa de aprendizado e fator de desconto com repetições suficientes para uma banda de confiança.

## Três projetos finais sugeridos

Para quem prefere fechar o estudo com uma obra própria, três propostas que usam o livro inteiro:

1. **Assistente de estudos com fontes.** RAG sobre o próprio material do leitor (Capítulo 12), com citação obrigatória, verificação de fidelidade (Capítulo 15) e recusa quando não há evidência.
2. **Analista de dados com aprovação humana.** Um agente que consulta uma base, calcula com ferramentas (e não "de cabeça"), mostra o que fará antes de qualquer ação com efeito externo e registra um traço de auditoria completo (Capítulos 13 a 15).
3. **Comparativo honesto de modelos.** Escolher uma tarefa, treinar um modelo clássico, uma rede pequena e um modelo de linguagem ajustado, e compará-los com validação cruzada, intervalos de confiança e análise de custo (Capítulos 4, 5, 6, 10 e 15).

Em qualquer um deles, comece pelo conjunto de testes e pela métrica, e só depois escreva o sistema.

## Palavra final

Uma ferramenta que hoje parece indispensável pode ser substituída em um ano. A razão pela qual um gradiente aponta para o crescimento da função, a razão pela qual o erro de teste supera o de treino, a razão pela qual dez passos de 95% de acerto não dão 95%: essas permanecem. Quem as tem consigo lê um artigo novo, avalia uma biblioteca nova e desconfia, com argumentos, de uma demonstração brilhante demais.

Estude com lápis e com um interpretador. Meça antes de afirmar. E, ao construir sistemas que agem no mundo, projete primeiro o que acontece quando eles erram.
