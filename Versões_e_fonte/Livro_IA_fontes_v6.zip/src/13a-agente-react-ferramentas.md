<div class="objetivos">

Objetivos do capítulo

- Definir **agente baseado em LLM** como uma política que, a cada passo, lê um histórico e decide uma **ação** (chamar uma ferramenta) ou a **resposta final**, e ligar essa definição à arquitetura sensores, programa, atuadores do Capítulo 2.
- Implementar e analisar o laço **ReAct** (raciocinar e agir), incluindo a interpretação do texto do modelo, a condição de parada e o limite de passos.
- Demonstrar que o custo em *tokens* de um laço sem cache cresce com o **quadrado** do número de passos, e verificar a fórmula por contagem exata.
- Projetar **ferramentas**: contrato tipado (JSON Schema e Pydantic), validação, execução segura (lista de permissões, nunca `eval`), erros devolvidos como observações.
- Comparar **ReAct**, **Plan-and-Solve** e **Reflexion**: quando cada um economiza chamadas, como o erro se acumula em tarefas longas e quanto vale um avaliador externo.
- Construir o **Projeto 9** (agente com quatro ferramentas e 60 tarefas com gabarito) e executar o mesmo laço no **LangChain** real, com um modelo roteirizado.
- Saber o que **não** foi medido: um "LLM" simulado mede a estrutura dos laços, e não a qualidade de um modelo real.

**Pré-requisitos:** Capítulo 2 (agentes, PEAS), Capítulo 11 (saídas estruturadas e contratos), Capítulo 12 (recuperação como ferramenta).

</div>

## 13.1 O que é um agente baseado em LLM

No Capítulo 2, um agente é "tudo que percebe seu ambiente por sensores e age sobre ele por atuadores", e os tipos (reativo, baseado em modelo, em objetivo, em utilidade) diferem em **como o programa do agente escolhe a ação**. Um **agente baseado em LLM** usa um modelo de linguagem como esse programa: o texto do histórico entra, a próxima decisão sai.

::: definicao 13.1 · Agente baseado em LLM
Seja $h_t=(x,\,a_1,o_1,\dots,a_{t-1},o_{t-1})$ o **histórico** no passo $t$: a tarefa $x$, as ações já tomadas $a_i$ e as observações $o_i$ que o ambiente devolveu. Um agente baseado em LLM é uma **política** $\pi_\theta$ que, a partir de $h_t$, produz $a_t\sim\pi_\theta(\cdot\mid h_t)$, em que $a_t$ é **uma chamada de ferramenta** $(f,\,\text{args})$ ou **uma resposta final**. O ambiente (ferramentas, bancos de dados, a web) devolve $o_t=\operatorname{executar}(a_t)$, que entra em $h_{t+1}$. O laço termina quando $a_t$ é uma resposta final, ou quando um limite de passos, de custo ou de tempo é atingido.
:::

Três componentes, além do modelo, completam o agente (Figura 13.1).

- **Percepção**: tudo que entra no histórico: a pergunta, os resultados das ferramentas, mensagens do usuário. É o equivalente dos *sensores*.
- **Memória**: o histórico recente dentro do contexto (memória de **curto prazo**) e o que fica **fora** dele para ser recuperado depois, como o índice vetorial do Capítulo 12 (memória de **longo prazo**).
- **Ação**: as ferramentas registradas. São os *atuadores*: pesquisar, calcular, executar código, consultar uma API, escrever um arquivo. **O que o agente pode fazer é o que as ferramentas deixam**, e esse é o principal controle de segurança (seção 13.3).

<figure>
+++ fig_c13_laco.svg
<figcaption><b>Figura 13.1.</b> O laço do agente. O modelo lê o histórico inteiro e decide uma ação ou a resposta final; o registro de ferramentas valida e executa a ação; a observação (resultado ou erro) entra no histórico e o laço recomeça.</figcaption>
</figure>

Em termos do **framework PEAS** (Capítulo 2), o ambiente de tarefa de um agente de LLM costuma ser **parcialmente observável** (o modelo só vê o que as ferramentas devolvem), **estocástico** (o mesmo histórico pode gerar saídas diferentes, e as ferramentas podem falhar), **sequencial** (o resultado de um passo condiciona o próximo), **dinâmico** quando as ferramentas acessam o mundo (a web muda) e **discreto** no espaço de ferramentas. É a combinação mais difícil da tipologia do Capítulo 2, e boa parte da engenharia consiste em **reduzir** essa dificuldade: ferramentas determinísticas, contratos estritos, limites de passos, ambientes que podem ser reiniciados.

::: atencao Nem toda tarefa pede um agente
A distinção prática (Anthropic, 2024, citado de memória) é entre ***workflows***, em que o **código** define a sequência de chamadas (por exemplo, o pipeline RAG do Capítulo 12: recuperar, montar o contexto, gerar), e ***agentes***, em que o **modelo** decide a sequência. Agentes trocam **previsibilidade, custo e latência** por **flexibilidade**. Se a sequência de passos é conhecida de antemão, um *workflow* é mais barato, mais rápido e mais fácil de testar. Use um agente quando o número e a ordem dos passos **dependem do que se encontra pelo caminho**.
:::

## 13.2 O padrão ReAct

O ReAct (*Reasoning and Acting*; Yao et al., 2023, citado de memória) alterna **raciocínio** em texto, **ação** (chamada de ferramenta) e **observação**. O raciocínio ("o que sei, o que falta") fica no histórico e orienta a próxima ação; a observação **ancora** o raciocínio em fatos devolvidos pelo ambiente, em vez de só na memória do modelo.

::: definicao 13.2 · Laço ReAct
Em cada passo, o modelo recebe o *prompt* (instruções, descrição das ferramentas, pergunta e o histórico) e devolve **um** de dois formatos:
```
Pensamento: <raciocínio curto>                    Pensamento: <raciocínio curto>
Ação: <nome da ferramenta>             ou         Resposta final: <valor>
Entrada: <JSON dos argumentos>
```
O programa **interpreta** o texto: se há "Resposta final", termina; se há "Ação" e "Entrada", valida e executa a ferramenta e acrescenta a **Observação** ao histórico; se não reconhece nenhum formato, devolve uma observação de erro ("formato inválido") e continua. Há um **limite de passos**.
:::

O código está no Projeto 9 (seção 13.8): a interpretação usa duas expressões regulares, e **todo** erro (formato inválido, ferramenta desconhecida, JSON malformado, argumentos fora do contrato, falha na execução) vira **observação**, nunca exceção. O agente **vê** o erro e pode corrigir-se. Esse princípio é a diferença entre um protótipo que quebra na primeira falha e um sistema que continua.

### O custo do histórico: crescimento quadrático

O modelo não tem memória entre chamadas: **a cada passo, o histórico inteiro é reenviado**. Isso tem uma consequência aritmética importante.

::: proposicao 13.1 · Custo em *tokens* do laço ReAct
Seja $P_0$ o tamanho do *prompt* inicial (instruções, ferramentas e pergunta) e $m_j$ o tamanho da $j$-ésima rodada (pensamento, ação e observação), $j=0,\dots,T-1$. Em um laço com $T$ ações seguidas da resposta final (isto é, $T+1$ chamadas ao modelo), **sem reaproveitamento de cache**, o total de *tokens* **de entrada** é
$$N_\text{entrada}\;=\;(T+1)\,P_0\;+\;\sum_{j=0}^{T-1} m_j\,(T-j).$$
Se as rodadas têm tamanho médio constante $m$, $N_\text{entrada}=(T+1)P_0+m\,\dfrac{T(T+1)}{2}$, que é um polinômio **quadrático** em $T$ com coeficiente dominante $m/2$.
:::

::: demonstracao
A chamada de índice $t\in\{0,\dots,T\}$ recebe $P_0$ mais as rodadas já concluídas, $j<t$. Logo, $N=\sum_{t=0}^{T}\bigl(P_0+\sum_{j<t}m_j\bigr)=(T+1)P_0+\sum_{j=0}^{T-1}m_j\,\#\{t:\,j<t\le T\}$, e o número de chamadas que incluem a rodada $j$ é $T-j$. Com $m_j=m$, $\sum_{j=0}^{T-1}(T-j)=T(T+1)/2$.
:::

O experimento 2 do Projeto 9 conta as palavras do *prompt* de verdade (ReAct sem erros, tarefa de $T$ somas encadeadas) e compara com a fórmula.

<<< codigo/p9_exp2_custo.py

>>> codigo/p9_exp2_custo.out

A fórmula **coincide exatamente** com a contagem em todos os $T$. Para $T=32$ são $13\,398$ palavras de entrada, **$3{,}0$ vezes** as $4\,454$ de $T=16$: o custo por passo sobe de $127$ para $406$ palavras ($T=1$ contra $T=32$). A figura 13.2 (painel direito) mostra a curva. Em um agente de $5$ passos o efeito é pequeno; em um de $50$, domina a conta. As respostas são: **limitar o número de passos**, **resumir** ou **podar** o histórico (seção 13.7), usar **cache de prefixo** (provedores cobram menos pelos *tokens* repetidos, o que reduz o custo, mas **não** a latência de enviar nem o limite da janela) e **planejar** em vez de reagir (seção 13.5). *Aqui, "palavras" substitui "tokens", e a razão entre os dois depende do tokenizador (Capítulo 10).*

## 13.3 Chamada de ferramentas

Uma **ferramenta** é uma função que o agente pode pedir ao programa para executar. O modelo **não executa nada**: ele escreve texto que **descreve** uma chamada, e quem executa é o seu código. Isso tem duas consequências: a segurança está **no seu código**, e o contrato da ferramenta precisa ser **explícito e verificado**.

::: definicao 13.3 · Ferramenta e contrato
Uma ferramenta é uma tupla (nome, descrição, esquema de argumentos, função). O **esquema** (em geral, um JSON Schema) declara os argumentos, seus tipos e restrições (intervalos, padrões, obrigatoriedade). O **contrato** é cumprido em três camadas: **(i)** o modelo vê o nome, a descrição e o esquema, e deve produzir argumentos que os respeitem; **(ii)** o programa **valida** os argumentos recebidos contra o esquema **antes** de executar; **(iii)** a execução é **protegida**: erros e limites de tempo viram observações.
:::

Os mesmos modelos Pydantic do Capítulo 11 definem o contrato e **geram** o esquema que o modelo vê:

<<< codigo/c13_ferramentas.py

>>> codigo/c13_ferramentas_demo.out

Seis observações sobre o que a demonstração mostra, e que valem para qualquer ferramenta.

1. **A descrição é *prompt*.** O modelo escolhe a ferramenta pelo nome e pela descrição; nomes vagos ou descrições ambíguas causam escolhas erradas. Escreva-as como documentação para alguém que **nunca viu** o sistema.
2. **Restrições no esquema** (`ge=1, le=11`, `pattern`) rejeitam argumentos absurdos antes de chegar à função. A observação de erro diz **o que** violou, o que ajuda o modelo a corrigir. (Por padrão, o Pydantic **ignora** campos extras; para uma API mais estrita, use `extra="forbid"`.)
3. **Passar no esquema não é ter sucesso**: `palavras_secao("99.9")` é válido no formato e falha na execução, e o registro devolve o erro como observação.
4. **Ferramentas que executam código são perigosas.** Chamar `eval(expressao)` com texto vindo do modelo é uma **execução remota de código** nas mãos de quem controla o texto (o usuário, ou uma página web lida pelo agente). A calculadora do projeto **interpreta** a árvore sintática (`ast`) com uma **lista de permissões** (números, operadores aritméticos, `sqrt`, `log` etc.): tudo o mais, incluindo chamadas, atributos e `lambda`, é **recusado**. Uma **lista de permissões** é segura por construção; uma **lista de bloqueios** ("recuse `os` e `open`") sempre deixa algo de fora (Exercício 13.10). Para código arbitrário, só **sandbox** isolado (contêiner ou máquina virtual sem rede e com limites de CPU e memória).
5. **O limite de recursos faz parte do contrato**: a calculadora recusa expoentes grandes (`9**9**9` consumiria a máquina) e expressões profundas ou longas. Todo laço precisa de **limite de passos**, de **tempo** e de **custo**.
6. **O princípio do menor privilégio.** Registre só as ferramentas necessárias, com o menor poder possível (leitura antes de escrita, um diretório em vez do disco todo). Ações **irreversíveis** ou com efeito externo (enviar e-mail, pagar, apagar) devem exigir **aprovação humana** (Capítulo 14).

### As mesmas ferramentas no LangChain

O LangChain (versão $1{,}5$ nas execuções deste livro) gera o esquema a partir da assinatura e da docstring com o decorador `@tool`, e a função `create_agent` monta o laço sobre o LangGraph (Capítulo 14). O programa abaixo usa **ferramentas e laço reais**, mas um **modelo roteirizado**: ele não consulta nenhum LLM e devolve três respostas pré-escritas.

<<< codigo/c13_langchain.py

>>> codigo/c13_langchain.out

Vê-se o fluxo de mensagens do agente (humana, IA com `tool_calls`, ferramenta, IA, ferramenta, IA final) e o tratamento de um argumento fora do contrato: o LangChain devolve uma **mensagem de ferramenta com o erro**, o laço continua e o "modelo" (roteirizado) responde que não conseguiu. Nada disso diz que **um modelo real** escolheria bem as ferramentas ou os argumentos, e por isso essa parte do livro é **não executada** com um LLM: com chave de API, basta trocar o `ModeloRoteirizado` por `init_chat_model("<provedor>:<modelo>")`, e o restante do código é o mesmo (os nomes de provedores e de modelos mudam rápido; consulte a documentação).
