"""Figuras do Capítulo 13 (SVG), a partir das saídas reais de codigo/p9_*.out."""
import re

import numpy as np

from figs_c6 import curva, fmt, legenda, painel, salvar
from figs_c9 import SETA, caixa, rotulo, seta

# ---------- Figura 13.1: o laço do agente ----------
c = [SETA]
def bloco(x, y, w, h, cls, linhas, topo=None):
    out = [f'<rect class="{cls}" x="{x}" y="{y}" width="{w}" height="{h}" rx="8"/>']
    y0 = y + h / 2 - (len(linhas) - 1) * 8 + 4
    for i, (t, st) in enumerate(linhas):
        out.append(f'<text x="{x + w / 2}" y="{y0 + 16 * i}" font-size="{13 if i == 0 else 11}" text-anchor="middle"' + (' font-weight="600"' if i == 0 else '') + (' class="t2"' if st else '') + f'>{t}</text>')
    return "".join(out)
c.append(bloco(10, 100, 100, 56, "cxa", [("Pergunta", 0), ("do usuário", 1)]))
c.append(bloco(160, 70, 170, 116, "cx", [("Modelo (LLM)", 0), ("motor de raciocínio", 1), ("lê o histórico inteiro", 1), ("e decide o próximo passo", 1)]))
c.append(bloco(410, 40, 150, 64, "cxm", [("Registro de ferramentas", 0), ("valida e executa", 1)]))
c.append(bloco(410, 150, 150, 52, "cxg", [("Memória", 0), ("curta e longa", 1)]))
c.append(bloco(600, 100, 100, 56, "cxa", [("Resposta", 0), ("final", 1)]))
c.append(seta(110, 128, 160, 128))
c.append(seta(330, 95, 410, 72))
c.append(rotulo(372, 70, "Ação", 11, "t2"))
c.append('<path class="seta" d="M485,40 C485,8 245,8 245,70"/>')
c.append(rotulo(365, 20, "Observação (resultado ou erro) volta ao histórico", 11, "t2"))
c.append('<line class="seta" x1="330" y1="168" x2="410" y2="176"/><line class="seta" x1="410" y1="190" x2="330" y2="182"/>')
c.append(rotulo(372, 214, "lê e escreve", 11, "t2"))
c.append(seta(330, 128, 600, 128))
c.append(rotulo(465, 122, "ou: Resposta final", 11, "t2"))
salvar("fig_c13_laco.svg", 720, 230, "Laço do agente: o modelo lê o histórico e decide uma ação ou a resposta final; o registro de ferramentas valida e executa a ação; a observação volta ao histórico", c)

# ---------- leitura das saídas ----------
e1 = open("codigo/p9_exp1_estrategias.out").read()
estr = {}
for bloco in re.split(r"== ", e1)[1:]:
    nome = bloco.splitlines()[0].strip()
    estr[nome] = [(float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4))) for m in
                  re.finditer(r"p=([\d.]+)\s+acerto ([\d.]+) \[[\d.;\s]+\]\s+chamadas\s+([\d.]+)\s+palavras\s+(\d+)", bloco)]
e2 = open("codigo/p9_exp2_custo.out").read()
lin2 = [list(map(int, re.findall(r"\d+", l)[:2])) + [int(re.findall(r"\d+", l.split("|")[1])[0])] for l in e2.splitlines() if re.match(r"\s+\d+\s+\d+\s+\d+\s+(True|False)", l)]
T = [l[0] for l in lin2]
# ---------- Figura 13.2: acerto contra p; custo contra T ----------
c = []
s, X, Y = painel(60, 20, 250, 210, 0, 0.3, 0.45, 1.0, [0, 0.1, 0.2, 0.3], [0.5, 0.6, 0.7, 0.8, 0.9, 1.0], "taxa de erro p por decisão", "acerto")
c += s
cl = {"ReAct": ("lv", None), "Plan-and-Solve": ("la", "6 3"), "Reflexion rho=1": ("lg", None), "Reflexion rho=0.5": ("lm", "3 3")}
for nome, (cls, d) in cl.items():
    pts = estr[nome]
    c.append(curva(X, Y, [p[0] for p in pts], [p[1] for p in pts], cls, d))
s, X2, Y2 = painel(400, 20, 250, 210, 0, 32, 0, 14000, [0, 8, 16, 24, 32], [0, 4000, 8000, 12000], "passos T", "palavras de entrada")
c += s
c.append(curva(X2, Y2, T, [l[1] for l in lin2], "lv", None))
c.append(curva(X2, Y2, T, [l[2] for l in lin2], "la", "6 3"))
c += legenda([("lv", "ReAct", None), ("la", "Plan-and-Solve", "6 3"), ("lg", "Reflexion (ρ=1)", None), ("lm", "Reflexion (ρ=0,5)", "3 3")], 40, 290, 150)
salvar("fig_c13_resultados.svg", 700, 310, "À esquerda, acerto de ReAct, Plan-and-Solve e Reflexion contra a taxa de erro do modelo simulado; à direita, palavras de entrada contra o número de passos para ReAct e Plan-and-Solve", c)
print("ok", T, estr["ReAct"][:2])
