## 9.5 Codificação posicional

Pelo Teorema 9.4, sem informação de posição a autoatenção trata a sequência como um **conjunto**. A solução do Transformer original é somar às entradas um vetor que depende da posição.

::: definicao 9.4 · Codificação posicional senoidal
Para a posição $p\in\{0,1,2,\dots\}$ e a dimensão par $d$, o vetor $\operatorname{PE}(p)\in\mathbb{R}^{d}$ tem coordenadas
$$\operatorname{PE}(p)_{2i}=\sin(\omega_ip),\qquad \operatorname{PE}(p)_{2i+1}=\cos(\omega_ip),\qquad \omega_i=10000^{-2i/d},\quad i=0,\dots,\tfrac d2-1.$$
A entrada da primeira camada é $\mathbf{x}_p+\operatorname{PE}(p)$, em que $\mathbf{x}_p$ é o *embedding* do token na posição $p$.
:::

As frequências $\omega_i$ formam uma progressão geométrica de $1$ a $\approx10^{-4}$: as primeiras coordenadas oscilam rapidamente (comprimento de onda de $2\pi\approx6$ posições) e as últimas, devagar ($\approx60\,000$ posições, para $d$ grande). É um "relógio" de vários ponteiros, como os dígitos de um contador, em que cada dígito muda em uma escala diferente.

::: proposicao 9.7 · Posições senoidais e deslocamentos
(a) Para todo deslocamento $k$, existe uma matriz $\mathbf{M}_k$, **independente de $p$**, tal que $\operatorname{PE}(p+k)=\mathbf{M}_k\operatorname{PE}(p)$; $\mathbf{M}_k$ é bloco-diagonal, com blocos de rotação $2\times2$ de ângulos $\omega_ik$.
(b) O produto escalar entre duas posições depende **apenas da distância**: $\operatorname{PE}(p)^{\top}\operatorname{PE}(p+k)=\sum_{i}\cos(\omega_ik)$. Em particular, $\lVert\operatorname{PE}(p)\rVert^2=d/2$ para todo $p$.
:::

::: demonstracao
(a) Pelas fórmulas da soma de ângulos, $\sin(\omega(p+k))=\sin\omega p\cos\omega k+\cos\omega p\sin\omega k$ e $\cos(\omega(p+k))=\cos\omega p\cos\omega k-\sin\omega p\sin\omega k$. Em forma matricial,
$$\begin{pmatrix}\sin\omega(p+k)\\ \cos\omega(p+k)\end{pmatrix}=\begin{pmatrix}\cos\omega k&\sin\omega k\\ -\sin\omega k&\cos\omega k\end{pmatrix}\begin{pmatrix}\sin\omega p\\ \cos\omega p\end{pmatrix},$$
uma rotação que não depende de $p$. Aplicando isso a cada par $(2i,2i+1)$ com $\omega=\omega_i$, obtém-se $\mathbf{M}_k$. (b) Em cada par, $\sin\omega p\sin\omega(p+k)+\cos\omega p\cos\omega(p+k)=\cos(\omega k)$ pela fórmula do cosseno da diferença. Somando sobre os $d/2$ pares, obtém-se $\sum_i\cos(\omega_ik)$; com $k=0$, a soma vale $d/2$.
:::

O programa a seguir confere os dois itens sobre todas as posições de 0 a 199.

<<< codigo/c9_posicional.py

>>> codigo/c9_posicional.out

Os erros de $(a)$ ficam em $10^{-14}$, e os produtos escalares do item $(b)$ são **idênticos** para todo $p$ (mínimo e máximo coincidem). Note que $\sum_i\cos(\omega_ik)$ não é monótona em $k$, mas decresce em geral com a distância ($8{,}0$ em $k=0$, $6{,}1$ em $k=5$, $3{,}5$ em $k=100$).

::: atencao O que a proposição garante e o que não garante
A Proposição 9.7 vale para os **vetores** $\operatorname{PE}(p)$. Depois de passar por $\mathbf{W}_Q$ e $\mathbf{W}_K$, a pontuação $\mathbf{q}_p^{\top}\mathbf{k}_{p'}$ mistura conteúdo e posição, e **nada garante** que dependa só da distância. O que a propriedade oferece é que **a informação de deslocamento relativo é acessível por uma transformação linear**, o que facilita o aprendizado de padrões como "o token três posições atrás".
:::

### Alternativas

- **Embeddings de posição aprendidos:** uma tabela $\mathbf{P}\in\mathbb{R}^{P\times d}$ treinada com o resto do modelo (BERT, GPT-2). Simples e flexível, mas limitada a $P$ posições.
- **Posições relativas:** a pontuação recebe um termo que depende de $j-i$ (Shaw, Uszkoreit e Vaswani, 2018; o T5 usa um viés relativo aprendido).
- **Rotações (RoPE):** Su e colegas (2021) rodam $\mathbf{q}$ e $\mathbf{k}$ por ângulos proporcionais à posição, de modo que o produto escalar entre elas depende **exatamente** da distância relativa; é a escolha de muitos modelos de linguagem recentes.
- **ALiBi:** Press, Smith e Lewis (2022) somam à pontuação uma penalidade linear na distância, e o objetivo é extrapolar para sequências mais longas do que as do treino.

## 9.6 O bloco Transformer

### Normalização de camada

::: definicao 9.5 · Normalização de camada
Dado um vetor $\mathbf{x}\in\mathbb{R}^{d}$ (o estado de **uma** posição), a normalização de camada (*layer normalization*, Ba, Kiros e Hinton, 2016) é
$$\operatorname{LN}(\mathbf{x})=\boldsymbol\gamma\odot\frac{\mathbf{x}-\mu\mathbf{1}}{\sqrt{\sigma^2+\varepsilon}}+\boldsymbol\beta,\qquad \mu=\frac1d\sum_ix_i,\quad \sigma^2=\frac1d\sum_i(x_i-\mu)^2,$$
com $\boldsymbol\gamma,\boldsymbol\beta\in\mathbb{R}^{d}$ parâmetros aprendidos (escala e deslocamento).
:::

Compare com a normalização em lote (*batch normalization*) do Capítulo 6: lá, as estatísticas são calculadas **sobre o lote**, para cada característica; aqui, **sobre as características**, para cada exemplo e cada posição. Por isso a LayerNorm não depende do tamanho do lote, funciona com lote $1$ e com comprimentos variáveis, e se comporta do mesmo modo no treino e na inferência, sem estatísticas móveis, o que a torna a escolha natural para sequências.

### Rede por posição e conexões residuais

A atenção mistura informação **entre** posições; a **rede por posição** (*position-wise feed-forward*) processa cada posição **separadamente**, com o mesmo MLP de duas camadas:
$$\operatorname{FFN}(\mathbf{x})=\mathbf{W}_2\,\varphi(\mathbf{W}_1\mathbf{x}+\mathbf{b}_1)+\mathbf{b}_2,\qquad \mathbf{W}_1\in\mathbb{R}^{d_\mathrm{ff}\times d},\ \mathbf{W}_2\in\mathbb{R}^{d\times d_\mathrm{ff}},$$
em geral com $d_\mathrm{ff}=4d$ e $\varphi$ igual à ReLU (Transformer original) ou à GELU (BERT, GPT). É na FFN que boa parte do "conhecimento" do modelo parece ficar guardada, e é nela que está a maior parte dos parâmetros.

Cada subcamada é envolvida por uma **conexão residual**, $\mathbf{x}\mapsto\mathbf{x}+F(\mathbf{x})$. Pelo Teorema 7.5, o jacobiano passa a ser $\mathbf{I}+\partial F/\partial\mathbf{x}$, e o gradiente tem um caminho direto, sem atravessar a subcamada, o que permite empilhar dezenas de blocos.

::: definicao 9.6 · Bloco Transformer (pré-LN)
Com $\mathbf{X}\in\mathbb{R}^{T\times d}$, um **bloco** (da variante pré-LN, usada na maioria dos modelos atuais) calcula
$$\mathbf{X}'=\mathbf{X}+\operatorname{MHA}\bigl(\operatorname{LN}_1(\mathbf{X})\bigr),\qquad \mathbf{X}''=\mathbf{X}'+\operatorname{FFN}\bigl(\operatorname{LN}_2(\mathbf{X}')\bigr).$$
No Transformer original (variante **pós-LN**), a normalização vem **depois** da soma: $\operatorname{LN}(\mathbf{X}+F(\mathbf{X}))$.
:::

<figure>
+++ fig_c9_bloco.svg
<figcaption><b>Figura 9.2.</b> Um bloco Transformer pré-LN e a pilha de um modelo decodificador. A linha vertical contínua é o fluxo residual: as subcamadas <b>somam</b> a ele, e não o substituem.</figcaption>
</figure>

A diferença entre as variantes é prática: na pós-LN, a normalização fica no caminho principal do gradiente, e o treino sem aquecimento da taxa de aprendizado tende a ser instável; na pré-LN, o fluxo residual permanece intacto, e o treino é mais estável (Xiong e colegas, 2020). O preço, em alguns casos, é uma qualidade final ligeiramente menor.

### Contando parâmetros

::: proposicao 9.8 · Parâmetros do bloco e do modelo
Um bloco pré-LN com dimensão $d$, $d_\mathrm{ff}=4d$ e vieses tem $12d^2+13d$ parâmetros: $4d^2+4d$ na atenção, $8d^2+5d$ na rede por posição e $4d$ nas duas normalizações. Um modelo decodificador com vocabulário $V$, $P$ posições aprendidas, $N$ blocos e pesos de saída amarrados aos da entrada tem
$$V\,d+P\,d+N\,(12d^2+13d)+2d$$
parâmetros, em que o último termo é a normalização final.
:::

::: demonstracao
Atenção: Proposição 9.6. Rede por posição: $\mathbf{W}_1$ tem $4d\cdot d$ pesos e $4d$ vieses, $\mathbf{W}_2$ tem $d\cdot4d$ pesos e $d$ vieses, no total $8d^2+5d$. Cada LayerNorm tem $\boldsymbol\gamma$ e $\boldsymbol\beta$, $2d$ parâmetros, e há duas por bloco. A soma é $4d^2+4d+8d^2+5d+4d=12d^2+13d$. O modelo acrescenta a tabela de *embeddings* de tokens ($Vd$), a de posições ($Pd$) e a LayerNorm final ($2d$); os pesos da camada de saída são a transposta da tabela de tokens e não contam de novo.
:::

O programa confere a proposição com `torch` (um bloco) e com o `GPT2LMHeadModel` da biblioteca `transformers` (modelo completo), e aplica a fórmula às dimensões do GPT-2 pequeno.

<<< codigo/c9_bloco.py

>>> codigo/c9_bloco.out

A fórmula reproduz **exatamente** os parâmetros do bloco e do modelo minúsculo. Com $V=50\,257$, $P=1\,024$, $N=12$ e $d=768$ ela dá $124{,}4$ milhões, o tamanho conhecido do GPT-2 pequeno, e com $N=24$ e $d=1\,024$, $354{,}8$ milhões, o do GPT-2 médio. Duas lições: a rede por posição concentra $2/3$ dos parâmetros de um bloco ($8d^2$ de $12d^2$); e, em modelos pequenos, a tabela de *embeddings* é uma fração relevante do total ($26{,}5\%$ no modelo minúsculo do programa).

## 9.7 As três famílias

O bloco é o mesmo; o que muda é **qual máscara** a atenção usa, **qual objetivo** treina o modelo e **como** o resultado é usado.

| Família | Atenção | Objetivo de pré-treino | Exemplos | Uso típico |
|---|---|---|---|---|
| Codificador | bidirecional (sem máscara causal) | linguagem mascarada | BERT | classificação, extração, busca por similaridade |
| Decodificador | causal | prever o próximo token | família GPT | geração de texto, modelos de linguagem de uso geral |
| Codificador-decodificador | bidirecional no codificador; causal no decodificador, com atenção cruzada | reconstruir texto corrompido | T5, BART | tradução, resumo |

### Codificadores: BERT

O BERT (Devlin e colegas, 2019) usa apenas a pilha de blocos **sem** máscara causal: cada posição enxerga as da esquerda e as da direita, e a representação resultante, rica em contexto, serve a tarefas de classificação e extração. Como não há um "próximo token" a prever, o pré-treino usa a **modelagem de linguagem mascarada** (MLM): sorteia-se $15\%$ das posições; em $80\%$ delas o token é trocado por um símbolo especial de máscara, em $10\%$ por um token aleatório e em $10\%$ permanece, e a perda é a entropia cruzada **apenas nessas posições**. Os $10\%$ inalterados e os $10\%$ aleatórios evitam que o modelo aprenda somente a reagir ao símbolo de máscara, que não aparece nos usos finais.

### Decodificadores: família GPT

O decodificador usa a máscara causal e o objetivo de **modelagem de linguagem autorregressiva**. Pela regra da cadeia da probabilidade,
$$p_\theta(x_1,\dots,x_T)=\prod_{t=1}^{T}p_\theta(x_t\mid x_{<t}),\qquad \mathcal{L}(\theta)=-\sum_{t=1}^{T}\log p_\theta(x_t\mid x_{<t}).$$
A Proposição 9.5 garante que a saída na posição $t$ só usa $x_{\le t}$, de modo que **todas as $T$ previsões são calculadas em um único passo para frente**, com o alvo em $t$ igual à entrada em $t+1$ (o deslocamento de uma posição). É a vantagem de paralelismo sobre a RNN do Capítulo 8, que precisava de $T$ passos sequenciais para o mesmo cálculo. A geração, em contrapartida, é **sequencial**: cada token depende do anterior (seção 9.8). A família GPT (Radford e colegas, 2018, 2019; Brown e colegas, 2020) e a maioria dos grandes modelos de linguagem de uso geral seguem este desenho.

### Codificador-decodificador: T5 e BART

O Transformer original (Vaswani e colegas, 2017) tinha as duas pilhas. O **codificador** lê a entrada sem máscara causal; o **decodificador** gera a saída com máscara causal e, em cada bloco, uma subcamada de **atenção cruzada** (Definição 9.2) em que as consultas vêm do decodificador, e as chaves e os valores, da saída final do codificador. O T5 (Raffel e colegas, 2020) formula toda tarefa como **texto para texto** e pré-treina corrompendo trechos do texto, que o decodificador deve reconstruir. O BART (Lewis e colegas, 2020) é um autocodificador de remoção de ruído: corrompe o texto de várias formas e treina o modelo a reconstruí-lo.

<figure>
+++ fig_c9_familias.svg
<figcaption><b>Figura 9.3.</b> Quem pode atender a quem. Em cada painel, a linha é a posição que consulta e a coluna é a posição consultada; célula preenchida = atenção permitida. O codificador vê tudo; o decodificador, só o passado; na atenção cruzada, o decodificador (linhas) vê toda a entrada do codificador (colunas).</figcaption>
</figure>

O programa abaixo instancia as três famílias, **sem pesos pré-treinados** e em tamanho minúsculo, e verifica as propriedades de máscara.

<<< codigo/c9_familias.py

>>> codigo/c9_familias.out

Mudar os tokens das posições $5$ a $7$ **altera** as saídas em $t<5$ do BERT (em $7{,}2$ nos logits) e **não altera** as do GPT-2 (exatamente $0$): é a Proposição 9.5 em ação. No T5, trocar a entrada do codificador muda as saídas do decodificador em $2{,}8$ (atenção cruzada), e trocar os tokens futuros do alvo não altera as saídas anteriores. Sem treino, as perdas são da ordem de $\ln V=4{,}605$, o valor de um modelo que chuta uniformemente entre os $V=100$ tokens: $3{,}884$ no BERT (só as duas posições mascaradas contam) e $6{,}194$ no GPT-2. Com pesos aleatórios, o desvio em relação a $\ln V$ reflete a inicialização, e não aprendizado.

## 9.8 Treino, inferência e o custo da atenção

### Treino em paralelo, geração em série

No treino de um decodificador, a sequência inteira entra de uma vez e a máscara causal garante que não haja vazamento; isso se chama **forçamento do professor** (*teacher forcing*) e é totalmente paralelo no tempo. Na **geração**, porém, o token $x_t$ só existe depois de amostrado, e o próximo passo depende dele. A geração é, portanto, **sequencial**: $T$ passagens pelo modelo.

### Cache de chaves e valores

Na geração, recalcular as chaves e os valores de **todo** o prefixo a cada novo token é desperdício: as posições anteriores não mudaram, e (pela máscara causal) o que elas calculam não depende do token novo. O **cache de chaves e valores** (*KV cache*) guarda, para cada camada, os $\mathbf{k}_j$ e $\mathbf{v}_j$ já calculados; o passo novo calcula **só** a consulta, a chave e o valor da posição nova e atende ao cache.

O programa a seguir mede o custo.

<<< codigo/c9_cache_custo.py

>>> codigo/c9_cache_custo.out

Os resultados dizem quatro coisas:

1. **Custo quadrático.** O tempo de uma camada de atenção, para $d_k=64$ e $8$ cabeças, vai de $0{,}7$ ms em $T=256$ a $83$ ms em $T=4\,096$; nas dobras maiores, a razão fica em torno de $3{,}2$ a $3{,}7\times$, caminhando para o $4\times$ teórico (as medidas iniciais são ruidosas, pois o tempo é pequeno e a CPU tem apenas $2$ núcleos). A matriz $T\times T$ de cada cabeça, caso fosse materializada, ocuparia $512$ MiB em $T=4\,096$.
2. **O cache não muda o resultado.** A geração gulosa de $300$ tokens produz **exatamente** os mesmos tokens com e sem cache.
3. **O ganho medido é modesto em um modelo minúsculo:** $2{,}0\times$ ($0{,}83$ s contra $1{,}64$ s). Em modelos pequenos e prefixos curtos, o custo de cada passagem é dominado por sobrecarga, e não por aritmética, de modo que recalcular o prefixo é barato.
4. **Na contagem de operações, o ganho cresce com o comprimento:** o número de produtos $\mathbf{q}^{\top}\mathbf{k}$ com cache é $\sum_tt=O(T^2)$, e sem cache, $\sum_tt(t+1)/2=O(T^3)$, razão $T/3$ aproximadamente: $34\times$ em $T=100$ e $3\,334\times$ em $T=10\,000$.

O preço do cache é **memória**: $2\cdot N\cdot d$ números por token (a chave e o valor de cada camada). Em um modelo com $N=32$ camadas e $d=4\,096$, em *float16*, são $512$ KiB por token e **$2$ GiB para um único contexto de $4\,096$ tokens**, por sequência do lote. Em modelos grandes, é a memória do cache, e não a aritmética, que limita quantos usuários o servidor atende. Daí as variantes que **reduzem** o cache compartilhando chaves e valores entre cabeças: *multi-query attention* (Shazeer, 2019) e *grouped-query attention* (Ainslie e colegas, 2023).

### Reduzindo o custo da atenção

O custo de $O(T^2)$ em tempo e memória é o gargalo para contextos longos. O **FlashAttention** (Dao e colegas, 2022) calcula a atenção **exata**, com o mesmo resultado, mas reorganiza o cálculo em blocos que cabem na memória rápida do acelerador e **evita materializar** a matriz $T\times T$; o tempo continua quadrático, mas a memória passa a ser linear em $T$. Outras abordagens trocam a atenção densa por padrões esparsos ou por aproximações lineares; elas **mudam** o resultado e não serão tratadas aqui. A função `F.scaled_dot_product_attention` do PyTorch, usada no programa acima, escolhe uma implementação eficiente conforme o hardware.
