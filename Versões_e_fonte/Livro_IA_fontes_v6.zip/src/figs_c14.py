"""Figuras do Capítulo 14 (SVG), a partir das saídas reais de codigo/p10_*.out."""
import re

from figs_c6 import curva, fmt, legenda, painel, salvar
from figs_c9 import SETA, caixa, rotulo, seta


def duas(x1, y1, x2, y2, d=5):
    """Duas setas paralelas em sentidos opostos (ida e volta)."""
    import math
    dx, dy = x2 - x1, y2 - y1
    n = math.hypot(dx, dy)
    ox, oy = -dy / n * d, dx / n * d
    return seta(x1 + ox, y1 + oy, x2 + ox, y2 + oy) + seta(x2 - ox, y2 - oy, x1 - ox, y1 - oy)


# ---------- Figura 14.1: anatomia de um grafo com estado ----------
c = [SETA]
c.append('<rect class="cxa" x="10" y="92" width="70" height="36" rx="18"/><text x="45" y="115" font-size="12" text-anchor="middle">START</text>')
c.append(caixa(130, 82, 130, 56, "nó: modelo", "cx"))
c.append(caixa(380, 14, 140, 52, "nó: ferramentas", "cxm"))
c.append('<rect class="cxa" x="620" y="104" width="70" height="36" rx="18"/><text x="655" y="127" font-size="12" text-anchor="middle">END</text>')
c.append(seta(80, 110, 130, 110))
c.append(rotulo(105, 102, "fixa", 10, "t2"))
c.append('<path class="seta" d="M230,82 C230,40 330,40 380,40"/>')
c.append('<text x="120" y="22" font-size="11" class="t2">condicional: há chamada</text><text x="120" y="36" font-size="11" class="t2">de ferramenta?</text>')
c.append('<path class="seta" d="M450,66 C450,100 330,100 262,100"/>')
c.append('<text x="470" y="84" font-size="11" class="t2">fixa: ferramentas → modelo</text><text x="470" y="98" font-size="11" class="t2">(fecha o ciclo)</text>')
c.append(seta(260, 122, 620, 122))
c.append(rotulo(440, 140, "condicional: não há chamada → END", 11, "t2"))
c.append('<rect class="cxg" x="10" y="174" width="700" height="52" rx="8"/>')
c.append('<text x="360" y="196" font-size="13" text-anchor="middle" font-weight="600">Estado compartilhado</text>')
c.append('<text x="360" y="214" font-size="11" text-anchor="middle" class="t2">esquema de chaves, um redutor por chave; cada nó devolve uma atualização parcial</text>')
c.append(rotulo(360, 166, "cada passo: os nós prontos executam e as atualizações são fundidas pelos redutores", 10, "t2"))
salvar("fig_c14_anatomia.svg", 720, 236, "Anatomia de um grafo com estado: nós, arestas fixas, arestas condicionais e o estado compartilhado que todos os nós leem e atualizam", c)

# ---------- Figura 14.2: arquitetura do Projeto 10 ----------
c = [SETA]
sx, sy, sw, sh = 290, 112, 140, 64
c.append(caixa(sx, sy, sw, sh, "supervisor", "cxa", 15))
def bx(x, y, cl, t, sub):
    return (f'<rect class="{cl}" x="{x}" y="{y}" width="160" height="56" rx="8"/><text x="{x + 80}" y="{y + 25}" font-size="13" text-anchor="middle">{t}</text>'
            f'<text x="{x + 80}" y="{y + 43}" font-size="10" text-anchor="middle" class="t2">{sub}</text>')
esq = [("pesquisadores ×n", "em paralelo (Send)", "cxm", 40), ("calculador", "calculadora do Projeto 9", "cx", 116), ("redator", "pode errar em silêncio", "cx", 192)]
dir_ = [("revisor", "confere texto × fatos", "cx", 40), ("aprovador (humano)", "pausa: interrupt()", "cxg", 116), ("publicador", "efeito irreversível, idempotente", "cxm", 192)]
for t, sub, cl, y in esq:
    c.append(bx(30, y, cl, t, sub))
    c.append(duas(190, y + 28, sx, sy + sh / 2 + (y - 116) * 0.22))
for t, sub, cl, y in dir_:
    c.append(bx(530, y, cl, t, sub))
    c.append(duas(530, y + 28, sx + sw, sy + sh / 2 + (y - 116) * 0.22))
c.append(rotulo(360, 22, "Todo trabalhador devolve o controle ao supervisor, que decide o próximo passo olhando o estado", 11, "t2"))
c.append(rotulo(360, 218, "revisor e redator formam um ciclo", 10, "t2"))
c.append('<rect class="cxg" x="30" y="268" width="660" height="40" rx="8" style="opacity:.75"/>')
c.append('<text x="360" y="293" font-size="13" text-anchor="middle">Checkpointer: grava o estado após cada passo (retomar, pausar, bifurcar)</text>')
salvar("fig_c14_projeto10.svg", 720, 318, "Arquitetura do Projeto 10: um supervisor central roteia para pesquisadores paralelos, calculador, redator, revisor, aprovador humano e publicador, sobre um checkpointer", c)

# ---------- leitura das saídas ----------
e1 = open("codigo/p10_exp1_revisao_humano.out").read().split("B. Revisor")[0]
A = {}
for m in re.finditer(r"^\s*([\d.]+)\s+(\d)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)$", e1, re.M):
    q, R = float(m.group(1)), int(m.group(2))
    A.setdefault(q, []).append((R, float(m.group(3)), float(m.group(4))))
e2 = open("codigo/p10_exp2_falhas.out").read()
F = {}
for m in re.finditer(r"^\s*([\d.]+)\s+(sim|não)\s+(sim|não)\s+\|\s+([\d.]+)\s+([\d.]+)", e2, re.M):
    f, ck, idem, nf, ferr = float(m.group(1)), m.group(2), m.group(3), float(m.group(4)), float(m.group(5))
    if idem == "sim":
        F.setdefault(ck, {})[f] = ferr
base = F["sim"][0.0]

# ---------- Figura 14.3 ----------
c = []
s, X, Y = painel(60, 20, 260, 200, 0, 3, 0.6, 1.0, [0, 1, 2, 3], [0.6, 0.7, 0.8, 0.9, 1.0], "refações permitidas R", "relatórios corretos")
c += s
cls = {1.0: ("lv", None), 0.7: ("la", "6 3"), 0.4: ("lr", "3 3")}
for q, (cl, d) in cls.items():
    pts = A[q]
    c.append(curva(X, Y, [p[0] for p in pts], [p[2] for p in pts], cl, d))                 # fórmula (linha)
    for R, obs, f in pts:
        c.append(f'<circle cx="{fmt(X(R))}" cy="{fmt(Y(obs))}" r="3.5" class="{cl}" style="fill:var(--papel);stroke-width:2"/>')
s, X2, Y2 = painel(410, 20, 260, 200, 0, 0.6, 0, 16, [0, 0.2, 0.4, 0.6], [0, 4, 8, 12, 16], "prob. de falha na publicação f", "chamadas de ferramenta/pedido")
c += s
fs = [0.0, 0.3, 0.6]
c.append(curva(X2, Y2, fs, [F["não"][f] for f in fs], "lr", None))
c.append(curva(X2, Y2, fs, [F["sim"][f] for f in fs], "lv", None))
xs = [i / 100 * 0.6 for i in range(0, 101, 4)]
c.append(curva(X2, Y2, xs, [base / (1 - f) for f in xs], "la", "4 3"))
c += legenda([("lv", "q=1", None), ("la", "q=0,7", "6 3"), ("lr", "q=0,4", "3 3")], 60, 272, 90)
c += legenda([("lr", "recomeço", None), ("lv", "retomada", None), ("la", "previsão", "4 3")], 380, 272, 110)
salvar("fig_c14_resultados.svg", 720, 292, "À esquerda, fração de relatórios corretos contra o número de refações para três qualidades de revisor (pontos observados, linhas da fórmula); à direita, chamadas de ferramenta por pedido contra a probabilidade de falha, com e sem checkpoint", c)
print("ok", A[0.7][:2], F)
