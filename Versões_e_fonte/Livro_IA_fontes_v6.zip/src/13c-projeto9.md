## 13.8 Projeto 9: um agente com ferramentas e três estratégias

::: projeto Agente que consulta o livro, conta e calcula
O projeto monta um agente com **quatro ferramentas** reais (calculadora segura, contagem de seções, contagem de palavras de uma seção e busca BM25 no livro do Projeto 8) e **60 tarefas com gabarito** (calculado executando a sequência correta, não escrito à mão). Três laços (ReAct, Plan-and-Solve e Reflexion) rodam sobre um **"LLM" simulado**, uma política estocástica que conhece a sequência certa e erra com probabilidade $p$ por decisão, em quatro modos (dois detectáveis, dois silenciosos). **Nenhum modelo de linguagem real foi usado.** O que o projeto mede é a **estrutura** dos laços: acúmulo de erro, custo em chamadas e em *tokens*, recuperação por avaliador. O mesmo conjunto de ferramentas também roda no LangChain real, com modelo roteirizado (seção 13.3).
:::

### Objetivo

Verificar, por experimento e por dedução, cinco afirmações: (1) o custo do ReAct cresce com $T^2$ (Proposição 13.1); (2) a taxa de acerto decai como prevê a Proposição 13.2; (3) o Plan-and-Solve reduz chamadas e *tokens* sem mudar o acerto quando o modelo de erros é o mesmo; (4) o Reflexion segue a Proposição 13.3; (5) as ferramentas rejeitam entradas inválidas e hostis sem derrubar o laço.

### Problema

**Tarefas** (60), de cinco tipos com $1$ a $3$ ações:

| Tipo | Exemplo | Ações | Qtde |
|---|---|---:|---:|
| T1 | "Quanto é $(37\cdot52)+110$?" | calculadora | $12$ |
| T2 | "Quantas seções expositivas tem o Capítulo 5?" | contar_secoes | $10$ |
| T3 | "Raiz quadrada do número de seções do Capítulo 5, com 2 casas" | contar_secoes, calculadora | $11$ |
| T4 | "Quantas palavras tem a seção que melhor responde a: «…»?" | buscar_livro, palavras_secao | $14$ |
| T5 | "Soma do número de palavras das seções 5.4 e 9.2" | palavras_secao $\times2$, calculadora | $13$ |

O gabarito de T4 usa a seção **de gabarito** do Projeto 8, e não a que o agente recuperou: **errar a busca é errar a tarefa**. As $14$ perguntas de T4 são diretas, e a busca BM25 acertou a seção em $14$ de $14$; em perguntas parafraseadas, o teto do agente seria menor (Capítulo 12).

**Modelo de erro** do "LLM" simulado, por decisão (inclusive a final): com probabilidade $p$, um de quatro modos, escolhido ao acaso: *formato malformado* e *ferramenta inexistente* (**detectáveis**: o registro devolve erro e o agente repete); *argumento válido, mas errado* e *resposta precoce* ou erro de transcrição (**silenciosos**). Metade dos erros é detectável ($\delta=\tfrac12$). **Essa taxa e essa divisão são premissas do simulador, não medidas de nenhum modelo.**

**Métricas.** Taxa de acerto (resposta numérica com tolerância de arredondamento), chamadas ao LLM por tarefa e palavras de entrada por tarefa (substituto de *tokens*).

### Requisitos

- Quatro ferramentas com contrato Pydantic e registro que devolve **sempre** uma observação (nunca exceção).
- Calculadora **sem `eval`**, por percurso da AST com lista de permissões e limites.
- Laços ReAct (interpretação do texto por expressões regulares, limite de passos), Plan-and-Solve (plano, execução, replanejamento limitado e composição final) e Reflexion (avaliador, reflexão, $K$ tentativas).
- Contagem **exata** de palavras de entrada, conferida contra a Proposição 13.1.
- Testes automáticos; experimentos com $100$ sementes e percentis entre sementes.

### Arquitetura

| Peça | Programa | Papel |
|---|---|---|
| Ferramentas e registro | `c13_ferramentas.py` | Contratos, validação, execução protegida, calculadora segura, ferramentas sobre o corpus do Projeto 8. |
| Laços e simulador | `c13_agentes.py` | Tarefas e gabaritos, "LLM" simulado, ReAct, Plan-and-Solve, Reflexion. |
| Demonstração das ferramentas | `c13_ferramentas_demo.py` | Esquema JSON, chamadas válidas e inválidas, entradas hostis. |
| LangChain real | `c13_langchain.py` | `@tool` e `create_agent` com modelo roteirizado. |
| Testes | `p9_testes.py` | $19$ testes automáticos. |
| Experimento 1 | `p9_exp1_estrategias.py` | Acerto e custo contra $p$; Proposição 13.2. |
| Experimento 2 | `p9_exp2_custo.py` | Custo quadrático; Proposição 13.1 (seção 13.2). |
| Experimento 3 | `p9_exp3_reflexion.py` | Avaliador e tentativas; Proposição 13.3. |

### Fundamentos teóricos

Definição 13.1 (agente), Definição 13.2 (ReAct), Definição 13.3 (contrato de ferramenta), Proposição 13.1 (custo quadrático), Proposição 13.2 (erro composto), Definição 13.4 (Plan-and-Solve), Definição 13.5 e Proposição 13.3 (Reflexion). Do Capítulo 11: saídas estruturadas e validação; do Capítulo 12: a busca BM25 do corpus.

### Implementação

As ferramentas e o registro estão na seção 13.3. Os laços e o simulador:

<<< codigo/c13_agentes.py

### Testes e resultados

#### Testes automáticos

<<< codigo/p9_testes.py

>>> codigo/p9_testes.out

Dois deles merecem comentário. O teste "com $p=0$ todo laço acerta" garante que o simulador **não introduz** erros por si, e que o gabarito é alcançável. O teste do teto de T4 mostra que, mesmo sem erros do "modelo", o agente **herda** o acerto do recuperador.

#### Experimento 1: estratégias contra a taxa de erro

<<< codigo/p9_exp1_estrategias.py

>>> codigo/p9_exp1_estrategias.out

#### Experimento 3: Reflexion

<<< codigo/p9_exp3_reflexion.py

>>> codigo/p9_exp3_reflexion.out

#### Síntese dos resultados

| Afirmação | Resultado | Observação |
|---|---|---|
| Custo $\propto T^2$ | Fórmula **exata**: contagem igual em $8$ de $8$ valores de $T$; razão $T=32$ contra $T=16$: $3{,}0$ | Em palavras, não *tokens* |
| Erro composto | Observado $0{,}005$ a $0{,}013$ **acima** do previsto, por erros silenciosos inofensivos | Premissa de independência |
| Plan-and-Solve | Mesmo acerto; $2{,}00$ contra $2{,}85$ chamadas e $245$ contra $398$ palavras ($p=0$) | Igualdade de acerto **é premissa** |
| Reflexion | Fórmula acerta dentro de $0{,}009$; com $q=0{,}4$, $K=5$ não supera $K=3$ | Avaliador decide |
| Ferramentas | $6$ entradas hostis recusadas e $5$ chamadas inválidas devolvidas como erro; o laço continua | Teste de contrato |

### Limitações

- **O "LLM" é uma política simulada.** As taxas de erro, a divisão entre detectáveis e silenciosos e a independência entre decisões são **premissas**. Um modelo real tem erros **correlacionados** (o mesmo histórico confunde várias vezes), **dependentes do contexto** e **de cauda longa**. Os resultados valem como **verificação das fórmulas e da estrutura dos laços**, e não como previsão do desempenho de um agente real.
- **Plan-and-Solve e ReAct com a mesma taxa de erro** é uma escolha de projeto; a comparação de acerto entre eles **não** é um resultado.
- **Reflexion: o efeito de aprendizado ($\rho<1$) é suposto**; só a parte de repetição com avaliador (H1) tem base na Proposição 13.3. O avaliador do simulador conhece o gabarito e erra com taxa conhecida $q$; avaliadores reais não têm gabarito.
- **Tarefas curtas** (de $1$ a $3$ ações), geradas por modelos fixos; sem ambiente aberto, sem web, sem ferramentas com efeitos.
- **Palavras no lugar de *tokens***, sem cache e sem preços.
- **A busca do T4 é fácil** (perguntas diretas, $14/14$).
- **Sem LLM real, sem seleção de ferramentas por um modelo, sem *function calling* de provedor:** esse código está descrito, mas **não foi executado**.

### Melhorias possíveis

- Trocar o `ModeloRoteirizado` por um LLM real (`init_chat_model`) e repetir os três experimentos, medindo **erros correlacionados** e **ferramentas escolhidas**.
- Medir $\delta$, $p$ e o efeito da reflexão ($\rho$) com o modelo real, em vez de supô-los.
- Adicionar tarefas **longas** ($10$ a $50$ ações) e ver o decaimento da Proposição 13.2.
- Adicionar **aprovação humana** para ferramentas com efeito externo (Capítulo 14) e um **orçamento** de passos, *tokens* e tempo imposto pelo código (Capítulo 15).
- Testar **injeção de instrução** nas observações das ferramentas (Capítulo 15).
