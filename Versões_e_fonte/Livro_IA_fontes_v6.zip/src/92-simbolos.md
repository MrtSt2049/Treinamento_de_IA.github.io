Este índice complementa a tabela de notação da abertura. Os símbolos estão agrupados por tema, com o capítulo em que aparecem. Alguns são **reutilizados com outro sentido** em capítulos diferentes: $T$ é o comprimento da sequência no Capítulo 8, a temperatura no Capítulo 11 e o número de ações de um agente no Capítulo 13; $q$ é a probabilidade de um ramo lento no Capítulo 15 e a detecção do avaliador no Capítulo 13. Em cada ocorrência o texto define o significado local, e esta tabela o registra.

## Álgebra linear e cálculo (Capítulo 1)

| Símbolo | Significado |
|---|---|
| $\mathbf{u}^\top\mathbf{v}$ | Produto escalar |
| $\lVert\mathbf{u}\rVert_1$, $\lVert\mathbf{u}\rVert_2$ | Normas $\ell_1$ (soma dos módulos) e $\ell_2$ (euclidiana) |
| $\lambda,\ \mathbf{v}$ | Autovalor e autovetor: $\mathbf{A}\mathbf{v}=\lambda\mathbf{v}$ |
| $\operatorname{diag}(\mathbf{v})$ | Matriz diagonal com o vetor $\mathbf{v}$ na diagonal |
| $\operatorname{posto}(\mathbf{A})$ | Posto (número de colunas linearmente independentes) |
| $\partial f/\partial x_i$ | Derivada parcial |
| $\nabla f$, $\mathbf{H}_f$ | Gradiente e matriz Hessiana |
| $\eta$ | Taxa de aprendizado |
| $\odot$ | Produto elemento a elemento (de Hadamard) |

## Probabilidade e estatística (Capítulos 1, 3, 4 e 15)

| Símbolo | Significado |
|---|---|
| $P(A\mid B)$ | Probabilidade condicional |
| $\mathbb{E}[X]$, $\operatorname{Var}(X)$, $\operatorname{Cov}(X,Y)$ | Esperança, variância e covariância |
| $\mathcal{N}(\mu,\sigma^2)$, $\operatorname{Bernoulli}(p)$ | Distribuições Gaussiana e de Bernoulli |
| $\varepsilon$ | Termo de ruído na resposta, $Y=f(X)+\varepsilon$ (Capítulos 3 e 4); meia-largura de um intervalo de confiança, no cálculo do tamanho de amostra (Capítulo 15) |
| $\kappa$ | Kappa de Cohen (Capítulo 15) |
| $\bar{D}$ | Média das diferenças pareadas entre dois sistemas (Capítulo 15) |

## Aprendizado supervisionado e avaliação (Capítulos 3 a 5)

| Símbolo | Significado |
|---|---|
| $X,\ Y$ | Preditoras e resposta |
| $f,\ \hat f$ | Função verdadeira (desconhecida) e sua estimativa |
| $\mathbf{X}$ | Matriz de dados, uma linha por exemplo; no Capítulo 4, com uma primeira coluna de uns para o intercepto |
| $\beta_0,\ \beta_1,\ \boldsymbol\beta$ | Intercepto, inclinação e vetor de coeficientes do modelo linear (Capítulo 4) |
| $R^2$ | Coeficiente de determinação |
| $\lambda$ | Intensidade da penalização no Lasso e no Ridge (Capítulo 5) |
| $\mathrm{VP},\ \mathrm{VN},\ \mathrm{FP},\ \mathrm{FN}$ | Verdadeiros positivos e negativos, falsos positivos e negativos |
| $F_1$ | Média harmônica de precisão e *recall* |

## Redes neurais (Capítulo 6)

| Símbolo | Significado |
|---|---|
| $L$ | Número de camadas |
| $n_l$ | Largura (número de unidades) da camada $l$ |
| $\mathbf{W}^{(l)},\ \mathbf{b}^{(l)}$ | Pesos e viés da camada $l$ |
| $\mathbf{z}^{(l)}$ | Pré-ativação: $\mathbf{z}^{(l)}=\mathbf{W}^{(l)\top}\mathbf{h}^{(l-1)}+\mathbf{b}^{(l)}$ |
| $\mathbf{h}^{(l)}$ | Ativação da camada $l$: $\mathbf{h}^{(l)}=\varphi^{(l)}(\mathbf{z}^{(l)})$ |
| $\varphi,\ \sigma$ | Função de ativação genérica; sigmoide |
| $\boldsymbol\delta^{(l)}$ | Sinal de erro da camada $l$: $\partial\mathcal{L}/\partial\mathbf{z}^{(l)}$ |
| $\mathbf{m}_t,\ \mathbf{v}_t,\ \beta_1,\ \beta_2,\ \epsilon$ | Momentos e hiperparâmetros do Adam |
| $\gamma$ | Margem de separação no teorema de convergência do perceptron |

## Visão computacional (Capítulo 7)

| Símbolo | Significado |
|---|---|
| $H,\ W,\ C$ | Altura, largura e número de canais |
| $K,\ S,\ P$ | Tamanho do filtro, passo (*stride*) e preenchimento (*padding*); a saída tem $\lfloor(H+2P-K)/S\rfloor+1$ posições |
| $\star$ | Correlação cruzada (a "convolução" das bibliotecas, Definição 7.1) |

## Sequências (Capítulo 8)

| Símbolo | Significado |
|---|---|
| $\mathbf{x}_t,\ \mathbf{h}_t$ | Entrada e estado oculto no passo $t$ |
| $\mathbf{W}_{xh},\ \mathbf{W}_{hh}$ | Pesos de entrada e de recorrência |
| $\mathbf{f}_t,\ \mathbf{i}_t,\ \mathbf{o}_t$ | Portas de esquecimento, de escrita e de leitura da LSTM |
| $\mathbf{g}_t,\ \mathbf{c}_t$ | Candidato a escrever e estado de célula da LSTM |

## Transformers e ajuste fino (Capítulos 9 e 10)

| Símbolo | Significado |
|---|---|
| $\mathbf{Q},\ \mathbf{K},\ \mathbf{V}$ | Matrizes de consultas, chaves e valores |
| $d,\ d_k,\ d_v,\ d_\mathrm{ff}$ | Dimensão do modelo, das chaves, dos valores e da rede por posição |
| $h$ | Número de cabeças de atenção, com $d_k=d_v=d/h$ |
| $\mathbf{W}_Q^{(i)},\ \mathbf{W}_K^{(i)},\ \mathbf{W}_V^{(i)}$ | Projeções da cabeça $i$ |
| $\operatorname{PE}(p)$ | Codificação posicional da posição $p$ |
| $V$ | Tamanho do vocabulário |
| $\mathbf{W}_0,\ \mathbf{B},\ \mathbf{A}$ | Peso congelado e fatores de baixo posto da LoRA |
| $r,\ \alpha$ | Posto e fator de escala da LoRA: $\mathbf{W}=\mathbf{W}_0+(\alpha/r)\mathbf{B}\mathbf{A}$ |

## Geração e confiabilidade (Capítulo 11)

| Símbolo | Significado |
|---|---|
| $\mathbf{z}_t$ | *Logits* no passo $t$ |
| $T$ | Temperatura: $p_T(i)=e^{z_i/T}/\sum_j e^{z_j/T}$ |
| $\operatorname{ECE}$ | Erro de calibração esperado |
| $\operatorname{conf}(b),\ \operatorname{acc}(b)$ | Confiança média e acurácia na faixa $b$ do diagrama de confiabilidade |

## Recuperação (Capítulos 12 e 15)

| Símbolo | Significado |
|---|---|
| $\cos(\mathbf{a},\mathbf{b})$ | Similaridade por cosseno |
| $\operatorname{RRF}(d)$ | Fusão recíproca de *ranks*: $\sum_j 1/(k+\operatorname{pos}_j(d))$, com $k=60$ por padrão |
| $G$ | Conjunto dos itens relevantes de uma pergunta |
| $\mathrm{P@}k,\ \mathrm{R@}k$ | Precisão e revocação nas $k$ primeiras posições |
| $\mathrm{RR},\ \mathrm{MRR}$ | Rank recíproco e sua média |
| $\mathrm{AP},\ \mathrm{MAP}$ | Precisão média e sua média |
| $\mathrm{nDCG@}k$ | Ganho cumulativo descontado normalizado |
| $\tau$ | Limiar do verificador lexical de fidelidade |

## Agentes e grafos (Capítulos 13 e 14)

| Símbolo | Significado |
|---|---|
| $h_t$ | Histórico no passo $t$: tarefa, ações e observações anteriores |
| $\pi_\theta$ | Política do agente: $a_t\sim\pi_\theta(\cdot\mid h_t)$ |
| $a_t,\ o_t$ | Ação e observação no passo $t$ |
| $P_0,\ m_j,\ T$ | *Prompt* inicial, tamanho da rodada $j$ e número de ações (Proposição 13.1) |
| $n,\ p,\ \delta$ | Número de ações, probabilidade de erro por decisão e fração dos erros detectáveis (Proposição 13.2) |
| $s,\ q,\ K,\ u$ | Acerto por tentativa, detecção pelo avaliador, máximo de tentativas e $u=q(1-s)$ (Proposição 13.3) |
| $\rho$ | Redutor de uma chave do estado (Proposição 14.1) |
| $C,\ c_i,\ f$ | Custo total, custo do nó $i$ e probabilidade de falha do último nó (Proposição 14.2) |
| $e,\ d$ | Probabilidade de o relatório chegar errado ao portão humano e de a pessoa perceber o erro (Proposição 14.3) |

## Operação (Capítulo 15)

| Símbolo | Significado |
|---|---|
| $q$ | Probabilidade de um ramo paralelo ser lento (Proposição 15.3) |
| $f,\ m$ | Probabilidade de falha de uma tentativa e máximo de tentativas (Proposição 15.4) |
| $\text{pass}@k,\ \text{pass}^k$ | Ao menos um acerto em $k$ tentativas; acerto em **todas** as $k$ |
