(function () {
  var I = window.INDICE, cache = {}, espera = {};
  var raiz = document.documentElement;
  var vInicio = document.getElementById('vista-inicio');
  var vCap = document.getElementById('vista-capitulo');
  var sumario = document.getElementById('sumario');
  var passos = document.getElementById('passos');
  var prontas = I.vistas.filter(function (v) { return v.pronto; });

  window.LIVRO = { registrar: function (id, html) { cache[id] = html; if (espera[id]) { espera[id](); delete espera[id]; } } };

  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  // Sumário lateral
  function montarSumario(atual) {
    var h = '<a class="s-inicio' + (atual === 'inicio' ? ' ativo' : '') + '" href="#inicio">Abertura e pré-textuais</a>';
    I.modulos.forEach(function (m) {
      h += '<div class="s-mod"><p class="s-mod-t"><b>Módulo ' + m.num + '</b><span>' + m.nivel + '</span></p><ol>';
      I.vistas.filter(function (v) { return v.modulo === m.num; }).forEach(function (v) {
        if (!v.pronto) { h += '<li class="s-cap pendente"><span><i>' + v.num + '</i>' + esc(v.titulo) + '</span></li>'; return; }
        h += '<li class="s-cap' + (v.id === atual ? ' ativo' : '') + '"><a href="#' + v.id + '"><i>' + v.num + '</i>' + esc(v.titulo) + '</a>';
        if (v.id === atual) {
          h += '<ol class="s-sec">';
          v.secoes.forEach(function (s) { h += '<li><a href="#' + s.id + '">' + esc(s.titulo) + '</a></li>'; });
          h += '</ol>';
        }
        h += '</li>';
      });
      h += '</ol></div>';
    });
    var pos = I.vistas.filter(function (v) { return v.grupo === 'pos'; });
    if (pos.length) {
      h += '<div class="s-mod"><p class="s-mod-t"><b>Pós-textuais</b><span>Fechamento</span></p><ol>';
      pos.forEach(function (v) {
        h += '<li class="s-cap' + (v.id === atual ? ' ativo' : '') + '"><a href="#' + v.id + '">' + esc(v.titulo) + '</a>';
        if (v.id === atual) {
          h += '<ol class="s-sec">';
          v.secoes.forEach(function (s) { h += '<li><a href="#' + s.id + '">' + esc(s.titulo) + '</a></li>'; });
          h += '</ol>';
        }
        h += '</li>';
      });
      h += '</ol></div>';
    }
    if (I.vistas.some(function (v) { return !v.pronto; })) h += '<p class="s-nota">Capítulos em cinza ainda estão em produção.</p>';
    sumario.innerHTML = h;
  }

  function vistaDe(hash) {
    if (!hash || hash === 'inicio' || /^f-/.test(hash)) return 'inicio';
    var direto = prontas.filter(function (v) { return v.id === hash; })[0];
    if (direto) return direto.id;
    var mp = /^([a-z0-9]+)-\d/.exec(hash);
    if (mp) { var alvo = prontas.filter(function (v) { return v.prefixo === mp[1]; })[0]; if (alvo) return alvo.id; }
    return 'inicio';
  }

  function carregar(id, feito) {
    if (id === 'inicio' || cache[id]) return feito();
    espera[id] = feito;
    var s = document.createElement('script');
    s.src = 'capitulos/' + id + '.js';
    s.onerror = function () { vCap.innerHTML = '<div class="texto"><p>Não foi possível carregar este capítulo. Recarregue a página.</p></div>'; };
    document.head.appendChild(s);
  }

  function botoesCopiar(el) {
    el.querySelectorAll('pre.codigo').forEach(function (pre) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'copiar'; b.textContent = 'Copiar';
      b.addEventListener('click', function () {
        try {
          navigator.clipboard.writeText(pre.querySelector('code').textContent).then(
            function () { b.textContent = 'Copiado'; setTimeout(function () { b.textContent = 'Copiar'; }, 1500); },
            function () { b.textContent = 'Selecione e copie'; });
        } catch (e) { b.textContent = 'Selecione e copie'; }
      });
      pre.appendChild(b);
    });
  }

  var atual = null;
  function mostrar() {
    var hash = location.hash.replace(/^#/, '');
    var id = vistaDe(hash);
    carregar(id, function () {
      if (id !== atual) {
        atual = id;
        if (id === 'inicio') { vInicio.hidden = false; vCap.hidden = true; }
        else {
          var v = prontas.filter(function (x) { return x.id === id; })[0];
          var topo = v.grupo === 'pos' ? '<p class="cap-mod">Pós-textual</p><p class="cap-num">' + esc(v.rotulo || '') + '</p>' :
            '<p class="cap-mod">Módulo ' + v.modulo + '</p><p class="cap-num">Capítulo ' + v.num + '</p>';
          vCap.innerHTML = '<header class="cap-topo">' + topo + '<h1>' + esc(v.titulo) + '</h1></header><div class="texto">' + cache[id] + '</div>';
          botoesCopiar(vCap);
          vInicio.hidden = true; vCap.hidden = false;
        }
        montarSumario(id);
        var i = prontas.map(function (x) { return x.id; }).indexOf(id), h = '';
        if (i > 0) h += '<a class="passo ant" href="#' + prontas[i - 1].id + '"><span>Anterior</span>' + esc(prontas[i - 1].titulo) + '</a>';
        if (i < prontas.length - 1) h += '<a class="passo prox" href="#' + prontas[i + 1].id + '"><span>Próximo</span>' + esc(prontas[i + 1].titulo) + '</a>';
        passos.innerHTML = h;
      }
      var alvo = hash && hash !== id ? document.getElementById(hash) : null;
      if (alvo) alvo.scrollIntoView(); else window.scrollTo(0, 0);
      fecharMenu();
    });
  }

  // Menu em telas estreitas
  var btnMenu = document.getElementById('btn-menu');
  function fecharMenu() { document.body.classList.remove('menu-aberto'); btnMenu.setAttribute('aria-expanded', 'false'); }
  btnMenu.addEventListener('click', function () {
    var a = document.body.classList.toggle('menu-aberto');
    btnMenu.setAttribute('aria-expanded', a ? 'true' : 'false');
  });

  // Tema
  var btnTema = document.getElementById('btn-tema');
  function escuro() {
    var t = raiz.getAttribute('data-theme');
    return t ? t === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  function rotuloTema() { btnTema.textContent = escuro() ? 'Tema claro' : 'Tema escuro'; }
  try { var salvo = localStorage.getItem('livro-tema'); if (salvo) raiz.setAttribute('data-theme', salvo); } catch (e) {}
  btnTema.addEventListener('click', function () {
    var novo = escuro() ? 'light' : 'dark';
    raiz.setAttribute('data-theme', novo);
    try { localStorage.setItem('livro-tema', novo); } catch (e) {}
    rotuloTema();
  });
  rotuloTema();

  // Progresso de leitura
  var barra = document.getElementById('progresso');
  window.addEventListener('scroll', function () {
    var d = document.documentElement, total = d.scrollHeight - d.clientHeight;
    barra.style.width = (total > 0 ? (d.scrollTop / total) * 100 : 0) + '%';
  }, { passive: true });

  botoesCopiar(vInicio);
  window.addEventListener('hashchange', mostrar);
  mostrar();
})();
