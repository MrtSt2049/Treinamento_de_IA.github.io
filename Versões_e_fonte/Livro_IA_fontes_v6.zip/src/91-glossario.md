Os termos estão em ordem alfabética, com o equivalente em inglês (em itálico) quando ele é de uso corrente na literatura e nas bibliotecas. A indicação final remete ao capítulo em que o conceito é desenvolvido. As definições são curtas por escolha: o texto do capítulo é a referência completa.

## A

- **Acurácia** (*accuracy*). Fração de previsões corretas de um classificador. Enganosa quando as classes são desbalanceadas. → Cap. 5.
- **Adam.** Otimizador que combina *momentum* com taxas de aprendizado adaptativas por parâmetro, usando médias móveis do gradiente e do seu quadrado. → Cap. 6.
- **Agente** (*agent*). Sistema que percebe um ambiente por sensores e age sobre ele por atuadores. Em um agente baseado em LLM, o modelo é o motor de raciocínio acoplado a ferramentas e memória. → Caps. 2, 13.
- **Agente racional.** Agente que, para cada sequência de percepções, escolhe a ação que maximiza o valor esperado da medida de desempenho, dado o que sabe. → Cap. 2.
- **Alucinação** (*hallucination*). Texto fluente e plausível gerado por um modelo de linguagem, mas sem fundamento nos dados de entrada ou na realidade. → Cap. 11.
- **Aresta condicional** (*conditional edge*). Em um grafo de estado, aresta cujo destino é escolhido por uma função do estado atual. → Cap. 14.
- **Atenção** (*attention*). Operação em que cada posição calcula uma média ponderada dos valores de todas as posições, com pesos dados pela compatibilidade entre consultas e chaves. → Cap. 9.
- **Atenção multi-cabeça** (*multi-head attention*). Várias atenções em subespaços diferentes, executadas em paralelo e concatenadas. → Cap. 9.
- **Autoatenção** (*self-attention*). Atenção em que consultas, chaves e valores vêm da mesma sequência. → Cap. 9.
- **Autograd.** Mecanismo do PyTorch que registra as operações sobre tensores e calcula gradientes por diferenciação automática. → Cap. 6.
- **Autovalor e autovetor** (*eigenvalue, eigenvector*). Escalar $\lambda$ e vetor $\mathbf{v}\neq\mathbf{0}$ tais que $\mathbf{A}\mathbf{v}=\lambda\mathbf{v}$. → Cap. 1.

## B

- **Backpropagation** (retropropagação). Algoritmo que aplica a regra da cadeia de trás para a frente em uma rede para obter o gradiente da perda em relação a todos os parâmetros. → Cap. 6.
- **Batch normalization** (normalização em lote). Normaliza as ativações de cada variável usando a média e a variância do lote, com escala e deslocamento aprendidos. → Cap. 6.
- **Bayes, Teorema de.** $P(A\mid B)=P(B\mid A)P(A)/P(B)$. Atualiza uma probabilidade a partir de uma evidência. → Cap. 1.
- **BM25.** Função de pontuação lexical que pondera a frequência do termo, a raridade dele na coleção e o comprimento do documento. → Cap. 12.
- **Bootstrap.** Reamostragem com reposição dos dados observados para estimar a variabilidade de uma estatística, em particular intervalos de confiança. → Caps. 12, 15.
- **BPE** (*byte-pair encoding*). Algoritmo de tokenização que funde iterativamente o par de símbolos mais frequente. → Cap. 10.

## C

- **Camada** (*layer*). Transformação parametrizada, em geral $\sigma(\mathbf{W}\mathbf{x}+\mathbf{b})$, que é um bloco de construção de uma rede neural. → Cap. 6.
- **Checkpointer.** Componente do LangGraph que grava o estado do grafo ao fim de cada passo, permitindo pausar, retomar e inspecionar execuções. → Cap. 14.
- **Chunking** (fatiamento). Divisão de documentos em trechos (*chunks* ou nós) que serão indexados e recuperados. → Cap. 12.
- **Classificação.** Aprendizado supervisionado em que a resposta é uma categoria. → Caps. 3, 4.
- **Cohen, kappa de.** Medida de concordância entre dois avaliadores que desconta a concordância esperada ao acaso. → Cap. 15.
- **Convolução.** Operação que desliza um filtro sobre a entrada calculando produtos escalares locais, com pesos compartilhados. → Cap. 7.
- **Covariância.** $\operatorname{Cov}(X,Y)=\mathbb{E}[(X-\mathbb{E}X)(Y-\mathbb{E}Y)]$; mede a variação conjunta de duas variáveis. → Cap. 1.
- **Custo** (*loss, cost*). Ver *função de perda*.

## D

- **Dados de treino, validação e teste.** Partições de um conjunto: ajustar parâmetros, escolher hiperparâmetros e estimar o erro final, respectivamente. → Cap. 5.
- **Decodificador** (*decoder*). Em Transformers, bloco com atenção causal que modela a sequência de forma autoregressiva, como na família GPT. → Cap. 9.
- **Descida do gradiente** (*gradient descent*). Método iterativo que atualiza $\boldsymbol{\theta}\leftarrow\boldsymbol{\theta}-\eta\nabla\mathcal{L}(\boldsymbol{\theta})$. → Cap. 1.
- **Descida dupla** (*double descent*). Comportamento em que o erro de teste volta a cair quando a capacidade do modelo ultrapassa o ponto de interpolação. → Cap. 5.
- **Determinante.** Escalar associado a uma matriz quadrada; seu módulo é o fator de variação de volume da transformação linear. → Cap. 1.
- **Disjuntor** (*circuit breaker*). Padrão que interrompe chamadas a um serviço que falha repetidamente, para dar tempo de recuperação. → Cap. 15.
- **Dropout.** Regularização que zera aleatoriamente ativações durante o treino. → Cap. 6.

## E

- **Embedding** (incorporação vetorial). Representação de um objeto (palavra, trecho, imagem) como vetor denso em que a proximidade reflete similaridade semântica. → Caps. 10, 12.
- **Encoder** (codificador). Bloco de Transformer com atenção bidirecional, como no BERT. → Cap. 9.
- **Entropia.** $H=-\sum p_i\log p_i$; mede a incerteza de uma distribuição. Também é critério de divisão em árvores. → Caps. 4, 6.
- **Entropia cruzada** (*cross-entropy*). Perda que compara a distribuição prevista com a verdadeira; é a log-verossimilhança negativa em classificação. → Cap. 6.
- **Época** (*epoch*). Uma passagem completa pelos dados de treino. → Cap. 6.
- **Erro irredutível.** Parte do erro que nenhum modelo elimina, por causa do ruído na resposta. → Cap. 3.
- **Erro redutível.** Parte do erro que melhora com um modelo melhor ou mais dados. → Cap. 3.
- **Esparsidade.** Proporção de coeficientes iguais a zero; induzida pela penalidade $\ell_1$ (Lasso). → Cap. 5.
- **Esperança** (*expected value*). Média ponderada pelos valores possíveis de uma variável aleatória. → Cap. 1.
- **Estado** (*state*). Em um grafo de agentes, o conjunto de dados compartilhado entre nós, atualizado por redutores. → Cap. 14.

## F

- **F1.** Média harmônica de precisão e *recall*. → Cap. 5.
- **Fidelidade** (*faithfulness*). Grau em que uma resposta é sustentada pelo contexto recuperado. → Cap. 15.
- **Fine-tuning** (ajuste fino). Continuação do treinamento de um modelo pré-treinado em dados de uma tarefa específica. → Cap. 10.
- **Função de ativação.** Não linearidade aplicada a cada unidade (sigmoide, tanh, ReLU, softmax). → Cap. 6.
- **Função de perda** (*loss function*). Mede o desacordo entre previsão e resposta; é o que o treinamento minimiza. → Cap. 6.

## G

- **Gaussiana, distribuição.** Distribuição normal, determinada por média $\mu$ e variância $\sigma^2$. → Cap. 1.
- **Generalização.** Capacidade de um modelo de ter bom desempenho em dados que não viu no treino. → Cap. 5.
- **Gradiente.** Vetor das derivadas parciais; aponta na direção de maior crescimento da função. → Cap. 1.
- **Gradiente, dissipação e explosão** (*vanishing, exploding gradients*). Redução ou crescimento exponencial do gradiente ao longo de muitas camadas ou passos de tempo. → Cap. 8.
- **Grafo de estado** (*state graph*). Modelo de execução com nós (funções), arestas e estado compartilhado. → Cap. 14.
- **Guardrail.** Mecanismo de contenção que valida, filtra ou bloqueia entradas, saídas ou ações de um sistema. → Cap. 15.

## H

- **Hessiana.** Matriz das derivadas parciais de segunda ordem. → Cap. 1.
- **Hiperparâmetro.** Parâmetro de configuração escolhido antes do treino (taxa de aprendizado, $\lambda$, posto $r$), e não aprendido. → Cap. 5.
- **Human-in-the-loop.** Padrão em que a execução pausa para validação ou edição humana antes de continuar. → Cap. 14.

## I

- **Idempotência.** Propriedade de uma operação que, repetida com a mesma chave, tem o mesmo efeito que uma execução. → Cap. 14.
- **Injeção de *prompt*** (*prompt injection*). Instruções maliciosas embutidas em entradas ou em conteúdo lido pelo modelo, que tentam desviar seu comportamento. → Caps. 13, 15.
- **Intervalo de confiança.** Faixa de valores plausíveis para uma quantidade estimada, com um nível de cobertura declarado. → Cap. 15.

## K

- **K-means.** Algoritmo de agrupamento que alterna atribuição de pontos ao centroide mais próximo e recálculo dos centroides. → Cap. 3.
- **KNN** (*k-nearest neighbors*). Classifica ou prevê pela vizinhança de $k$ exemplos de treino mais próximos. → Cap. 4.
- **Kernel** (filtro). Pequena matriz de pesos de uma convolução. → Cap. 7.

## L

- **Lasso.** Regressão com penalidade $\ell_1$, que encolhe e zera coeficientes. → Cap. 5.
- **LayerNorm.** Normalização das ativações de uma posição ao longo das suas variáveis. → Cap. 9.
- **LLM** (*large language model*). Modelo de linguagem de grande escala, em geral um Transformer decodificador treinado para prever o próximo *token*. → Caps. 9 a 11.
- **LoRA** (*low-rank adaptation*). Ajuste eficiente que congela os pesos originais e treina uma atualização de baixo posto $\mathbf{B}\mathbf{A}$. → Cap. 10.
- **LSTM** (*long short-term memory*). Célula recorrente com portas e estado de célula aditivo, que mitiga a dissipação do gradiente. → Cap. 8.

## M

- **Matriz de confusão.** Tabela de acertos e erros por classe, base de precisão, *recall* e derivadas. → Cap. 5.
- **MLP** (*multilayer perceptron*). Rede *feedforward* com camadas densas e não linearidades. → Cap. 6.
- **Momentum.** Acumula uma média móvel dos gradientes para suavizar e acelerar a descida. → Cap. 6.
- **MRR** (*mean reciprocal rank*). Média do inverso da posição do primeiro resultado relevante. → Cap. 15.

## N

- **nDCG.** Ganho cumulativo descontado normalizado; avalia rankings com relevância graduada. → Cap. 15.
- **Norma.** Medida de tamanho de um vetor: $\ell_1$ (soma dos módulos), $\ell_2$ (euclidiana). → Cap. 1.

## O

- **Observabilidade.** Capacidade de entender o estado interno de um sistema a partir de seus rastros, métricas e registros. → Cap. 15.
- **OLS** (*ordinary least squares*). Mínimos quadrados ordinários: escolhe os coeficientes que minimizam a soma dos erros quadráticos. → Cap. 4.
- **Overfitting** (superajuste). O modelo memoriza peculiaridades do treino e generaliza mal. → Cap. 5.

## P

- **Padding.** Preenchimento de bordas em uma convolução; também o preenchimento de sequências até um comprimento comum. → Caps. 7, 8.
- **PEAS.** Descrição de um problema de agente por Medida de desempenho, Ambiente, Atuadores e Sensores. → Cap. 2.
- **PEFT** (*parameter-efficient fine-tuning*). Família de métodos que ajustam poucos parâmetros (LoRA, adaptadores, *prefix-tuning*). → Cap. 10.
- **Perceptron.** Unidade linear com limiar, que classifica por $\operatorname{sinal}(\mathbf{w}^\top\mathbf{x}+b)$. → Cap. 6.
- **Pooling** (agrupamento). Resume regiões de um mapa de características por máximo ou média. → Cap. 7.
- **Precisão** (*precision*). Fração dos exemplos previstos como positivos que de fato o são. → Cap. 5.
- **Prompt.** Texto de entrada que condiciona a geração de um modelo de linguagem. → Cap. 11.

## Q

- **Quantização.** Representação de pesos ou ativações com menos bits para reduzir memória e custo. → Cap. 10.
- **Query, key, value** (consulta, chave, valor). As três projeções de cada posição usadas na atenção. → Cap. 9.

## R

- **RAG** (*retrieval-augmented generation*). Geração condicionada a trechos recuperados de uma base de conhecimento. → Cap. 12.
- **ReAct.** Padrão de agente que alterna raciocínio (*reason*) e ação (*act*), usando as observações para o passo seguinte. → Cap. 13.
- **Recall** (revocação, sensibilidade). Fração dos positivos verdadeiros que o sistema encontra. → Caps. 5, 15.
- **Redutor** (*reducer*). Função que combina o valor atual de um campo do estado com uma atualização. → Cap. 14.
- **Reflexion.** Padrão em que o agente avalia sua tentativa e usa a crítica na tentativa seguinte. → Cap. 13.
- **Regressão.** Aprendizado supervisionado em que a resposta é uma quantidade contínua. → Caps. 3, 4.
- **Regressão logística.** Modelo linear cuja saída, via sigmoide, é a probabilidade de uma classe. → Cap. 4.
- **Regularização.** Qualquer penalidade ou restrição que reduz a complexidade efetiva do modelo. → Caps. 5, 6.
- **Reranking** (reordenação). Segundo estágio que reordena candidatos recuperados com um modelo mais preciso. → Cap. 12.
- **ReLU.** $\max(0,x)$; ativação padrão em redes profundas. → Cap. 6.
- **Residual, conexão.** Atalho que soma a entrada à saída de um bloco; facilita o treino de redes profundas. → Caps. 7, 9.
- **Ridge.** Regressão com penalidade $\ell_2$, que encolhe os coeficientes. → Cap. 5.
- **RNN** (rede neural recorrente). Rede que processa sequências passando um estado oculto de um passo ao próximo. → Cap. 8.
- **ROC-AUC.** Área sob a curva que relaciona taxa de verdadeiros positivos e de falsos positivos; probabilidade de um positivo receber pontuação maior que um negativo. → Cap. 5.
- **RRF** (*reciprocal rank fusion*). Funde rankings somando $1/(k+\text{posição})$. → Cap. 12.

## S

- **Self-consistency.** Amostrar várias respostas e escolher a mais frequente. → Cap. 11.
- **Sigmoide.** $\sigma(z)=1/(1+e^{-z})$; leva a reta real a $(0,1)$. → Cap. 6.
- **Softmax.** Transforma um vetor de números em uma distribuição de probabilidade. → Caps. 6, 9.
- **SGD** (*stochastic gradient descent*). Descida do gradiente com gradientes estimados em lotes. → Cap. 6.
- **Stride** (passo). Deslocamento do filtro entre posições sucessivas de uma convolução. → Cap. 7.
- **Supervisão** (aprendizado supervisionado). Aprender uma função a partir de pares entrada–resposta. → Cap. 3.

## T

- **Temperatura.** Parâmetro que divide os *logits* antes do softmax; valores altos aumentam a diversidade. → Cap. 11.
- **Tensor.** Arranjo multidimensional de números; generaliza escalares, vetores e matrizes. → Cap. 1.
- **Token.** Unidade em que o texto é dividido por um tokenizador. → Cap. 10.
- **Tool calling** (chamada de ferramentas). Mecanismo pelo qual o modelo emite uma chamada estruturada a uma função externa. → Cap. 13.
- **Top-k, top-p.** Estratégias de amostragem que restringem a escolha aos $k$ *tokens* mais prováveis ou ao menor conjunto com massa acumulada $p$. → Cap. 11.
- **Transfer learning.** Reaproveitar um modelo treinado em uma tarefa como ponto de partida para outra. → Caps. 7, 10.
- **Transformer.** Arquitetura baseada em atenção, conexões residuais, normalização e redes por posição. → Cap. 9.

## U

- **Underfitting** (subajuste). O modelo é simples demais para capturar a estrutura dos dados. → Cap. 5.

## V

- **Validação cruzada** (*cross-validation*). Estimar o erro dividindo os dados em $k$ partes e rotacionando a de teste. → Cap. 5.
- **Variância.** $\operatorname{Var}(X)=\mathbb{E}[(X-\mathbb{E}X)^2]$; dispersão em torno da média. No dilema viés–variância, sensibilidade do modelo à amostra de treino. → Caps. 1, 5.
- **Vector store** (banco vetorial). Estrutura que indexa embeddings e responde a buscas por vizinhos mais próximos. → Cap. 12.
- **Viés** (*bias*). Erro sistemático por hipóteses simplificadoras do modelo. Também o termo constante $b$ de uma camada. → Caps. 5, 6.
