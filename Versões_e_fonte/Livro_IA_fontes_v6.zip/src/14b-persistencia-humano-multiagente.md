## 14.3 Persistência: checkpoints, retomada e bifurcação

Um laço de agente pode durar minutos, esperar uma pessoa por dias e falhar no meio (rede, limite de taxa, erro de ferramenta). Sem persistência, qualquer interrupção **perde tudo**. O LangGraph resolve isso com **checkpointers**: depois de cada passo, o estado é gravado.

::: definicao 14.2 · Checkpoint e thread
Um **checkpoint** é o instantâneo do estado ao final de um passo, junto com os **nós que serão executados em seguida** e metadados (número do passo, origem). Uma **thread** é uma sequência de checkpoints identificada por um `thread_id`; execuções com identificadores diferentes **não** compartilham estado. Um **checkpointer** é o armazenamento desses instantâneos (na memória, em arquivo SQLite, em banco Postgres, etc.).
:::

O programa abaixo faz uma execução de quatro nós, com uma falha transitória injetada no terceiro.

<<< codigo/c14_persistencia.py

>>> codigo/c14_persistencia.out

Os resultados, comentados:

- **Seção 1 (sem checkpointer).** A falha em `analisar` obriga a recomeçar: `coletar` e `limpar` rodam **duas vezes**, e o total foi de $7$ execuções de nós.
- **Seção 2 (com checkpointer).** O estado salvo mostra `log = ['coletar', 'limpar']` e o próximo nó `analisar`. `invoke(None, config)` **retoma** dali: os dois primeiros nós rodam **uma** vez, e só `analisar` repete (total $5$).
- **Seção 3 (histórico).** Há **um checkpoint por passo**, do passo $-1$ (entrada) ao $4$ (fim). É um registro completo e auditável da execução.
- **Seção 4 (bifurcação).** Um checkpoint antigo pode ser **editado** (`update_state`) e a execução continuada a partir dele, gerando um ramo novo. O checkpoint original permanece intacto (`valor = 22`), e o estado "atual" da thread passa a ser o do ramo novo (`98`). Serve para depurar ("e se esse valor fosse outro?") e para corrigir uma execução sem refazê-la.
- **Seção 5 (isolamento).** Duas threads no mesmo grafo mantêm estados independentes.

::: proposicao 14.2 · Custo esperado de uma falha, com e sem checkpoint
Um pipeline executa os nós $1,\dots,n$ em ordem, com custos $c_1,\dots,c_n$ e $C=\sum_i c_i$. O último nó falha com probabilidade $f<1$ a cada tentativa, de forma independente, e uma falha custa $c_n$. **Sem checkpoint**, cada falha obriga a refazer tudo, e o custo esperado é $\mathbb{E}[\text{custo}]=C/(1-f)$. **Com checkpoint**, só o último nó repete: $\mathbb{E}[\text{custo}]=C+c_n\,\dfrac{f}{1-f}$. A economia é $(C-c_n)\dfrac{f}{1-f}$.
:::

::: demonstracao
O número de tentativas até o primeiro sucesso é geométrico, com média $1/(1-f)$. Sem checkpoint, cada tentativa custa $C$ (as falhas ocorrem no último nó, depois de todos os outros), logo $C/(1-f)$. Com checkpoint, a primeira tentativa custa $C$ e cada uma das $\mathbb{E}[\text{falhas}]=f/(1-f)$ tentativas extras custa só $c_n$. A diferença é $C/(1-f)-C-c_nf/(1-f)=(C-c_n)f/(1-f)$.
:::

O Projeto 10 (seção 14.6) mede isso com chamadas de ferramenta, com $c_n=0$ (o publicador não chama ferramentas): sem checkpoint, $5{,}94$, $8{,}69$ e $14{,}90$ chamadas por pedido para $f=0$, $0{,}3$ e $0{,}6$, contra a previsão $5{,}94/(1-f)=5{,}94$, $8{,}49$ e $14{,}85$; com checkpoint, $5{,}94$ nos três casos.

::: atencao A retomada repete o nó que falhou: o efeito externo precisa ser idempotente
O checkpoint guarda o estado **entre** nós, e não o que ocorreu **dentro** de um nó. Se um nó faz um efeito externo (enviar e-mail, cobrar, publicar) e falha **depois**, a retomada o executa de novo. A seção 6 do programa mostra o resultado: o nó ingênuo deixa $2$ mensagens na caixa de saída; o nó com **chave de idempotência** (o efeito é registrado por uma chave derivada da entrada, e uma repetição é ignorada) deixa $1$. A regra: todo nó com efeito externo deve ser **idempotente**, ou dividido em dois nós (um que prepara e outro que executa, protegido por chave).
:::

::: nota Checkpointers em produção
O programa usa o `InMemorySaver`, que vive na memória do processo: serve para testes e para os experimentos deste livro, mas **não sobrevive** a uma reinicialização. Em produção usa-se um checkpointer durável (SQLite para um servidor único; Postgres para vários). Eles **não foram executados** aqui: o ambiente não tinha os pacotes correspondentes instalados, e o livro só afirma o que rodou. A interface é a mesma (`compile(checkpointer=...)`).
:::

## 14.4 Humano no laço

Algumas decisões não devem ser automáticas: gastar dinheiro, apagar dados, falar com um cliente. **Humano no laço** (*human-in-the-loop*) é o padrão em que a execução **pausa**, mostra a uma pessoa o que vai acontecer, e só continua com a resposta dela.

O LangGraph oferece duas formas, e ambas dependem de um checkpointer (a pausa **é** um checkpoint em que o grafo espera).

- **Dinâmica**, com `interrupt(valor)` dentro de um nó: a execução para ali, o `valor` (por exemplo, a ação proposta) é devolvido ao chamador em `__interrupt__`, e a execução **retoma** com `invoke(Command(resume=resposta), config)`; a chamada a `interrupt` **devolve** a resposta. O nó pode então decidir: aprovar, rejeitar, editar.
- **Estática**, com `compile(interrupt_before=["nó"])`: o grafo pausa **antes** de um nó especificado, o estado pode ser **editado** (`update_state`), e a execução prossegue com `invoke(None, config)`.

<<< codigo/c14_hitl.py

>>> codigo/c14_hitl.out

O que os resultados mostram:

- **Três respostas ao mesmo pedido.** Aprovar executa a transferência ($1000\to700$); rejeitar não executa nada ($1000$ continua); editar executa com o **valor corrigido** pelo humano ($1000\to880$). A pessoa não é só um "sim ou não": pode **corrigir** a ação proposta.
- **A pausa vem antes do efeito.** Em todos os casos, o saldo continua em $1000$ enquanto o sistema aguarda: nada foi executado.
- **O nó reinicia do começo.** O contador `aprovar (entrada)` marca $2$: quando a execução retoma, o nó **roda desde a primeira linha**, e `interrupt` agora devolve a resposta. Por isso **nada que tenha efeito externo pode vir antes de um `interrupt`** no mesmo nó (seria repetido).
- **Sem checkpointer, não há retomada.** A pausa é anunciada, mas `Command(resume=...)` levanta `RuntimeError`.
- **A pausa é durável.** Na seção 4, a instância do grafo é descartada e **outra** retoma a mesma thread a partir do armazenamento: o servidor pode reiniciar (com um checkpointer durável) entre a pergunta e a resposta, e a resposta pode demorar horas.

### Que ações exigem aprovação

Aprovar **tudo** gera fadiga: a pessoa passa a clicar "aprovar" sem ler, e o portão vira teatro. Um critério prático é aprovar o que for **irreversível** (enviar, pagar, apagar), **caro** (acima de um limite), **externo** (afeta terceiros) ou de **baixa confiança**; o resto segue automático. O padrão aparece pronto no `HumanInTheLoopMiddleware` do `create_agent`, que recebe uma tabela ferramenta → exige aprovação (`True` ou `False`), como na saída do programa da seção 14.2.

::: proposicao 14.3 · Defesa em camadas: o revisor automático e o portão humano em série
Seja $e$ a probabilidade de o relatório chegar **errado** ao portão humano (depois do ciclo de revisão), e $d$ a probabilidade de a pessoa **perceber** um erro quando ele existe (e nunca rejeitar um relatório correto). Se as decisões são independentes, então
$$P(\text{publicar errado})=(1-d)\,e,\qquad P(\text{rejeitar})=d\,e,\qquad P(\text{publicar certo})=1-e.$$
O portão humano **troca erros publicados por não publicações**: a taxa de erros cai pelo fator $(1-d)$, e a de relatórios corretos publicados **não muda** (mas a de relatórios sem publicação sobe de $0$ para $de$).
:::

::: demonstracao
Com probabilidade $1-e$ o relatório chega correto e é aprovado. Com probabilidade $e$ chega errado, e a pessoa o rejeita com probabilidade $d$ (não publica) ou o aprova com probabilidade $1-d$ (publica errado). As três probabilidades somam $(1-e)+de+(1-d)e=1$.
:::

O experimento 1 do Projeto 10 verifica isso (seção 14.6): com $e=0{,}153$ (revisor imperfeito) e $d=0{,}5$, a previsão de erros publicados é $0{,}077$ e a medida foi $0{,}080$; com $d=1$, a taxa de erros publicados cai a $0{,}000$ e $16{,}5\%$ dos relatórios deixam de ser publicados. **Uma pessoa não é um verificador perfeito**: $d$ deve ser **medido**, e não suposto.

## 14.5 Sistemas multiagente

Um **sistema multiagente** divide o trabalho entre agentes com papéis distintos. As razões a favor são a **especialização** (cada agente tem um *prompt*, ferramentas e um contexto curtos e focados), a **isolação de contexto** (o histórico de uma subtarefa não polui as outras) e o **paralelismo**. As razões contra são o **custo de coordenação** (cada passagem de controle é uma chamada a mais) e a **propagação de erros** entre agentes, que a Proposição 13.2 já descreve para um agente só. Por isso a recomendação de Anthropic (2024) é começar pelo padrão **mais simples** que resolve o problema, e acrescentar agentes só quando medir ganho.

Três padrões de controle aparecem no LangGraph (programa abaixo).

- **Supervisor.** Um nó central lê o estado e **roteia** para o especialista adequado; cada especialista devolve o controle ao supervisor. O roteamento usa `Command(goto=destino, update=...)`, que **junta** a atualização do estado e a decisão do próximo nó numa só instrução. No Capítulo 13, o supervisor seria um LLM; aqui é uma regra.
- **Hierarquia.** Um **subgrafo** inteiro (uma equipe) funciona como **um nó** do grafo pai. O pai só conhece as chaves de estado que compartilha com a equipe; o interior é opaco. Equipes aninham-se em níveis.
- **Fan-out dinâmico com `Send`.** Um nó devolve uma lista de `Send(nó, entrada)`: uma **tarefa por item**, com o número de trabalhadores decidido em tempo de execução. As saídas se juntam por redutor.

<<< codigo/c14_multiagente.py

>>> codigo/c14_multiagente.out

A parte 1 mostra o supervisor decidindo pelo **que falta** no estado (fatos, conta, texto), e terminando com `END`. A parte 2 mostra o subgrafo `equipe_estatistica` como um nó do pai, com os eventos internos (`media`, `desvio`) visíveis pelo parâmetro `subgraphs=True`. A parte 3 mostra o `Send`: com $3$ itens há $3$ execuções do trabalhador, com $10$ há $10$, e a soma confere com o cálculo direto ($14$ e $385$).

::: aplicacao Quando usar um supervisor
O supervisor vale quando as subtarefas têm **ferramentas e contextos diferentes** e o próximo passo depende do que já foi feito. Não vale para um fluxo fixo (use arestas fixas, mais baratas e previsíveis) nem quando um único agente com as ferramentas certas já resolve. Cada volta ao supervisor tem **custo**: no Projeto 10, um relatório com $n$ capítulos e nenhuma refação exige **sete** execuções do supervisor, qualquer que seja $n$, porque os $n$ pesquisadores rodam **no mesmo passo**.
:::

::: atencao O supervisor é um ponto único de falha
Se o roteamento do supervisor erra (envia ao especialista errado, ou nunca termina), todo o sistema falha. As contenções são as de sempre: **limite de recursão**, roteamento por **regras** quando possível, **trilha** de quem agiu (para auditar) e, nos pontos críticos, a **aprovação humana** da seção 14.4.
:::
