"""Capítulo 14: humano no laço (human-in-the-loop): interrupt, Command(resume=...), interrupt_before e edição de estado."""
from collections import Counter
from typing import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt

contagem = Counter()
conta = {"saldo": 1000}                     # o "mundo externo": só muda se a ação for executada

class Est(TypedDict, total=False):
    pedido: str
    valor: int
    decisao: str
    resultado: str

def propor(s: Est) -> dict:
    contagem["propor"] += 1                 # (aqui um LLM extrairia o valor do pedido)
    return {"valor": int(s["pedido"].split()[-1])}

def aprovar(s: Est) -> Command:
    contagem["aprovar (entrada)"] += 1      # ATENÇÃO: este trecho roda de novo quando a execução é retomada
    resposta = interrupt({"acao": "transferir", "valor": s["valor"], "saldo": conta["saldo"],
                          "opcoes": ["aprovar", "rejeitar", "editar"]})
    if resposta["decisao"] == "rejeitar":
        return Command(goto="encerrar", update={"decisao": "rejeitada"})
    novo = resposta.get("valor", s["valor"]) if resposta["decisao"] == "editar" else s["valor"]
    return Command(goto="executar", update={"decisao": resposta["decisao"], "valor": novo})

def executar(s: Est) -> dict:
    contagem["executar"] += 1
    conta["saldo"] -= s["valor"]
    return {"resultado": f"transferidos {s['valor']}; saldo {conta['saldo']}"}

def encerrar(s: Est) -> dict:
    return {"resultado": "nada foi executado"}

def monta(**kw):
    g = StateGraph(Est)
    g.add_node("propor", propor); g.add_node("aprovar", aprovar)
    g.add_node("executar", executar); g.add_node("encerrar", encerrar)
    g.add_edge(START, "propor"); g.add_edge("propor", "aprovar")
    g.add_edge("executar", END); g.add_edge("encerrar", END)
    return g.compile(**kw)

def roda(rotulo, resposta, saldo_inicial=1000):
    conta["saldo"] = saldo_inicial; contagem.clear()
    app = monta(checkpointer=InMemorySaver())
    cfg = {"configurable": {"thread_id": rotulo}}
    r1 = app.invoke({"pedido": "transferir 300"}, cfg)
    pend = r1["__interrupt__"][0].value
    print(f"[{rotulo}] pausa: pedido de aprovação = {pend}")
    print(f"[{rotulo}] antes da resposta: próximo nó = {app.get_state(cfg).next}, saldo = {conta['saldo']}")
    r2 = app.invoke(Command(resume=resposta), cfg)
    print(f"[{rotulo}] resposta humana = {resposta}")
    print(f"[{rotulo}] resultado: {r2['resultado']} | decisão = {r2['decisao']} | saldo = {conta['saldo']}")
    print(f"[{rotulo}] execuções dos nós: {dict(contagem)}\n")

print("=== 1. Três respostas possíveis a um mesmo pedido de aprovação ===")
roda("aprovar", {"decisao": "aprovar"})
roda("rejeitar", {"decisao": "rejeitar"})
roda("editar", {"decisao": "editar", "valor": 120})

print("=== 2. A pausa precisa de um checkpointer ===")
app = monta()   # sem checkpointer
r = app.invoke({"pedido": "transferir 300"})
print("A pausa é anunciada em __interrupt__:", "__interrupt__" in r)
try:
    app.invoke(Command(resume={"decisao": "aprovar"}))
except RuntimeError as e:
    print("Mas retomar é impossível -> RuntimeError:", e)

print("\n=== 3. Pausa estática: interrupt_before=['executar'] e edição do estado ===")
g = StateGraph(Est)                          # a pausa é configurada na compilação, sem interrupt() no nó
g.add_node("propor", propor); g.add_node("executar", executar)
g.add_edge(START, "propor"); g.add_edge("propor", "executar"); g.add_edge("executar", END)
app = g.compile(checkpointer=InMemorySaver(), interrupt_before=["executar"])
conta["saldo"] = 1000
cfg = {"configurable": {"thread_id": "estatica"}}
app.invoke({"pedido": "transferir 300"}, cfg)
print("Pausado antes de:", app.get_state(cfg).next, "| valor proposto:", app.get_state(cfg).values["valor"], "| saldo:", conta["saldo"])
app.update_state(cfg, {"valor": 50})
print("Humano editou o valor para 50.")
r = app.invoke(None, cfg)
print("Retomado ->", r["resultado"])

print("\n=== 4. A pausa dura: o processo pode terminar entre a pausa e a resposta ===")
saver = InMemorySaver()                      # num sistema real: um checkpointer em disco ou banco
app1 = monta(checkpointer=saver)
conta["saldo"] = 1000
app1.invoke({"pedido": "transferir 300"}, {"configurable": {"thread_id": "dura"}})
del app1                                     # "o servidor reinicia": a instância do grafo some
app2 = monta(checkpointer=saver)             # outra instância, mesmo armazenamento
r = app2.invoke(Command(resume={"decisao": "aprovar"}), {"configurable": {"thread_id": "dura"}})
print("Retomado por outra instância ->", r["resultado"])
