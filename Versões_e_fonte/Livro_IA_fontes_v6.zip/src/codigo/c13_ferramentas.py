"""Capítulo 13: registro de ferramentas com validação de argumentos (Pydantic), execução segura e observações estruturadas."""
import ast
import json
import math
import operator as op
import time

from pydantic import BaseModel, Field, ValidationError

# ---------- calculadora segura: interpreta só aritmética, nunca chama eval() ----------
_BIN = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.Pow: op.pow, ast.Mod: op.mod}
_UN = {ast.USub: op.neg, ast.UAdd: op.pos}
_FUN = {"sqrt": math.sqrt, "log": math.log, "abs": abs, "round": round, "min": min, "max": max}


def calcular(expressao: str):
    """Avalia uma expressão aritmética por percurso da AST, com lista de permissões. Levanta ValueError se algo for proibido."""
    if len(expressao) > 200:
        raise ValueError("expressão longa demais")

    def ev(n, prof=0):
        if prof > 20:
            raise ValueError("expressão profunda demais")
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
            a, b = ev(n.left, prof + 1), ev(n.right, prof + 1)
            if isinstance(n.op, ast.Pow) and abs(b) > 100:
                raise ValueError("expoente grande demais")
            return _BIN[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _UN:
            return _UN[type(n.op)](ev(n.operand, prof + 1))
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUN and not n.keywords:
            return _FUN[n.func.id](*[ev(a, prof + 1) for a in n.args])
        raise ValueError(f"construção não permitida: {type(n).__name__}")

    return ev(ast.parse(expressao.strip(), mode="eval").body)


# ---------- esquemas de argumentos (o "contrato" de cada ferramenta) ----------
class ArgsCalc(BaseModel):
    expressao: str = Field(description="expressão aritmética, por exemplo 'sqrt(16)+2'")


class ArgsContar(BaseModel):
    cap: int = Field(ge=1, le=11, description="número do capítulo (1 a 11)")


class ArgsPalavras(BaseModel):
    secao: str = Field(pattern=r"^\d{1,2}\.\d{1,2}$", description="identificador da seção, como '5.4'")


class ArgsBuscar(BaseModel):
    consulta: str = Field(min_length=3, description="pergunta ou termos de busca")
    k: int = Field(default=1, ge=1, le=5, description="quantos resultados")


class Ferramenta:
    def __init__(self, nome, descricao, modelo, funcao):
        self.nome, self.descricao, self.modelo, self.funcao = nome, descricao, modelo, funcao

    def esquema(self):
        """Esquema no formato usado por APIs de chamada de função (JSON Schema dos argumentos)."""
        return {"name": self.nome, "description": self.descricao, "parameters": self.modelo.model_json_schema()}


class Registro:
    """Guarda as ferramentas, valida a chamada contra o contrato, executa e devolve SEMPRE uma observação em texto."""

    def __init__(self, ferramentas):
        self.f = {x.nome: x for x in ferramentas}
        self.chamadas = 0
        self.erros = {"ferramenta_desconhecida": 0, "json_invalido": 0, "argumentos_invalidos": 0, "falha_execucao": 0}

    def descricoes(self):
        return "\n".join(f"- {x.nome}: {x.descricao} Argumentos: {json.dumps(list(x.modelo.model_fields))}" for x in self.f.values())

    def executar(self, nome, entrada_json):
        self.chamadas += 1
        if nome not in self.f:
            self.erros["ferramenta_desconhecida"] += 1
            return json.dumps({"ok": False, "erro": f"ferramenta desconhecida: {nome}", "disponiveis": sorted(self.f)}, ensure_ascii=False)
        try:
            bruto = json.loads(entrada_json)
        except (json.JSONDecodeError, TypeError) as e:
            self.erros["json_invalido"] += 1
            return json.dumps({"ok": False, "erro": f"JSON inválido: {e.__class__.__name__}"}, ensure_ascii=False)
        try:
            args = self.f[nome].modelo(**bruto) if isinstance(bruto, dict) else self.f[nome].modelo.model_validate(bruto)
        except ValidationError as e:
            self.erros["argumentos_invalidos"] += 1
            return json.dumps({"ok": False, "erro": "argumentos inválidos", "detalhe": [x["msg"] for x in e.errors()]}, ensure_ascii=False)
        try:
            return json.dumps({"ok": True, "resultado": self.f[nome].funcao(args)}, ensure_ascii=False)
        except Exception as e:  # a ferramenta falhou: o agente precisa VER o erro, não o programa quebrar
            self.erros["falha_execucao"] += 1
            return json.dumps({"ok": False, "erro": f"{e.__class__.__name__}: {e}"}, ensure_ascii=False)


def montar_registro():
    """As quatro ferramentas do Projeto 9. O corpus é o mesmo do Projeto 8 (Capítulos 1 a 11)."""
    import p8_corpus
    from p8_rag import tokens
    from rank_bm25 import BM25Okapi

    secoes = p8_corpus.carregar_secoes(ate_cap=11)
    por_id = {s["id"]: s for s in secoes}
    bm = BM25Okapi([tokens(s["titulo"] + " " + s["texto"]) for s in secoes], k1=1.5, b=0.75)

    def f_calc(a):
        v = calcular(a.expressao)
        return round(v, 6) if isinstance(v, float) else v

    def f_contar(a):
        return sum(1 for s in secoes if s["cap"] == a.cap)

    def f_palavras(a):
        if a.secao not in por_id:
            raise KeyError(f"seção inexistente: {a.secao}")
        return len(por_id[a.secao]["texto"].split())

    def f_buscar(a):
        pont = bm.get_scores(tokens(a.consulta))
        ordem = sorted(range(len(secoes)), key=lambda i: -pont[i])[: a.k]
        return [{"secao": secoes[i]["id"], "titulo": secoes[i]["titulo"], "pontuacao": round(float(pont[i]), 3)} for i in ordem]

    return Registro([
        Ferramenta("calculadora", "Avalia uma expressão aritmética (+ - * / ** %, sqrt, log, abs, round, min, max).", ArgsCalc, f_calc),
        Ferramenta("contar_secoes", "Conta as seções expositivas de um capítulo do livro (1 a 11).", ArgsContar, f_contar),
        Ferramenta("palavras_secao", "Devolve o número de palavras da prosa de uma seção do livro.", ArgsPalavras, f_palavras),
        Ferramenta("buscar_livro", "Busca lexical (BM25) no livro; devolve as seções mais relevantes para a consulta.", ArgsBuscar, f_buscar),
    ])
