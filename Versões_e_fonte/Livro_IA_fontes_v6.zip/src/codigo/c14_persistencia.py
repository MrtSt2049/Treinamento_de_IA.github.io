"""Capítulo 14: persistência de estado (checkpointers): retomar após falha, histórico, bifurcação e isolamento por thread."""
import operator
from collections import Counter
from typing import Annotated, TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END

execucoes = Counter()          # quantas vezes cada nó executou de fato
falhas_restantes = {"analisar": 1}

class Pipe(TypedDict):
    entrada: int
    log: Annotated[list, operator.add]
    valor: int

def no(nome, f):
    def _no(s):
        execucoes[nome] += 1
        if falhas_restantes.get(nome, 0) > 0:
            falhas_restantes[nome] -= 1
            raise RuntimeError(f"falha transitória em '{nome}'")
        return {"valor": f(s["valor"]), "log": [nome]}
    return _no

def monta(checkpointer=None):
    g = StateGraph(Pipe)
    g.add_node("coletar", no("coletar", lambda v: v + 10))
    g.add_node("limpar", no("limpar", lambda v: v * 2))
    g.add_node("analisar", no("analisar", lambda v: v + 1))
    g.add_node("publicar", no("publicar", lambda v: v - 3))
    g.add_edge(START, "coletar"); g.add_edge("coletar", "limpar"); g.add_edge("limpar", "analisar")
    g.add_edge("analisar", "publicar"); g.add_edge("publicar", END)
    return g.compile(checkpointer=checkpointer)

def tenta(app, entrada, cfg=None):
    try:
        return app.invoke(entrada, cfg) if cfg else app.invoke(entrada)
    except RuntimeError as e:
        return f"ERRO: {e}"

print("=== 1. Sem checkpointer: a falha obriga a recomeçar do zero ===")
execucoes.clear(); falhas_restantes.update({"analisar": 1})
app = monta()
print("1ª tentativa:", tenta(app, {"entrada": 1, "log": [], "valor": 1}))
print("2ª tentativa (recomeço):", tenta(app, {"entrada": 1, "log": [], "valor": 1}))
print("Execuções por nó:", dict(execucoes), "| total:", sum(execucoes.values()))

print("\n=== 2. Com checkpointer: retoma do último passo concluído ===")
execucoes.clear(); falhas_restantes.update({"analisar": 1})
app = monta(InMemorySaver())
cfg = {"configurable": {"thread_id": "execucao-A"}}
print("1ª tentativa:", tenta(app, {"entrada": 1, "log": [], "valor": 1}, cfg))
est = app.get_state(cfg)
print("Estado salvo:", est.values, "| próximo nó:", est.next)
print("Retomada (invoke(None)):", tenta(app, None, cfg))
print("Execuções por nó:", dict(execucoes), "| total:", sum(execucoes.values()))

print("\n=== 3. Histórico de checkpoints (um por passo) ===")
for e in app.get_state_history(cfg):
    print(f"  passo {e.metadata['step']:>2}  próximo={str(e.next):<16} valor={e.values.get('valor')}  log={e.values.get('log')}")

print("\n=== 4. Bifurcação (time travel): editar o estado de um checkpoint antigo e continuar dali ===")
hist = list(app.get_state_history(cfg))
antigo = [e for e in hist if e.next == ("analisar",)][0]            # estado logo antes de 'analisar'
print("Checkpoint escolhido: valor =", antigo.values["valor"], "| próximo =", antigo.next)
nova_cfg = app.update_state(antigo.config, {"valor": 100})           # cria um novo checkpoint (bifurcação)
print("Estado editado:", app.get_state(nova_cfg).values["valor"])
execucoes.clear()
r = app.invoke(None, nova_cfg)
print("Continuação a partir do estado editado:", r["valor"], "| nós executados:", dict(execucoes))
print("O checkpoint original continua no histórico, intacto: valor =", app.get_state(antigo.config).values["valor"])
print("O estado 'atual' da thread passou a ser o da bifurcação: valor =", app.get_state(cfg).values["valor"])

print("\n=== 5. Isolamento por thread_id ===")
app = monta(InMemorySaver())
falhas_restantes.update({"analisar": 0})
a = app.invoke({"entrada": 1, "log": [], "valor": 1}, {"configurable": {"thread_id": "u1"}})
b = app.invoke({"entrada": 5, "log": [], "valor": 5}, {"configurable": {"thread_id": "u2"}})
print("u1:", app.get_state({"configurable": {"thread_id": "u1"}}).values["valor"],
      "| u2:", app.get_state({"configurable": {"thread_id": "u2"}}).values["valor"])

print("\n=== 6. Idempotência: um nó que falha DEPOIS de um efeito externo repete o efeito ao ser retomado ===")
caixa_de_saida = []                         # o "mundo externo"
chaves_vistas = set()
tentativas = Counter()

def enviar_ingenuo(s):
    tentativas["ingenuo"] += 1
    caixa_de_saida.append(("pedido", s["entrada"]))        # efeito externo
    if tentativas["ingenuo"] == 1:
        raise RuntimeError("queda de rede depois de enviar")
    return {"log": ["enviar"]}

def enviar_idempotente(s):
    tentativas["idem"] += 1
    chave = ("pedido", s["entrada"])                       # chave de idempotência
    if chave not in chaves_vistas:
        chaves_vistas.add(chave)
        caixa_de_saida.append(chave)
    if tentativas["idem"] == 1:
        raise RuntimeError("queda de rede depois de enviar")
    return {"log": ["enviar"]}

for nome, f in (("ingênuo", enviar_ingenuo), ("idempotente", enviar_idempotente)):
    caixa_de_saida.clear()
    g = StateGraph(Pipe); g.add_node("enviar", f); g.add_edge(START, "enviar"); g.add_edge("enviar", END)
    app = g.compile(checkpointer=InMemorySaver())
    c = {"configurable": {"thread_id": nome}}
    tenta(app, {"entrada": 7, "log": [], "valor": 0}, c)
    tenta(app, None, c)
    print(f"  nó {nome:<12} -> mensagens na caixa de saída após a retomada: {len(caixa_de_saida)}")
