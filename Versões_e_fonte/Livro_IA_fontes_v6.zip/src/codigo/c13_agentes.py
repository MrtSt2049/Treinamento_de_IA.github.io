"""Capítulo 13: laços de agente (ReAct, Plan-and-Solve, Reflexion) sobre um 'LLM' SIMULADO e estocástico.

O 'LLM' aqui NÃO é um modelo de linguagem: é uma política que conhece a sequência certa de ações de cada tarefa e erra com
probabilidade p a cada decisão, em quatro modos (dois detectáveis pelo registro de ferramentas, dois silenciosos). Serve para
medir a ESTRUTURA dos laços (custo, propagação de erro, recuperação), não a qualidade de um modelo real.
"""
import json
import math
import random
import re

from c13_ferramentas import montar_registro

SISTEMA = ("Você é um agente que resolve a pergunta usando ferramentas. Responda SEMPRE em um destes formatos.\n"
           "Pensamento: <raciocínio curto>\nAção: <nome da ferramenta>\nEntrada: <JSON dos argumentos>\n"
           "ou\nPensamento: <raciocínio curto>\nResposta final: <valor>\nFerramentas disponíveis:\n")

# ----------------------------------------------------------------------------------------- tarefas
def roteiro(t):
    """Sequência correta de ações: lista de (ferramenta, função resultados->argumentos). O último resultado é a resposta."""
    k = t["tipo"]
    if k == "T1":
        return [("calculadora", lambda r: {"expressao": t["expr"]})]
    if k == "T2":
        return [("contar_secoes", lambda r: {"cap": t["cap"]})]
    if k == "T3":
        return [("contar_secoes", lambda r: {"cap": t["cap"]}),
                ("calculadora", lambda r: {"expressao": f"round(sqrt({r[0]}), 2)"})]
    if k == "T4":
        return [("buscar_livro", lambda r: {"consulta": t["consulta"], "k": 1}),
                ("palavras_secao", lambda r: {"secao": r[0][0]["secao"]})]
    if k == "T6":                                                # T passos encadeados: soma acumulada
        v = t["valores"]
        return [("calculadora", lambda r, i=i: {"expressao": (f"{v[0]} + {v[1]}" if i == 0 else f"{r[i-1]} + {v[i+1]}")}) for i in range(len(v) - 1)]
    if k == "T5":
        return [("palavras_secao", lambda r: {"secao": t["a"]}), ("palavras_secao", lambda r: {"secao": t["b"]}),
                ("calculadora", lambda r: {"expressao": f"{r[0]} + {r[1]}"})]
    raise ValueError(k)


def gerar_tarefas(reg, seed=7):
    """60 tarefas com gabarito calculado EXECUTANDO a sequência correta (não escrito à mão)."""
    import p8_gold
    rng = random.Random(seed)
    ts = []
    for _ in range(12):
        a, b, c = rng.randint(12, 99), rng.randint(12, 99), rng.randint(10, 500)
        ts.append({"tipo": "T1", "expr": f"({a}*{b})+{c}", "texto": f"Quanto é ({a}*{b})+{c}?"})
    for cap in rng.sample(range(1, 12), 10):
        ts.append({"tipo": "T2", "cap": cap, "texto": f"Quantas seções expositivas tem o Capítulo {cap} do livro?"})
    for cap in rng.sample(range(1, 12), 11):
        ts.append({"tipo": "T3", "cap": cap, "texto": f"Qual a raiz quadrada do número de seções expositivas do Capítulo {cap}, com 2 casas decimais?"})
    unicas = [(q, g[0]) for q, g, _ in p8_gold.EM_CORPUS if len(g) == 1]
    for q, g in rng.sample(unicas, 14):
        ts.append({"tipo": "T4", "consulta": q, "gold": g, "texto": f"Quantas palavras tem a seção do livro que melhor responde a: «{q}»?"})
    ids = [s for s in sorted({g for _, g in unicas})]
    for _ in range(13):
        a, b = rng.sample(ids, 2)
        ts.append({"tipo": "T5", "a": a, "b": b, "texto": f"Qual a soma do número de palavras das seções {a} e {b} do livro?"})
    for t in ts:                                           # gabarito = execução da sequência correta com a ferramenta real
        rs = []
        for nome, fa in roteiro(t):
            rs.append(json.loads(reg.executar(nome, json.dumps(fa(rs))))["resultado"])
        t["gabarito"] = rs[-1] if t["tipo"] != "T4" else rs[-1]
        if t["tipo"] == "T4":                              # gabarito de T4: palavras da seção GOLD (não da recuperada)
            t["gabarito"] = json.loads(reg.executar("palavras_secao", json.dumps({"secao": t["gold"]})))["resultado"]
    return ts


def confere(resp, gab):
    m = re.search(r"-?\d+(?:[.,]\d+)?", str(resp).replace(" ", ""))
    if not m:
        return False
    v = float(m.group().replace(",", "."))
    return abs(v - float(gab)) <= max(0.006, 1e-9 * abs(float(gab)))


# ----------------------------------------------------------------------------------------- LLM simulado
MODOS = ("malformado", "ferramenta_inexistente", "argumento_errado", "resposta_precoce")
DETECTAVEIS = {"malformado", "ferramenta_inexistente"}


def perturbar(nome, args, rng):
    """Argumento VÁLIDO mas errado (erro silencioso): o registro aceita, o resultado sai errado."""
    a = dict(args)
    if "cap" in a:
        a["cap"] = max(1, min(11, a["cap"] + rng.choice([-1, 1])))
    elif "secao" in a:
        a["secao"] = rng.choice(["1.1", "2.3", "3.2", "4.4", "5.1", "6.2", "7.3", "8.1"])
    elif "expressao" in a:
        a["expressao"] = re.sub(r"\d", lambda m: str((int(m.group()) + 1) % 10), a["expressao"], count=1)
    elif "consulta" in a:
        a["consulta"] = " ".join(a["consulta"].split()[2:] or a["consulta"].split())
    return a


class LLMSimulado:
    def __init__(self, rng, p):
        self.rng, self.p = rng, p
        self.chamadas = 0

    def _modo(self, permitidos=MODOS):
        return self.rng.choice([m for m in MODOS if m in permitidos]) if self.rng.random() < self.p else None

    @staticmethod
    def _fmt(nome, args, bruto=None):
        ent = bruto if bruto is not None else json.dumps(args, ensure_ascii=False)
        return f"Pensamento: vou usar {nome}.\nAção: {nome}\nEntrada: {ent}"

    def passo(self, t, resultados_ok):
        """Decisão do agente ReAct dado o que já foi observado com sucesso (lista de resultados)."""
        self.chamadas += 1
        r = roteiro(t)
        i = len(resultados_ok)
        modo = self._modo()
        if i >= len(r):                                                 # hora de responder
            v = resultados_ok[-1]
            if modo is not None:                                        # erro de transcrição/arredondamento (silencioso)
                v = (v + 1) if isinstance(v, (int, float)) else "?"
            return f"Pensamento: já tenho o resultado.\nResposta final: {v}"
        nome, fa = r[i]
        args = fa(resultados_ok)
        if modo == "resposta_precoce":
            return f"Pensamento: acho que sei.\nResposta final: {self.rng.randint(0, 99)}"
        if modo == "malformado":
            return self._fmt(nome, args, bruto=json.dumps(args, ensure_ascii=False).replace('"', "'"))
        if modo == "ferramenta_inexistente":
            return self._fmt("pesquisar_na_web", args)
        if modo == "argumento_errado":
            args = perturbar(nome, args, self.rng)
        return self._fmt(nome, args)

    def planejar(self, t, resultados_ok):
        """Plano completo (de uma vez) para o que falta; cada passo pode sair corrompido com prob. p, nos MESMOS quatro modos do
        ReAct. 'resposta_precoce' num plano é um plano truncado: ele para antes e o executor devolve um chute."""
        self.chamadas += 1
        plano, truncado = [], False
        for nome, fa in roteiro(t)[len(resultados_ok):]:
            modo = self._modo()
            if modo == "resposta_precoce":
                truncado = True
                break
            plano.append((nome, fa, modo))
        return plano, truncado

    def finalizar(self, resultados_ok):
        """Última chamada do Plan-and-Solve: compor a resposta final a partir dos resultados (erro de transcrição com prob. p)."""
        self.chamadas += 1
        v = resultados_ok[-1]
        return (v + 1) if (self._modo() is not None and isinstance(v, (int, float))) else v


RE_FINAL = re.compile(r"Resposta final:\s*(.+)", re.S)
RE_ACAO = re.compile(r"Ação:\s*(\w+)\s*\nEntrada:\s*(.+)", re.S)


def _palavras(s):
    return len(s.split())


def react(t, reg, llm, max_passos=12, memoria_extra=0):
    """Laço ReAct: a cada passo o 'modelo' recebe o prompt inteiro (sistema + pergunta + histórico) e devolve texto a ser interpretado."""
    base = SISTEMA + reg.descricoes() + "\nPergunta: " + t["texto"]
    hist, oks, tin, tout, resp = [], [], 0, 0, None
    for _ in range(max_passos):
        prompt = base + "".join(hist)
        saida = llm.passo(t, oks)
        tin += _palavras(prompt) + memoria_extra
        tout += _palavras(saida)
        mf = RE_FINAL.search(saida)
        if mf:
            resp = mf.group(1).strip()
            break
        ma = RE_ACAO.search(saida)
        if not ma:
            obs = json.dumps({"ok": False, "erro": "formato inválido"}, ensure_ascii=False)
        else:
            obs = reg.executar(ma.group(1), ma.group(2).strip())
            o = json.loads(obs)
            if o["ok"]:
                oks.append(o["resultado"])
        hist.append("\n" + saida + "\nObservação: " + obs)
    return {"resposta": resp, "tin": tin, "tout": tout, "chamadas_llm": llm.chamadas, "passos": len(hist) + (1 if resp else 0),
            "P0": _palavras(base) + memoria_extra, "m": [_palavras(h) for h in hist]}


def plan_solve(t, reg, llm, replanos=2):
    """Planejar uma vez, executar sem consultar o modelo a cada passo, replanejar só quando uma ferramenta devolve ERRO, e
    terminar com uma chamada que compõe a resposta (a mesma chance de erro de transcrição do ReAct)."""
    base = SISTEMA + reg.descricoes() + "\nPergunta: " + t["texto"]
    oks, tin, tout, nrep = [], 0, 0, 0
    while True:
        tin += _palavras(base) + sum(_palavras(json.dumps(o, ensure_ascii=False)) for o in oks)
        plano, truncado = llm.planejar(t, oks)
        tout += 12 * len(plano)
        falhou = False
        for nome, fa, modo in plano:
            args = fa(oks)
            if modo == "ferramenta_inexistente":
                obs = reg.executar("pesquisar_na_web", json.dumps(args))
            elif modo == "malformado":
                obs = reg.executar(nome, json.dumps(args).replace('"', "'"))
            else:
                obs = reg.executar(nome, json.dumps(perturbar(nome, args, llm.rng) if modo == "argumento_errado" else args, ensure_ascii=False))
            o = json.loads(obs)
            if not o["ok"]:
                falhou = True
                break
            oks.append(o["resultado"])
        if falhou:
            nrep += 1
            if nrep > replanos:
                return {"resposta": None, "tin": tin, "tout": tout, "chamadas_llm": llm.chamadas, "passos": len(oks)}
            continue
        if truncado:                                                   # o plano parou cedo: sem os dados, o executor chuta
            return {"resposta": str(llm.rng.randint(0, 99)), "tin": tin, "tout": tout, "chamadas_llm": llm.chamadas, "passos": len(oks)}
        tin += _palavras(base) + sum(_palavras(json.dumps(o, ensure_ascii=False)) for o in oks)
        resp = llm.finalizar(oks)
        tout += 6
        return {"resposta": resp, "tin": tin, "tout": tout, "chamadas_llm": llm.chamadas, "passos": len(oks)}


def reflexion(t, reg, rng, p, K=3, rho=1.0, q_detecta=1.0, palavras_reflexao=30):
    """Até K tentativas ReAct. Um avaliador externo julga a resposta (detecta erro com prob. q_detecta); se julga errada, escreve
    uma 'reflexão' que entra na memória (mais palavras no prompt) e, no modelo de aprendizado, reduz a taxa de erro por rho."""
    mem, tot = 0, {"tin": 0, "tout": 0, "chamadas_llm": 0, "passos": 0, "tentativas": 0}
    resp = None
    for k in range(K):
        llm = LLMSimulado(rng, p * rho ** k)
        r = react(t, reg, llm, memoria_extra=mem)
        for c in ("tin", "tout", "chamadas_llm", "passos"):
            tot[c] += r[c]
        tot["tentativas"] += 1
        resp = r["resposta"]
        certa = resp is not None and confere(resp, t["gabarito"])
        if certa or rng.random() >= q_detecta:                 # aceita (certa) ou o avaliador deixou passar o erro
            break
        mem += palavras_reflexao
    tot["resposta"] = resp
    return tot
