"""Capítulo 15: métricas de recuperação escritas à mão, com intervalos de confiança e comparação PAREADA entre dois recuperadores.
Unidade de recuperação = seção do livro (Capítulos 1 a 11). Perguntas e gabaritos: os do Projeto 8 (43 diretas + 24 parafraseadas)."""
import numpy as np

from p8_comum import DIRETAS, PARAF, S, embedding, tokens
from rank_bm25 import BM25Okapi

rng = np.random.default_rng(15)
ids = [s["id"] for s in S]
textos = [s["titulo"] + ". " + s["texto"] for s in S]
bm = BM25Okapi([tokens(t) for t in textos], k1=1.5, b=0.75)
emb = embedding(128)
V = np.array(emb._get_text_embeddings(textos))
Q = [(q, g, "dir") for q, g in DIRETAS] + [(q, g, "par") for q, g in PARAF]


def ranking_bm25(q): return np.argsort(-bm.get_scores(tokens(q)))
def ranking_lsa(q): return np.argsort(-(V @ np.array(emb._get_query_embedding(q))))


# ----------------------------------------------------------------------------------------- métricas (relevância binária)
def precisao_k(rank, gold, k): return sum(ids[i] in gold for i in rank[:k]) / k
def revocacao_k(rank, gold, k): return sum(ids[i] in gold for i in rank[:k]) / len(gold)
def acerto_k(rank, gold, k): return float(any(ids[i] in gold for i in rank[:k]))
def rr(rank, gold):
    for pos, i in enumerate(rank, 1):
        if ids[i] in gold: return 1 / pos
    return 0.0
def ap(rank, gold, K=100):
    """precisão média: média das precisões nas posições dos relevantes (normalizada pelo nº de relevantes)."""
    hits, soma = 0, 0.0
    for pos, i in enumerate(rank[:K], 1):
        if ids[i] in gold:
            hits += 1; soma += hits / pos
    return soma / len(gold)
def ndcg_k(rank, gold, k=10):
    dcg = sum(1 / np.log2(pos + 1) for pos, i in enumerate(rank[:k], 1) if ids[i] in gold)
    idcg = sum(1 / np.log2(pos + 1) for pos in range(1, min(len(gold), k) + 1))
    return dcg / idcg

METRICAS = {"acerto@1": lambda r, g: acerto_k(r, g, 1), "acerto@5": lambda r, g: acerto_k(r, g, 5), "precisão@5": lambda r, g: precisao_k(r, g, 5),
            "revocação@5": lambda r, g: revocacao_k(r, g, 5), "MRR": rr, "MAP": ap, "nDCG@10": lambda r, g: ndcg_k(r, g, 10)}

R = {"BM25": [ranking_bm25(q) for q, _, _ in Q], "LSA": [ranking_lsa(q) for q, _, _ in Q]}
G = [g for _, g, _ in Q]
POR = np.array([t for _, _, t in Q])
P = {nome: {m: np.array([f(r, g) for r, g in zip(rs, G)]) for m, f in METRICAS.items()} for nome, rs in R.items()}


def ic_bootstrap(x, B=10000):
    idx = rng.integers(0, len(x), (B, len(x)))
    medias = x[idx].mean(1)
    return np.percentile(medias, [2.5, 97.5])


print(f"{len(Q)} perguntas ({(POR == 'dir').sum()} diretas, {(POR == 'par').sum()} parafraseadas); {len(S)} seções; bootstrap com 10000 reamostragens\n")
print("A. Métricas por recuperador, com IC de 95% (bootstrap sobre as perguntas)")
print(f"{'métrica':<13} {'BM25':>22} {'LSA':>22}")
for m in METRICAS:
    out = []
    for nome in ("BM25", "LSA"):
        x = P[nome][m]; lo, hi = ic_bootstrap(x)
        out.append(f"{x.mean():.3f} [{lo:.3f}; {hi:.3f}]")
    print(f"{m:<13} {out[0]:>22} {out[1]:>22}")

print("\nB. Perguntas diretas x parafraseadas (MRR)")
for nome in ("BM25", "LSA"):
    for t, rot in (("dir", "diretas"), ("par", "parafraseadas")):
        x = P[nome]["MRR"][POR == t]; lo, hi = ic_bootstrap(x)
        print(f"  {nome:<5} {rot:<14} n={len(x):>2}  MRR={x.mean():.3f} [{lo:.3f}; {hi:.3f}]")

print("\nC. Comparação PAREADA BM25 - LSA (a diferença é calculada por pergunta; o IC é da diferença)")
for m in ("acerto@5", "MRR", "nDCG@10"):
    d = P["BM25"][m] - P["LSA"][m]
    lo, hi = ic_bootstrap(d)
    # IC dos dois recuperadores tratados como independentes (ERRADO para dados pareados): variância soma
    se_ind = np.sqrt(P["BM25"][m].var(ddof=1) / len(d) + P["LSA"][m].var(ddof=1) / len(d))
    print(f"  {m:<9} diferença média = {d.mean():+.3f}  IC pareado [{lo:+.3f}; {hi:+.3f}]  (erro-padrão pareado {d.std(ddof=1)/np.sqrt(len(d)):.3f} x independente {se_ind:.3f})")

print("\nD. Quantas perguntas o conjunto de avaliação precisa? (meia-largura do IC de 95% de uma proporção p=0,8)")
for n in (20, 50, 100, 400, 1600):
    print(f"  n = {n:>4}: ±{1.96*np.sqrt(0.8*0.2/n):.3f}")
n_necessario = int(np.ceil((1.96 ** 2) * 0.8 * 0.2 / 0.03 ** 2))
print(f"  para meia-largura ±0,03: n = {n_necessario}")
