"""Projeto 9, experimento 2: o custo em tokens (palavras) de um laço ReAct cresce com o QUADRADO do número de passos."""
import random

import numpy as np

import c13_agentes as A
from c13_ferramentas import montar_registro

reg = montar_registro()
rng = random.Random(3)
print("Tarefa T6: soma acumulada de T+1 números por T chamadas encadeadas à calculadora; 'LLM' sem erros (p=0).")
print("Proposição 13.1: palavras_de_entrada = (T+1)*P0 + soma_j m_j*(T-j);  com m constante: (T+1)*P0 + m*T*(T+1)/2\n")
print(f"{'T':>3} {'medido ReAct':>13} {'fórmula exata':>14} {'iguais':>7} {'por passo':>10} | {'Plan-and-Solve':>14}")
Ts = [1, 2, 4, 8, 12, 16, 24, 32]
med = []
for T in Ts:
    t = {"tipo": "T6", "valores": [rng.randint(1, 99) for _ in range(T + 1)], "texto": f"Some os números: " + ", ".join(["x"] * (T + 1))}
    t["texto"] = "Some os números: " + ", ".join(str(v) for v in t["valores"]) + " (use a calculadora, de dois em dois)."
    r = A.react(t, reg, A.LLMSimulado(random.Random(0), 0.0), max_passos=64)
    P0, m = r["P0"], r["m"]
    exata = (T + 1) * P0 + sum(mj * (T - j) for j, mj in enumerate(m))
    ps = A.plan_solve(t, reg, A.LLMSimulado(random.Random(0), 0.0))
    med.append(r["tin"])
    print(f"{T:3d} {r['tin']:13d} {exata:14d} {str(r['tin']==exata):>7} {r['tin']/(T+1):10.0f} | {ps['tin']:14d}   (acerto ReAct: {A.confere(r['resposta'], sum(t['valores']))})")
x = np.array(Ts, float)
y = np.array(med, float)
c2, c1, c0 = np.polyfit(x, y, 2)
print(f"\nAjuste quadrático das palavras de entrada: {c2:.1f}*T^2 + {c1:.1f}*T + {c0:.1f}   (previsto: m/2 = metade do tamanho médio de uma rodada)")
print(f"Razão medida entre T=32 e T=16: {med[-1]/med[5]:.2f}   (linear daria 2,0; quadrático puro, 4,0)")
