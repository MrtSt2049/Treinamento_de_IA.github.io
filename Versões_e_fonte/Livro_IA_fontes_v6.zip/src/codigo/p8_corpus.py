"""Projeto 8: corpus de recuperação = o texto expositivo dos Capítulos 1 a 11 deste livro, uma unidade por seção."""
import json
import re
import unicodedata

SRC = ".."
EXCLUIR = ("Resumo do capítulo", "Exercícios", "Soluções comentadas", "Referências e leituras")


def limpar(texto):
    """Remove da fonte em Markdown o que não é prosa: matemática, includes de código, figuras, cercas de contêineres."""
    texto = re.sub(r"\$\$.*?\$\$", " ", texto, flags=re.S)           # fórmulas em bloco
    texto = re.sub(r"\$[^$\n]*\$", " ", texto)                        # fórmulas em linha
    linhas = []
    for lin in texto.splitlines():
        s = lin.strip()
        if s.startswith(("<<<", ">>>", "+++", "<figure", "</figure", "<div", "</div", "```")) or s == ":::":
            continue
        if s.startswith(":::"):                                       # ::: definicao 11.1 · Título  ->  Título
            partes = s.split("·", 1)
            lin = partes[1].strip() if len(partes) > 1 else ""
        lin = re.sub(r"<[^>]+>", " ", lin)
        lin = re.sub(r"[*`]|\\\w+", " ", lin)
        linhas.append(lin)
    return re.sub(r"[ \t]+", " ", "\n".join(linhas)).strip()


def carregar_secoes(ate_cap=11):
    """Retorna uma lista de dicts {id, cap, titulo, texto} (um por seção expositiva)."""
    livro = json.load(open(f"{SRC}/livro.json"))
    secoes = []
    for v in livro["vistas"]:
        if v["id"] == "inicio" or "arquivos" not in v or "num" not in v or v["num"] > ate_cap:
            continue
        bruto = "\n".join(open(f"{SRC}/{a}", encoding="utf-8").read() for a in v["arquivos"])
        partes = re.split(r"(?m)^## ", bruto)[1:]
        for p in partes:
            cab, _, corpo = p.partition("\n")
            m = re.match(r"(\d+\.\d+)\s+(.*)", cab.strip())
            if not m or any(cab.strip().endswith(x) or x in cab for x in EXCLUIR):
                continue
            secoes.append({"id": m.group(1), "cap": v["num"], "titulo": m.group(2).strip(), "texto": limpar(corpo)})
    return secoes


def sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


if __name__ == "__main__":
    s = carregar_secoes()
    palavras = [len(x["texto"].split()) for x in s]
    print(len(s), "seções;", sum(palavras), "palavras; por seção: mín", min(palavras), "mediana", sorted(palavras)[len(palavras) // 2], "máx", max(palavras))
    for x in s[:3] + s[-3:]:
        print(x["id"], x["titulo"], len(x["texto"].split()), repr(x["texto"][:120]))
