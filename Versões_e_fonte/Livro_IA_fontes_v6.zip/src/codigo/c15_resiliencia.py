"""Capítulo 15: resiliência. Parte A-B: retry e fallback do LangChain/LangGraph REAIS. Parte C: simulação de tempestade de tentativas.
Parte D: disjuntor (circuit breaker) com relógio falso, testado. Sem modelo de linguagem."""
import operator
import random
from typing import Annotated, TypedDict

import numpy as np
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, START, StateGraph
from langgraph.types import RetryPolicy

# ----------------------------------------------------------------------------------------- A. retry e fallback
print("=== A. with_retry e with_fallbacks (LangChain) sobre uma chamada que falha com probabilidade f ===")
rng = random.Random(0)
chamadas = {"n": 0}

def instavel(x, f):
    chamadas["n"] += 1
    if rng.random() < f:
        raise ConnectionError("indisponível")
    return x

N = 20000
print(f"{'f':>5} {'tentativas máx. m':>18} {'sucesso medido':>15} {'1-f^m':>8} {'chamadas/pedido':>16} {'(1-f^m)/(1-f)':>14}")
for f in (0.2, 0.5):
    for m in (1, 3, 5):
        chamadas["n"] = 0; ok = 0
        r = RunnableLambda(lambda x, f=f: instavel(x, f)).with_retry(stop_after_attempt=m, wait_exponential_jitter=False, retry_if_exception_type=(ConnectionError,))
        for i in range(N):
            try:
                r.invoke(i); ok += 1
            except ConnectionError:
                pass
        print(f"{f:>5} {m:>18} {ok / N:>15.4f} {1 - f ** m:>8.4f} {chamadas['n'] / N:>16.3f} {(1 - f ** m) / (1 - f):>14.3f}")

principal = RunnableLambda(lambda x: instavel(x, 1.0))                     # sempre falha
reserva = RunnableLambda(lambda x: f"resposta degradada para {x}")
print("\nwith_fallbacks: principal sempre falha ->", principal.with_fallbacks([reserva]).invoke("pedido-1"))

# ----------------------------------------------------------------------------------------- B. RetryPolicy no LangGraph
print("\n=== B. RetryPolicy em um nó do LangGraph ===")
class E(TypedDict):
    log: Annotated[list, operator.add]
tentativas = {"n": 0}
def no_instavel(s):
    tentativas["n"] += 1
    if tentativas["n"] < 3:
        raise ConnectionError(f"falha {tentativas['n']}")
    return {"log": [f"ok na tentativa {tentativas['n']}"]}
for politica in (RetryPolicy(max_attempts=3, initial_interval=0.001, jitter=False), RetryPolicy(max_attempts=2, initial_interval=0.001, jitter=False)):
    tentativas["n"] = 0
    g = StateGraph(E); g.add_node("n", no_instavel, retry_policy=politica); g.add_edge(START, "n"); g.add_edge("n", END)
    try:
        r = g.compile().invoke({"log": []})
        print(f"  max_attempts={politica.max_attempts}: {r['log']} | execuções do nó: {tentativas['n']}")
    except ConnectionError as e:
        print(f"  max_attempts={politica.max_attempts}: esgotou, erro propagado ({e}) | execuções do nó: {tentativas['n']}")
tentativas["n"] = 0
def sempre_erro_de_programa(s):
    tentativas["n"] += 1
    raise ValueError("bug")
g = StateGraph(E); g.add_node("n", sempre_erro_de_programa, retry_policy=RetryPolicy(max_attempts=3, initial_interval=0.001, jitter=False)); g.add_edge(START, "n"); g.add_edge("n", END)
try:
    g.compile().invoke({"log": []})
except ValueError:
    print(f"  ValueError (bug): execuções do nó = {tentativas['n']}  (a política padrão NÃO repete erros de programação)")

# ----------------------------------------------------------------------------------------- C. tempestade de tentativas
print("\n=== C. Tempestade de tentativas (simulação em tempo discreto) ===")
def simula(estrategia, clientes=2000, capacidade=100, queda=20, semente=3, horizonte=600):
    """Um servidor atende até `capacidade` requisições por tick, e fica fora do ar nos primeiros `queda` ticks.
    Cada cliente envia 1 requisição no instante 0 e repete se falhar (queda ou excesso de carga)."""
    r = np.random.default_rng(semente)
    prox = np.zeros(clientes)                      # instante da próxima tentativa
    n_falhas = np.zeros(clientes, int)
    feito = np.full(clientes, -1)
    carga = np.zeros(horizonte, int)
    for t in range(horizonte):
        ativos = np.where((feito < 0) & (prox <= t))[0]
        carga[t] = len(ativos)
        if len(ativos) == 0:
            continue
        if t < queda:
            servidos = np.array([], int)
        else:
            servidos = r.permutation(ativos)[:capacidade]
        feito[servidos] = t
        for c in np.setdiff1d(ativos, servidos):
            n_falhas[c] += 1
            k = n_falhas[c]
            if estrategia == "imediata":
                espera = 1
            elif estrategia == "fixa":
                espera = 10
            elif estrategia == "exponencial":
                espera = min(2 ** k, 64)
            else:                                   # exponencial com jitter completo
                espera = 1 + r.integers(0, min(2 ** k, 64))
            prox[c] = t + espera
    concl = feito[feito >= 0]
    pos = carga[queda:]
    return dict(total=int(carga.sum()), pico=int(pos.max()), p95=int(np.percentile(concl, 95)) if len(concl) else -1, ok=len(concl) / clientes)

print("2000 clientes, servidor com capacidade 100 requisições/tick, fora do ar nos primeiros 20 ticks")
print(f"{'estratégia':<26} {'requisições enviadas':>21} {'pico de carga após a volta':>27} {'tick em que 95% terminaram':>28}")
for e in ("imediata", "fixa", "exponencial", "exponencial+jitter"):
    r = simula(e)
    print(f"{e:<26} {r['total']:>21d} {r['pico']:>27d} {r['p95']:>28d}")
print("(carga = requisições que chegam ao servidor em um tick; sem jitter, os clientes sincronizam e voltam em ondas)")

# ----------------------------------------------------------------------------------------- D. disjuntor
print("\n=== D. Disjuntor (circuit breaker): fechado -> aberto -> semiaberto ===")
class Disjuntor:
    def __init__(self, limite=3, espera=30.0, relogio=None):
        self.limite, self.espera, self.relogio = limite, espera, relogio
        self.estado, self.falhas, self.aberto_em = "fechado", 0, None
    def chama(self, f):
        if self.estado == "aberto":
            if self.relogio() - self.aberto_em >= self.espera:
                self.estado = "semiaberto"                      # deixa passar UMA tentativa de teste
            else:
                raise RuntimeError("disjuntor aberto: falha rápida, sem chamar o serviço")
        try:
            r = f()
        except ConnectionError:
            self.falhas += 1
            if self.estado == "semiaberto" or self.falhas >= self.limite:
                self.estado, self.aberto_em = "aberto", self.relogio()
            raise
        self.estado, self.falhas = "fechado", 0
        return r

t = {"agora": 0.0}
servico = {"no_ar": False, "chamadas": 0}
def f():
    servico["chamadas"] += 1
    if not servico["no_ar"]:
        raise ConnectionError("fora do ar")
    return "ok"
d = Disjuntor(limite=3, espera=30.0, relogio=lambda: t["agora"])
roteiro = [(0, "fora"), (1, "fora"), (2, "fora"), (3, "fora"), (10, "fora"), (31, "fora"), (40, "volta"), (72, "volta"), (73, "volta")]
for instante, evento in roteiro:
    t["agora"] = float(instante)
    if evento == "volta":
        servico["no_ar"] = True
    antes = servico["chamadas"]
    try:
        res = d.chama(f); desfecho = f"sucesso ({res})"
    except ConnectionError:
        desfecho = "falha do serviço"
    except RuntimeError as e:
        desfecho = "falha rápida (serviço não chamado)"
    print(f"  t={instante:>3}s serviço {'no ar ' if servico['no_ar'] else 'fora  '} -> {desfecho:<36} estado={d.estado:<10} chamadas reais ao serviço: {servico['chamadas'] - antes}")
print(f"Total de chamadas reais ao serviço: {servico['chamadas']} (de {len(roteiro)} pedidos)")
