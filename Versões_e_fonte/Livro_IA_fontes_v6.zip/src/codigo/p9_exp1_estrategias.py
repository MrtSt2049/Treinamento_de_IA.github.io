"""Projeto 9, experimento 1: taxa de acerto e custo de ReAct, Plan-and-Solve e Reflexion contra a taxa de erro p do 'LLM' simulado."""
import random
import time

import numpy as np

import c13_agentes as A
from c13_ferramentas import montar_registro

reg = montar_registro()
tarefas = A.gerar_tarefas(reg)
SEMENTES, PS = 100, (0.0, 0.05, 0.10, 0.20, 0.30)
n_passos = {"T1": 1, "T2": 1, "T3": 2, "T4": 2, "T5": 3}


def rodar(estrategia, p, semente):
    rng = random.Random(10_000 * semente + int(p * 1000))
    ac, cl, ti = [], [], []
    for t in tarefas:
        if estrategia == "ReAct":
            r = A.react(t, reg, A.LLMSimulado(rng, p))
        elif estrategia == "Plan-and-Solve":
            r = A.plan_solve(t, reg, A.LLMSimulado(rng, p))
        elif estrategia == "Reflexion rho=1":
            r = A.reflexion(t, reg, rng, p, K=3, rho=1.0)
        else:
            r = A.reflexion(t, reg, rng, p, K=3, rho=0.5)
        ac.append(r["resposta"] is not None and A.confere(r["resposta"], t["gabarito"]))
        cl.append(r["chamadas_llm"])
        ti.append(r["tin"])
    return np.mean(ac), np.mean(cl), np.mean(ti)


t0 = time.time()
print(f"{len(tarefas)} tarefas x {SEMENTES} sementes; 'LLM' simulado com taxa de erro p por decisão (metade dos erros é detectável pelo registro).")
print("Acerto médio [percentis 2,5-97,5 entre sementes] | chamadas ao LLM por tarefa | palavras de prompt por tarefa\n")
estrategias = ("ReAct", "Plan-and-Solve", "Reflexion rho=1", "Reflexion rho=0.5")
res = {}
for e in estrategias:
    print(f"== {e}")
    for p in PS:
        v = np.array([rodar(e, p, s) for s in range(SEMENTES)])
        res[(e, p)] = v
        a = v[:, 0]
        print(f"  p={p:.2f}  acerto {a.mean():.3f} [{np.percentile(a,2.5):.3f}; {np.percentile(a,97.5):.3f}]   chamadas {v[:,1].mean():5.2f}   palavras {v[:,2].mean():7.0f}")

print("\nFórmula da Proposição 13.2 para o ReAct (erros detectáveis são recuperados; os silenciosos acumulam):")
print("  P(acerto) = média sobre as tarefas de [(1-p)/(1-delta*p)]^n * (1-p), delta = 1/2 (fração detectável), n = ações com ferramenta")
for p in PS:
    prev = np.mean([((1 - p) / (1 - 0.5 * p)) ** n_passos[t["tipo"]] * (1 - p) for t in tarefas])
    obs = res[("ReAct", p)][:, 0].mean()
    print(f"  p={p:.2f}  previsto {prev:.3f}   observado {obs:.3f}   diferença {obs-prev:+.3f}")
print(f"\n[tempo de execução: {time.time()-t0:.0f} s]")
