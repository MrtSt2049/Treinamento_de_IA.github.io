"""Capítulo 13: as mesmas ferramentas no LangChain real (@tool, ToolNode, create_agent) com um modelo de chat ROTEIRIZADO.

O que é real: a definição de ferramentas, a geração do esquema, o laço do agente e o fluxo de mensagens do LangChain/LangGraph.
O que NÃO é real: o 'modelo' só devolve respostas pré-escritas (FakeMessagesListChatModel); nenhuma LLM foi consultada."""
import json
import langchain
import langgraph
from langchain.agents import create_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool

from c13_ferramentas import calcular, montar_registro

reg = montar_registro()
print("versões:", "langchain", langchain.__version__, "| langgraph", __import__("importlib.metadata").metadata.version("langgraph"))


@tool
def contar_secoes(cap: int) -> int:
    """Conta as seções expositivas de um capítulo do livro (1 a 11)."""
    return json.loads(reg.executar("contar_secoes", json.dumps({"cap": cap})))["resultado"]


@tool
def calculadora(expressao: str) -> float:
    """Avalia uma expressão aritmética (+ - * / ** %, sqrt, log, abs, round, min, max)."""
    return calcular(expressao)


print("\nEsquema gerado pelo @tool a partir da assinatura e da docstring:")
print(json.dumps(contar_secoes.args_schema.model_json_schema() if hasattr(contar_secoes.args_schema, "model_json_schema") else contar_secoes.args, ensure_ascii=False))
print("nome:", contar_secoes.name, "| descrição:", contar_secoes.description)

# o 'modelo' roteirizado: 1) pede contar_secoes(5); 2) pede calculadora(round(sqrt(8),2)); 3) responde
roteiro = [
    AIMessage(content="", tool_calls=[{"name": "contar_secoes", "args": {"cap": 5}, "id": "c1"}]),
    AIMessage(content="", tool_calls=[{"name": "calculadora", "args": {"expressao": "round(sqrt(8), 2)"}, "id": "c2"}]),
    AIMessage(content="A raiz quadrada de 8 é 2,83."),
]


class ModeloRoteirizado(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kw):                     # create_agent chama bind_tools; o roteiro ignora o esquema
        return self


agente = create_agent(ModeloRoteirizado(responses=roteiro), tools=[contar_secoes, calculadora],
                      system_prompt="Use as ferramentas para responder.")
saida = agente.invoke({"messages": [HumanMessage("Qual a raiz quadrada do número de seções do Capítulo 5, com 2 casas?")]})
print("\nFluxo de mensagens do laço do agente (tipo -> conteúdo/chamadas):")
for m in saida["messages"]:
    extra = f" tool_calls={[ (c['name'], c['args']) for c in m.tool_calls]}" if getattr(m, "tool_calls", None) else ""
    print(f"  {m.type:5} {str(m.content)[:60]!r}{extra}")

# um erro de ferramenta vira ToolMessage de erro (o agente continua, o programa não quebra)
roteiro2 = [AIMessage(content="", tool_calls=[{"name": "contar_secoes", "args": {"cap": "cinco"}, "id": "e1"}]),
            AIMessage(content="Não consegui: o argumento era inválido.")]
agente2 = create_agent(ModeloRoteirizado(responses=roteiro2), tools=[contar_secoes])
s2 = agente2.invoke({"messages": [HumanMessage("Quantas seções tem o capítulo cinco?")]})
print("\nArgumento fora do contrato dentro do LangChain:")
for m in s2["messages"]:
    print(f"  {m.type:5} {str(m.content)[:110]!r}")
