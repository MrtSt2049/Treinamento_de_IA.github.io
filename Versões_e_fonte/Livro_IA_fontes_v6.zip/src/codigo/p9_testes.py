"""Projeto 9: testes automáticos do registro, da calculadora segura, do parser e dos três laços."""
import json
import random

import c13_agentes as A
from c13_ferramentas import calcular, montar_registro

reg = montar_registro()
tarefas = A.gerar_tarefas(reg)
n = 0


def ok(nome, cond):
    global n
    assert cond, nome
    n += 1
    print(f"ok  {nome}")


ok("60 tarefas: 12 T1, 10 T2, 11 T3, 14 T4, 13 T5", len(tarefas) == 60 and [sum(t['tipo'] == k for t in tarefas) for k in ('T1', 'T2', 'T3', 'T4', 'T5')] == [12, 10, 11, 14, 13])
ok("calculadora segura: aritmética correta", calcular("(3+4)*2**3 - 10/4") == 53.5 and abs(calcular("sqrt(2)") - 2**0.5) < 1e-12)
for hostil in ("__import__('os')", "[1,2][0]", "x+1", "open('a')", "(1).real", "1 if 1 else 2"):
    try:
        calcular(hostil)
        ok("hostil recusado: " + hostil, False)
    except (ValueError, SyntaxError):
        ok("hostil recusado: " + hostil, True)
o = json.loads(reg.executar("contar_secoes", '{"cap": 0}'))
ok("contrato: cap=0 viola ge=1", not o["ok"] and o["erro"] == "argumentos inválidos")
ok("contrato: argumento extra é ignorado, não executa nada novo", json.loads(reg.executar("calculadora", '{"expressao":"1+1","extra":"x"}'))["resultado"] == 2)
ok("ferramenta falha -> observação (programa não quebra)", not json.loads(reg.executar("palavras_secao", '{"secao":"88.8"}'))["ok"])
ok("gabarito T3 = round(sqrt(nº de seções),2)", all(abs(t["gabarito"] - round(json.loads(reg.executar("contar_secoes", json.dumps({"cap": t["cap"]}))) ["resultado"] ** 0.5, 2)) < 1e-9 for t in tarefas if t["tipo"] == "T3"))
ok("confere(): tolerância de arredondamento", A.confere("Resposta 3,46", 3.4641) and not A.confere("3.5", 3.4641) and A.confere("1024", 1024))

# p = 0: todo laço acerta tudo (sem erros do 'modelo')
for nome, f in (("ReAct", lambda t, r: A.react(t, reg, A.LLMSimulado(r, 0.0))),
                ("Plan-and-Solve", lambda t, r: A.plan_solve(t, reg, A.LLMSimulado(r, 0.0))),
                ("Reflexion", lambda t, r: A.reflexion(t, reg, r, 0.0))):
    acertos = sum(A.confere(f(t, random.Random(1))["resposta"], t["gabarito"]) for t in tarefas if t["tipo"] != "T4")
    ok(f"{nome} com p=0 acerta as 46 tarefas sem busca", acertos == 46)
# T4 depende da busca BM25: o teto é o acerto do recuperador, não do agente
t4 = [t for t in tarefas if t["tipo"] == "T4"]
teto = sum(A.confere(A.react(t, reg, A.LLMSimulado(random.Random(1), 0.0))["resposta"], t["gabarito"]) for t in t4)
direto = sum(json.loads(reg.executar("buscar_livro", json.dumps({"consulta": t["consulta"]})))["resultado"][0]["secao"] == t["gold"] for t in t4)
print(f"    T4: agente com p=0 acerta {teto}/14 ; BM25 top-1 acerta a seção em {direto}/14 (o agente herda o teto da busca)")
ok("T4: o teto do agente é o do recuperador (mesma contagem, ou mais por coincidência de nº de palavras)", teto >= direto)

# o parser do ReAct trata saída malformada como ERRO de observação, não como exceção
class Mudo:
    chamadas = 0
    def passo(self, t, oks):
        self.chamadas += 1
        return "blá blá sem formato" if self.chamadas < 3 else "Resposta final: 42"
r = A.react(tarefas[0], reg, Mudo())
ok("saída sem formato vira observação de erro e o laço continua", r["resposta"] == "42" and r["passos"] == 3)
r = A.react(tarefas[0], reg, type("Sempre", (), {"chamadas": 0, "passo": lambda s, t, o: "Pensamento: x\nAção: calculadora\nEntrada: {\"expressao\":\"1+1\"}"})(), max_passos=5)
ok("limite de passos impede laço infinito", r["resposta"] is None and r["passos"] == 5)
print(f"\n{n} testes ok")
