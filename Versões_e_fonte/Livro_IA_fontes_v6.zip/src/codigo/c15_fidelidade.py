"""Capítulo 15: fidelidade (faithfulness) sem LLM-juiz: um verificador LEXICAL de suporte e a medição da sua própria validade.
As respostas de teste são construídas por regras, com rótulo conhecido por construção (nenhum modelo de linguagem foi usado):
  fiel     = 2 frases extraídas do contexto recuperado;
  externa  = 1 frase fiel + 1 frase VERDADEIRA do livro, mas de uma seção FORA do contexto;
  numero   = 1 frase fiel + 1 frase do contexto com um número alterado;
  negacao  = 1 frase fiel + 1 frase do contexto com 'não' inserido (contradiz o contexto, quase a mesma sequência de palavras)."""
import re

import numpy as np

from p8_comum import DIRETAS, PARAF, S, tokens
from rank_bm25 import BM25Okapi

rng = np.random.default_rng(2026)
textos = {s["id"]: s["titulo"] + ". " + s["texto"] for s in S}
ids = list(textos)
bm = BM25Okapi([tokens(textos[i]) for i in ids], k1=1.5, b=0.75)
Q = [(q, g) for q, g in DIRETAS] + [(q, g) for q, g in PARAF]
NUM = re.compile(r"\d+(?:[.,]\d+)?")


def frases(texto):
    fs = [f.strip() for f in re.split(r"(?<=[.!?])\s+|\n+", texto)]
    return [f for f in fs if 7 <= len(f.split()) <= 40 and "$" not in f and "<" not in f and ">" not in f]


def contexto(q, k=3):
    pont = bm.get_scores(tokens(q))
    return [ids[i] for i in np.argsort(-pont)[:k]]


# ----------------------------------------------------------------------------------------- verificador
def suporte(frase, ctx_tokens, ctx_nums):
    """Pontuação de suporte da frase: fração dos radicais da frase presentes no contexto; 0 se algum número da frase não está no contexto."""
    nums = NUM.findall(frase)
    if any(n.replace(",", ".") not in ctx_nums for n in nums):
        return 0.0
    ts = tokens(frase)
    return sum(t in ctx_tokens for t in ts) / max(len(ts), 1)


def pontuar(resposta, ctx_ids):
    ctx = " ".join(textos[i] for i in ctx_ids)
    ct = set(tokens(ctx)); cn = {n.replace(",", ".") for n in NUM.findall(ctx)}
    return min(suporte(f, ct, cn) for f in resposta)          # a resposta vale o que vale sua frase MENOS apoiada


# ----------------------------------------------------------------------------------------- conjunto de teste construído
def altera_numero(f):
    m = NUM.search(f)
    v = m.group()
    novo = str(int(float(v.replace(",", "."))) + 3) if float(v.replace(",", ".")).is_integer() else v + "7"
    return f[:m.start()] + novo + f[m.end():]


def insere_negacao(f):
    for alvo in (" é ", " são ", " tem ", " tem ", " pode ", " permite ", " usa "):
        if alvo in f:
            return f.replace(alvo, alvo[:-1] + " não" + " ", 1) if alvo.strip() in ("é", "são") else f.replace(alvo, " não" + alvo, 1)
    return None


casos = []
for q, g in Q:
    ctx = contexto(q)
    pool = [f for i in ctx for f in frases(textos[i])]
    ct = set(tokens(" ".join(textos[i] for i in ctx)))
    pont = sorted(pool, key=lambda f: -len(set(tokens(q)) & set(tokens(f))))
    if len(pont) < 4:
        continue
    base = pont[:2]
    com_num = [f for f in pool if NUM.search(f) and f not in base]
    com_neg = [f for f in pool if insere_negacao(f) and f not in base]
    fora = [f for i in rng.permutation(ids)[:8] if i not in ctx for f in frases(textos[i])]
    if not (com_num and com_neg and fora):
        continue
    casos.append(dict(q=q, ctx=ctx, fiel=base,
                      externa=[base[0], fora[rng.integers(len(fora))]],
                      numero=[base[0], altera_numero(com_num[rng.integers(len(com_num))])],
                      negacao=[base[0], insere_negacao(com_neg[rng.integers(len(com_neg))])]))
TIPOS = ("fiel", "externa", "numero", "negacao")
pontos = {t: np.array([pontuar(c[t], c["ctx"]) for c in casos]) for t in TIPOS}
print(f"{len(casos)} casos (cada um gera 4 respostas: {len(casos) * 4} respostas)\n")
print("Exemplos (primeiro caso):")
for t in TIPOS:
    print(f"  [{t:<7}] suporte = {pontos[t][0]:.2f} | 2ª frase: {casos[0][t][1][:130]}")

# ----------------------------------------------------------------------------------------- avaliação do verificador
def auc(pos, neg):
    """AUC = P(pontuação de uma resposta INFIEL < pontuação de uma fiel) com empates valendo 1/2 (estatística U de Mann-Whitney)."""
    return float(np.mean([(n < p) + 0.5 * (n == p) for n in neg for p in pos]))

print("\nA. Pontuação de suporte (mínimo entre as frases): quartis por tipo de resposta")
for t in TIPOS:
    q1, q2, q3 = np.percentile(pontos[t], [25, 50, 75])
    print(f"  {t:<8} Q1={q1:.2f}  mediana={q2:.2f}  Q3={q3:.2f}")

print("\nB. AUC de cada tipo de infidelidade contra as respostas fiéis (0,5 = acaso; 1 = separação perfeita)")
for t in TIPOS[1:]:
    print(f"  {t:<8} AUC = {auc(pontos['fiel'], pontos[t]):.3f}")

print("\nC. Taxa de detecção por limiar tau (resposta marcada INFIEL se suporte < tau)")
print(f"{'tau':>5} {'falso alarme (fiel)':>20} {'externa':>9} {'numero':>8} {'negacao':>9} {'kappa (global)':>15}")
melhor = None
for tau in (0.5, 0.6, 0.7, 0.8, 0.9, 0.95):
    fa = float(np.mean(pontos["fiel"] < tau))
    det = {t: float(np.mean(pontos[t] < tau)) for t in TIPOS[1:]}
    # kappa de Cohen entre o rótulo por construção (fiel x infiel) e o veredito, com as 4 respostas por caso
    y = np.array([0] * len(casos) + [1] * (3 * len(casos)))
    v = np.concatenate([pontos["fiel"] < tau] + [pontos[t] < tau for t in TIPOS[1:]]).astype(int)
    po = float(np.mean(y == v)); pe = float(np.mean(y) * np.mean(v) + (1 - np.mean(y)) * (1 - np.mean(v)))
    kappa = (po - pe) / (1 - pe)
    print(f"{tau:>5} {fa:>20.3f} {det['externa']:>9.3f} {det['numero']:>8.3f} {det['negacao']:>9.3f} {kappa:>15.3f}")

print("\nD. Fidelidade não é correção: a resposta 'externa' é VERDADEIRA segundo o livro, e mesmo assim infiel ao contexto recuperado.")
print("   Um verificador de fidelidade a mede (e deve marcá-la); um de correção factual a aprovaria.")
print("\nE. Por que a negação passa: o verificador compara radicais SEM palavras vazias, e 'não' é palavra vazia.")
iguais = np.mean([tokens(c["negacao"][1].replace(" não ", " ")) == tokens(c["negacao"][1]) for c in casos])
print(f"   Casos em que a frase negada e a frase sem o 'não' têm exatamente os mesmos radicais: {iguais:.2f}")
print("\nF. Aviso de validade: as respostas 'fiel' são trechos copiados do contexto, então o falso alarme 0,000 é artefato da construção.")
print("   Respostas fiéis REAIS parafraseiam, e um verificador lexical erraria aí; medir isso exigiria um gerador de paráfrases (um LLM), não executado.")
