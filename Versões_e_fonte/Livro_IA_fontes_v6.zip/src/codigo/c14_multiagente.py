"""Capítulo 14: sistemas multiagente em grafo: supervisor (Command/goto), subgrafo hierárquico e fan-out dinâmico (Send).
Os 'agentes' são funções determinísticas: o objetivo é mostrar a ESTRUTURA de controle, não a qualidade de um modelo."""
import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, Send

# ----------------------------------------------------------------------------------------- 1. supervisor
print("=== 1. Padrão supervisor: um nó roteia para especialistas e recebe o controle de volta ===")

class Eq(TypedDict, total=False):
    tarefa: str
    fatos: list
    conta: float
    texto: str
    rota: Annotated[list, operator.add]       # trilha de quem agiu (para inspeção)

def supervisor(s: Eq) -> Command:
    """Política de roteamento (no capítulo 13 seria um LLM): olha o que falta no estado."""
    if not s.get("fatos"):
        destino = "pesquisador"
    elif s.get("conta") is None:
        destino = "calculador"
    elif not s.get("texto"):
        destino = "redator"
    else:
        destino = END
    return Command(goto=destino, update={"rota": [f"supervisor->{destino}"]})

def pesquisador(s): return Command(goto="supervisor", update={"fatos": ["preço=40", "quantidade=3"]})
def calculador(s):
    f = dict(x.split("=") for x in s["fatos"])
    return Command(goto="supervisor", update={"conta": float(f["preço"]) * float(f["quantidade"])})
def redator(s): return Command(goto="supervisor", update={"texto": f"Total: {s['conta']:.0f}"})

g = StateGraph(Eq)
for nome, f in (("supervisor", supervisor), ("pesquisador", pesquisador), ("calculador", calculador), ("redator", redator)):
    g.add_node(nome, f)
g.add_edge(START, "supervisor")                # só a entrada é aresta estática: o resto é roteado por Command
app = g.compile()
r = app.invoke({"tarefa": "total do pedido", "rota": []})
print("Trilha:", r["rota"])
print("Resultado:", r["texto"])

# ----------------------------------------------------------------------------------------- 2. subgrafo
print("\n=== 2. Hierarquia: um subgrafo inteiro funciona como um nó do grafo pai ===")

class EstSub(TypedDict, total=False):
    numeros: list
    media: float
    desvio: float
    relatorio: str

def calc_media(s): return {"media": sum(s["numeros"]) / len(s["numeros"])}
def calc_desvio(s):
    m = s["media"]; return {"desvio": (sum((x - m) ** 2 for x in s["numeros"]) / len(s["numeros"])) ** 0.5}
sub = StateGraph(EstSub)
sub.add_node("media", calc_media); sub.add_node("desvio", calc_desvio)
sub.add_edge(START, "media"); sub.add_edge("media", "desvio"); sub.add_edge("desvio", END)
equipe_estatistica = sub.compile()

def coletar(s): return {"numeros": [2, 4, 4, 4, 5, 5, 7, 9]}
def relatar(s): return {"relatorio": f"média={s['media']:.1f}, desvio={s['desvio']:.1f}"}
pai = StateGraph(EstSub)
pai.add_node("coletar", coletar); pai.add_node("equipe_estatistica", equipe_estatistica); pai.add_node("relatar", relatar)
pai.add_edge(START, "coletar"); pai.add_edge("coletar", "equipe_estatistica"); pai.add_edge("equipe_estatistica", "relatar"); pai.add_edge("relatar", END)
app = pai.compile()
print("Resultado:", app.invoke({})["relatorio"])
print("Eventos com subgrafos visíveis (namespace do evento, nós):")
for ns, upd in app.stream({}, stream_mode="updates", subgraphs=True):
    print("  ", ("/".join(p.split(":")[0] for p in ns) or "(raiz)"), list(upd))

# ----------------------------------------------------------------------------------------- 3. Send
print("\n=== 3. Fan-out dinâmico com Send: o número de trabalhadores só se sabe em tempo de execução ===")

class Mapa(TypedDict):
    itens: list
    resultados: Annotated[list, operator.add]
    total: int

def despachar(s: Mapa):
    return [Send("trabalhador", {"item": x}) for x in s["itens"]]       # uma tarefa por item

def trabalhador(entrada: dict) -> dict:
    return {"resultados": [entrada["item"] ** 2]}

def somar(s: Mapa): return {"total": sum(s["resultados"])}

g = StateGraph(Mapa)
g.add_node("trabalhador", trabalhador); g.add_node("somar", somar)
g.add_conditional_edges(START, despachar, ["trabalhador"])
g.add_edge("trabalhador", "somar"); g.add_edge("somar", END)
app = g.compile()
for itens in ([1, 2, 3], list(range(1, 11))):
    r = app.invoke({"itens": itens, "resultados": []})
    print(f"  {len(itens):>2} itens -> {len(r['resultados']):>2} execuções do trabalhador; soma dos quadrados = {r['total']} (conferência: {sum(x*x for x in itens)})")
