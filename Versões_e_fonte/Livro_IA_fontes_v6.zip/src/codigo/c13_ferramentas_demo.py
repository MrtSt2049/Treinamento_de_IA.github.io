"""Demonstração: o registro de ferramentas e a calculadora segura diante de entradas válidas, inválidas e hostis."""
import json
import time
from c13_ferramentas import calcular, montar_registro

reg = montar_registro()
print("Esquema JSON da ferramenta contar_secoes (o que o modelo 'enxerga'):")
print(json.dumps(reg.f["contar_secoes"].esquema(), ensure_ascii=False, indent=1))
print("\nChamadas ao registro (nome, entrada) -> observação:")
casos = [
    ("calculadora", '{"expressao": "sqrt(16) + 2*3"}'),
    ("contar_secoes", '{"cap": 5}'),
    ("contar_secoes", '{"cap": 99}'),                               # fora do contrato
    ("contar_secoes", '{"cap": "cinco"}'),                          # tipo errado
    ("contar_secoes", '{cap: 5}'),                                  # JSON malformado
    ("palavras_secao", '{"secao": "5.4"}'),
    ("palavras_secao", '{"secao": "99.9"}'),                        # passa no esquema, falha na execução
    ("buscar_livro", '{"consulta": "produto escalar de dois vetores", "k": 2}'),
    ("enviar_email", '{"para": "x"}'),                              # ferramenta inexistente
]
for nome, ent in casos:
    print(f"{nome} {ent}\n   -> {reg.executar(nome, ent)}")
print("\nContagem de erros por tipo:", reg.erros)

print("\nCalculadora segura contra entradas hostis:")
for e in ["2**10", "__import__('os').system('echo invadido')", "open('/etc/passwd').read()", "(1).__class__", "9**9**9", "lambda: 1", "1/0"]:
    t0 = time.perf_counter()
    try:
        r = calcular(e)
    except Exception as ex:
        r = f"RECUSADO ({ex.__class__.__name__}: {ex})"
    print(f"  {e!r:42} -> {r}   [{(time.perf_counter()-t0)*1000:.2f} ms]")
