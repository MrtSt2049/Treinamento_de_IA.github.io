"""Projeto 10: testes de comportamento do grafo (determinísticos: as probabilidades são fixadas em 0 ou 1)."""
import random

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.errors import GraphRecursionError
from langgraph.types import Command

import p10_equipe as P
from c13_ferramentas import montar_registro

REG = montar_registro()
VERDADE = {c: __import__("json").loads(REG.executar("contar_secoes", '{"cap": %d}' % c))["resultado"] for c in range(1, 12)}
n_ok = 0


def mundo(**kw):
    return P.Mundo(REG, random.Random(kw.pop("semente", 1)), **kw)


def verifica(nome, cond):
    global n_ok
    assert cond, "FALHOU: " + nome
    n_ok += 1
    print("ok  ", nome)


# 1. caminho feliz
m = mundo(p_redator=0.0)
est, f = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [3, 5, 8]}, "t1")
verifica("caminho feliz: publica exatamente um relatório", len(m.mural) == 1 and est["publicado"])
verifica("relatório correto (números = ferramentas reais)", P.le_relatorio(m.mural[0]) == ({c: VERDADE[c] for c in (3, 5, 8)}, sum(VERDADE[c] for c in (3, 5, 8))))
verifica("três pesquisadores em paralelo, um por capítulo", m.execucoes["pesquisador"] == 3 and m.chamadas_ferramenta == 3 + 2)
verifica("trilha começa em pesquisadores e termina em publicador", est["trilha"][0] == "supervisor->pesquisadores" and est["trilha"][-2] == "publicador")

# 2. o redutor mescla escritas paralelas
verifica("redutor de dicionário: 5 capítulos paralelos, 5 chaves", len(P.executa(*(lambda m: (P.construir(m, InMemorySaver()), m, {"caps": [1, 2, 3, 4, 5]}, "t2"))(mundo(p_redator=0.0)))[0]["contagens"]) == 5)

# 3. ciclo de revisão: redator sempre erra, revisor perfeito -> esgota as revisões e o supervisor encaminha ao humano com aviso
m = mundo(p_redator=1.0, q_revisor=1.0, max_revisoes=2, humano=lambda r: {"decisao": "rejeitar"})
est, _ = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [3, 5]}, "t3")
verifica("redator erra sempre: 1 rascunho + 2 refações = 3 execuções do redator", m.execucoes["redator"] == 3)
verifica("revisor perfeito + humano que rejeita: nada é publicado", m.mural == [] and est["aprovacao"] == "rejeitado")

# 4. revisor perfeito corrige um erro ocasional (semente que erra só no 1º rascunho)
achou = None
for sem in range(200):
    m = mundo(p_redator=0.5, q_revisor=1.0, max_revisoes=3, semente=sem)
    est, _ = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [2, 4, 6]}, f"t4-{sem}")
    if m.execucoes["redator"] == 2:
        achou = (sem, m, est); break
verifica("há execução em que o revisor devolve o rascunho e o 2º rascunho passa", achou is not None)
sem, m, est = achou
verifica("trilha registra o ciclo redator -> revisor:refazer -> redator", "revisor:refazer" in est["trilha"] and est["trilha"].count("redator") == 2)
verifica("o relatório publicado após a correção está certo", P.le_relatorio(m.mural[0])[0] == {c: VERDADE[c] for c in (2, 4, 6)})

# 5. aprovação humana: rejeitar, editar
m = mundo(p_redator=0.0, humano=lambda r: {"decisao": "rejeitar"})
est, _ = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [3]}, "t5a")
verifica("humano rejeita: mural vazio e estado final 'rejeitado'", m.mural == [] and est["aprovacao"] == "rejeitado" and not est.get("publicado"))
m = mundo(p_redator=0.0, humano=lambda r: {"decisao": "editar", "relatorio": r + " (revisado por humano)"})
est, _ = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [3]}, "t5b")
verifica("humano edita: é o texto EDITADO que vai ao mural", m.mural[0].endswith("(revisado por humano)"))

# 6. a pausa de fato interrompe antes de qualquer efeito externo
m = mundo(p_redator=0.0)
app = P.construir(m, InMemorySaver())
cfg = {"configurable": {"thread_id": "t6"}, "recursion_limit": 60}
r = app.invoke({"caps": [3, 5], "contagens": {}, "trilha": []}, cfg)
verifica("antes da resposta humana: pausado em 'aprovador' e mural vazio", "__interrupt__" in r and app.get_state(cfg).next == ("aprovador",) and m.mural == [])
r = app.invoke(Command(resume={"decisao": "aprovar"}), cfg)
verifica("após Command(resume): publica uma vez", len(m.mural) == 1)

# 7. falha transitória na publicação: retoma, sem duplicar e sem refazer o trabalho anterior
m = mundo(p_redator=0.0, f_publicar=0.7, semente=11)
est, falhas = P.executa(P.construir(m, InMemorySaver()), m, {"caps": [3, 5, 8]}, "t7", tentativas_publicacao=50)
verifica(f"{falhas} falha(s) transitória(s) na publicação, depois sucesso", falhas >= 1 and est["publicado"])
verifica("idempotência: exatamente 1 publicação no mural apesar das repetições", len(m.mural) == 1)
verifica("a retomada não repetiu pesquisa, cálculo, redação, revisão nem aprovação", m.execucoes["pesquisador"] == 3 and m.execucoes["calculador"] == 1 and m.execucoes["redator"] == 1 and m.execucoes["revisor"] == 1)

# 8. isolamento entre threads
m = mundo(p_redator=0.0)
app = P.construir(m, InMemorySaver())
a, _ = P.executa(app, m, {"caps": [1, 2]}, "A")
b, _ = P.executa(app, m, {"caps": [9, 10, 11]}, "B")
verifica("duas threads no mesmo grafo: estados independentes", a["total"] == VERDADE[1] + VERDADE[2] and b["total"] == sum(VERDADE[c] for c in (9, 10, 11)))

# 9. limite de segurança contra ciclos
m = mundo(p_redator=1.0, q_revisor=1.0, max_revisoes=10 ** 6)
app = P.construir(m, InMemorySaver())
try:
    app.invoke({"caps": [3], "contagens": {}, "trilha": []}, {"configurable": {"thread_id": "t9"}, "recursion_limit": 25})
    verifica("recursion_limit interrompe um ciclo sem fim", False)
except GraphRecursionError:
    verifica("recursion_limit interrompe um ciclo sem fim", True)

print(f"\n{n_ok} verificações ok")
