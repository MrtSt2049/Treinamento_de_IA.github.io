"""Projeto 10: equipe de agentes em LangGraph (supervisor + especialistas + revisor + aprovação humana + publicação com checkpoint).

Os 'agentes' decidem por regras e por sorteios controlados; as ferramentas são as REAIS do Projeto 9. O objetivo é exercitar a
ARQUITETURA (estado, redutores, roteamento, ciclo de revisão, pausa para humano, retomada), e não medir a qualidade de um LLM.
"""
import hashlib
import json
import operator
import random
import re
from dataclasses import dataclass, field
from typing import Annotated, TypedDict

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, Send, interrupt


# ----------------------------------------------------------------------------------------- estado
def mescla_dicts(antigo: dict, novo: dict) -> dict:
    """Redutor: escritas paralelas em chaves diferentes de um dicionário compartilhado."""
    return {**(antigo or {}), **(novo or {})}


class Estado(TypedDict, total=False):
    caps: list                                   # pedido: capítulos a incluir
    contagens: Annotated[dict, mescla_dicts]     # cap -> nº de seções (escrito em paralelo pelos pesquisadores)
    total: int
    media: float
    relatorio: str
    revisoes: int                                # quantas vezes o redator foi reacionado por feedback
    veredito: str                                # '', 'ok' ou 'refazer'
    feedback: str
    aprovacao: str                               # '', 'aprovado', 'rejeitado'
    publicado: bool
    trilha: Annotated[list, operator.add]        # quem agiu, em ordem (observabilidade)


# ----------------------------------------------------------------------------------------- mundo externo
@dataclass
class Mundo:
    """Tudo que NÃO é estado do grafo: o registro de ferramentas, o mural onde se publica e os sorteios."""
    reg: object
    rng: random.Random
    p_redator: float = 0.3          # prob. de o redator transcrever errado um número (erro silencioso)
    q_revisor: float = 1.0          # prob. de o revisor perceber uma discrepância que existe
    max_revisoes: int = 2           # R: quantas vezes o supervisor devolve ao redator
    f_publicar: float = 0.0         # prob. de falha transitória DEPOIS do efeito externo (rede caiu)
    humano: object = None           # função relatorio -> {'decisao': ...}; None = aprova sempre
    mural: list = field(default_factory=list)       # o efeito externo irreversível
    chaves: set = field(default_factory=set)        # chaves de idempotência já usadas
    chamadas_ferramenta: int = 0
    execucoes: dict = field(default_factory=dict)   # nó -> nº de execuções (para medir custo de recomeço)

    def conta(self, no):
        self.execucoes[no] = self.execucoes.get(no, 0) + 1

    def ferramenta(self, nome, args):
        self.chamadas_ferramenta += 1
        o = json.loads(self.reg.executar(nome, json.dumps(args)))
        if not o["ok"]:
            raise RuntimeError(o["erro"])
        return o["resultado"]


RE_NUM = re.compile(r"(cap\s*(\d+)\s*=\s*(\d+))|(Total\s*=\s*(\d+))")


def formata(contagens: dict, total: int, media: float) -> str:
    itens = "; ".join(f"cap {c} = {contagens[c]}" for c in sorted(contagens))
    return f"Relatório de seções: {itens}. Total = {total}. Média = {media:.2f}."


def le_relatorio(texto: str):
    cont, total = {}, None
    for m in RE_NUM.finditer(texto):
        if m.group(1):
            cont[int(m.group(2))] = int(m.group(3))
        else:
            total = int(m.group(5))
    return cont, total


# ----------------------------------------------------------------------------------------- grafo
def construir(mundo: Mundo, checkpointer=None, **compilar):
    def supervisor(s: Estado) -> Command:
        mundo.conta("supervisor")
        if s.get("publicado") or s.get("aprovacao") == "rejeitado":
            destino = END
        elif len(s.get("contagens", {})) < len(s["caps"]):
            return Command(goto=[Send("pesquisador", {"cap": c}) for c in s["caps"]], update={"trilha": ["supervisor->pesquisadores"]})
        elif s.get("total") is None:
            destino = "calculador"
        elif not s.get("relatorio") or (s.get("veredito") == "refazer" and s.get("revisoes", 0) < mundo.max_revisoes):
            destino = "redator"
        elif not s.get("veredito"):
            destino = "revisor"
        elif not s.get("aprovacao"):
            destino = "aprovador"
        else:
            destino = "publicador"
        return Command(goto=destino, update={"trilha": [f"supervisor->{destino}"]})

    def pesquisador(entrada: dict) -> dict:
        mundo.conta("pesquisador")
        n = mundo.ferramenta("contar_secoes", {"cap": entrada["cap"]})
        return {"contagens": {entrada["cap"]: n}}

    def calculador(s: Estado) -> dict:
        mundo.conta("calculador")
        valores = [s["contagens"][c] for c in s["caps"]]
        total = int(mundo.ferramenta("calculadora", {"expressao": " + ".join(map(str, valores))}))
        media = float(mundo.ferramenta("calculadora", {"expressao": f"round({total}/{len(valores)}, 2)"}))
        return {"total": total, "media": media}

    def redator(s: Estado) -> dict:
        mundo.conta("redator")
        cont, total = dict(s["contagens"]), s["total"]
        if mundo.rng.random() < mundo.p_redator:                     # erro silencioso de transcrição
            alvo = mundo.rng.choice(sorted(cont) + ["total"])
            delta = mundo.rng.choice([-3, -2, -1, 1, 2, 3])
            if alvo == "total":
                total += delta
            else:
                cont[alvo] += delta
        rev = s.get("revisoes", 0) + (1 if s.get("relatorio") else 0)
        return {"relatorio": formata(cont, total, s["media"]), "revisoes": rev, "veredito": "", "feedback": "",
                "trilha": ["redator"]}

    def revisor(s: Estado) -> dict:
        """Confere o texto contra os fatos do estado (recomputando). Com prob. 1-q, deixa passar uma discrepância."""
        mundo.conta("revisor")
        cont, total = le_relatorio(s["relatorio"])
        soma_do_texto = sum(cont.values())
        discrepante = (cont != {int(k): v for k, v in s["contagens"].items()} or total != s["total"] or soma_do_texto != total)
        if discrepante and mundo.rng.random() < mundo.q_revisor:
            return {"veredito": "refazer", "feedback": "números do texto não conferem com os fatos coletados", "trilha": ["revisor:refazer"]}
        return {"veredito": "ok", "trilha": ["revisor:ok"]}

    def aprovador(s: Estado) -> dict:
        mundo.conta("aprovador")
        resp = interrupt({"acao": "publicar", "relatorio": s["relatorio"], "veredito": s.get("veredito"), "feedback": s.get("feedback", "")})   # pausa: nada acima daqui tem efeito externo
        dec = resp["decisao"]
        if dec == "rejeitar":
            return {"aprovacao": "rejeitado", "trilha": ["humano:rejeitou"]}
        out = {"aprovacao": "aprovado", "trilha": [f"humano:{dec}"]}
        if dec == "editar":
            out["relatorio"] = resp["relatorio"]
        return out

    def publicador(s: Estado) -> dict:
        mundo.conta("publicador")
        chave = hashlib.sha256(s["relatorio"].encode()).hexdigest()[:12]       # chave de idempotência
        if chave not in mundo.chaves:
            mundo.chaves.add(chave)
            mundo.mural.append(s["relatorio"])                                 # EFEITO EXTERNO
        if mundo.rng.random() < mundo.f_publicar:
            raise ConnectionError("a rede caiu depois de publicar")
        return {"publicado": True, "trilha": ["publicador"]}

    g = StateGraph(Estado)
    for nome, f in (("supervisor", supervisor), ("pesquisador", pesquisador), ("calculador", calculador), ("redator", redator),
                    ("revisor", revisor), ("aprovador", aprovador), ("publicador", publicador)):
        g.add_node(nome, f)
    g.add_edge(START, "supervisor")
    for nome in ("pesquisador", "calculador", "redator", "revisor", "aprovador", "publicador"):
        g.add_edge(nome, "supervisor")
    return g.compile(checkpointer=checkpointer, **compilar)


# ----------------------------------------------------------------------------------------- execução
def executa(app, mundo: Mundo, pedido: dict, thread: str, tentativas_publicacao: int = 5):
    """Dirige a execução: atende pausas com a política humana e retoma após falhas transitórias. Devolve o estado final."""
    cfg = {"configurable": {"thread_id": thread}, "recursion_limit": 60}
    entrada = {"caps": pedido["caps"], "contagens": {}, "trilha": []}
    falhas = 0
    while True:
        try:
            r = app.invoke(entrada, cfg)
        except ConnectionError:
            falhas += 1
            if falhas > tentativas_publicacao:
                break
            entrada = None                              # retomar do último checkpoint
            continue
        if "__interrupt__" in r:
            dec = mundo.humano(r["__interrupt__"][0].value["relatorio"]) if mundo.humano else {"decisao": "aprovar"}
            entrada = Command(resume=dec)
            continue
        break
    return app.get_state(cfg).values, falhas
