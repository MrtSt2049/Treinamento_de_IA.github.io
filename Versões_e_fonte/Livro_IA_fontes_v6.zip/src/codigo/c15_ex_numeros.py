"""Capítulo 15: números verificados para as soluções dos exercícios."""
import math

import numpy as np

# 15.1 ranking com relevância [0,1,0,1,0,0], |G|=3 (um relevante não foi recuperado)
rel = [0, 1, 0, 1, 0, 0]; G = 3
for k in (1, 3, 5):
    print(f"15.1 P@{k}={sum(rel[:k]) / k:.4f}  R@{k}={sum(rel[:k]) / G:.4f}")
rr = 1 / (rel.index(1) + 1)
ap = (1 / 2 + 2 / 4) / G
dcg = sum(r / math.log2(i + 2) for i, r in enumerate(rel)); idcg = sum(1 / math.log2(i + 2) for i in range(G))
print(f"15.1 RR={rr:.4f}  AP={ap:.4f}  DCG={dcg:.4f}  IDCG={idcg:.4f}  nDCG={dcg / idcg:.4f}")

# 15.2 kappa de Cohen
tab = np.array([[40, 10], [5, 45]])
n = tab.sum(); po = np.trace(tab) / n
pe = (tab.sum(0) / n * tab.sum(1) / n).sum()
print(f"15.2 po={po:.3f} pe={pe:.3f} kappa={(po - pe) / (1 - pe):.3f}")

# 15.3 tamanho amostral
for p in (0.8, 0.5):
    for eps in (0.05, 0.03):
        print(f"15.3 p={p} eps={eps}: n={math.ceil(1.96 ** 2 * p * (1 - p) / eps ** 2)}")

# 15.4 pass@k e pass^k
s = 0.8
for k in (1, 3, 5, 10):
    print(f"15.4 s={s} k={k}: pass@k={1 - (1 - s) ** k:.5f}  pass^k={s ** k:.5f}")

# 15.5 retry
f, m = 0.3, 4
print(f"15.5 f={f} m={m}: sucesso={1 - f ** m:.4f}  chamadas={(1 - f ** m) / (1 - f):.4f}")

# 15.6 cauda em escala
for q, n_ in ((0.01, 10), (0.01, 100), (0.001, 100)):
    print(f"15.6 q={q} n={n_}: P(ao menos um lento)={1 - (1 - q) ** n_:.4f}")

# 15.7 VPP
prev, tpr, fpr = 0.02, 0.9, 0.02
print(f"15.7 VPP={tpr * prev / (tpr * prev + fpr * (1 - prev)):.4f}")

# 15.8 custo
ti, to = 726, 48
c = (ti * 3 + to * 15) / 1e6
print(f"15.8 custo por tarefa=US$ {c:.6f}; 100000 tarefas/dia = US$ {c * 100000:.2f}")
# 15.9 entrada por chamada: P0 + j*m ; total quadrático
ent = [151, 171, 191, 213]
print("15.9 incrementos:", [b - a for a, b in zip(ent, ent[1:])])
# 15.13 jitter uniforme em [0,W]: carga N/W
N, C = 2000, 100
print(f"15.13 janela mínima W = N/C = {N / C:.0f} ticks")
# 15.10 reaproveitando o disjuntor: chamadas reais
