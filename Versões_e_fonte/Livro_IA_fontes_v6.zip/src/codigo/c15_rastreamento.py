"""Capítulo 15: rastreamento (tracing) de um agente e de um grafo com callbacks do LangChain/LangGraph REAIS.
O modelo é ROTEIRIZADO (nenhuma LLM consultada): os tokens são ESTIMADOS (caracteres/4) e os preços são ILUSTRATIVOS.
As durações são medidas nesta execução (variam de uma execução a outra)."""
import random
import time
from collections import Counter, defaultdict

import numpy as np
from langchain.agents import create_agent
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

import p10_equipe as P
from c13_ferramentas import calcular, montar_registro

PRECO_ENTRADA, PRECO_SAIDA = 3.0, 15.0        # US$ por milhão de tokens: valores ILUSTRATIVOS, não são de nenhum provedor


class Rastreador(BaseCallbackHandler):
    """Registra um 'span' por execução (cadeia/nó, modelo, ferramenta): quem, pai, duração, tokens."""
    raise_error = True                          # um erro levantado aqui interrompe a execução (usado no orçamento da parte D)

    def __init__(self, orcamento_tokens=None):
        self.spans, self.orcamento, self.gasto = {}, orcamento_tokens, 0

    def _abre(self, run_id, pai, tipo, nome):
        self.spans[run_id] = dict(id=run_id, pai=pai, tipo=tipo, nome=nome, t0=time.perf_counter(), dur=None, tok_in=0, tok_out=0, ordem=len(self.spans))

    def _fecha(self, run_id):
        s = self.spans[run_id]; s["dur"] = (time.perf_counter() - s["t0"]) * 1000

    def on_chain_start(self, ser, inp, *, run_id, parent_run_id=None, **kw): self._abre(run_id, parent_run_id, "nó/cadeia", kw.get("name") or "?")
    def on_chain_end(self, out, *, run_id, **kw): self._fecha(run_id)
    def on_chat_model_start(self, ser, msgs, *, run_id, parent_run_id=None, **kw): self._abre(run_id, parent_run_id, "modelo", "LLM")
    def on_tool_start(self, ser, inp, *, run_id, parent_run_id=None, **kw): self._abre(run_id, parent_run_id, "ferramenta", (ser or {}).get("name") or kw.get("name") or "?")
    def on_tool_end(self, out, *, run_id, **kw): self._fecha(run_id)

    def on_llm_end(self, resp, *, run_id, **kw):
        self._fecha(run_id)
        u = resp.generations[0][0].message.usage_metadata or {}
        s = self.spans[run_id]; s["tok_in"], s["tok_out"] = u.get("input_tokens", 0), u.get("output_tokens", 0)
        self.gasto += s["tok_in"] + s["tok_out"]
        if self.orcamento is not None and self.gasto > self.orcamento:
            raise RuntimeError(f"orçamento de tokens excedido: {self.gasto} > {self.orcamento}")

    # ---- consultas
    def custo(self):
        ti = sum(s["tok_in"] for s in self.spans.values()); to = sum(s["tok_out"] for s in self.spans.values())
        return ti, to, (ti * PRECO_ENTRADA + to * PRECO_SAIDA) / 1e6

    def arvore(self, esconder=("RunnableSequence", "ChannelWrite", "__start__")):
        filhos = defaultdict(list)
        for s in sorted(self.spans.values(), key=lambda s: s["ordem"]):
            filhos[s["pai"]].append(s)
        linhas = []
        def desce(pai, nivel):
            for s in filhos.get(pai, []):
                if s["nome"] in esconder or s["nome"].startswith("_"):
                    desce(s["id"], nivel); continue
                extra = f"  tokens {s['tok_in']}+{s['tok_out']}" if s["tipo"] == "modelo" else ""
                linhas.append(f"{'  ' * nivel}{s['tipo']:<10} {s['nome']:<14} {s['dur'] or 0:>7.1f} ms{extra}")
                desce(s["id"], nivel + 1)
        desce(None, 0)
        return linhas


class Roteirizado(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kw): return self
    def _generate(self, messages, stop=None, run_manager=None, **kw):
        r = super()._generate(messages, stop, run_manager, **kw)
        m = r.generations[0].message
        n_in = sum(len(str(x.content)) + sum(len(str(c)) for c in getattr(x, "tool_calls", [])) for x in messages) // 4   # estimativa
        m.usage_metadata = {"input_tokens": n_in, "output_tokens": max(len(str(m.content)) // 4, 12), "total_tokens": 0}
        time.sleep(0.02)                                                                                                   # latência artificial de 20 ms por chamada
        return r


reg = montar_registro()
@tool
def calculadora(expressao: str) -> float:
    """Avalia uma expressão aritmética (+ - * / ** %, sqrt, log, abs, round, min, max)."""
    return calcular(expressao)

@tool
def contar_secoes(cap: int) -> int:
    """Conta as seções expositivas de um capítulo do livro (1 a 11)."""
    import json
    return json.loads(reg.executar("contar_secoes", json.dumps({"cap": cap})))["resultado"]

SISTEMA = "Você é um assistente que usa ferramentas para responder com precisão. " * 8      # ~600 caracteres de instruções fixas
def roteiro():
    return [AIMessage(content="", tool_calls=[{"name": "contar_secoes", "args": {"cap": 5}, "id": "c1"}]),
            AIMessage(content="", tool_calls=[{"name": "contar_secoes", "args": {"cap": 6}, "id": "c2"}]),
            AIMessage(content="", tool_calls=[{"name": "calculadora", "args": {"expressao": "8 + 8"}, "id": "c3"}]),
            AIMessage(content="O total de seções dos capítulos 5 e 6 é 16.")]

print("=== A. Árvore de spans de um agente (create_agent, modelo roteirizado) ===")
ag = create_agent(Roteirizado(responses=roteiro()), tools=[calculadora, contar_secoes], system_prompt=SISTEMA)
tr = Rastreador()
ag.invoke({"messages": [HumanMessage("Quantas seções têm os capítulos 5 e 6 juntos?")]}, {"callbacks": [tr]})
print("\n".join(tr.arvore()))
ti, to, usd = tr.custo()
modelos = [s for s in sorted(tr.spans.values(), key=lambda s: s["ordem"]) if s["tipo"] == "modelo"]
print(f"\nchamadas ao modelo: {len(modelos)} | tokens de entrada por chamada: {[s['tok_in'] for s in modelos]}")
print(f"entrada total = {ti} tokens; saída total = {to}; custo ilustrativo = US$ {usd:.6f}")
print(f"identidade de contabilidade: soma das entradas por chamada = {sum(s['tok_in'] for s in modelos)} (= entrada total {ti}): {sum(s['tok_in'] for s in modelos) == ti}")

print("\n=== B. O rastro confere com a execução? Grafo do Projeto 10 (LangGraph) ===")
mundo = P.Mundo(reg, random.Random(5), p_redator=0.0, max_revisoes=2)
app = P.construir(mundo, InMemorySaver())
tr = Rastreador()
cfg = {"configurable": {"thread_id": "rastro"}, "recursion_limit": 60, "callbacks": [tr]}
r = app.invoke({"caps": [3, 5, 8], "contagens": {}, "trilha": []}, cfg)
from langgraph.types import Command
app.invoke(Command(resume={"decisao": "aprovar"}), cfg)
nos = Counter(s["nome"] for s in tr.spans.values() if s["nome"] in mundo.execucoes)
print(f"{'nó':<12} {'spans no rastro':>16} {'execuções contadas pelo programa':>34}")
for n in sorted(mundo.execucoes):
    print(f"{n:<12} {nos.get(n, 0):>16} {mundo.execucoes[n]:>34}")
print("Conferem em todos os nós:", all(nos.get(n, 0) == mundo.execucoes[n] for n in mundo.execucoes))

print("\n=== C. Latência é cauda: soma de chamadas sequenciais (simulação, 200000 execuções) ===")
rng = np.random.default_rng(1)
mu, sg = np.log(1.0), 0.6                                  # latência de uma chamada ~ lognormal, mediana 1 s (parâmetros ilustrativos)
print(f"{'chamadas':>9} {'média':>7} {'p50':>6} {'p95':>6} {'p99':>6} {'p99/p50':>8}")
for n in (1, 5, 10, 20):
    x = rng.lognormal(mu, sg, (200000, n)).sum(1)
    p50, p95, p99 = np.percentile(x, [50, 95, 99])
    print(f"{n:>9} {x.mean():>7.2f} {p50:>6.2f} {p95:>6.2f} {p99:>6.2f} {p99 / p50:>8.2f}")
print("Uma chamada isolada: média teórica exp(mu+sigma^2/2) =", f"{np.exp(mu + sg**2 / 2):.3f}", "(maior que a mediana 1,000: a média esconde a cauda)")

print("\n=== D. Orçamento de tokens como disjuntor ===")
ag = create_agent(Roteirizado(responses=roteiro()), tools=[calculadora, contar_secoes], system_prompt=SISTEMA)
tr = Rastreador(orcamento_tokens=400)
try:
    ag.invoke({"messages": [HumanMessage("Quantas seções têm os capítulos 5 e 6 juntos?")]}, {"callbacks": [tr]})
    print("terminou dentro do orçamento")
except RuntimeError as e:
    print("Execução interrompida:", e)
print("chamadas ao modelo até a interrupção:", sum(1 for s in tr.spans.values() if s["tipo"] == "modelo"))
