"""Capítulo 14: o create_agent do Capítulo 13 É um grafo do LangGraph. Inspeção da estrutura e uso de checkpointer/interrupção nele.
Modelo ROTEIRIZADO (nenhuma LLM consultada)."""
import json
from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from c13_ferramentas import calcular


@tool
def calculadora(expressao: str) -> float:
    """Avalia uma expressão aritmética."""
    return calcular(expressao)


@tool
def enviar_email(para: str, corpo: str) -> str:
    """Envia um e-mail (efeito irreversível)."""
    return f"e-mail enviado para {para}"


class Roteirizado(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kw):
        return self


def roteiro():
    return [AIMessage(content="", tool_calls=[{"name": "calculadora", "args": {"expressao": "6*7"}, "id": "a"}]),
            AIMessage(content="", tool_calls=[{"name": "enviar_email", "args": {"para": "x@exemplo.org", "corpo": "42"}, "id": "b"}]),
            AIMessage(content="Feito.")]


print("=== 1. A estrutura do agente é um grafo ===")
ag = create_agent(Roteirizado(responses=roteiro()), tools=[calculadora, enviar_email])
gr = ag.get_graph()
print("nós:", sorted(n for n in gr.nodes))
print("arestas:", sorted((e.source, e.target, bool(e.conditional)) for e in gr.edges))

print("\n=== 2. Aprovação humana de ferramentas críticas no agente pronto (middleware sobre interrupt) ===")
ag = create_agent(Roteirizado(responses=roteiro()), tools=[calculadora, enviar_email],
                  middleware=[HumanInTheLoopMiddleware(interrupt_on={"enviar_email": True, "calculadora": False})],
                  checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "a1"}}
r = ag.invoke({"messages": [HumanMessage("some e envie")]}, cfg)
pend = r["__interrupt__"][0].value
print("pausa antes de executar:", json.dumps(pend, ensure_ascii=False, default=str)[:300])
r = ag.invoke(Command(resume={"decisions": [{"type": "reject", "message": "não envie sem revisão"}]}), cfg)
print("mensagens finais:", [(m.type, str(m.content)[:50]) for m in r["messages"]][-3:])
