"""Capítulo 14: o essencial do LangGraph, executado de verdade (sem modelo de linguagem).
Parte A: cadeia linear x grafo com ciclo. Parte B: estado compartilhado e redutores. Parte C: passos (super-steps) e paralelismo."""
import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.errors import GraphRecursionError, InvalidUpdateError
from langgraph.graph.message import add_messages

# ----------------------------------------------------------------------------------------- Parte A
print("=== A. Cadeia linear (DAG) x grafo com ciclo: raiz quadrada de Newton ===")

class Newton(TypedDict):
    alvo: float
    x: float
    iteracoes: int

def passo(s: Newton) -> dict:
    x = 0.5 * (s["x"] + s["alvo"] / s["x"])
    return {"x": x, "iteracoes": s["iteracoes"] + 1}

def convergiu(s: Newton) -> str:
    return END if abs(s["x"] ** 2 - s["alvo"]) < 1e-9 * s["alvo"] else "passo"

# Cadeia linear: profundidade FIXA (3 aplicações), decidida ao projetar o grafo.
g = StateGraph(Newton)
for nome in ("p1", "p2", "p3"):
    g.add_node(nome, passo)
g.add_edge(START, "p1"); g.add_edge("p1", "p2"); g.add_edge("p2", "p3"); g.add_edge("p3", END)
cadeia = g.compile()

# Grafo com ciclo: a aresta condicional decide, em tempo de execução, se repete.
g = StateGraph(Newton)
g.add_node("passo", passo)
g.add_edge(START, "passo")
g.add_conditional_edges("passo", convergiu, ["passo", END])
ciclo = g.compile()

print(f"{'alvo':>10} {'cadeia(3): erro rel.':>22} {'ciclo: iterações':>18} {'ciclo: erro rel.':>18}")
for alvo in (4.0, 100.0, 1e4, 1e8):
    r1 = cadeia.invoke({"alvo": alvo, "x": 1.0, "iteracoes": 0})
    r2 = ciclo.invoke({"alvo": alvo, "x": 1.0, "iteracoes": 0})
    e1 = abs(r1["x"] ** 2 - alvo) / alvo
    e2 = abs(r2["x"] ** 2 - alvo) / alvo
    print(f"{alvo:>10.0f} {e1:>22.2e} {r2['iteracoes']:>18d} {e2:>18.2e}")

print("\nLimite de segurança: um ciclo que nunca converge é interrompido por recursion_limit.")
g = StateGraph(Newton)
g.add_node("passo", passo)
g.add_edge(START, "passo")
g.add_conditional_edges("passo", lambda s: "passo", ["passo"])        # nunca termina
try:
    g.compile().invoke({"alvo": 2.0, "x": 1.0, "iteracoes": 0}, {"recursion_limit": 7})
except GraphRecursionError as e:
    print("GraphRecursionError:", str(e).split("\n")[0][:90])

# ----------------------------------------------------------------------------------------- Parte B
print("\n=== B. Estado compartilhado e redutores ===")

class SemRedutor(TypedDict):
    x: int

def a(s): return {"x": 1}
def b(s): return {"x": 2}
g = StateGraph(SemRedutor)
g.add_node("a", a); g.add_node("b", b)
g.add_edge(START, "a"); g.add_edge(START, "b"); g.add_edge("a", END); g.add_edge("b", END)
try:
    g.compile().invoke({"x": 0})
except InvalidUpdateError as e:
    print("Sem redutor, duas escritas paralelas na mesma chave:", type(e).__name__)

def maximo(antigo: int, novo: int) -> int:
    return max(antigo, novo)

class ComRedutor(TypedDict):
    escritas: Annotated[list, operator.add]       # concatena
    melhor: Annotated[int, maximo]                # redutor personalizado
    ultimo: int                                   # sem redutor: sobrescreve (um só escritor por passo)

def r1(s): return {"escritas": ["r1"], "melhor": 3}
def r2(s): return {"escritas": ["r2"], "melhor": 7}
def fim(s): return {"ultimo": len(s["escritas"])}
g = StateGraph(ComRedutor)
g.add_node("r1", r1); g.add_node("r2", r2); g.add_node("fim", fim)
g.add_edge(START, "r1"); g.add_edge(START, "r2"); g.add_edge("r1", "fim"); g.add_edge("r2", "fim"); g.add_edge("fim", END)
res = g.compile().invoke({"escritas": [], "melhor": 0, "ultimo": 0})
print("Com redutores:", res)

class Msgs(TypedDict):
    mensagens: Annotated[list, add_messages]
def fala(s): return {"mensagens": [("ai", "olá")]}
g = StateGraph(Msgs); g.add_node("fala", fala); g.add_edge(START, "fala"); g.add_edge("fala", END)
res = g.compile().invoke({"mensagens": [("user", "oi")]})
print("add_messages:", [(m.type, m.content) for m in res["mensagens"]], "| ids atribuídos:", all(m.id for m in res["mensagens"]))

# add_messages substitui por id (não duplica): útil para editar uma mensagem do histórico
from langchain_core.messages import HumanMessage
m = HumanMessage(content="versão 1", id="m1")
print("Mesmo id substitui:", [x.content for x in add_messages([m], [HumanMessage(content="versão 2", id="m1")])])

# ----------------------------------------------------------------------------------------- Parte C
print("\n=== C. Passos (super-steps): fan-out e fan-in ===")

class Pipe(TypedDict):
    nos: Annotated[list, operator.add]
def mk(nome):
    return lambda s: {"nos": [nome]}
g = StateGraph(Pipe)
for n in ("ler", "a", "b", "c", "juntar"):
    g.add_node(n, mk(n))
g.add_edge(START, "ler")
g.add_edge("ler", "a"); g.add_edge("ler", "b"); g.add_edge("ler", "c")
g.add_edge(["a", "b", "c"], "juntar")                       # barreira: espera os três
g.add_edge("juntar", END)
app = g.compile()
por_passo = {}
for ev in app.stream({"nos": []}, stream_mode="debug"):
    if ev["type"] == "task":
        por_passo.setdefault(ev["step"], []).append(ev["payload"]["name"])
for k, v in por_passo.items():
    print(f"  passo {k}: {sorted(v)}")
print("Resultado final:", app.invoke({"nos": []})["nos"])
seqs = {tuple(app.invoke({"nos": []})["nos"]) for _ in range(50)}
print("Sequências distintas do estado final em 50 execuções:", len(seqs))
