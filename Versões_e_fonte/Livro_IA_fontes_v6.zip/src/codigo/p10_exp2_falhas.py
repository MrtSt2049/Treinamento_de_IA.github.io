"""Projeto 10, experimento 2: custo de uma falha transitória na publicação, com e sem checkpointer, com e sem idempotência.
Falha com prob. f DEPOIS do efeito externo. Mede chamadas de ferramenta, execuções de nós e mensagens duplicadas no mural."""
import json
import random

from langgraph.checkpoint.memory import InMemorySaver

import p10_equipe as P
from c13_ferramentas import montar_registro

REG = montar_registro()
N = 300


def com_checkpoint(m, caps, tid):
    return P.executa(P.construir(m, InMemorySaver()), m, {"caps": caps}, tid, tentativas_publicacao=200)


def roda(rotulo, f, idempotente, usa_checkpoint):
    rng = random.Random(2024)
    tot = dict(ferr=0, supervisor=0, pesquisador=0, redator=0, publicador=0, duplicadas=0, falhas=0)
    for i in range(N):
        caps = sorted(rng.sample(range(1, 12), rng.randint(2, 6)))
        m = P.Mundo(REG, random.Random(rng.random()), p_redator=0.0, f_publicar=f)
        if not idempotente:
            class Sempre(set):                                  # conjunto que nunca "lembra": a chave de idempotência deixa de funcionar
                def __contains__(self, x): return False
            m.chaves = Sempre()
        if usa_checkpoint:
            est, falhas = com_checkpoint(m, caps, f"{rotulo}-{i}")
        else:
            # sem checkpointer a pausa humana não existe: contornamos executando com humano embutido (aprova) via nó sem interrupt
            est, falhas = sem_checkpoint_sem_pausa(m, caps)
        tot["ferr"] += m.chamadas_ferramenta
        for k in ("supervisor", "pesquisador", "redator", "publicador"):
            tot[k] += m.execucoes.get(k, 0)
        tot["duplicadas"] += len(m.mural) - 1
        tot["falhas"] += falhas
    return {k: v / N for k, v in tot.items()}


def sem_checkpoint_sem_pausa(m, caps):
    """Sem checkpointer, 'interrupt' não pode ser retomado; para isolar o efeito, o aprovador automático é injetado no estado."""
    falhas = 0
    while True:
        app = P.construir(m)
        try:
            r = app.invoke({"caps": caps, "contagens": {}, "trilha": [], "aprovacao": "aprovado"})   # já 'aprovado': o supervisor pula o aprovador
            return r, falhas
        except ConnectionError:
            falhas += 1


print(f"N = {N} pedidos por linha; cada pedido tem 2 a 6 capítulos; a falha ocorre DEPOIS de publicar\n")
print(f"{'f':>4} {'checkpoint':>10} {'idempot.':>8} | {'falhas':>6} {'ferram.':>8} {'pesquis.':>8} {'supervis.':>9} {'publicad.':>9} {'duplicadas':>10}")
for f in (0.0, 0.3, 0.6):
    for ck in (True, False):
        for idem in (True, False):
            if f == 0.0 and not idem:
                continue
            r = roda(f"f{f}{ck}{idem}", f, idem, ck)
            print(f"{f:>4} {'sim' if ck else 'não':>10} {'sim' if idem else 'não':>8} | {r['falhas']:>6.2f} {r['ferr']:>8.2f} {r['pesquisador']:>8.2f} {r['supervisor']:>9.2f} {r['publicador']:>9.2f} {r['duplicadas']:>10.2f}")
base = roda("base", 0.0, True, False)["ferr"]
print(f"\nReferência (sem falhas: {base:.2f} chamadas de ferramenta por pedido). Previsão geométrica:")
for f in (0.3, 0.6):
    print(f"  f = {f}: falhas esperadas f/(1-f) = {f/(1-f):.2f}; sem checkpoint, chamadas = base/(1-f) = {base/(1-f):.2f}; com checkpoint, chamadas = base (só o publicador repete)")
print("Nota: a linha sem checkpoint e f = 0 tem 1 execução a menos do supervisor porque o pedido já entra 'aprovado' (sem pausa possível).")
