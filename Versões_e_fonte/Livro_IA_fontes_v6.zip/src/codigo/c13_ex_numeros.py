"""Números dos exercícios do Capítulo 13 (conferência das soluções)."""
import math
import random

import c13_agentes as A
from c13_ferramentas import montar_registro

print("13.2  palavras de entrada, T=10, P0=500, m=80:", (10 + 1) * 500 + 80 * 10 * 11 // 2)
print("13.3  (1-p)^n, p=0.02: n=10 ->", round(0.98 ** 10, 4), "; n=50 ->", round(0.98 ** 50, 4), "; n=100 ->", round(0.98 ** 100, 4))
s = 0.7
print("13.4  Reflexion s=0.7, K=3, q=1 ->", round(1 - (1 - s) ** 3, 4), "; K=5 ->", round(1 - (1 - s) ** 5, 4))
for e, n in ((0.1, 5), (0.1, 20), (0.3, 10)):
    pre = 1 / (1 - e) ** n + 1
    rea = n / (1 - e) + 1
    print(f"13.9  e={e}, n={n}: replanejar tudo -> {pre:.2f} chamadas ; ReAct -> {rea:.2f} chamadas")
for n in range(2, 40):
    if (1 / (1 - 0.3) ** (n - 1)) > n:
        print("13.9  e=0.3: a partir de n =", n, "o ReAct (que repete só o passo) gasta menos"); break
s1, c1 = 0.668, 2.88
for K in (1, 3, 5, 10):
    S = 1 - (1 - s1) ** K
    print(f"13.11 K={K:2d}: S={S:.4f}  chamadas esperadas = c1*S/s = {c1 * S / s1:.2f}")
V, lam = 10.0, 1.0
print("13.11 valor líquido por tarefa U(K)=S*(V - lam*c1/s) com V=10, lam=1:", round(V - lam * c1 / s1, 3), "(constante em K: só importa se é > 0)")
print("      se V=4:", round(4 - lam * c1 / s1, 3), "(negativo: não compensa nem a 1ª tentativa)")
q, f, K = 0.7, 0.2, 3
r = s1 * f + (1 - s1) * q
ac = s1 * (1 - f) * sum(r ** k for k in range(K - 1)) + r ** (K - 1) * s1
print(f"13.12 s={s1}, q={q}, f={f}, K={K}: r={r:.4f}, P(correta)={ac:.4f}; (com f=0: {s1*sum((q*(1-s1))**k for k in range(K-1)) + (q*(1-s1))**(K-1)*s1:.4f})")
reg = montar_registro()
t = {"tipo": "T6", "valores": [3, 4], "texto": "Some 3 e 4."}
r1 = A.react(t, reg, A.LLMSimulado(random.Random(0), 0.0))
P0, m0 = r1["P0"], r1["m"][0]
t = {"tipo": "T6", "valores": list(range(1, 34)), "texto": "Some os números: " + ", ".join(map(str, range(1, 34))) + " (use a calculadora, de dois em dois)."}
r32 = A.react(t, reg, A.LLMSimulado(random.Random(0), 0.0), max_passos=64)
m = sum(r32["m"]) / len(r32["m"])
Tn, w = 32, 4
completo = (Tn + 1) * r32["P0"] + sum(mj * (Tn - j) for j, mj in enumerate(r32["m"]))
janela = (Tn + 1) * r32["P0"] + sum(r32["m"][j] * min(Tn - j, w) for j in range(Tn))
print(f"13.13 T=32: P0={r32['P0']}, m médio={m:.1f}; palavras completo={completo} (medido {r32['tin']}); com janela w={w}: {janela}; razão {janela/completo:.3f}")
Sm = sum(r32["m"])
novo = r32["P0"] + Sm
cache = Tn * r32["P0"] + sum(r32["m"][j] * (Tn - 1 - j) for j in range(Tn))
print(f"13.6  T=32: soma m_j={Sm}; tokens novos={novo}; reaproveitados={cache}; soma={novo+cache} (completo {completo}); custo com gamma=0.1: {novo + 0.1*cache:.1f} = {(novo+0.1*cache)/completo:.3f} do total")
p, dl, L, n = 0.3, 0.5, 3, 3
ps = (1 - p) * (1 - (dl * p) ** L) / (1 - dl * p)
print(f"13.7  p=0.3, delta=0.5, L=3 tentativas/passo, n=3: P(passo)={ps:.4f}; P(acerto)={ps**n*(1-p):.4f}; (L=inf: {((1-p)/(1-dl*p))**n*(1-p):.4f})")
s_, q_, K_ = 0.5, 0.8, 4
u = q_ * (1 - s_)
print(f"13.8  s=0.5,q=0.8,K=4: u={u}; P={s_*(1-u**K_)/(1-u):.4f}; E[tentativas]={(1-u**K_)/(1-u):.4f}")
print("13.3  n de decisões para (0.98)^n < 0.5:", math.ceil(math.log(0.5) / math.log(0.98)), "->", round(0.98 ** 34, 4), round(0.98 ** 35, 4))
print("13.2  T=20:", 21 * 500 + 80 * 20 * 21 // 2)
