"""Capítulo 14: números verificados para as soluções dos exercícios."""
import math
import operator
import random
from typing import Annotated, TypedDict

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

# 14.3 Newton a=100 a partir de x0=1
x = 1.0
print("14.3 Newton a=100:", end=" ")
for i in range(1, 8):
    x = 0.5 * (x + 100 / x)
    print(f"x{i}={x:.4f}", end="; ")
    if i == 3:
        print(f"[erro rel. após 3: {abs(x*x-100)/100:.3f}]", end="; ")
print()

# 14.5 / 14.12: junção com aresta de lista x arestas separadas, ramos de comprimentos diferentes
class P(TypedDict):
    nos: Annotated[list, operator.add]

def mk(n): return lambda s: {"nos": [n]}

def junta(modo):
    g = StateGraph(P)
    for n in ("ler", "a", "a2", "b", "juntar"):
        g.add_node(n, mk(n))
    g.add_edge(START, "ler"); g.add_edge("ler", "a"); g.add_edge("ler", "b"); g.add_edge("a", "a2")
    if modo == "lista":
        g.add_edge(["a2", "b"], "juntar")
    else:
        g.add_edge("a2", "juntar"); g.add_edge("b", "juntar")
    g.add_edge("juntar", END)
    app = g.compile()
    passos = {}
    for ev in app.stream({"nos": []}, stream_mode="debug"):
        if ev["type"] == "task":
            passos.setdefault(ev["step"], []).append(ev["payload"]["name"])
    return app.invoke({"nos": []})["nos"], {k: sorted(v) for k, v in passos.items()}

for modo in ("lista", "separadas"):
    nos, passos = junta(modo)
    print(f"14.12 junção por {modo}: execuções de 'juntar' = {nos.count('juntar')}; passos = {passos}")

# 14.10 dois interrupts em um nó
entradas = {"n": 0}
class Q(TypedDict, total=False):
    r: str
def dois(s):
    entradas["n"] += 1
    a = interrupt("pergunta 1")
    b = interrupt("pergunta 2")
    return {"r": f"{a}+{b}"}
g = StateGraph(Q); g.add_node("dois", dois); g.add_edge(START, "dois"); g.add_edge("dois", END)
app = g.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "x"}}
r1 = app.invoke({}, cfg); print("14.10 após 1ª chamada: entradas =", entradas["n"], "| pausa:", r1["__interrupt__"][0].value)
r2 = app.invoke(Command(resume="x"), cfg); print("14.10 após resume 'x': entradas =", entradas["n"], "| pausa:", r2["__interrupt__"][0].value)
r3 = app.invoke(Command(resume="y"), cfg); print("14.10 após resume 'y': entradas =", entradas["n"], "| resultado:", r3["r"])

# 14.7 falhas por nó: com e sem checkpoint
c = [2, 5, 1, 1]; f = [0.1, 0.2, 0.3, 0.1]
com = sum(ck / (1 - fk) for ck, fk in zip(c, f))
Q_ = math.prod(1 - fk for fk in f)
por_tent = sum(c[k] * math.prod(1 - f[j] for j in range(k)) for k in range(len(c)))
sem = por_tent / Q_
print(f"14.7 c={c} f={f}: com checkpoint = {com:.3f}; sem checkpoint = {sem:.3f}  (P(passada completa) = {Q_:.4f})")
rng = random.Random(1)
def sim(com_ck, n=200000):
    tot = 0.0
    for _ in range(n):
        k = 0
        while k < len(c):
            tot += c[k]
            if rng.random() < f[k]:
                if not com_ck:
                    k = 0
                continue
            k += 1
    return tot / n
print(f"14.7 simulação (2e5 execuções): com = {sim(True):.3f}; sem = {sim(False):.3f}")

# 14.8 portão humano com falso alarme g
e, d, g_ = 0.2, 0.9, 0.1
cert = (1 - e) * (1 - g_); err = e * (1 - d); nao = (1 - e) * g_ + e * d
print(f"14.8 e={e} d={d} g={g_}: certo publicado={cert:.3f}; errado publicado={err:.3f}; não publicado={nao:.3f}; soma={cert+err+nao:.3f}; precisão publicada={cert/(cert+err):.4f}")

# 14.9 revisor
p = 0.3
for K in (1, 2, 3, 4):
    print(f"14.9 q=1 K={K}: P={1 - p**K:.4f}")
print(f"14.9 q=1, P >= 0,95 exige K >= {math.log(0.05)/math.log(p):.2f}")
for q in (0.7, 0.877, 0.9):
    print(f"14.9 q={q}: teto (1-p)/(1-pq) = {(1-p)/(1-p*q):.4f}")
print(f"14.9 q mínimo para teto 0,95: {(1 - (1-p)/0.95)/p:.4f}")
# 14.13 hierarquia
m, k = 3, 4
print(f"14.13 hierarquia m={m} k={k}: supervisores = {(m+1) + m*(k+1)}; plano com {m*k} trabalhadores = {m*k+1}")
