"""Projeto 9, experimento 3: Reflexion = tentativas repetidas com avaliador. Quanto vale o avaliador e quanto custa cada tentativa?"""
import random

import numpy as np

import c13_agentes as A
from c13_ferramentas import montar_registro

reg = montar_registro()
tarefas = A.gerar_tarefas(reg)
P, SEM = 0.20, 100


def acerto(K, q, rho):
    out, calls = [], []
    for s in range(SEM):
        rng = random.Random(777 + s)
        r = [A.reflexion(t, reg, rng, P, K=K, rho=rho, q_detecta=q) for t in tarefas]
        out.append(np.mean([x["resposta"] is not None and A.confere(x["resposta"], t["gabarito"]) for x, t in zip(r, tarefas)]))
        calls.append(np.mean([x["chamadas_llm"] for x in r]))
    return np.mean(out), np.mean(calls)


s1 = acerto(1, 1.0, 1.0)[0]
print(f"p = {P}; acerto de UMA tentativa (K=1) = {s1:.3f}   (as fórmulas abaixo usam este s)\n")
print("Sem aprendizado (rho = 1): o avaliador só decide se tenta de novo. Fórmula (Prop. 13.3): s * (1 - (q(1-s))^K) / (1 - q(1-s))")
print(f"{'K':>2} {'q (avaliador detecta erro)':>27} {'observado':>10} {'fórmula':>8} {'chamadas LLM/tarefa':>20}")
for K in (1, 2, 3, 5):
    for q in (1.0, 0.7, 0.4):
        o, c = acerto(K, q, 1.0)
        f = s1 * (1 - (q * (1 - s1)) ** K) / (1 - q * (1 - s1))
        print(f"{K:2d} {q:27.1f} {o:10.3f} {f:8.3f} {c:20.2f}")
print("\nCom aprendizado (rho = 0.5: cada reflexão corta a taxa de erro pela metade; SUPOSIÇÃO do simulador, não resultado), q = 1:")
for K in (1, 2, 3, 5):
    o, c = acerto(K, 1.0, 0.5)
    print(f"  K={K}  acerto {o:.3f}   chamadas {c:.2f}")
