"""Projeto 10, experimento 1: o ciclo revisor->redator e o portão humano como camadas de defesa em série.
Mede, em N pedidos, a fração de relatórios CORRETOS publicados, ERRADOS publicados e NÃO publicados, e compara com a fórmula."""
import json
import random
import time

from langgraph.checkpoint.memory import InMemorySaver

import p10_equipe as P
from c13_ferramentas import montar_registro

REG = montar_registro()
VERD = {c: json.loads(REG.executar("contar_secoes", json.dumps({"cap": c})))["resultado"] for c in range(1, 12)}
N = 400
p = 0.3


def correto(texto, caps):
    cont, total = P.le_relatorio(texto)
    return cont == {c: VERD[c] for c in caps} and total == sum(VERD[c] for c in caps)


def formula(p, q, K):
    u = p * q
    return (1 - p) * (1 - u ** K) / (1 - u) if u != 1 else (1 - p) * K          # Prop. 13.3 com s = 1-p


def rodar(q, R, d, semente):
    """d = prob. de o humano perceber que o relatório está errado (None = sem portão humano)."""
    rng = random.Random(semente)
    cert = err = nada = redator = 0
    for i in range(N):
        caps = sorted(rng.sample(range(1, 12), rng.randint(2, 6)))
        m = P.Mundo(REG, random.Random(rng.random()), p_redator=p, q_revisor=q, max_revisoes=R)
        if d is not None:
            m.humano = lambda rel, caps=caps, m=m: ({"decisao": "aprovar"} if correto(rel, caps) or m.rng.random() >= d else {"decisao": "rejeitar"})
        est, _ = P.executa(P.construir(m, InMemorySaver()), m, {"caps": caps}, f"e{semente}-{i}")
        redator += m.execucoes["redator"]
        if not m.mural:
            nada += 1
        elif correto(m.mural[0], caps):
            cert += 1
        else:
            err += 1
    return cert / N, err / N, nada / N, redator / N


t0 = time.time()
print(f"p (erro do redator por rascunho) = {p}; N = {N} pedidos por linha; 2 a 6 capítulos por pedido\n")
print("A. Só o ciclo de revisão (sem humano). R = nº máximo de refações; q = prob. de o revisor perceber o erro")
print(f"{'q':>4} {'R':>2} {'corretos':>9} {'fórmula':>8} {'errados':>8} {'rascunhos/pedido':>17} {'fórmula':>8}")
for q in (1.0, 0.7, 0.4):
    for R in (0, 1, 2, 3):
        c, e, n, rd = rodar(q, R, None, semente=100 + R)
        u = p * q
        esp = sum(u ** k for k in range(R + 1))
        print(f"{q:>4} {R:>2} {c:>9.3f} {formula(p, q, R + 1):>8.3f} {e:>8.3f} {rd:>17.2f} {esp:>8.2f}")

print("\nB. Revisor imperfeito (q = 0,7, R = 1) + portão humano que percebe o erro com prob. d")
print(f"{'d':>5} {'corretos':>9} {'errados':>8} {'sem publicar':>13}   fórmula: errados = (1-d)·P(errado no portão)")
c0 = formula(p, 0.7, 2)
for d in (None, 0.5, 0.9, 1.0):
    c, e, n, _ = rodar(0.7, 1, d, semente=500)
    prev = (1 - c0) * (1 - (d or 0))
    print(f"{('—' if d is None else d):>5} {c:>9.3f} {e:>8.3f} {n:>13.3f}   {prev:.3f}")
print(f"\ntempo total: {time.time() - t0:.0f} s")
