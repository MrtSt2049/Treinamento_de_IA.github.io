"""Testes automáticos do Projeto 6 (formas, vazamento temporal, viés das portas, recorte de gradiente)."""
import numpy as np
import torch
from torch import nn

from projeto6 import Modelo, aplicar_vies, gerar_memoria, janelas, serie

# 1) formas: (N, T, F) -> (N, saída)
for tipo in ("RNN", "GRU", "LSTM"):
    m = Modelo(tipo, 5, 32, 5)
    assert m(torch.randn(7, 11, 5)).shape == (7, 5)
print("ok 1: formas da saída dos três modelos")

# 2) o rótulo da tarefa de memória está de fato na posição 0 e o resto é ruído sem informação sobre ele
g = torch.Generator().manual_seed(0)
x, y = gerar_memoria(5000, 30, g)
assert (x[:, 0].argmax(1) == y).all()
corr = np.corrcoef(x[:, 1:, :].reshape(5000, -1).abs().mean(1).numpy(), y.numpy())[0, 1]
assert abs(corr) < 0.05
print(f"ok 2: rótulo em x[:, 0]; correlação do ruído com o rótulo = {corr:+.3f}")

# 3) divisão cronológica sem vazamento de alvos: a janela k usa s[k..k+29] e tem alvo s[k+30]
s = serie()
X, yv = janelas(s, 30)
n = len(yv)
i1, i2 = int(0.7 * n), int(0.85 * n)
assert np.allclose(X[i1], s[i1:i1 + 30]) and np.isclose(yv[i1], s[i1 + 30])
maior_indice_treino = (i1 - 1) + 30                 # último alvo de treino
maior_indice_validacao = (i2 - 1) + 30
assert maior_indice_treino < i1 + 30                # nenhum valor usado no treino é um alvo de validação
assert maior_indice_validacao < i2 + 30             # nenhum valor usado até a validação é um alvo de teste
print(f"ok 3: treino [0,{i1}), validação [{i1},{i2}), teste [{i2},{n}); alvos de validação e teste nunca aparecem no treino")
# observação: as primeiras janelas de validação/teste contêm, como ENTRADA, valores que foram alvos do período anterior;
# isso é inevitável em séries e não revela nenhum alvo futuro.

# 4) o viés é aplicado ao bloco certo: LSTM -> f (bloco 1 de i,f,g,o); GRU -> z (bloco 1 de r,z,n); os demais ficam intocados
for tipo in ("LSTM", "GRU"):
    m = Modelo(tipo, 5, 32, 5)
    antes = m.rec.bias_ih_l0.detach().clone()
    aplicar_vies(m, tipo, 5.0)
    dif = (m.rec.bias_ih_l0.detach() - antes)
    assert torch.allclose(dif[32:64], torch.full((32,), 5.0)) and dif[:32].abs().max() == 0 and dif[64:].abs().max() == 0
print("ok 4: o viés +5 altera só o bloco da porta de esquecimento (LSTM) ou de atualização (GRU)")

# 5) recorte de gradiente: a norma global após o recorte é no máximo o limiar
torch.manual_seed(0)
m = Modelo("LSTM", 5, 32, 5)
perda = 1000 * nn.functional.cross_entropy(m(torch.randn(8, 20, 5)), torch.randint(0, 5, (8,)))
perda.backward()
antes = nn.utils.clip_grad_norm_(m.parameters(), 1.0)
depois = torch.sqrt(sum((p.grad ** 2).sum() for p in m.parameters())).item()
assert antes > 1.0 and depois <= 1.0 + 1e-5
print(f"ok 5: recorte da norma do gradiente de {antes:.1f} para {depois:.4f}")
