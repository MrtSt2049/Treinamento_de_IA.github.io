"""Figuras do Capítulo 15 (SVG), a partir das saídas reais de codigo/c15_*.out."""
import re

from figs_c6 import curva, fmt, legenda, painel, salvar
from figs_c9 import SETA, caixa, rotulo, seta

# ---------- Figura 15.1: o triângulo da avaliação de RAG ----------
c = [SETA]
c.append(caixa(290, 14, 140, 48, "Pergunta", "cxa", 14))
c.append(caixa(40, 190, 170, 56, "Contexto recuperado", "cxm", 14))
c.append(caixa(510, 190, 170, 56, "Resposta gerada", "cx", 14))
c.append(seta(290, 52, 150, 190)); c.append(seta(210, 218, 510, 218)); c.append(seta(600, 190, 430, 56))
c.append('<text x="40" y="110" font-size="12" font-weight="600">Relevância do contexto</text><text x="40" y="126" font-size="11" class="t2">o que foi recuperado serve à pergunta?</text><text x="40" y="141" font-size="11" class="t2">precisão e revocação da recuperação</text>')
c.append('<text x="360" y="208" font-size="12" font-weight="600" text-anchor="middle">Fidelidade</text><text x="360" y="240" font-size="11" class="t2" text-anchor="middle">cada afirmação tem suporte no contexto?</text>')
c.append('<text x="680" y="110" font-size="12" font-weight="600" text-anchor="end">Relevância da resposta</text><text x="680" y="126" font-size="11" class="t2" text-anchor="end">a resposta trata da pergunta?</text>')
c.append('<text x="360" y="290" font-size="11" class="t2" text-anchor="middle">Correção factual é uma quarta medida, comparada a um gabarito externo: uma resposta pode ser fiel ao contexto e ainda assim errada.</text>')
salvar("fig_c15_triangulo.svg", 720, 300, "Triângulo da avaliação de RAG: relevância do contexto (pergunta e contexto), fidelidade (contexto e resposta) e relevância da resposta (resposta e pergunta)", c)

# ---------- leitura das saídas ----------
f = open("codigo/c15_fidelidade.out").read()
det = {}
for m in re.finditer(r"^\s*0\.8\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)$", f, re.M):
    det = {"externa": float(m.group(2)), "número alterado": float(m.group(3)), "negação": float(m.group(4)), "falso alarme": float(m.group(1))}
r = open("codigo/c15_metricas_recuperacao.out").read()
mrr = {}
for m in re.finditer(r"^\s+(BM25|LSA)\s+(diretas|parafraseadas)\s+n=\s*\d+\s+MRR=([\d.]+) \[([\d.]+); ([\d.]+)\]", r, re.M):
    mrr[(m.group(1), m.group(2))] = tuple(map(float, m.group(3, 4, 5)))
rs = open("codigo/c15_resiliencia.out").read()
tempest = {}
for m in re.finditer(r"^(imediata|fixa|exponencial\+jitter|exponencial)\s+(\d+)\s+(\d+)\s+(\d+)\s*$", rs, re.M):
    tempest[m.group(1)] = (int(m.group(2)), int(m.group(3)), int(m.group(4)))
rt = open("codigo/c15_rastreamento.out").read()
lat = {}
for m in re.finditer(r"^\s+(\d+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)$", rt, re.M):
    lat[int(m.group(1))] = tuple(map(float, m.group(2, 3, 4, 5)))

# ---------- Figura 15.2: duas medidas de qualidade, com incerteza ----------
c = []
# esquerda: taxa de detecção do verificador de fidelidade (tau = 0,8)
x0, y0, w = 140, 40, 160
c.append('<text x="220" y="22" font-size="12" font-weight="600" text-anchor="middle">Verificador de fidelidade (τ = 0,8)</text>')
for i, (nome, cl) in enumerate((("externa", "cxm"), ("número alterado", "cxa"), ("negação", "cxg"))):
    y = y0 + 14 + i * 46
    v = det[nome]
    c.append(f'<text x="{x0 - 8}" y="{y + 16}" font-size="12" text-anchor="end">{nome}</text>')
    c.append(f'<rect class="{cl}" x="{x0}" y="{y}" width="{max(w * v, 1.5)}" height="26" rx="4"/>')
    c.append(f'<text x="{x0 + w * v + 6}" y="{y + 18}" font-size="12">{v:.2f}</text>')
c.append(f'<line x1="{x0}" y1="{y0 + 4}" x2="{x0}" y2="{y0 + 154}" stroke="var(--tinta-2)" stroke-width="1"/>')
c.append('<text x="220" y="206" font-size="11" class="t2" text-anchor="middle">fração das respostas infiéis marcadas</text>')
# direita: MRR com IC
X0 = 520
c.append('<text x="620" y="22" font-size="12" font-weight="600" text-anchor="middle">MRR com IC de 95% (bootstrap)</text>')
def px(v): return X0 + 20 + (v - 0.4) / 0.6 * 200
for k in (0.4, 0.6, 0.8, 1.0):
    c.append(f'<line x1="{px(k)}" y1="40" x2="{px(k)}" y2="170" class="fraco"/><text x="{px(k)}" y="186" font-size="10" text-anchor="middle" class="t2">{str(k).replace(".", ",")}</text>')
linhas = [(("BM25", "diretas"), "BM25 · diretas", "lv"), (("LSA", "diretas"), "LSA · diretas", "la"), (("BM25", "parafraseadas"), "BM25 · parafr.", "lv"), (("LSA", "parafraseadas"), "LSA · parafr.", "la")]
for i, (k, nome, cl) in enumerate(linhas):
    y = 56 + i * 30 + (12 if i >= 2 else 0)
    m, lo, hi = mrr[k]
    c.append(f'<text x="{X0 + 12}" y="{y + 4}" font-size="11" text-anchor="end">{nome}</text>')
    c.append(f'<line class="{cl}" x1="{px(lo)}" y1="{y}" x2="{px(hi)}" y2="{y}"/><circle cx="{px(m)}" cy="{y}" r="4" class="{cl}" style="fill:var(--papel);stroke-width:2"/>')
c.append('<text x="620" y="206" font-size="11" class="t2" text-anchor="middle">67 perguntas: 43 diretas, 24 parafraseadas</text>')
salvar("fig_c15_qualidade.svg", 760, 216, "À esquerda, taxa de detecção do verificador lexical de fidelidade por tipo de infidelidade; à direita, MRR e intervalo de confiança de BM25 e LSA em perguntas diretas e parafraseadas", c)

# ---------- Figura 15.3: operação ----------
c = []
nomes = ["imediata", "fixa", "exponencial", "exponencial+jitter"]
c.append('<text x="190" y="22" font-size="12" font-weight="600" text-anchor="middle">Pico de carga no servidor após a volta</text>')
for i, n in enumerate(nomes):
    y = 40 + i * 40
    pico = tempest[n][1]
    c.append(f'<text x="118" y="{y + 18}" font-size="11" text-anchor="end">{n.replace("exponencial+jitter", "exp. + jitter")}</text>')
    c.append(f'<rect class="{"cxg" if "jitter" in n else "cxm"}" x="124" y="{y}" width="{pico / 2000 * 150}" height="26" rx="4"/><text x="{124 + pico / 2000 * 150 + 5}" y="{y + 18}" font-size="11">{pico}</text>')
c.append('<text x="190" y="206" font-size="11" class="t2" text-anchor="middle">requisições por tick (capacidade do servidor: 100)</text>')
s, X, Y = painel(430, 30, 250, 150, 0, 20, 0, 36, [0, 5, 10, 20], [0, 10, 20, 30], "chamadas sequenciais", "latência total (s)")
c += s
ns = sorted(lat)
c.append(curva(X, Y, ns, [lat[n][1] for n in ns], "lv", None))
c.append(curva(X, Y, ns, [lat[n][2] for n in ns], "la", "6 3"))
c.append(curva(X, Y, ns, [lat[n][3] for n in ns], "lr", "3 3"))
c += legenda([("lv", "p50", None), ("la", "p95", "6 3"), ("lr", "p99", "3 3")], 440, 250, 70)
salvar("fig_c15_operacao.svg", 720, 266, "À esquerda, pico de carga no servidor após uma queda para quatro estratégias de repetição; à direita, percentis de latência de um agente contra o número de chamadas sequenciais", c)
print("ok", det, mrr[("BM25", "diretas")], tempest, lat[5])
