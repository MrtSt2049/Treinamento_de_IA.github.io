Esta é a auditoria final do livro: o que existe, como foi verificado, o que **não** foi feito e o que o leitor deve conferir por conta própria. Os números das tabelas foram **calculados por programa** sobre o manuscrito, e não digitados.

## Escopo e critérios

A revisão aplica ao livro inteiro os critérios fixados no início da obra:

1. **Coerência de notação e de numeração** (seções, definições, resultados, exemplos, figuras e exercícios sequenciais em cada capítulo).
2. **Todo código foi executado**, e toda saída impressa no texto vem de um arquivo gerado pela execução (diretivas de inclusão), e não de transcrição manual.
3. **Nenhuma referência, DOI ou URL inventado.** As referências são declaradas "de memória" e devem ser conferidas.
4. **Honestidade sobre limites:** tudo o que não foi executado está rotulado como tal no ponto em que aparece.
5. **Profundidade equivalente** dos módulos finais e dos iniciais.

## Verificações automáticas do manuscrito

O programa `tools/qa.py` percorre os quinze capítulos e confere: sequência das seções, das figuras, das definições, dos exemplos e dos resultados; existência de todos os arquivos de código, de saída e de figura incluídos; referências cruzadas a definições, proposições, figuras e seções que existem; e, para cada exercício, a presença de uma solução com o mesmo número. Resultado da última execução:

> 15 capítulos verificados; 0 problema(s)

A construção do site (`node build.js`) usa o KaTeX com **erro fatal**: qualquer fórmula inválida interrompe o processo, de modo que um livro que compila não contém LaTeX quebrado.

## Inventário por capítulo

| Cap. | Título | Seções | Palavras | Def. | Teor. e prop. | Exemplos | Figuras | Programas | Exercícios |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Fundamentos Matemáticos para Computação e Aprendizado | 20 | 10.859 | 25 | 11 | 8 | 3 | 9 | 18 |
| 2 | Fundamentos da Inteligência Artificial e Agentes Racionais | 14 | 7.427 | 4 | 0 | 3 | 1 | 4 | 13 |
| 3 | Formulação do Aprendizado Supervisionado e Não Supervisionado | 12 | 4.732 | 4 | 5 | 0 | 0 | 4 | 13 |
| 4 | Modelos Clássicos de Regressão e Classificação | 12 | 5.186 | 7 | 4 | 3 | 1 | 4 | 14 |
| 5 | Avaliação. Generalização e Seleção de Modelos | 12 | 6.205 | 7 | 7 | 1 | 3 | 6 | 14 |
| 6 | Redes Neurais Artificiais | 14 | 9.970 | 8 | 11 | 0 | 4 | 11 | 16 |
| 7 | Visão Computacional com CNNs | 12 | 6.897 | 5 | 5 | 1 | 5 | 7 | 15 |
| 8 | Processamento de Sequências e RNNs | 10 | 6.615 | 5 | 5 | 0 | 5 | 9 | 15 |
| 9 | A Revolução da Atenção e a Arquitetura Transformer | 13 | 6.928 | 6 | 8 | 1 | 4 | 8 | 15 |
| 10 | Ecossistema Hugging Face e Ajuste Fino | 14 | 9.717 | 4 | 8 | 2 | 4 | 8 | 15 |
| 11 | Engenharia de Contexto e Fundamentos de LLMs em Produção | 10 | 7.692 | 8 | 5 | 1 | 2 | 6 | 14 |
| 12 | Arquitetura RAG com LlamaIndex | 13 | 10.198 | 4 | 4 | 2 | 4 | 12 | 14 |
| 13 | Frameworks de Agentes Autônomos e Execução de Ferramentas | 12 | 6.915 | 5 | 3 | 1 | 2 | 7 | 14 |
| 14 | Orquestração Stateful e Grafos com LangChain e LangGraph | 10 | 6.850 | 2 | 3 | 0 | 3 | 9 | 14 |
| 15 | Avaliação. Monitoramento e Governança de Sistemas de IA | 12 | 7.716 | 5 | 4 | 0 | 3 | 5 | 14 |
| | **Total** | **190** | **113.907** | **99** | **83** | **23** | **44** | **109** | **218** |

As contagens de palavras excluem código, fórmulas e figuras. "Programas" conta as inclusões de código no texto (um mesmo arquivo pode aparecer uma vez); os arquivos de apoio e de teste somam **127 programas** em `codigo/`, com **126 arquivos de saída**, e há **39 figuras** vetoriais geradas por scripts. Todos os exercícios têm solução comentada.

## Reexecução dos programas

Dos **115** programas com saída salva, **103** reproduziram a saída **idêntica**, caractere por caractere, em uma cópia limpa do material, e os **12** restantes se explicam assim:

- **Só variam as medidas de tempo (8 programas):** `c13_ferramentas_demo`, `c15_rastreamento`, `c9_cache_custo`, `p8_exp1_fatiamento`, `p8_exp6_ann`, `p9_exp1_estrategias`, `p10_exp1_revisao_humano`, `p7_testes`. Os números impressos em milissegundos ou segundos mudam de uma execução para outra; todo o restante da saída (métricas, contagens, acertos) é idêntico.
- **Não determinismo do treino do tokenizador:** `c10_tokenizers`. O treinador de vocabulário WordPiece da biblioteca `tokenizers` não produz exatamente o mesmo vocabulário em toda execução: a contagem de *tokens* por mil *bytes* e alguns identificadores diferem na última casa. A saída publicada é a de uma execução, e as conclusões do texto não dependem dessas casas.
- **Defeitos encontrados por esta auditoria e já corrigidos:** (i) `c9_familias`: o arquivo de saída salvo estava **truncado** (faltavam cinco linhas que o programa imprime: contagem de parâmetros do GPT-2 e do T5 e as duas perdas sem treino); a saída foi regenerada e o parágrafo do Capítulo 9 foi ajustado; (ii) `projeto6_testes`: a norma do gradiente antes do recorte **não tinha semente** e mudava a cada execução; a semente foi fixada e a saída regenerada.
- **Não reexecutado:** `c9_lab_gpt`, que exige argumentos de linha de comando e treino longo. `c11_qualidade_diversidade` excedeu o limite de 4 minutos da auditoria, foi reexecutado separadamente (cerca de 14 minutos) e reproduziu a saída idêntica.

Os programas de apoio sem saída própria (módulos importados pelos demais) não entram na contagem.

Isso mostra que o material é **reprodutível**, com as exceções acima, no ambiente descrito na abertura (Python 3.13, CPU, versões de bibliotecas indicadas), com sementes explícitas. Não mostra que os resultados sejam idênticos em outras versões de bibliotecas, em outro processador ou com GPU: operações de ponto flutuante em paralelo podem diferir na última casa decimal, e as **interfaces dos pacotes de LLM mudam entre versões**, especialmente as de `langchain`, `langgraph` e `transformers`.

## O que foi executado e o que não foi

| Tema | Situação |
|---|---|
| Álgebra linear, cálculo, probabilidade, modelos clássicos, validação, regularização | Executado com NumPy, SciPy, scikit-learn e statsmodels |
| Redes neurais do zero, PyTorch, CNN, RNN, LSTM, GRU | Executado em CPU, em dados pequenos (tamanhos indicados em cada projeto) |
| Transformer, tokenização, LoRA, quantização | Executado com um **GPT-2 minúsculo** (cerca de $0{,}9$ milhão de parâmetros, vocabulário BPE de $1\,000$ *tokens*) treinado **neste ambiente** em texto do próprio livro |
| Pesos pré-treinados da internet (ResNet-18, modelos do Hugging Face Hub) | **Não executado:** o acesso ao *Hub* e à internet estava bloqueado; o código de uso aparece rotulado como não executado |
| RAG | Executado com BM25, FAISS e **LSA** como substituto de um *embedding* neural; LlamaParse, *cross-encoder* e *embeddings* neurais **não executados** |
| Agentes (Capítulos 13 a 15) | `langchain` e `langgraph` **reais**, com **modelos de chat scriptados** (determinísticos) no lugar de um LLM; seleção de ferramentas por um modelo real e *function calling* de provedor **não executados** |
| Persistência | Executado com o *checkpointer* em memória; *checkpointers* duráveis (SQLite, Postgres) **não executados** |
| Observabilidade | Rastreamento por *callbacks* próprios executado; LangSmith (instalado) **não usado** |
| Avaliação por LLM-juiz, RAGAs | Descrito e discutido; **não executado** |
| Normas e leis (LGPD, regulamento europeu, NIST) | Apenas indicações; **não** é aconselhamento jurídico |

Consequência importante: **os resultados dos Capítulos 12 a 15 que dependem do comportamento de um LLM** (por exemplo, a taxa de erro de um agente) vêm de **simuladores com parâmetros declarados**, e não de medições de um modelo real. Eles demonstram a **mecânica** (como erros se compõem, como um *checkpoint* reduz custo, como um portão humano troca erros publicados por não publicações) e validam o código, mas **não estimam** quanto um modelo real erraria. As proposições dos capítulos valem sob as hipóteses explícitas em cada enunciado.

## Limites conhecidos

- **Referências de memória.** A Bibliografia consolidada reúne 188 obras sem conferência nas fontes. Anos, volumes, páginas e edições merecem verificação antes de qualquer citação formal.
- **Escala.** Os experimentos são pequenos de propósito: cabem em CPU e rodam em minutos. Fenômenos que dependem de escala (leis de escala, emergência, comportamento de modelos de bilhões de parâmetros) **não** são reproduzidos aqui.
- **Verificador de fidelidade lexical.** O verificador do Capítulo 15 foi validado em casos **construídos pelo autor**; a negação o engana, e ele não substitui um juiz humano nem um modelo de inferência textual.
- **Detector de injeção heurístico.** Pegou as injeções diretas dos casos de teste e **falhou nas parafraseadas**; por isso o texto defende a aplicação de políticas **em código**.
- **Texto em português do Brasil.** A maior parte da literatura citada está em inglês; os termos em inglês aparecem entre parênteses na primeira ocorrência e no glossário.
- **Versões.** Os nomes e as assinaturas de funções dos pacotes de LLM foram conferidos **na versão executada**; nada garante a mesma interface em versões futuras.
- **Acessibilidade e leitura.** A interface foi revisada visualmente em claro e escuro e em telas largas e estreitas, mas não foi testada com leitores de tela.
- **Redação assistida por IA.** O texto, o código e as figuras foram produzidos por um modelo de linguagem (Claude, da Anthropic) a partir do roteiro e das exigências fornecidos pelo autor. Isso **reforça** o valor das verificações automáticas e a recomendação central do livro: **não confiar sem medir**. Erros de conteúdo, em especial em detalhes de referências e de interfaces de software, são possíveis.

## Como relatar um erro e como estender o livro

O material-fonte (Markdown, programas, figuras e scripts de construção) acompanha esta edição. Para corrigir um trecho, edite o arquivo de origem, reexecute o programa correspondente, regenere o `.out`, rode `qa.py` e reconstrua com `node build.js`. Os programas `gera_bibliografia.py`, `gera_indice.py` e `gera_revisao.py` regeneram, respectivamente, a bibliografia, o índice remissivo e esta revisão.

## Veredito

O livro cobre **6 módulos, 15 capítulos e dez projetos integradores**, com 218 exercícios resolvidos, código executado e uma lista explícita do que **não** foi executado. É um texto **completo e reprodutível** dentro das condições descritas, e **não** um substituto para a leitura das fontes originais nem para a medição de sistemas reais com dados reais.
