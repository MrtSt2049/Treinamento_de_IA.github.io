Esta bibliografia reúne, **sem duplicatas**, as obras indicadas nas seções *Referências e leituras* dos quinze capítulos. Cada entrada traz, ao final, os capítulos em que foi citada. A ordem é alfabética dentro de cada grupo.

::: atencao Leia antes de citar
Todas as referências foram escritas **de memória**, sem consulta às páginas originais. Autores, títulos, anos e locais são os que o autor conhece com confiança, mas **páginas, volumes, números de edição e endereços podem conter imprecisões** e devem ser conferidos nas fontes antes de qualquer citação formal. Os documentos legais e normativos devem ser lidos **nas fontes oficiais**, e este livro **não** constitui aconselhamento jurídico. Nenhum DOI ou URL foi inventado: quando um endereço aparece, é o endereço conhecido do projeto, não uma ligação verificada.
:::


## Livros didáticos e de referência

- BLITZSTEIN, J. K.; HWANG, J. *Introduction to Probability*. 2. ed. Boca Raton: CRC Press, 2019. <span class="cit">Cap.&nbsp;1.</span>
- BOYD, S.; VANDENBERGHE, L. *Convex Optimization*. Cambridge: Cambridge University Press, 2004. <span class="cit">Cap.&nbsp;1.</span>
- BREIMAN, L.; FRIEDMAN, J. H.; OLSHEN, R. A.; STONE, C. J. *Classification and Regression Trees*. Belmont: Wadsworth, 1984. <span class="cit">Cap.&nbsp;4.</span>
- DEISENROTH, M. P.; FAISAL, A. A.; ONG, C. S. *Mathematics for Machine Learning*. Cambridge: Cambridge University Press, 2020. <span class="cit">Cap.&nbsp;1.</span>
- EFRON, B.; TIBSHIRANI, R. J. *An Introduction to the Bootstrap*. Nova York: Chapman & Hall, 1993. <span class="cit">Caps.&nbsp;12, 15.</span>
- GOODFELLOW, I.; BENGIO, Y.; COURVILLE, A. *Deep Learning*. Cambridge, MA: MIT Press, 2016. <span class="cit">Caps.&nbsp;1, 6, 7, 8.</span>
- HASTIE, T.; TIBSHIRANI, R.; FRIEDMAN, J. *The Elements of Statistical Learning*. 2. ed. New York: Springer, 2009. <span class="cit">Caps.&nbsp;3, 4, 5, 6.</span>
- JAMES, G.; WITTEN, D.; HASTIE, T.; TIBSHIRANI, R.; TAYLOR, J. *An Introduction to Statistical Learning: with Applications in Python*. Cham: Springer, 2023. <span class="cit">Caps.&nbsp;1, 3, 4, 5, 6, 7.</span>
- JURAFSKY, D.; MARTIN, J. H. *Speech and Language Processing*. 3. ed. (rascunho). Capítulos sobre Transformers e modelos de linguagem. Texto completo em web.stanford.edu/~jurafsky/slp3. <span class="cit">Caps.&nbsp;9, 10, 11.</span>
- MANNING, C. D.; RAGHAVAN, P.; SCHÜTZE, H. *Introduction to Information Retrieval*. Cambridge: Cambridge University Press, 2008. <span class="cit">Caps.&nbsp;12, 15.</span>
- MINSKY, M.; PAPERT, S. *Perceptrons*. Cambridge: MIT Press, 1969. <span class="cit">Cap.&nbsp;6.</span>
- NOCEDAL, J.; WRIGHT, S. J. *Numerical Optimization*. 2. ed. New York: Springer, 2006. <span class="cit">Cap.&nbsp;1.</span>
- RUSSELL, S.; NORVIG, P. *Artificial Intelligence: A Modern Approach*. 4. ed. Hoboken: Pearson, 2021. <span class="cit">Caps.&nbsp;2, 3, 13.</span>
- RUSSELL, S. *Human Compatible: Artificial Intelligence and the Problem of Control*. New York: Viking, 2019. <span class="cit">Cap.&nbsp;2.</span>
- STRANG, G. *Introduction to Linear Algebra*. 5. ed. Wellesley: Wellesley-Cambridge Press, 2016. <span class="cit">Cap.&nbsp;1.</span>
- SUTTON, R. S.; BARTO, A. G. *Reinforcement Learning: An Introduction*. 2. ed. Cambridge, MA: MIT Press, 2018. <span class="cit">Caps.&nbsp;2, 3.</span>
- TREFETHEN, L. N.; BAU, D. *Numerical Linear Algebra*. Philadelphia: SIAM, 1997. <span class="cit">Cap.&nbsp;1.</span>
- VON NEUMANN, J.; MORGENSTERN, O. *Theory of Games and Economic Behavior*. Princeton: Princeton University Press, 1944. <span class="cit">Cap.&nbsp;2.</span>
- WASSERMAN, L. *All of Statistics: A Concise Course in Statistical Inference*. New York: Springer, 2004. <span class="cit">Cap.&nbsp;1.</span>
- WOOLDRIDGE, M. *An Introduction to MultiAgent Systems*. 2. ed. Chichester: Wiley, 2009. <span class="cit">Cap.&nbsp;2.</span>
- ZHANG, A.; LIPTON, Z. C.; LI, M.; SMOLA, A. J. *Dive into Deep Learning*. Cambridge: Cambridge University Press, 2023. <span class="cit">Caps.&nbsp;8, 9, 10, 11.</span>

## Artigos, teses e textos originais

- AGHAJANYAN, A.; ZETTLEMOYER, L.; GUPTA, S. Intrinsic dimensionality explains the effectiveness of language model fine-tuning. In: *Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2021. <span class="cit">Cap.&nbsp;10.</span>
- AINSLIE, J. et al. GQA: training generalized multi-query transformer models from multi-head checkpoints. In: *Proceedings of the Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2023. <span class="cit">Cap.&nbsp;9.</span>
- ARTHUR, D.; VASSILVITSKII, S. k-means++: the advantages of careful seeding. In: *Proceedings of the 18th Annual ACM-SIAM Symposium on Discrete Algorithms*, 2007. p. 1027–1035. <span class="cit">Cap.&nbsp;3.</span>
- BAHDANAU, D.; CHO, K.; BENGIO, Y. Neural machine translation by jointly learning to align and translate. In: *3rd International Conference on Learning Representations (ICLR)*, 2015. <span class="cit">Caps.&nbsp;8, 9.</span>
- BA, J. L.; KIROS, J. R.; HINTON, G. E. Layer normalization. *arXiv:1607.06450*, 2016. <span class="cit">Cap.&nbsp;9.</span>
- BAYDIN, A. G.; PEARLMUTTER, B. A.; RADUL, A. A.; SISKIND, J. M. Automatic differentiation in machine learning: a survey. *Journal of Machine Learning Research*, v. 18, n. 153, p. 1–43, 2018. <span class="cit">Cap.&nbsp;6.</span>
- BELKIN, M.; HSU, D.; MA, S.; MANDAL, S. Reconciling modern machine-learning practice and the classical bias–variance trade-off. *Proceedings of the National Academy of Sciences*, v. 116, n. 32, p. 15849–15854, 2019. <span class="cit">Cap.&nbsp;5.</span>
- BENGIO, Y.; SIMARD, P.; FRASCONI, P. Learning long-term dependencies with gradient descent is difficult. *IEEE Transactions on Neural Networks*, v. 5, n. 2, p. 157–166, 1994. <span class="cit">Cap.&nbsp;8.</span>
- BIDERMAN, D. et al. LoRA learns less and forgets less. *Transactions on Machine Learning Research*, 2024. <span class="cit">Cap.&nbsp;10.</span>
- BROOKER, M. Exponential backoff and jitter. *AWS Architecture Blog*, 2015. <span class="cit">Cap.&nbsp;15.</span>
- BROOKS, R. A. Intelligence without representation. *Artificial Intelligence*, v. 47, n. 1–3, p. 139–159, 1991. <span class="cit">Cap.&nbsp;2.</span>
- BROWN, T. et al. Language models are few-shot learners. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 33, 2020. <span class="cit">Caps.&nbsp;9, 11.</span>
- CHO, K. et al. Learning phrase representations using RNN encoder–decoder for statistical machine translation. In: *Proceedings of the Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2014. p. 1724–1734. <span class="cit">Cap.&nbsp;8.</span>
- COHEN, J. A coefficient of agreement for nominal scales. *Educational and Psychological Measurement*, 1960. <span class="cit">Cap.&nbsp;15.</span>
- CORMACK, G. V.; CLARKE, C. L. A.; BÜTTCHER, S. Reciprocal rank fusion outperforms Condorcet and individual rank learning methods. In: *Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval*, 2009. <span class="cit">Cap.&nbsp;12.</span>
- COVER, T.; HART, P. Nearest neighbor pattern classification. *IEEE Transactions on Information Theory*, v. 13, n. 1, p. 21–27, 1967. <span class="cit">Cap.&nbsp;4.</span>
- CYBENKO, G. Approximation by superpositions of a sigmoidal function. *Mathematics of Control, Signals and Systems*, v. 2, n. 4, p. 303–314, 1989. <span class="cit">Cap.&nbsp;6.</span>
- DAO, T. et al. FlashAttention: fast and memory-efficient exact attention with IO-awareness. In: *NeurIPS*, v. 35, 2022. <span class="cit">Cap.&nbsp;9.</span>
- DAVIS, J.; GOADRICH, M. The relationship between Precision-Recall and ROC curves. In: *Proceedings of the 23rd International Conference on Machine Learning*, 2006. p. 233–240. <span class="cit">Cap.&nbsp;5.</span>
- DEAN, J.; BARROSO, L. A. The tail at scale. *Communications of the ACM*, 2013. <span class="cit">Cap.&nbsp;15.</span>
- DEERWESTER, S.; DUMAIS, S. T.; FURNAS, G. W.; LANDAUER, T. K.; HARSHMAN, R. Indexing by latent semantic analysis. *Journal of the American Society for Information Science*, v. 41, n. 6, 1990. <span class="cit">Cap.&nbsp;12.</span>
- DETTMERS, T. et al. LLM.int8(): 8-bit matrix multiplication for transformers at scale. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 35, 2022. <span class="cit">Cap.&nbsp;10.</span>
- DETTMERS, T.; PAGNONI, A.; HOLTZMAN, A.; ZETTLEMOYER, L. QLoRA: efficient finetuning of quantized LLMs. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 36, 2023. <span class="cit">Cap.&nbsp;10.</span>
- DEVLIN, J.; CHANG, M.-W.; LEE, K.; TOUTANOVA, K. BERT: pre-training of deep bidirectional transformers for language understanding. In: *Proceedings of NAACL-HLT*, 2019. <span class="cit">Cap.&nbsp;9.</span>
- DUMOULIN, V.; VISIN, F. A guide to convolution arithmetic for deep learning. *arXiv:1603.07285*, 2016. <span class="cit">Cap.&nbsp;7.</span>
- ECKART, C.; YOUNG, G. The approximation of one matrix by another of lower rank. *Psychometrika*, v. 1, n. 3, p. 211–218, 1936. <span class="cit">Cap.&nbsp;10.</span>
- ELMAN, J. L. Finding structure in time. *Cognitive Science*, v. 14, n. 2, p. 179–211, 1990. <span class="cit">Cap.&nbsp;8.</span>
- ES, S. et al. RAGAs: automated evaluation of retrieval augmented generation. *arXiv*, 2023. <span class="cit">Cap.&nbsp;15.</span>
- FAN, A.; LEWIS, M.; DAUPHIN, Y. Hierarchical neural story generation. In: *Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2018. <span class="cit">Cap.&nbsp;11.</span>
- FAWCETT, T. An introduction to ROC analysis. *Pattern Recognition Letters*, v. 27, n. 8, p. 861–874, 2006. <span class="cit">Cap.&nbsp;5.</span>
- FUKUSHIMA, K. Neocognitron: a self-organizing neural network model for a mechanism of pattern recognition unaffected by shift in position. *Biological Cybernetics*, v. 36, p. 193–202, 1980. <span class="cit">Cap.&nbsp;7.</span>
- GAGE, P. A new algorithm for data compression. *The C Users Journal*, v. 12, n. 2, 1994. <span class="cit">Cap.&nbsp;10.</span>
- GEBRU, T. et al. Datasheets for datasets. *Communications of the ACM*, 2021. <span class="cit">Cap.&nbsp;15.</span>
- GEIFMAN, Y.; EL-YANIV, R. Selective classification for deep neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017. <span class="cit">Cap.&nbsp;11.</span>
- GEMAN, S.; BIENENSTOCK, E.; DOURSAT, R. Neural networks and the bias/variance dilemma. *Neural Computation*, v. 4, n. 1, p. 1–58, 1992. <span class="cit">Cap.&nbsp;5.</span>
- GERS, F. A.; SCHMIDHUBER, J.; CUMMINS, F. Learning to forget: continual prediction with LSTM. *Neural Computation*, v. 12, n. 10, p. 2451–2471, 2000. <span class="cit">Cap.&nbsp;8.</span>
- GLOROT, X.; BENGIO, Y. Understanding the difficulty of training deep feedforward neural networks. In: *Proceedings of the 13th International Conference on Artificial Intelligence and Statistics (AISTATS)*, 2010. p. 249–256. <span class="cit">Cap.&nbsp;6.</span>
- GRESHAKE, K. et al. Not what you've signed up for: compromising real-world LLM-integrated applications with indirect prompt injection. In: *Proceedings of the 16th ACM Workshop on Artificial Intelligence and Security (AISec)*, 2023. <span class="cit">Caps.&nbsp;11, 13, 15.</span>
- GUO, C.; PLEISS, G.; SUN, Y.; WEINBERGER, K. Q. On calibration of modern neural networks. In: *Proceedings of the 34th International Conference on Machine Learning (ICML)*, 2017. <span class="cit">Cap.&nbsp;11.</span>
- HARRIS, C. R. et al. Array programming with NumPy. *Nature*, v. 585, p. 357–362, 2020. <span class="cit">Cap.&nbsp;1.</span>
- HE, K.; ZHANG, X.; REN, S.; SUN, J. Deep residual learning for image recognition. In: *Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016. p. 770–778. <span class="cit">Cap.&nbsp;7.</span>
- HE, K.; ZHANG, X.; REN, S.; SUN, J. Delving deep into rectifiers: surpassing human-level performance on ImageNet classification. In: *Proceedings of the IEEE International Conference on Computer Vision (ICCV)*, 2015. p. 1026–1034. <span class="cit">Cap.&nbsp;6.</span>
- HOCHREITER, S.; SCHMIDHUBER, J. Long short-term memory. *Neural Computation*, v. 9, n. 8, p. 1735–1780, 1997. <span class="cit">Cap.&nbsp;8.</span>
- HOCHREITER, S. *Untersuchungen zu dynamischen neuronalen Netzen*. Diplomarbeit, Technische Universität München, 1991. <span class="cit">Cap.&nbsp;8.</span>
- HOERL, A. E.; KENNARD, R. W. Ridge regression: biased estimation for nonorthogonal problems. *Technometrics*, v. 12, n. 1, p. 55–67, 1970. <span class="cit">Cap.&nbsp;5.</span>
- HOLTZMAN, A.; BUYS, J.; DU, L.; FORBES, M.; CHOI, Y. The curious case of neural text degeneration. In: *8th International Conference on Learning Representations (ICLR)*, 2020. <span class="cit">Cap.&nbsp;11.</span>
- HONG, S. et al. MetaGPT: meta programming for a multi-agent collaborative framework. In: *International Conference on Learning Representations (ICLR)*, 2024. <span class="cit">Cap.&nbsp;14.</span>
- HORNIK, K.; STINCHCOMBE, M.; WHITE, H. Multilayer feedforward networks are universal approximators. *Neural Networks*, v. 2, n. 5, p. 359–366, 1989. <span class="cit">Cap.&nbsp;6.</span>
- HOULSBY, N. et al. Parameter-efficient transfer learning for NLP. In: *Proceedings of the 36th International Conference on Machine Learning (ICML)*, 2019. <span class="cit">Cap.&nbsp;10.</span>
- HUANG, J. et al. Large language models cannot self-correct reasoning yet. In: *International Conference on Learning Representations (ICLR)*, 2024. <span class="cit">Cap.&nbsp;13.</span>
- HU, E. J. et al. LoRA: low-rank adaptation of large language models. In: *10th International Conference on Learning Representations (ICLR)*, 2022. <span class="cit">Cap.&nbsp;10.</span>
- IOFFE, S.; SZEGEDY, C. Batch normalization: accelerating deep network training by reducing internal covariate shift. In: *Proceedings of the 32nd International Conference on Machine Learning (ICML)*, 2015. p. 448–456. <span class="cit">Cap.&nbsp;6.</span>
- JÄRVELIN, K.; KEKÄLÄINEN, J. Cumulated gain-based evaluation of IR techniques. *ACM Transactions on Information Systems*, v. 20, n. 4, 2002. <span class="cit">Caps.&nbsp;12, 15.</span>
- JÉGOU, H.; DOUZE, M.; SCHMID, C. Product quantization for nearest neighbor search. *IEEE Transactions on Pattern Analysis and Machine Intelligence*, v. 33, n. 1, 2011. <span class="cit">Cap.&nbsp;12.</span>
- JI, Z. et al. Survey of hallucination in natural language generation. *ACM Computing Surveys*, v. 55, n. 12, 2023. <span class="cit">Cap.&nbsp;11.</span>
- JOHNSON, J.; DOUZE, M.; JÉGOU, H. Billion-scale similarity search with GPUs. *IEEE Transactions on Big Data*, v. 7, n. 3, 2021 (a biblioteca FAISS). <span class="cit">Cap.&nbsp;12.</span>
- JONES, C. R.; BERGEN, B. K. *Large Language Models Pass the Turing Test*. Preprint arXiv:2503.23674, 2025. <span class="cit">Cap.&nbsp;2.</span>
- JOZEFOWICZ, R.; ZAREMBA, W.; SUTSKEVER, I. An empirical exploration of recurrent network architectures. In: *Proceedings of the 32nd International Conference on Machine Learning (ICML)*, 2015. <span class="cit">Cap.&nbsp;8.</span>
- KADAVATH, S. et al. Language models (mostly) know what they know. *arXiv*, 2022. <span class="cit">Cap.&nbsp;11.</span>
- KARPAS, E. et al. MRKL systems: a modular, neuro-symbolic architecture that combines large language models, external knowledge sources and discrete reasoning. *arXiv*, 2022. <span class="cit">Cap.&nbsp;13.</span>
- KARPUKHIN, V. et al. Dense passage retrieval for open-domain question answering. In: *Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2020. <span class="cit">Cap.&nbsp;12.</span>
- KINGMA, D. P.; BA, J. Adam: a method for stochastic optimization. In: *3rd International Conference on Learning Representations (ICLR)*, 2015. arXiv:1412.6980. <span class="cit">Cap.&nbsp;6.</span>
- KRIZHEVSKY, A.; SUTSKEVER, I.; HINTON, G. E. ImageNet classification with deep convolutional neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 25, 2012. <span class="cit">Cap.&nbsp;7.</span>
- KUDO, T.; RICHARDSON, J. SentencePiece: a simple and language independent subword tokenizer and detokenizer for neural text processing. In: *Proceedings of the 2018 Conference on Empirical Methods in Natural Language Processing: System Demonstrations*, 2018. <span class="cit">Cap.&nbsp;10.</span>
- KUDO, T. Subword regularization: improving neural network translation models with multiple subword candidates. In: *Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2018. <span class="cit">Cap.&nbsp;10.</span>
- LECUN, Y.; BOTTOU, L.; BENGIO, Y.; HAFFNER, P. Gradient-based learning applied to document recognition. *Proceedings of the IEEE*, v. 86, n. 11, p. 2278–2324, 1998. <span class="cit">Cap.&nbsp;7.</span>
- LEGG, S.; HUTTER, M. Universal intelligence: a definition of machine intelligence. *Minds and Machines*, v. 17, n. 4, p. 391–444, 2007. <span class="cit">Cap.&nbsp;2.</span>
- LESHNO, M.; LIN, V. Y.; PINKUS, A.; SCHOCKEN, S. Multilayer feedforward networks with a nonpolynomial activation function can approximate any function. *Neural Networks*, v. 6, n. 6, p. 861–867, 1993. <span class="cit">Cap.&nbsp;6.</span>
- LESTER, B.; AL-RFOU, R.; CONSTANT, N. The power of scale for parameter-efficient prompt tuning. In: *Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2021. <span class="cit">Cap.&nbsp;10.</span>
- LEWIS, M. et al. BART: denoising sequence-to-sequence pre-training for natural language generation, translation, and comprehension. In: *Proceedings of ACL*, 2020. <span class="cit">Cap.&nbsp;9.</span>
- LEWIS, P. et al. Retrieval-augmented generation for knowledge-intensive NLP tasks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 33, 2020. <span class="cit">Cap.&nbsp;12.</span>
- LIU, N. F. et al. Lost in the middle: how language models use long contexts. *Transactions of the Association for Computational Linguistics*, v. 12, 2024. <span class="cit">Cap.&nbsp;12.</span>
- LI, X. L.; LIANG, P. Prefix-tuning: optimizing continuous prompts for generation. In: *Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2021. <span class="cit">Cap.&nbsp;10.</span>
- LLOYD, S. P. Least squares quantization in PCM. *IEEE Transactions on Information Theory*, v. 28, n. 2, p. 129–137, 1982. <span class="cit">Cap.&nbsp;3.</span>
- LOSHCHILOV, I.; HUTTER, F. Decoupled weight decay regularization. In: *7th International Conference on Learning Representations (ICLR)*, 2019. <span class="cit">Cap.&nbsp;6.</span>
- LUO, W.; LI, Y.; URTASUN, R.; ZEMEL, R. Understanding the effective receptive field in deep convolutional neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 29, 2016. <span class="cit">Cap.&nbsp;7.</span>
- MAAS, A. L.; HANNUN, A. Y.; NG, A. Y. Rectifier nonlinearities improve neural network acoustic models. In: *ICML Workshop on Deep Learning for Audio, Speech and Language Processing*, 2013. <span class="cit">Cap.&nbsp;6.</span>
- MALEWICZ, G. et al. Pregel: a system for large-scale graph processing. In: *ACM SIGMOD International Conference on Management of Data*, 2010. <span class="cit">Cap.&nbsp;14.</span>
- MALKOV, Y. A.; YASHUNIN, D. A. Efficient and robust approximate nearest neighbor search using hierarchical navigable small world graphs. *IEEE Transactions on Pattern Analysis and Machine Intelligence*, v. 42, n. 4, 2020. <span class="cit">Cap.&nbsp;12.</span>
- McCARTHY, J.; MINSKY, M. L.; ROCHESTER, N.; SHANNON, C. E. *A Proposal for the Dartmouth Summer Research Project on Artificial Intelligence*. 1955. <span class="cit">Cap.&nbsp;2.</span>
- MICHEL, P.; LEVY, O.; NEUBIG, G. Are sixteen heads really better than one? In: *NeurIPS*, v. 32, 2019. <span class="cit">Cap.&nbsp;9.</span>
- MITCHELL, M. et al. Model cards for model reporting. In: *Conference on Fairness, Accountability, and Transparency (FAccT)*, 2019. <span class="cit">Cap.&nbsp;15.</span>
- NAEINI, M. P.; COOPER, G. F.; HAUSKRECHT, M. Obtaining well calibrated probabilities using Bayesian binning. In: *Proceedings of the AAAI Conference on Artificial Intelligence*, 2015. <span class="cit">Cap.&nbsp;11.</span>
- NAIR, V.; HINTON, G. E. Rectified linear units improve restricted Boltzmann machines. In: *Proceedings of the 27th International Conference on Machine Learning (ICML)*, 2010. p. 807–814. <span class="cit">Cap.&nbsp;6.</span>
- NGUYEN, M. et al. Turning up the heat: min-$p$ sampling for creative and coherent LLM outputs. In: *13th International Conference on Learning Representations (ICLR)*, 2025. <span class="cit">Cap.&nbsp;11.</span>
- NOGUEIRA, R.; CHO, K. Passage re-ranking with BERT. *arXiv*, 2019. <span class="cit">Cap.&nbsp;12.</span>
- NOVIKOFF, A. B. J. On convergence proofs on perceptrons. In: *Proceedings of the Symposium on the Mathematical Theory of Automata*, v. 12, 1962. p. 615–622. <span class="cit">Cap.&nbsp;6.</span>
- NYGARD, M. *Release It!* 2. ed. Pragmatic Bookshelf, 2018. <span class="cit">Cap.&nbsp;15.</span>
- OVADIA, Y. et al. Can you trust your model's uncertainty? Evaluating predictive uncertainty under dataset shift. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 32, 2019. <span class="cit">Cap.&nbsp;11.</span>
- PASCANU, R.; MIKOLOV, T.; BENGIO, Y. On the difficulty of training recurrent neural networks. In: *Proceedings of the 30th International Conference on Machine Learning (ICML)*, 2013. <span class="cit">Cap.&nbsp;8.</span>
- PASZKE, A. et al. PyTorch: an imperative style, high-performance deep learning library. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 32, 2019. <span class="cit">Cap.&nbsp;6.</span>
- PEDREGOSA, F. et al. Scikit-learn: machine learning in Python. *Journal of Machine Learning Research*, v. 12, p. 2825–2830, 2011. <span class="cit">Cap.&nbsp;3.</span>
- POLYAK, B. T. Some methods of speeding up the convergence of iteration methods. *USSR Computational Mathematics and Mathematical Physics*, v. 4, n. 5, p. 1–17, 1964. <span class="cit">Cap.&nbsp;6.</span>
- PRESS, O.; SMITH, N. A.; LEWIS, M. Train short, test long: attention with linear biases enables input length extrapolation. In: *ICLR*, 2022. <span class="cit">Cap.&nbsp;9.</span>
- RADFORD, A. et al. Language models are unsupervised multitask learners. OpenAI, 2019. <span class="cit">Caps.&nbsp;9, 10.</span>
- RAFFEL, C. et al. Exploring the limits of transfer learning with a unified text-to-text transformer. *Journal of Machine Learning Research*, v. 21, n. 140, p. 1–67, 2020. <span class="cit">Cap.&nbsp;9.</span>
- RAJBHANDARI, S. et al. ZeRO: memory optimizations toward training trillion parameter models. In: *International Conference for High Performance Computing, Networking, Storage and Analysis (SC)*, 2020. <span class="cit">Cap.&nbsp;10.</span>
- REIMERS, N.; GUREVYCH, I. Sentence-BERT: sentence embeddings using Siamese BERT-networks. In: *Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing (EMNLP)*, 2019. <span class="cit">Cap.&nbsp;12.</span>
- ROBERTSON, S.; ZARAGOZA, H. The probabilistic relevance framework: BM25 and beyond. *Foundations and Trends in Information Retrieval*, v. 3, n. 4, 2009. <span class="cit">Cap.&nbsp;12.</span>
- ROSENBLATT, F. The perceptron: a probabilistic model for information storage and organization in the brain. *Psychological Review*, v. 65, n. 6, p. 386–408, 1958. <span class="cit">Cap.&nbsp;6.</span>
- RUMELHART, D. E.; HINTON, G. E.; WILLIAMS, R. J. Learning representations by back-propagating errors. *Nature*, v. 323, p. 533–536, 1986. <span class="cit">Cap.&nbsp;6.</span>
- RUSSAKOVSKY, O. et al. ImageNet Large Scale Visual Recognition Challenge. *International Journal of Computer Vision*, v. 115, n. 3, p. 211–252, 2015. <span class="cit">Cap.&nbsp;7.</span>
- SANTURKAR, S.; TSIPRAS, D.; ILYAS, A.; MĄDRY, A. How does batch normalization help optimization? In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 31, 2018. <span class="cit">Cap.&nbsp;6.</span>
- SCHICK, T. et al. Toolformer: language models can teach themselves to use tools. In: *NeurIPS*, 2023. <span class="cit">Cap.&nbsp;13.</span>
- SCHUSTER, M.; NAKAJIMA, K. Japanese and Korean voice search. In: *IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP)*, 2012. <span class="cit">Cap.&nbsp;10.</span>
- SEARLE, J. R. Minds, brains, and programs. *Behavioral and Brain Sciences*, v. 3, n. 3, p. 417–424, 1980. <span class="cit">Cap.&nbsp;2.</span>
- SENNRICH, R.; HADDOW, B.; BIRCH, A. Neural machine translation of rare words with subword units. In: *Proceedings of the 54th Annual Meeting of the Association for Computational Linguistics (ACL)*, 2016. <span class="cit">Cap.&nbsp;10.</span>
- SHAW, P.; USZKOREIT, J.; VASWANI, A. Self-attention with relative position representations. In: *Proceedings of NAACL-HLT*, 2018. <span class="cit">Cap.&nbsp;9.</span>
- SHAZEER, N. Fast transformer decoding: one write-head is all you need. *arXiv:1911.02150*, 2019. <span class="cit">Cap.&nbsp;9.</span>
- SHINN, N. et al. Reflexion: language agents with verbal reinforcement learning. In: *NeurIPS*, 2023. <span class="cit">Cap.&nbsp;13.</span>
- SHORTEN, C.; KHOSHGOFTAAR, T. M. A survey on image data augmentation for deep learning. *Journal of Big Data*, v. 6, art. 60, 2019. <span class="cit">Cap.&nbsp;7.</span>
- SIMON, H. A. A behavioral model of rational choice. *The Quarterly Journal of Economics*, v. 69, n. 1, p. 99–118, 1955. <span class="cit">Cap.&nbsp;2.</span>
- SIMONYAN, K.; ZISSERMAN, A. Very deep convolutional networks for large-scale image recognition. In: *3rd International Conference on Learning Representations (ICLR)*, 2015. <span class="cit">Cap.&nbsp;7.</span>
- SRIVASTAVA, N.; HINTON, G.; KRIZHEVSKY, A.; SUTSKEVER, I.; SALAKHUTDINOV, R. Dropout: a simple way to prevent neural networks from overfitting. *Journal of Machine Learning Research*, v. 15, n. 56, p. 1929–1958, 2014. <span class="cit">Cap.&nbsp;6.</span>
- STONE, M. Cross-validatory choice and assessment of statistical predictions. *Journal of the Royal Statistical Society: Series B*, v. 36, n. 2, p. 111–147, 1974. <span class="cit">Cap.&nbsp;5.</span>
- SU, J. et al. RoFormer: enhanced transformer with rotary position embedding. *arXiv:2104.09864*, 2021. <span class="cit">Cap.&nbsp;9.</span>
- SUTSKEVER, I.; VINYALS, O.; LE, Q. V. Sequence to sequence learning with neural networks. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 27, 2014. <span class="cit">Cap.&nbsp;8.</span>
- TIBSHIRANI, R. Regression shrinkage and selection via the lasso. *Journal of the Royal Statistical Society: Series B*, v. 58, n. 1, p. 267–288, 1996. <span class="cit">Cap.&nbsp;5.</span>
- TIELEMAN, T.; HINTON, G. Lecture 6.5, RMSProp. *COURSERA: Neural Networks for Machine Learning*, 2012. <span class="cit">Cap.&nbsp;6.</span>
- TURING, A. M. Computing machinery and intelligence. *Mind*, v. 59, n. 236, p. 433–460, 1950. <span class="cit">Cap.&nbsp;2.</span>
- VASWANI, A. et al. Attention is all you need. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017. <span class="cit">Cap.&nbsp;9.</span>
- WANG, L. et al. Plan-and-solve prompting: improving zero-shot chain-of-thought reasoning by large language models. In: *Proceedings of the 61st Annual Meeting of the Association for Computational Linguistics (ACL)*, 2023. <span class="cit">Cap.&nbsp;13.</span>
- WANG, X. et al. Self-consistency improves chain of thought reasoning in language models. In: *11th International Conference on Learning Representations (ICLR)*, 2023. <span class="cit">Cap.&nbsp;11.</span>
- WASSERSTEIN, R. L.; LAZAR, N. A. The ASA statement on p-values: context, process, and purpose. *The American Statistician*, v. 70, n. 2, p. 129–133, 2016. <span class="cit">Cap.&nbsp;4.</span>
- WEI, J. et al. Chain-of-thought prompting elicits reasoning in large language models. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 35, 2022. <span class="cit">Caps.&nbsp;11, 13.</span>
- WILLARD, B. T.; LOUF, R. Efficient guided generation for large language models. *arXiv*, 2023. <span class="cit">Cap.&nbsp;11.</span>
- WILSON, A. C.; ROELOFS, R.; STERN, M.; SREBRO, N.; RECHT, B. The marginal value of adaptive gradient methods in machine learning. In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 30, 2017. <span class="cit">Cap.&nbsp;6.</span>
- WOLF, T. et al. Transformers: state-of-the-art natural language processing. In: *Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing: System Demonstrations*, 2020. <span class="cit">Cap.&nbsp;10.</span>
- WU, Q. et al. AutoGen: enabling next-gen LLM applications via multi-agent conversation. *arXiv*, 2023. <span class="cit">Cap.&nbsp;14.</span>
- XIONG, R. et al. On layer normalization in the transformer architecture. In: *Proceedings of the 37th International Conference on Machine Learning (ICML)*, 2020. <span class="cit">Cap.&nbsp;9.</span>
- YAO, S. et al. ReAct: synergizing reasoning and acting in language models. In: *International Conference on Learning Representations (ICLR)*, 2023. <span class="cit">Cap.&nbsp;13.</span>
- YAO, S. et al. $\tau$-bench: a benchmark for tool-agent-user interaction in real-world domains. *arXiv*, 2024. A métrica $\text{pass}^k$. <span class="cit">Cap.&nbsp;15.</span>
- YOSINSKI, J.; CLUNE, J.; BENGIO, Y.; LIPSON, H. How transferable are features in deep neural networks? In: *Advances in Neural Information Processing Systems (NeurIPS)*, v. 27, 2014. <span class="cit">Cap.&nbsp;7.</span>
- ZHENG, L. et al. Judging LLM-as-a-judge with MT-Bench and Chatbot Arena. In: *NeurIPS (Datasets and Benchmarks)*, 2023. <span class="cit">Cap.&nbsp;15.</span>

## Normas, documentos legais e textos técnicos

- ANTHROPIC. *Building effective agents*. Texto técnico, 2024. <span class="cit">Caps.&nbsp;13, 14.</span>
- BRASIL. Lei nº 13.709, de 14 de agosto de 2018 (Lei Geral de Proteção de Dados Pessoais). <span class="cit">Cap.&nbsp;15.</span>
- NIST. *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*. 2023. <span class="cit">Cap.&nbsp;15.</span>
- OWASP. *Top 10 for Large Language Model Applications*. Projeto OWASP. <span class="cit">Cap.&nbsp;15.</span>
- UNIÃO EUROPEIA. Regulamento (UE) 2024/1689 (regulamento sobre inteligência artificial). <span class="cit">Cap.&nbsp;15.</span>

## Documentação técnica e de software

- Biblioteca `regex` (correspondência parcial, `partial=True`), em pypi.org/project/regex (versão $2026{,}11{,}9$ nas execuções). <span class="cit">Cap.&nbsp;11.</span>
- Códigos de apoio em português: github.com/guilhermesilveira/machine-learning e github.com/mattharrison/ml_pocket_reference. <span class="cit">Cap.&nbsp;4.</span>
- Curso de agentes da Hugging Face, unidade introdutória: huggingface.co/learn/agents-course. Usado como referência de terminologia para o Módulo VI. <span class="cit">Cap.&nbsp;2.</span>
- FAISS (Facebook AI Research): `IndexFlatIP`, `IndexIVFFlat`, `IndexHNSWFlat` (`faiss-cpu` $1{,}16{,}0$ nas execuções), no repositório do projeto. <span class="cit">Cap.&nbsp;12.</span>
- Hugging Face: classes de processadores de *logits* da biblioteca `transformers` (`TemperatureLogitsWarper`, `TopKLogitsWarper`, `TopPLogitsWarper`, `MinPLogitsWarper`), em huggingface.co/docs. <span class="cit">Cap.&nbsp;11.</span>
- Hugging Face: documentação das bibliotecas `transformers` (classes `Trainer`, `TrainingArguments`, `GPT2LMHeadModel`), `tokenizers`, `datasets` e `peft` (`LoraConfig`, `get_peft_model`, `merge_and_unload`), em huggingface.co/docs. Versões nas execuções deste livro: `transformers` 5.22.2, `tokenizers` 0.23.3, `datasets` 5.2.0, `peft` 0.21.3, `accelerate` 1.15.0. <span class="cit">Cap.&nbsp;10.</span>
- Hugging Face `transformers` (versão 5.22 nas execuções deste livro): `BertForMaskedLM`, `GPT2LMHeadModel`, `T5ForConditionalGeneration`; huggingface.co/docs/transformers. <span class="cit">Cap.&nbsp;9.</span>
- LangChain (`langchain` $1{,}5{,}0$, *callbacks*, `with_retry`, `with_fallbacks`), LangGraph (`langgraph` $1{,}2{,}21$, `RetryPolicy`) e LangSmith (`langsmith` $0{,}14{,}17$ instalado; **não** usado), nas documentações oficiais. <span class="cit">Cap.&nbsp;15.</span>
- LangChain: `langchain` $1{,}5{,}0$ (`create_agent` e `HumanInTheLoopMiddleware`). <span class="cit">Cap.&nbsp;14.</span>
- LangChain: `langchain` $1{,}5{,}0$ e `langchain-core` $1{,}8{,}0$ nas execuções deste livro (`@tool`, `create_agent`, modelos de chat de teste), na documentação oficial do projeto. <span class="cit">Cap.&nbsp;13.</span>
- LangGraph: `langgraph` $1{,}2{,}21$ (base do `create_agent`; tratado no Capítulo 14). <span class="cit">Cap.&nbsp;13.</span>
- LangGraph: `langgraph` $1{,}2{,}21$, com `langgraph-checkpoint` $4{,}3{,}1$ e `langgraph-prebuilt` $1{,}1{,}1$ nas execuções deste livro. Grafos de estado, redutores, checkpointers, `interrupt`, `Command` e `Send`, na documentação oficial do projeto. <span class="cit">Cap.&nbsp;14.</span>
- LlamaIndex: documentação de `Document`, `SentenceSplitter`, `HierarchicalNodeParser`, `AutoMergingRetriever`, `QueryFusionRetriever`, `get_response_synthesizer` e dos modos de resposta (`llama-index-core` $0{,}14{,}25$ nas execuções deste livro), no site oficial do projeto. <span class="cit">Cap.&nbsp;12.</span>
- LlamaParse e `llama-cloud-services`: documentação do LlamaIndex. **Não executados neste livro.** <span class="cit">Cap.&nbsp;12.</span>
- NumPy: guia do usuário e referência de `numpy.linalg` e `numpy.random`. numpy.org/doc. <span class="cit">Cap.&nbsp;1.</span>
- Pydantic: documentação de modelos, validadores, modo estrito e `model_json_schema`, em docs.pydantic.dev (versão $2{,}13{,}5$ nas execuções deste livro). <span class="cit">Cap.&nbsp;11.</span>
- Pydantic: `pydantic` $2{,}13$ (validação e geração de JSON Schema). <span class="cit">Cap.&nbsp;13.</span>
- PyTorch: `torch.nn.Conv2d`, `MaxPool2d`, `BatchNorm2d`; pytorch.org/docs. torchvision: modelos (`torchvision.models`) e transformações (`torchvision.transforms`); pytorch.org/vision. Versões 2.15 e 0.29 nas execuções deste livro. <span class="cit">Cap.&nbsp;7.</span>
- PyTorch: `torch.nn.MultiheadAttention`, `torch.nn.LayerNorm` e a função `scaled_dot_product_attention` (módulo `torch.nn.functional`); pytorch.org/docs. <span class="cit">Cap.&nbsp;9.</span>
- PyTorch: `torch.nn.RNN`, `GRU`, `LSTM` e `torch.nn.utils.rnn` (`pad_sequence`, `pack_padded_sequence`), `torch.nn.utils.clip_grad_norm_`; pytorch.org/docs. Versão 2.15 nas execuções deste livro. <span class="cit">Cap.&nbsp;8.</span>
- PyTorch, tutoriais e documentação: pytorch.org/tutorials e pytorch.org/docs. Em particular os módulos `torch.autograd`, `torch.nn` e `torch.optim`. Versão 2.15 nas execuções deste livro. Repositório dos tutoriais: github.com/pytorch/tutorials. <span class="cit">Cap.&nbsp;6.</span>
- `rank-bm25` (BM25 Okapi) e `PyStemmer` (radicais *snowball* do português), no índice de pacotes do Python. <span class="cit">Cap.&nbsp;12.</span>
- Repositório de implementações em Python dos algoritmos de Russell e Norvig: github.com/aimacode/aima-python. <span class="cit">Cap.&nbsp;2.</span>
- scikit-learn, guia do usuário: modelos lineares, vizinhos mais próximos e árvores de decisão (incluindo poda por custo-complexidade). scikit-learn.org/stable/user_guide.html. Versão 1.9. <span class="cit">Cap.&nbsp;4.</span>
- scikit-learn, guia do usuário: seções de decomposição (PCA) e de agrupamento (K-means). scikit-learn.org/stable/user_guide.html. Programas executados com a versão 1.9. <span class="cit">Cap.&nbsp;3.</span>
- scikit-learn, guia do usuário: validação cruzada, ajuste de hiperparâmetros, métricas de avaliação, `Pipeline` e armadilhas comuns (vazamento de dados). scikit-learn.org/stable/user_guide.html. Versão 1.9. <span class="cit">Cap.&nbsp;5.</span>
- SciPy: referência de `scipy.linalg`. docs.scipy.org. <span class="cit">Cap.&nbsp;1.</span>
- statsmodels: regressão por mínimos quadrados (`OLS`). www.statsmodels.org. Versão 0.15. <span class="cit">Cap.&nbsp;4.</span>

::: resumo Em números
188 obras distintas, a partir de 217 indicações nos capítulos.
:::
