#!/usr/bin/env python3
"""Consolida as listas 'Referências e leituras' de cada capítulo em src/93-bibliografia.md."""
import re, json, unicodedata, os
os.chdir(os.path.join(os.path.dirname(__file__), '..', 'src'))
d = json.load(open('livro.json'))
itens = []
for v in d['vistas']:
    if not v['id'].startswith('cap-'): continue
    txt = '\n'.join(open(f).read() for f in v['arquivos'])
    m = re.search(r'## \d+\.\d+ Referências e leituras\n(.*)', txt, re.S)
    cat = None
    for ln in m.group(1).split('\n'):
        if ln.startswith('### '): cat = ln[4:].strip()
        elif ln.startswith('- '): itens.append((v['num'], cat, ln[2:].strip()))

def norm(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]', '', s)

def chave(s):
    m = re.search(r'\*([^*]{8,})\*\.', s)
    if m and not re.search(r'In:|arXiv|Preprint', s):
        return norm(s.split(',')[0]) + norm(m.group(1))
    return norm(re.sub(r'\*', '', s))[:48]

def corta(s):
    m = re.search(r'((?:19|20)\d\d)\.(?=\s+[A-ZÁÉÍÓÚ]|\s*$)', s)
    if m and not re.search(r'\$', s[:m.end()]): return s[:m.end()]
    return s

NORMAS = ('BRASIL.', 'UNIÃO EUROPEIA.', 'NIST.', 'OWASP.', 'ANTHROPIC.')
def grupo(cat, s):
    if cat == 'Documentação técnica': return 'D'
    if s.startswith(NORMAS): return 'N'
    if re.search(r'In:|arXiv|Preprint|Diplomarbeit|Proposal|\*,\s|Lecture', s): return 'A'
    if re.search(r'\*\.\s', s): return 'L'
    return 'A'

reg = {}
for num, cat, s in itens:
    g = grupo(cat, s)
    base = s if g == 'D' else corta(s)
    k = (g, chave(base))
    if k not in reg: reg[k] = {'txt': base, 'caps': set(), 'g': g}
    elif len(base) > len(reg[k]['txt']) and g == 'D': reg[k]['txt'] = base
    reg[k]['caps'].add(num)

nomes = {'L': 'Livros didáticos e de referência', 'A': 'Artigos, teses e textos originais',
         'N': 'Normas, documentos legais e textos técnicos', 'D': 'Documentação técnica e de software'}
out = ['''Esta bibliografia reúne, **sem duplicatas**, as obras indicadas nas seções *Referências e leituras* dos quinze capítulos. Cada entrada traz, ao final, os capítulos em que foi citada. A ordem é alfabética dentro de cada grupo.

::: atencao Leia antes de citar
Todas as referências foram escritas **de memória**, sem consulta às páginas originais. Autores, títulos, anos e locais são os que o autor conhece com confiança, mas **páginas, volumes, números de edição e endereços podem conter imprecisões** e devem ser conferidos nas fontes antes de qualquer citação formal. Os documentos legais e normativos devem ser lidos **nas fontes oficiais**, e este livro **não** constitui aconselhamento jurídico. Nenhum DOI ou URL foi inventado: quando um endereço aparece, é o endereço conhecido do projeto, não uma ligação verificada.
:::
''']
total = 0
for g in 'LANDX':
    if g not in nomes: continue
    es = sorted([v for v in reg.values() if v['g'] == g], key=lambda v: chave(v['txt']))
    out.append(f'\n## {nomes[g]}\n')
    for e in es:
        caps = ', '.join(str(c) for c in sorted(e['caps']))
        rot = 'Cap.' if len(e['caps']) == 1 else 'Caps.'
        out.append(f'- {e["txt"]} <span class="cit">{rot}&nbsp;{caps}.</span>')
        total += 1
out.append(f'\n::: resumo Em números\n{total} obras distintas, a partir de {len(itens)} indicações nos capítulos.\n:::\n')
open('93-bibliografia.md', 'w').write('\n'.join(out))
print(total, 'obras;', len(itens), 'indicações')
