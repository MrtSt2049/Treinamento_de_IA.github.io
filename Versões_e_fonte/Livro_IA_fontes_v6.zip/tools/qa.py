"""Verificações automáticas do manuscrito (src/*.md): numeração, referências cruzadas, exercícios x soluções, arquivos incluídos."""
import json, os, re, sys
from collections import Counter, defaultdict
SRC = "/home/claude/livro/src"
d = json.load(open(f"{SRC}/livro.json"))
probs = []
defs = defaultdict(set)      # tipo -> {numeros definidos}
heads = set()
texto_cap = {}
for v in d["vistas"]:
    if "arquivos" not in v or v["id"] == "inicio" or not v["id"].startswith("cap-"): continue
    n = v["num"]
    t = "\n\n".join(open(f"{SRC}/{a}").read() for a in v["arquivos"])
    texto_cap[n] = t
    # seções
    secs = re.findall(r"^## (\d+\.\d+) ", t, re.M)
    for s in secs: heads.add(s)
    if secs != [f"{n}.{i}" for i in range(1, len(secs) + 1)]:
        probs.append(f"cap {n}: seções fora de sequência: {secs}")
    # figuras
    figs = re.findall(r"<b>Figura (\d+\.\d+)\.</b>", t)
    if figs != [f"{n}.{i}" for i in range(1, len(figs) + 1)]:
        probs.append(f"cap {n}: figuras fora de sequência: {figs}")
    for f in re.findall(r"^\+\+\+ (\S+)$", t, re.M):
        if not os.path.exists(f"{SRC}/{f}"): probs.append(f"cap {n}: figura ausente {f}")
    for f in re.findall(r"^(?:<<<|>>>) (\S+)$", t, re.M):
        if not os.path.exists(f"{SRC}/{f}"): probs.append(f"cap {n}: arquivo incluído ausente {f}")
    # definições, exemplos
    for tipo in ("definicao", "exemplo"):
        nums = re.findall(rf"^::: {tipo} (\d+\.\d+)", t, re.M)
        defs[tipo] |= set(nums)
        if nums != [f"{n}.{i}" for i in range(1, len(nums) + 1)]:
            probs.append(f"cap {n}: {tipo} fora de sequência: {nums}")
    teo = re.findall(r"^::: (?:teorema|proposicao) (\d+\.\d+)", t, re.M)
    defs["teo"] |= set(teo)
    if teo != [f"{n}.{i}" for i in range(1, len(teo) + 1)]:
        probs.append(f"cap {n}: teoremas/proposições fora de sequência: {teo}")
    # exercícios x soluções
    ex = re.findall(r"^\*\*(\d+\.\d+)\*\*", t, re.M)
    so = re.findall(r"^::: solucao (\d+\.\d+)", t, re.M)
    if ex != so: probs.append(f"cap {n}: exercícios {len(ex)} x soluções {len(so)}; diferença: {set(ex) ^ set(so)}")
    # saídas: arquivos .out sem include? (informativo)
# referências cruzadas
for n, t in texto_cap.items():
    for tipo, rot in (("definicao", "Definição"), ("teo", "Proposição|Teorema|Corolário"), ("exemplo", "Exemplo")):
        for m in re.finditer(rf"(?:{rot}) (\d+\.\d+)", t):
            ref = m.group(1)
            alvo = defs[tipo] if tipo != "teo" else defs["teo"]
            if ref not in alvo and not re.search(rf"(?:{rot}) {re.escape(ref)}\s*[·:]", t[m.start():m.start() + 40]):
                # pode ser teorema referido como Definição etc.: só avisa se não existe em nenhum conjunto
                if ref not in defs["definicao"] | defs["teo"] | defs["exemplo"]:
                    probs.append(f"cap {n}: referência a '{m.group(0)}' sem alvo")
    for m in re.finditer(r"[Ss]eç(?:ão|ões) (\d+\.\d+)", t):
        if m.group(1) not in heads: probs.append(f"cap {n}: referência à seção {m.group(1)} inexistente")
    for m in re.finditer(r"Figura (\d+\.\d+)", t):
        ok = any(re.search(rf"<b>Figura {re.escape(m.group(1))}\.</b>", tx) for tx in texto_cap.values())
        if not ok: probs.append(f"cap {n}: referência à Figura {m.group(1)} sem legenda")
print(f"{len(texto_cap)} capítulos verificados; {len(probs)} problema(s)")
for p in probs: print(" -", p)
