#!/usr/bin/env python3
"""Gera src/94-indice.md (índice remissivo) a partir do glossário e de termos extras,
procurando cada termo nas seções (h2) dos capítulos e ligando às âncoras #<prefixo>-<n>."""
import re, json, os, unicodedata, sys
os.chdir(os.path.join(os.path.dirname(__file__), '..', 'src'))
d = json.load(open('livro.json'))
EXCLUI = re.compile(r'^(Soluções|Exercícios|Referências|Resumo do capítulo)')

def limpa(t):
    t = re.sub(r'```.*?```', ' ', t, flags=re.S)
    t = re.sub(r'^(<<<|>>>|\+\+\+) \S+$', ' ', t, flags=re.M)
    t = re.sub(r'<svg.*?</svg>', ' ', t, flags=re.S)
    t = t.replace(r'\text{pass}', ' pass@k ')
    t = re.sub(r'\$\$.*?\$\$', ' ', t, flags=re.S)
    t = re.sub(r'\$[^$\n]+\$', ' ', t)
    t = re.sub(r'<[^>]+>', ' ', t)
    return t.replace('`', ' ').replace('*', '')

secoes = []   # (cap, n2, rotulo, titulo, texto)
for v in d['vistas']:
    if not v['id'].startswith('cap-'): continue
    txt = '\n'.join(open(f).read() for f in v['arquivos'])
    partes = re.split(r'^## ', txt, flags=re.M)
    for i, p in enumerate(partes[1:], 1):
        tit, _, corpo = p.partition('\n')
        if EXCLUI.match(re.sub(r'^[\d.]+ ', '', tit)): continue
        m = re.match(r'^([\d.]+) (.*)', tit)
        rot = m.group(1) if m else f'{v["num"]}.{i}'
        secoes.append((v['num'], v['prefixo'], i, rot, tit, corpo))

# --- termos: glossário + extras
termos = {}   # nome -> lista de aliases
for ln in open('91-glossario.md'):
    m = re.match(r'- \*\*(.+?)\*{2,3}\s*(?:\((.*?)\))?\.', ln)
    if not m: continue
    nome = m.group(1).rstrip('.').strip().replace('*', ''); par = m.group(2) or ''
    if nome in ('Custo',): continue
    al = [nome]
    if ', ' in nome and nome.endswith(' de'):  # "Bayes, Teorema de"
        a, b = nome.split(', ', 1); al = [f'{b} {a}']
    nome_exib = al[0]
    for x in par.split(','):
        x = x.replace('*', '').strip()
        if x and len(x) > 2 and not x.startswith('Ver'): al.append(x)
    termos[nome_exib] = al

EXTRAS = {
 'Árvore de decisão': ['árvore de decisão', 'árvores de decisão'], 'Poda de árvores': ['poda'],
 'Impureza de Gini': ['Gini'], 'Mínimos quadrados': ['mínimos quadrados'], 'p-valor': ['p-valor', 'p-valores'],
 'Razão de chances': ['razão de chances', 'odds ratio'], 'Curva ROC': ['curva ROC'],
 'Dilema viés–variância': ['viés e variância', 'viés–variância', 'viés-variância'],
 'Agrupamento (*clustering*)': ['agrupamento', 'clustering'], 'PCA': ['PCA', 'componentes principais'],
 'Aprendizado por reforço': ['aprendizado por reforço'], 'Aprendizado não supervisionado': ['não supervisionado'],
 'Tokenização': ['tokenização', 'tokenizador'], 'WordPiece': ['WordPiece'], 'SentencePiece': ['SentencePiece'],
 'Cadeia de pensamento': ['cadeia de pensamento', 'chain-of-thought'], 'Janela de contexto': ['janela de contexto'],
 'Cache de chaves e valores': ['cache de chaves', 'KV cache'], 'Codificação posicional': ['codificação posicional'],
 'GELU': ['GELU'], 'GRU': ['GRU'], 'Recorte de gradiente': ['recorte de gradiente', 'gradient clipping'],
 'Aumento de dados': ['aumento de dados', 'data augmentation'], 'Campo receptivo': ['campo receptivo'],
 'ResNet': ['ResNet'], 'Adaptador': ['adaptadores', 'adaptador'], 'Normalização de camada': ['normalização de camada'],
 'Busca em feixe': ['busca em feixe', 'beam search'],
 'Previsão seletiva': ['previsão seletiva'], 'Saída estruturada': ['saída estruturada', 'saídas estruturadas'],
 'Pydantic': ['Pydantic'], 'JSON Schema': ['JSON Schema'], 'HNSW': ['HNSW'], 'FAISS': ['FAISS'],
 'Quantização de produto': ['quantização de produto'], 'Distância euclidiana': ['distância euclidiana'],
 'Recuperação híbrida': ['híbrida', 'recuperação híbrida'], 'LlamaIndex': ['LlamaIndex'], 'LangChain': ['LangChain'],
 'LangGraph': ['LangGraph'], 'Super-passo (Pregel)': ['super-passo', 'Pregel'], 'Subgrafo': ['subgrafo', 'subgrafos'],
 'Supervisor': ['supervisor'], 'Sistema multiagente': ['multiagente'], 'Chave de idempotência': ['chave de idempotência'],
 'Backoff exponencial': ['backoff'], 'Latência de cauda': ['latência de cauda', 'cauda'], 'Orçamento de *tokens*': ['orçamento de tokens', 'orçamento diário'],
 'Model card': ['model card', 'model cards'], 'Datasheet': ['datasheet'], 'LGPD': ['LGPD'], 'NIST': ['NIST'],
 'Viés de posição (juiz LLM)': ['viés de posição'], 'LLM como juiz': ['LLM-juiz', 'LLM como juiz', 'juiz por LLM', 'LLM-as-a-judge'],
 'Mistura (*ensemble*)': ['ensemble', 'floresta aleatória'],
 'Vazamento de dados': ['vazamento'], 'Teorema da aproximação universal': ['aproximação universal'],
 'Perplexidade': ['perplexidade'], 'Máscara causal': ['máscara causal'], 'BERT': ['BERT'], 'GPT': ['GPT'],
 'T5 e BART': ['T5', 'BART'], 'Hugging Face': ['Hugging Face'], 'Trainer': ['Trainer'], 'Tracing (rastreamento)': ['rastreamento', 'tracing'],
 'Estado compartilhado': ['estado compartilhado'], 'Plan-and-Solve': ['Plan-and-Solve'], 'Registro de ferramentas': ['registro de ferramentas'], 'Lista de permissões': ['lista de permissões'],
 'Abstenção': ['abstenção', 'abster'],
 'Citação de fontes': ['citações', 'citação'], 'Reranker': ['reranker', 'reranking'],
 'Agente baseado em utilidade': ['baseado em utilidade', 'baseados na utilidade'], 'Agente reativo simples': ['reativo simples', 'reativos simples'],
 'Ambiente de tarefa': ['ambiente de tarefa', 'ambientes de tarefa'], 'Medida de desempenho': ['medida de desempenho'],
}
OVER = {
 'Autovalor e autovetor': ['autovalor', 'autovetor', 'autovalores', 'autovetores'],
 'Gradiente, dissipação e explosão': None,
 'Vector store': ['vector store', 'banco vetorial', 'bancos vetoriais', 'armazenamento vetorial'],
 'Injeção de prompt': ['injeção de prompt', 'injeção indireta', 'prompt injection', 'injeção de instruções', 'injeção', 'injeções'],
}
for k in list(termos):
    if k in OVER and OVER[k]: termos[k] = OVER[k]
if 'Gradiente, dissipação e explosão' in termos:
    del termos['Gradiente, dissipação e explosão']
    termos['Dissipação e explosão do gradiente'] = ['dissipação do gradiente', 'explosão do gradiente', 'dissipação e explosão', 'vanishing gradient', 'gradiente dissipado', 'gradientes dissipados', 'dissipação']
for k, v in EXTRAS.items():
    nome = k.replace('*', '')
    termos.setdefault(nome, [])
    for a in v:
        if a not in termos[nome]: termos[nome].append(a)

def norm(s):
    return unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().lower()

def padrao(a):
    n = re.escape(norm(a)).replace(r'\ ', r'\s+').replace(r'\-', r'[-\s]?')
    return re.compile(r'(?<![a-z0-9])' + n + r'(?:s|es)?(?![a-z0-9])')

sec_norm = [(s, norm(limpa(s[5]))) for s in secoes]
sec_tit = [norm(s[4]) for s in secoes]
saida = {}; sem = []
for nome, aliases in termos.items():
    pats = [padrao(a) for a in aliases]
    pont = []; raros = []
    for idx, (s, corpo) in enumerate(sec_norm):
        c = sum(len(p.findall(corpo)) for p in pats)
        h = any(p.search(sec_tit[idx]) for p in pats)
        # ocorrências de definição: **termo** ou *termo* no texto original
        orig = norm(s[5])
        e = 0
        for a in aliases:
            na = re.escape(norm(a)).replace(r'\ ', r'\s+')
            e += len(re.findall(r'\*{1,3}' + na + r'(?:s|es)?\*{1,3}', orig))
        score = 4 * h + 3 * min(e, 2) + c
        if score >= 2: pont.append((score, s))
        elif score >= 1: raros.append((score, s))
    if not pont and raros: pont = raros[:2]
    if not pont: sem.append(nome); continue
    pont.sort(key=lambda t: -t[0])
    top = sorted(pont[:6], key=lambda t: (t[1][0], t[1][2]))
    saida[nome] = [(s[3], f'{s[1]}-{s[2]}') for _, s in top]

def chave(n): return norm(re.sub(r'[^\w ]', '', n))
letras = {}
for nome in sorted(saida, key=chave):
    L = chave(nome)[:1].upper() or '#'
    letras.setdefault(L, []).append(nome)

out = ['''Cada entrada lista as **seções** em que o termo é definido ou discutido de forma relevante, com ligação direta. O índice foi **gerado por programa** a partir do glossário e de uma lista de termos adicionais, pontuando cada seção pela frequência do termo, por ele aparecer no título e por aparecer em destaque (negrito ou itálico); mostra no máximo seis seções por termo e ignora exercícios, soluções, resumos e referências. Um termo que não aparece aqui pode ainda estar no texto: use a busca do navegador.
''']
for L in sorted(letras):
    out.append(f'\n## {L}\n')
    for nome in letras[L]:
        links = ', '.join(f'[{rot}](#{anc})' for rot, anc in saida[nome])
        out.append(f'- **{nome}**: {links}')
open('94-indice.md', 'w').write('\n'.join(out) + '\n')
print(len(saida), 'termos indexados;', len(sem), 'sem ocorrência suficiente')
if '-v' in sys.argv: print('SEM:', '; '.join(sem))
