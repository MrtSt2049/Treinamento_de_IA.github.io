#!/usr/bin/env python3
"""Reexecuta cada programa de src/codigo (em uma cópia) e compara a saída com o .out salvo."""
import subprocess, glob, os, json, sys, time
raiz = sys.argv[1]
res = json.load(open('/tmp/reexec.json')) if os.path.exists('/tmp/reexec.json') and '--retoma' in sys.argv else {}
LIM = int(os.environ.get('LIMITE', '900'))
for py in sorted(glob.glob(f'{raiz}/codigo/*.py')):
    nome = os.path.basename(py)[:-3]
    if nome in res and res[nome].startswith(('igual', 'sem .out')): continue
    out = py[:-3] + '.out'
    if not os.path.exists(out): res[nome] = 'sem .out'; continue
    t0 = time.time()
    try:
        r = subprocess.run([sys.executable, py], cwd=os.path.dirname(py), capture_output=True, text=True, timeout=LIM)
        novo = r.stdout.rstrip(); velho = open(out).read().rstrip()
        res[nome] = ('igual' if novo == velho else ('diferente' if r.returncode == 0 else f'erro {r.returncode}')) + f' ({time.time()-t0:.0f}s)'
    except subprocess.TimeoutExpired:
        res[nome] = f'timeout (>{LIM}s)'
    json.dump(res, open('/tmp/reexec.json', 'w'), indent=1, ensure_ascii=False)
print('fim')
